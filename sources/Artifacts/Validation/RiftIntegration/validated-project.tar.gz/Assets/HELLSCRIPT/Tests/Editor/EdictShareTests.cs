using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace Hellscript.Tests
{
    public sealed class EdictShareTests
    {
        string directory,path;
        GameCatalog catalog;
        GameStore store;
        static string Json(object value)=>JsonUtility.ToJson(value);
        [SetUp] public void Setup()
        {
            directory=Path.Combine(Path.GetTempPath(),"hellscript-edict-share-"+Guid.NewGuid().ToString("N"));
            path=Path.Combine(directory,"hellscript-local-v1.json");
            catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();store=new GameStore(directory,catalog);
        }
        [TearDown] public void Teardown()
        {UnityEngine.Object.DestroyImmediate(catalog);if(Directory.Exists(directory))Directory.Delete(directory,true);}

        [Test]
        public void ACodeMadeFromTheStoredDocumentDecodesBackToIt()
        {
            var hero=store.Data.Hero;
            string code=HuntEdictV2Codec.Encode(hero.edict);
            StringAssert.StartsWith("HED2.",code);
            var decoded=HuntEdictV2Codec.Decode(code);
            Assert.AreEqual(Json(HuntEdictV2.Canonical(hero.edict)),Json(decoded));
            Assert.IsEmpty(HuntEdictV2Diff.Describe(hero.edict,decoded));
        }

        [Test]
        public void TheDifferenceListNamesEveryChangedValueAndNothingElse()
        {
            var hero=store.Data.Hero;var incoming=hero.edict.Copy();
            incoming.global.Single(o=>o.id=="survival.lowHp").value="ON";
            string skill=hero.edict.slots.First(s=>s!="");
            string before=HuntEdictV2.Value(hero.edict,skill,1);
            incoming=HuntEdictV2.WithOption(incoming,skill,1,before=="ON"?"OFF":"ON");
            var changes=HuntEdictV2Diff.Describe(hero.edict,incoming);
            Assert.AreEqual(2,changes.Count,string.Join(" / ",changes.Select(c=>c.ToString())));
            Assert.IsTrue(changes.Any(c=>c.group=="전역 설정"&&c.incoming=="ON"));
            Assert.IsTrue(changes.Any(c=>c.group==skill));
            Assert.IsEmpty(HuntEdictV2Diff.Describe(hero.edict,hero.edict.Copy()));
        }

        [Test]
        public void ImportingACodeWritesTheDocumentToDiskBeforeApplyingIt()
        {
            var hero=store.Data.Hero;hero.level=30;
            hero.edict=HuntEdictV2Storage.CreateForHero(hero);
            var incoming=hero.edict.Copy();
            incoming.global.Single(o=>o.id=="survival.lowHp").value="ON";
            string code=HuntEdictV2Codec.Encode(incoming);
            var preview=HuntEdictV2Import.Prepare(code,hero,catalog);
            Assert.IsFalse(preview.Partial,"a level 30 hero has every slot unlocked");
            Assert.IsTrue(store.SaveHeroEdict(hero.id,preview.Draft,catalog),store.Error);
            Assert.AreEqual("ON",hero.edict.global.Single(o=>o.id=="survival.lowHp").value);
            var reopened=new GameStore(directory,catalog);
            Assert.AreEqual("ON",reopened.Data.Hero.edict.global.Single(o=>o.id=="survival.lowHp").value);
        }

        [Test]
        public void AFailedWriteLeavesTheHeroFightingExactlyAsBefore()
        {
            var hero=store.Data.Hero;var incoming=hero.edict.Copy();
            incoming.global.Single(o=>o.id=="survival.lowHp").value="ON";
            string before=Json(hero.edict),disk=File.ReadAllText(path);
            // A directory where the temp file belongs makes the atomic write fail.
            Directory.CreateDirectory(path+".tmp");LogAssert.Expect(LogType.Error,new Regex("저장하지 못했습니다:"));
            Assert.IsFalse(store.SaveHeroEdict(hero.id,incoming,catalog));
            Assert.AreEqual(before,Json(hero.edict),"the in-memory document is untouched");
            Assert.AreEqual(disk,File.ReadAllText(path),"the saved file is untouched");
            Directory.Delete(path+".tmp");
            Assert.IsTrue(store.SaveHeroEdict(hero.id,incoming,catalog),store.Error);
        }

        [Test]
        public void ACodeFromAnotherClassIsRefusedWithAReason()
        {
            var hero=store.Data.Hero;
            string code=HuntEdictV2Codec.Encode(HuntEdictV2.Create(hero.heroClass==HeroClass.Warrior?HeroClass.Mage:HeroClass.Warrior));
            var error=Assert.Throws<ArgumentException>(()=>HuntEdictV2Import.Prepare(code,hero,catalog));
            StringAssert.Contains("직업",error.Message);
        }

        [TestCase("")]
        [TestCase("hello")]
        [TestCase("HED2.notbase64!.0000")]
        public void ADamagedCodeIsReportedInsteadOfThrowingAtTheCaller(string code)
        {
            Assert.IsFalse(HuntEdictV2Codec.TryDecode(code,out var document,out string error));
            Assert.IsNull(document);Assert.IsNotEmpty(error);
        }

        [Test]
        public void ATamperedCodeFailsItsChecksum()
        {
            string code=HuntEdictV2Codec.Encode(store.Data.Hero.edict);
            var parts=code.Split('.');
            string flipped=parts[1].Substring(0,parts[1].Length-1)+(parts[1].EndsWith("A")?"B":"A");
            Assert.IsFalse(HuntEdictV2Codec.TryDecode(parts[0]+"."+flipped+"."+parts[2],out _,out string error));
            Assert.IsNotEmpty(error);
        }

        [Test]
        public void ALockedSkillIsClearedFromTheSlotsAndReported()
        {
            var hero=store.Data.Hero;
            var late=catalog.skills.First(s=>s.heroClass==hero.heroClass&&s.unlock>1);
            var incoming=HuntEdictV2.Create(hero.heroClass);
            var slots=incoming.slots.ToArray();slots[0]=late.id;incoming.slots=slots;
            string code=HuntEdictV2Codec.Encode(incoming);
            hero.level=1;
            var preview=HuntEdictV2Import.Prepare(code,hero,catalog);
            Assert.IsTrue(preview.Partial);
            Assert.AreEqual(0,preview.MissingSkills[0].slot);
            Assert.AreEqual(late.unlock,preview.MissingSkills[0].requiredLevel);
            Assert.AreEqual("",preview.Draft.slots[0],"the locked skill is not carried into the draft");
            Assert.IsTrue(store.SaveHeroEdict(hero.id,preview.Draft,catalog),store.Error);
        }

        [Test]
        public void TheSwitchIsPersistedAndRefusedWhenNoDocumentExists()
        {
            var hero=store.Data.Hero;
            Assert.IsFalse(hero.useEdict);
            Assert.IsTrue(store.SetHeroEdictEnabled(hero.id,true,catalog),store.Error);
            Assert.IsTrue(hero.useEdict);
            Assert.IsTrue(new GameStore(directory,catalog).Data.Hero.useEdict);
            hero.edict=null;
            Assert.IsFalse(store.SetHeroEdictEnabled(hero.id,false,catalog));
            StringAssert.Contains("원본이 없습니다",store.Error);
        }
    }
}
