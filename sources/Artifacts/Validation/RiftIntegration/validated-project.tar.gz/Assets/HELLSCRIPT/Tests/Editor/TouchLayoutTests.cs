using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class TouchLayoutTests
    {
        [Test] public void TheAuthoredMinimumClearsFortyEightDpOnTheReferencePhone()
        {
            Assert.AreEqual(75.2f, TouchLayout.UnitsFor(TouchLayout.MinimumDp), .1f);
            Assert.GreaterOrEqual(TouchLayout.AuthoredMinimum, TouchLayout.UnitsFor(TouchLayout.MinimumDp));
            Assert.AreEqual(TouchLayout.AuthoredMinimum, TouchLayout.ScaledMinimum());
            Assert.AreEqual(TouchLayout.MinimumDp, TouchLayout.ConstantMinimum());
        }
        [Test] public void TheSameControlIsSmallerOnASmallPhoneAndTheReadingSizeLiftsItBack()
        {
            Assert.AreEqual(51f, TouchLayout.DpFor(TouchLayout.AuthoredMinimum), .5f);
            Assert.AreEqual(40f, TouchLayout.DpFor(TouchLayout.AuthoredMinimum, 720f, 360f), .5f);
            Assert.Less(TouchLayout.DpFor(TouchLayout.AuthoredMinimum, 720f, 360f), TouchLayout.MinimumDp);
            Assert.GreaterOrEqual(TouchLayout.DpFor(TouchLayout.AuthoredMinimum, 720f / 1.3f, 360f), TouchLayout.MinimumDp);
            Assert.GreaterOrEqual(TouchLayout.DpFor(TouchLayout.AuthoredMinimum, 720f / 1.4f, 360f), TouchLayout.MinimumDp);
        }
        [Test] public void UnitsAndDpConvertBackToEachOther()
        {
            foreach (float dp in new[] { 24f, 48f, 90f })
                Assert.AreEqual(dp, TouchLayout.DpFor(TouchLayout.UnitsFor(dp)), .001f);
        }
        [Test] public void DegenerateInputsStayPositiveAndNeverDivideByZero()
        {
            Assert.AreEqual(0f, TouchLayout.UnitsFor(-5));
            Assert.Greater(TouchLayout.UnitsFor(48, 0, 0), 0);
            Assert.Greater(TouchLayout.DpFor(48, -10, -10), 0);
        }
        [Test] public void BothSidesOfAControlMustReachTheMinimum()
        {
            Assert.IsTrue(TouchLayout.Meets(new Vector2(80, 80), 80));
            Assert.IsTrue(TouchLayout.Meets(new Vector2(300, 80), 80));
            Assert.IsFalse(TouchLayout.Meets(new Vector2(300, 68), 80));
            Assert.IsFalse(TouchLayout.Meets(new Vector2(64, 300), 80));
        }
        [Test] public void AControlIsInsideOnlyWhenEveryEdgeIsWithinTolerance()
        {
            var container = new Rect(0, 0, 600, 400);
            Assert.IsTrue(TouchLayout.Inside(new Rect(10, 10, 100, 50), container));
            Assert.IsTrue(TouchLayout.Inside(new Rect(0, 0, 600, 400), container));
            Assert.IsFalse(TouchLayout.Inside(new Rect(560, 10, 100, 50), container));
            Assert.IsFalse(TouchLayout.Inside(new Rect(-20, 10, 100, 50), container));
            Assert.IsFalse(TouchLayout.Inside(new Rect(10, 380, 100, 50), container));
        }
        [Test] public void SafeAreaInsetsAreTrimmedToTheDisplayAndNeverCollapse()
        {
            Assert.AreEqual(new Rect(0, 0, 1080, 2400), UiSafeArea.Inset(1080, 2400, Vector4.zero));
            Assert.AreEqual(new Rect(0, 60, 1080, 2210), UiSafeArea.Inset(1080, 2400, new Vector4(0, 60, 0, 130)));
            var absurd = UiSafeArea.Inset(1080, 2400, new Vector4(9000, 9000, 9000, 9000));
            Assert.AreEqual(432f, absurd.x, .01f); Assert.Greater(absurd.width, 0); Assert.Greater(absurd.height, 0);
        }
    }
}
