using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class EdictLootIntegrationTests
    {
        GameCatalog catalog;
        uint random=61493;
        [SetUp] public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown] public void Teardown()=>Object.DestroyImmediate(catalog);
        CombatSimulation Fixture(params (string id,string value)[] changes)
        {
            var account=GameStore.NewAccount(catalog);var hero=account.Hero;hero.level=30;
            hero.build=BehaviorPresets.ForLevel(HeroClass.Warrior,0,30,catalog);
            hero.edict=HuntEdictV2Storage.CreateForHero(hero);hero.useEdict=true;
            hero.edict=HuntEdictV2Editing.WithGlobal(hero.edict,"loot.slots","WEAPON,HEAD,CHEST,HANDS,FEET,WAIST,AMULET,RING");
            foreach(var change in changes)hero.edict=HuntEdictV2Editing.WithGlobal(hero.edict,change.id,change.value);
            var sim=new CombatSimulation(account,catalog,1,0,seed:17);
            // A known, open room keeps this test about collection, not randomized navigation.
            sim.State.training=-1;sim.State.enemies.Clear();sim.State.position=RiftMap.Rooms[0];
            foreach(var rule in sim.State.build.rules)rule.enabled=false;
            Assert.IsTrue(sim.EdictActive);Assert.IsTrue(sim.Map.Walkable(sim.State.position));return sim;
        }
        DropState Drop(CombatSimulation sim,int rarity=2,string unique=null,int slot=0,int level=30,float distance=0)
        {
            var item=ItemGenerator.Create(HeroClass.Warrior,slot,rarity,level,ref random,uniqueId:unique);
            var drop=new DropState{id=sim.State.nextId++,position=sim.State.position+Vector2.right*distance,item=item,discovered=true};
            Assert.IsTrue(sim.Map.LineClear(sim.State.position,drop.position));sim.State.drops.Add(drop);return drop;
        }
        static EnemyState Threat(CombatSimulation sim)
        {
            var enemy=new EnemyState{id=sim.State.nextId++,position=sim.State.position+Vector2.up*2,health=10000,maxHealth=10000,speed=0,attack=0,cooldown=1000};
            sim.State.enemies.Add(enemy);return enemy;
        }
        static void Tick(CombatSimulation sim)=>sim.Tick(CombatSimulation.Step);
        static bool HasLootGoal(CombatSimulation sim)
        {
            var condition=BehaviorRules.C("SC18",Comparison.Present);
            Assert.IsEmpty(BehaviorRules.ValidateCondition(condition));
            return sim.EvaluateCondition(condition,new Rule(-1),null,out _);
        }

        [Test]
        public void AnIgnoredHigherGradeIsNotCollectedThroughALowerGradeThreshold()
        {
            var sim=Fixture(("loot.MAGIC","PASSING"),("loot.RARE","IGNORE"));
            var magic=Drop(sim,1);var rare=Drop(sim);Tick(sim);
            Assert.IsTrue(magic.claimed);Assert.IsFalse(rare.claimed);Assert.IsTrue(rare.ignored);
            Assert.IsFalse(sim.Hero.inventory.Any(i=>i.id==rare.item.id));
        }
        [TestCase(true)] [TestCase(false)]
        public void SetAndOrdinaryLegendaryUseTheirOwnCollectionRows(bool takeSet)
        {
            var sim=Fixture(("loot.SET",takeSet?"PASSING":"IGNORE"),("loot.LEGENDARY",takeSet?"IGNORE":"PASSING"));
            var set=Drop(sim,3,"SW1",1);var legendary=Drop(sim,3,"LW01");Tick(sim);
            Assert.AreEqual(takeSet,set.claimed);Assert.AreEqual(!takeSet,legendary.claimed);
        }
        [Test]
        public void AfterCombatWaitsWithoutDiscardingTheDropThenCollectsWhenSafe()
        {
            var sim=Fixture(("loot.RARE","AFTER_COMBAT"));var drop=Drop(sim);var enemy=Threat(sim);
            Tick(sim);Assert.IsFalse(drop.claimed);Assert.IsFalse(drop.ignored);
            enemy.dead=true;Tick(sim);Assert.IsTrue(drop.claimed);
        }
        [Test]
        public void AnAbsentPriorityGradeDoesNotPromoteAnAfterCombatDrop()
        {
            var sim=Fixture(("loot.RARE","AFTER_COMBAT"),("loot.LEGENDARY","PRIORITY"));
            Drop(sim,distance:4);Threat(sim);Assert.IsFalse(HasLootGoal(sim));
        }
        [Test]
        public void PassingCollectionDoesNotCreateADetour()
        {
            var sim=Fixture(("loot.RARE","PASSING"));Drop(sim,distance:4);Assert.IsFalse(HasLootGoal(sim));
        }
        [Test]
        public void MinimumLevelAndSlotFiltersApplyBeforeAddingAnItem()
        {
            var sim=Fixture(("loot.RARE","PASSING"),("loot.slots","HEAD"),("loot.itemLevel","20"));
            var wrongSlot=Drop(sim,slot:0);var lowLevel=Drop(sim,slot:1,level:10);var valid=Drop(sim,slot:1);
            Tick(sim);Assert.IsFalse(wrongSlot.claimed);Assert.IsFalse(lowLevel.claimed);Assert.IsTrue(valid.claimed);
        }
        [Test]
        public void LegendaryFilterExceptionNeverOverridesItsIgnoreChoice()
        {
            var sim=Fixture(("loot.LEGENDARY","IGNORE"),("loot.exceptLegendary","ON"),("loot.slots","HEAD"));
            var drop=Drop(sim,3,"LW01");Tick(sim);Assert.IsFalse(drop.claimed);Assert.IsTrue(drop.ignored);
        }
        [Test]
        public void PursuitUsesTheConfiguredPathDistance()
        {
            var sim=Fixture(("loot.RARE","PRIORITY"),("loot.distance","2"));Drop(sim,distance:5);
            Assert.IsFalse(HasLootGoal(sim));
        }
        [Test]
        public void LeavingLootAtCompletionDoesNotRunAutomaticCollection()
        {
            var sim=Fixture(("loot.RARE","PRIORITY"),("loot.finish","LEAVE"));var drop=Drop(sim);
            sim.State.phase=RunPhase.Looting;Tick(sim);
            Assert.IsFalse(drop.claimed);Assert.IsTrue(drop.ignored);Assert.AreEqual(RunPhase.Cleared,sim.State.phase);
        }
        [Test]
        public void PriorityActuallyMovesDuringCombatDespiteTheLegacyNoEnemyCondition()
        {
            var sim=Fixture(("loot.RARE","PRIORITY"));var drop=Drop(sim,distance:5);Threat(sim);
            var rule=sim.State.build.rules.Single(r=>r.action==RuleAction.Loot);rule.enabled=true;
            Assert.IsTrue(rule.groups.Any(g=>g.conditions.Any(c=>c.id=="SC17")));
            Assert.IsTrue(HasLootGoal(sim));Vector2 start=sim.State.position;Tick(sim);
            Assert.AreEqual(RuleAction.Loot,sim.State.movementAction);Assert.AreEqual(drop.id,sim.State.movementDrop);
            Assert.Less(Vector2.Distance(sim.State.position,drop.position),Vector2.Distance(start,drop.position));
        }
        [Test]
        public void WaitingForDangerChecksTheRouteBetweenHeroAndDrop()
        {
            var sim=Fixture(("loot.RARE","PRIORITY"),("loot.danger","WAIT"));Drop(sim,distance:5);
            Assert.IsTrue(HasLootGoal(sim));
            sim.State.effects.Add(new GroundEffect{position=sim.State.position+Vector2.right*2.5f,radius=1,hostile=true,duration=10,delay=0});
            Assert.IsFalse(HasLootGoal(sim));sim.State.effects.Clear();Assert.IsTrue(HasLootGoal(sim));
        }
        [Test]
        public void CurrentClassIncludesCommonGearAndExcludesAnotherClassesWeapon()
        {
            var sim=Fixture(("loot.class","OWN"),("loot.RARE","PASSING"));var common=Drop(sim,slot:1);var other=Drop(sim);
            other.item=ItemGenerator.Create(HeroClass.Mage,0,2,30,ref random);
            Tick(sim);Assert.IsTrue(common.claimed);Assert.IsFalse(other.claimed);
        }
        [Test]
        public void AFilterExceptionAllowsAnOtherwiseExcludedLegendary()
        {
            var sim=Fixture(("loot.LEGENDARY","PASSING"),("loot.exceptLegendary","ON"),("loot.slots","HEAD"),("loot.itemLevel","60"));
            var drop=Drop(sim,3,"LW01");Tick(sim);Assert.IsTrue(drop.claimed);
        }
        [Test]
        public void RefreshingOrDisablingTheEdictReplacesItsCompiledLootPolicy()
        {
            var sim=Fixture(("loot.RARE","IGNORE"));var item=Drop(sim,distance:5);
            Assert.IsFalse(HasLootGoal(sim));sim.Hero.edict=HuntEdictV2Editing.WithGlobal(sim.Hero.edict,"loot.RARE","PRIORITY");
            Assert.IsFalse(HasLootGoal(sim));sim.RefreshEdict();Assert.IsTrue(HasLootGoal(sim));
            sim.Hero.useEdict=false;sim.RefreshEdict();sim.State.build.minimumRarity=3;sim.State.build.pursueRarity=3;
            Assert.IsFalse(HasLootGoal(sim));Assert.IsFalse(item.ignored);
        }
        [Test]
        public void AnExplicitlyEmptySlotSelectionCollectsNothing()
        {
            var sim=Fixture(("loot.RARE","PASSING"),("loot.slots",""));var item=Drop(sim);
            Tick(sim);Assert.IsFalse(item.claimed);Assert.IsTrue(item.ignored);
        }
        [Test]
        public void NewDocumentsSelectAllSlotsWithoutRewritingAnExistingEmptySelection()
        {
            var hero=GameStore.NewAccount(catalog).Hero;
            Assert.AreEqual("WEAPON,HEAD,CHEST,HANDS,FEET,WAIST,AMULET,RING",hero.edict.global.Single(o=>o.id=="loot.slots").value);
            var empty=HuntEdictV2Editing.WithGlobal(hero.edict,"loot.slots","");
            Assert.IsEmpty(HuntEdictV2.Canonical(empty).global.Single(o=>o.id=="loot.slots").value);
        }
    }
}
