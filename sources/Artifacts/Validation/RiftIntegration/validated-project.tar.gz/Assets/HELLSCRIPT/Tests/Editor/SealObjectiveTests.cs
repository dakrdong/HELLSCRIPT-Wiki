using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class SealObjectiveTests
    {
        GameCatalog catalog;
        [SetUp]public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown]public void Teardown(){UnityEngine.Object.DestroyImmediate(catalog);}
        AccountSave Account(int hero=0,int level=30)
        {var a=GameStore.NewAccount(catalog);a.selectedHero=hero;a.Hero.level=level;a.Hero.build=BehaviorPresets.ForLevel((HeroClass)hero,0,level,catalog);return a;}
        static int Meter(RiftLayout map,int room)
            =>map.spawns.Count(s=>s.room==room&&s.elite<0)+map.spawns.Count(s=>s.room==room&&s.elite>=0)*5;

        [Test]
        public void SealsAppearFromTierFiveAndNeverBelowIt()
        {
            for(uint seed=1;seed<=12;seed++)
            {
                var early=RiftGenerator.Generate(seed,"early",RiftGenerator.ObjectiveFirstStage-1,HeroClass.Warrior);
                Assert.AreEqual(RiftObjectiveKind.None,early.objective);Assert.IsEmpty(early.seals);Assert.IsFalse(early.gateOpen);
                var late=RiftGenerator.Generate(seed,"late",RiftGenerator.ObjectiveFirstStage,HeroClass.Warrior,forcedObjective:RiftObjectiveKind.Seals);
                Assert.AreEqual(RiftObjectiveKind.Seals,late.objective);Assert.AreEqual(RiftGenerator.ObjectiveSeals,late.seals.Count);Assert.IsFalse(late.gateOpen);
            }
        }
        [Test]
        public void SealsSitInFightingRoomsAndKeepTheObjectivePathHeavy()
        {
            for(uint seed=1;seed<=24;seed++)
            {
                var map=RiftGenerator.Generate(seed,"seals",10,HeroClass.Mage,"",-1,(int)(seed%2),6+(int)(seed%3),forcedObjective:RiftObjectiveKind.Seals);
                var nav=new RiftNavigation(map);
                Assert.AreEqual(RiftGenerator.ObjectiveSeals,map.seals.Select(s=>s.room).Distinct().Count());
                foreach(var seal in map.seals)
                {
                    var role=map.rooms[seal.room].role;
                    Assert.IsTrue(role==RiftRoomRole.Passage||role==RiftRoomRole.Crossroad||role==RiftRoomRole.Wing,"A seal must not sit in the entrance, the antechamber or the arena.");
                    Assert.IsTrue(nav.Reachable(seal.position));Assert.IsNotEmpty(seal.accessPoints);
                    foreach(var p in seal.accessPoints)Assert.IsTrue(nav.Reachable(p));
                    Assert.IsFalse(map.chests.Any(c=>c.room==seal.room&&Vector2.Distance(c.position,seal.position)<3));
                    Assert.AreEqual(SealPhase.Locked,seal.phase);
                }
                int ante=map.rooms.First(r=>r.role==RiftRoomRole.Antechamber).index;
                int path=map.seals.Select(s=>s.room).Concat(new[]{ante}).Distinct().Sum(room=>Meter(map,room));
                Assert.GreaterOrEqual(path,RiftGenerator.ObjectivePathMeter,"Following the objective must still mean fighting.");
            }
        }
        [Test]
        public void ASealStaysLockedWhileItsRoomStillFightsBack()
        {
            var sim=new CombatSimulation(Account(),catalog,10,seed:7,forcedObjective:RiftObjectiveKind.Seals);
            var seal=sim.State.layout.seals[0];
            sim.State.visited.Add(seal.room);
            for(int n=0;n<4;n++)sim.Tick(CombatSimulation.Step);
            Assert.AreEqual(SealPhase.Locked,seal.phase,"Guards alive means the seal is untouchable.");
            foreach(var e in sim.State.enemies.Where(e=>sim.State.layout.groups[e.group].room==seal.room))e.dead=true;
            for(int n=0;n<4;n++)sim.Tick(CombatSimulation.Step);
            Assert.AreNotEqual(SealPhase.Locked,seal.phase,"A cleared room exposes its seal.");
        }
        // A measurement, not a judgement: it prints which condition opens the gate in real runs.
        [Test]
        public void RecordWhichConditionOpensTheGate()
        {
            int seals=0,meter=0,unopened=0;
            for(uint seed=1;seed<=8;seed++)
            {
                var sim=new CombatSimulation(Account(),catalog,10,seed:seed,forcedObjective:RiftObjectiveKind.Seals);
                for(int n=0;n<6000&&!sim.State.layout.gateOpen&&sim.State.phase==RunPhase.Exploring&&sim.State.health>0;n++)sim.Tick(CombatSimulation.Step);
                if(!sim.State.layout.gateOpen)unopened++;
                else if(sim.State.layout.gateOpenedByMeter)meter++;
                else seals++;
                var detail=sim.State.layout.seals.Select(seal=>
                {
                    bool visited=sim.State.visited.Contains(seal.room);
                    bool guards=sim.State.enemies.Any(e=>!e.dead&&e.group==seal.guardGroup);
                    return $"{seal.phase}/visited={visited}/guards={guards}/progress={seal.progress:0.0}";
                });
                var wings=sim.State.layout.rooms.Where(r=>r.role==RiftRoomRole.Wing).ToList();
                Debug.Log($"WING_VISITS seed={seed} wings={wings.Count} visited={wings.Count(r=>sim.State.visited.Contains(r.index))}");
                Debug.Log($"SEAL_STATE seed={seed} time={sim.State.time:0} meter={sim.State.meter} visitedRooms={sim.State.visited.Count}/{sim.State.layout.rooms.Count} "+string.Join(" | ",detail));
            }
            Debug.Log($"GATE_OPENED_BY seals={seals} meter={meter} unopened={unopened} of 8");
            Assert.AreEqual(8,seals+meter+unopened);
        }
        [Test]
        public void TheBossWaitsForEverySealAndArrivesWhenTheGateOpens()
        {
            var sim=new CombatSimulation(Account(),catalog,10,seed:7,forcedObjective:RiftObjectiveKind.Seals);
            Assert.AreEqual(RiftObjectiveKind.Seals,sim.State.layout.objective);
            foreach(var e in sim.State.enemies)e.dead=true;
            sim.State.meter=0;
            for(int n=0;n<40;n++){foreach(var e in sim.State.enemies)e.dead=true;sim.State.meter=0;sim.Tick(CombatSimulation.Step);}
            Assert.IsFalse(sim.State.layout.gateOpen);
            Assert.AreEqual(RunPhase.Exploring,sim.State.phase,"An empty meter and unbroken seals keep the boss away.");
            Assert.IsFalse(sim.State.enemies.Any(e=>!e.dead&&e.boss));
            for(int index=0;index<sim.State.layout.seals.Count;index++)
            {
                var seal=sim.State.layout.seals[index];
                if(!sim.State.visited.Contains(seal.room))sim.State.visited.Add(seal.room);
                sim.State.exploration.sealId="";
                for(int n=0;n<400&&seal.phase!=SealPhase.Broken;n++)
                {
                    foreach(var e in sim.State.enemies)e.dead=true;sim.State.meter=0;
                    sim.State.position=seal.accessPoints[0];sim.Tick(CombatSimulation.Step);
                }
                Assert.AreEqual(SealPhase.Broken,seal.phase,"Seal "+index+" never broke.");
            }
            Assert.IsTrue(sim.State.layout.gateOpen,"Three broken seals open the gate.");
            Assert.IsFalse(sim.State.layout.gateOpenedByMeter,"The seals opened it, not the meter.");
            for(int n=0;n<20&&!sim.State.enemies.Any(e=>!e.dead&&e.boss);n++)sim.Tick(CombatSimulation.Step);
            Assert.IsTrue(sim.State.enemies.Any(e=>!e.dead&&e.boss),"The gate opening is what calls the boss.");
        }
        [Test]
        public void AFullMeterOpensTheGateWhenTheSealsAreOutOfReach()
        {
            var sim=new CombatSimulation(Account(),catalog,10,seed:7,forcedObjective:RiftObjectiveKind.Seals);
            Assert.AreEqual(RiftObjectiveKind.Seals,sim.State.layout.objective);
            foreach(var e in sim.State.enemies)e.dead=true;
            sim.State.meter=CombatSimulation.GateMeter;
            for(int n=0;n<8&&!sim.State.layout.gateOpen;n++)sim.Tick(CombatSimulation.Step);
            Assert.IsTrue(sim.State.layout.gateOpen,"The meter is the way that always works.");
            Assert.IsTrue(sim.State.layout.gateOpenedByMeter);
            Assert.Less(sim.State.layout.seals.Count(s=>s.phase==SealPhase.Broken),sim.State.layout.seals.Count);
            for(int n=0;n<20&&!sim.State.enemies.Any(e=>!e.dead&&e.boss);n++)sim.Tick(CombatSimulation.Step);
            Assert.IsTrue(sim.State.enemies.Any(e=>!e.dead&&e.boss));
        }
        [Test]
        public void BreakingASealCallsAnAnswerAndKeepsProgressThroughAnInterruption()
        {
            var sim=new CombatSimulation(Account(),catalog,10,seed:7,forcedObjective:RiftObjectiveKind.Seals);
            var seal=sim.State.layout.seals[0];
            sim.State.visited.Add(seal.room);
            foreach(var e in sim.State.enemies)e.dead=true;
            for(int n=0;n<6;n++){foreach(var e in sim.State.enemies)e.dead=true;sim.State.meter=0;sim.State.position=seal.accessPoints[0];sim.Tick(CombatSimulation.Step);}
            Assert.AreEqual(SealPhase.Breaking,seal.phase);
            float partial=seal.progress;Assert.Greater(partial,0);
            sim.CancelSealForTest("시험 중단");
            Assert.AreEqual(SealPhase.Available,seal.phase);
            Assert.AreEqual(partial,seal.progress,.0001f,"An interrupted seal resumes where it stopped.");
            int before=sim.State.enemies.Count;
            for(int n=0;n<400&&seal.phase!=SealPhase.Broken;n++)
            {
                foreach(var e in sim.State.enemies)e.dead=true;sim.State.meter=0;
                sim.State.position=seal.accessPoints[0];sim.Tick(CombatSimulation.Step);
            }
            Assert.AreEqual(SealPhase.Broken,seal.phase);
            Assert.Greater(sim.State.enemies.Count,before,"Breaking a seal calls something into the room.");
        }
    }
}
