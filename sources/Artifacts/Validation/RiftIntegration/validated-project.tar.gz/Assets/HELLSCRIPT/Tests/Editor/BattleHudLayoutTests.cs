using System.Collections;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class BattleHudLayoutTests
    {
        static IEnumerable Cases()
        {
            foreach (var size in new[] { new Vector2Int(360,640), new Vector2Int(390,844), new Vector2Int(720,1280), new Vector2Int(1080,2340), new Vector2Int(1080,2400), new Vector2Int(640,360), new Vector2Int(1280,720), new Vector2Int(2340,1080), new Vector2Int(2400,1080), new Vector2Int(1920,1200), new Vector2Int(3440,1440), new Vector2Int(900,900), new Vector2Int(1024,768), new Vector2Int(768,1024), new Vector2Int(958,640), new Vector2Int(960,640) })
                foreach (bool boss in new[] { false, true }) yield return new TestCaseData(size.x, size.y, boss);
        }
        [TestCaseSource(nameof(Cases))]
        public void CombatViewportIsPositiveAndDoesNotOverlapPersistentControls(int width, int height, bool boss)
        {
            var layout = new BattleHudLayout(width, height, boss); var bounds = new Rect(0,0,width,height);
            Assert.Greater(layout.world.width, 0); Assert.Greater(layout.world.height, 0);
            foreach (var rect in new[] { layout.header, layout.footer, layout.status, layout.actions, layout.world })
            {
                Assert.Greater(rect.width, 0); Assert.Greater(rect.height, 0);
                Assert.GreaterOrEqual(rect.xMin, 0); Assert.GreaterOrEqual(rect.yMin, 0); Assert.LessOrEqual(rect.xMax, bounds.xMax); Assert.LessOrEqual(rect.yMax, bounds.yMax);
            }
            foreach (var control in new[] { layout.header, layout.status, layout.actions, layout.footer }) Assert.IsFalse(layout.world.Overlaps(control));
            if (layout.wide) { Assert.IsFalse(layout.world.Overlaps(layout.minimap)); Assert.IsFalse(layout.actions.Overlaps(layout.minimap)); Assert.GreaterOrEqual(layout.minimap.height, 76); }
        }
        [TestCase(.3f)] [TestCase(.56f)] [TestCase(1f)] [TestCase(1.77f)] [TestCase(3.5f)]
        public void CameraRetainsLocalContextWithoutChangingAnyGameplayRange(float aspect)
        { float halfHeight = BattleHudLayout.CameraHalfHeight(aspect,180); Assert.GreaterOrEqual(halfHeight, 5); Assert.GreaterOrEqual(halfHeight * aspect, 6 - .0001f); }
        [Test] public void ShortPortraitFoldsSkillsToKeepTheBattleAreaReadable()
        {
            var shortPhone = new BattleHudLayout(360,640,false); var tallPhone = new BattleHudLayout(390,844,false);
            Assert.IsTrue(shortPhone.collapsedSkills); Assert.IsFalse(tallPhone.collapsedSkills); Assert.Greater(shortPhone.world.height, 250);
            Assert.Less(BattleHudLayout.CameraHalfHeight(1.5f,180), BattleHudLayout.CameraHalfHeight(1.5f,720));
        }
    }
}
