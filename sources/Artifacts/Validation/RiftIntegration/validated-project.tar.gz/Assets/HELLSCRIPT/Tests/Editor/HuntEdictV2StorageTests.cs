using System;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class HuntEdictV2StorageTests
    {
        GameCatalog catalog;
        [SetUp] public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown] public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        static HeroSave Round(HeroSave hero)=>JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(hero));

        [Test]
        public void EveryHeroOfANewAccountKeepsACanonicalEdict()
        {
            var account=GameStore.NewAccount(catalog);
            Assert.AreEqual(3,account.heroes.Count);
            foreach(var hero in account.heroes)
            {
                Assert.IsFalse(HuntEdictV2Storage.IsAbsent(hero.edict));
                Assert.AreEqual(HuntEdict.ClassId(hero.heroClass),hero.edict.heroClass);
                Assert.DoesNotThrow(()=>HuntEdictV2.Canonical(hero.edict));
                Assert.AreEqual(4,hero.edict.slots.Length);
            }
        }

        [Test]
        public void TheSlotsStartFromTheLoadoutTheHeroAlreadyFightsWith()
        {
            var account=GameStore.NewAccount(catalog);
            foreach(var hero in account.heroes)
            {
                var expected=hero.build.activeSkills.Where(i=>i>=0&&i<18).Select(CombatTelemetry.SkillId).Distinct().Take(4).ToArray();
                CollectionAssert.AreEqual(expected,hero.edict.slots.Where(s=>s!="").ToArray(),"slots follow the equipped skills");
            }
        }

        [Test]
        public void ASaveWrittenBeforeTheDocumentExistedGainsOneOnLoad()
        {
            var account=GameStore.NewAccount(catalog);
            foreach(var hero in account.heroes)hero.edict=null;
            // JsonUtility writes an absent serializable class as an empty object, which is what an older save looks like.
            var reloaded=JsonUtility.FromJson<AccountSave>(JsonUtility.ToJson(account));
            Assert.IsTrue(reloaded.heroes.All(h=>HuntEdictV2Storage.IsAbsent(h.edict)));
            GameStore.Migrate(reloaded);
            foreach(var hero in reloaded.heroes)
            {
                Assert.IsFalse(HuntEdictV2Storage.IsAbsent(hero.edict));
                Assert.AreEqual(HuntEdict.ClassId(hero.heroClass),hero.edict.heroClass);
            }
        }

        [Test]
        public void ADocumentBelongingToAnotherClassIsReplacedForThisHero()
        {
            var account=GameStore.NewAccount(catalog);var hero=account.heroes[0];
            hero.edict=HuntEdictV2.Create(HeroClass.Mage);
            HuntEdictV2Storage.Normalize(hero);
            Assert.AreEqual(HuntEdict.ClassId(hero.heroClass),hero.edict.heroClass);
            Assert.DoesNotThrow(()=>HuntEdictV2.Canonical(hero.edict));
        }

        [Test]
        public void ANewerDocumentStopsTheLoadInsteadOfBeingReset()
        {
            var account=GameStore.NewAccount(catalog);var hero=account.heroes[0];
            hero.edict.optionVersion=HuntEdictV2.OptionVersion+1;
            var error=Assert.Throws<NotSupportedException>(()=>HuntEdictV2Storage.Normalize(hero));
            StringAssert.Contains("보존",error.Message);
            Assert.AreEqual(HuntEdictV2.OptionVersion+1,hero.edict.optionVersion,"the stored document is left untouched");
        }

        [Test]
        public void AnUnreadableDocumentStopsTheLoadInsteadOfBeingReset()
        {
            var account=GameStore.NewAccount(catalog);var hero=account.heroes[0];
            hero.edict.skills.RemoveAt(0);
            Assert.Throws<NotSupportedException>(()=>HuntEdictV2Storage.Normalize(hero));
        }

        [Test]
        public void AnEditedOptionSurvivesASaveAndLoadRoundTrip()
        {
            var account=GameStore.NewAccount(catalog);var hero=account.heroes[0];
            string skill=hero.edict.slots.First(s=>s!="");
            string before=HuntEdictV2.Value(hero.edict,skill,1);
            string flipped=before=="ON"?"OFF":"ON";
            hero.edict=HuntEdictV2.WithOption(hero.edict,skill,1,flipped);
            var reloaded=Round(hero);HuntEdictV2Storage.Normalize(reloaded);
            Assert.AreEqual(flipped,HuntEdictV2.Value(reloaded.edict,skill,1));
            Assert.AreNotEqual(before,flipped,"the fixture must actually change the option");
        }

        [Test]
        public void NormalizingAnAlreadyCanonicalDocumentChangesNothing()
        {
            var account=GameStore.NewAccount(catalog);var hero=account.heroes[1];
            string before=JsonUtility.ToJson(hero.edict);
            HuntEdictV2Storage.Normalize(hero);
            Assert.AreEqual(before,JsonUtility.ToJson(hero.edict));
        }
    }
}
