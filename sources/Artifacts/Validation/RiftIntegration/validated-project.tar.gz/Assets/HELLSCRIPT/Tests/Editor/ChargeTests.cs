using System;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class ChargeTests
    {
        GameCatalog catalog;
        [SetUp]public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown]public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        static object Call(CombatSimulation sim,string name,params object[] args)
        {
            var method=typeof(CombatSimulation).GetMethod(name,BindingFlags.NonPublic|BindingFlags.Instance);var p=method.GetParameters();var full=new object[p.Length];
            for(int i=0;i<full.Length;i++)full[i]=i<args.Length?args[i]:p[i].DefaultValue;return method.Invoke(sim,full);
        }
        CombatSimulation Fixture(int skill,string set=null,bool movementPassive=false)
        {
            var account=GameStore.NewAccount();account.selectedHero=skill/6;var hero=account.Hero;hero.level=30;hero.build.passives=movementPassive?new[]{4}:Array.Empty<int>();
            hero.build.activeSkills.Clear();hero.build.activeSkills.Add(skill);hero.build.rules.Clear();hero.build.rules.Add(new Rule(skill));hero.build.movement=MovementMode.Stand;hero.build.distance=2;hero.build.potionThreshold=0;
            uint rng=625;if(set!=null)for(int i=1;i<=4;i++){var id=set+i;var d=ItemCatalog.Unique(id);var item=ItemGenerator.Create(hero.heroClass,d.slot,3,30,ref rng,uniqueId:id);item.equipped=true;hero.inventory.Add(item);}
            var sim=new CombatSimulation(account,catalog,1,1,seed:551);sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();sim.State.decisionTime=100;
            sim.State.enemies.Add(new EnemyState{id=900,position=sim.State.position+Vector2.up*(skill==1?6:2),health=100000,maxHealth=100000,speed=0,cooldown=1000});
            Controlled(sim);return sim;
        }
        static void Controlled(CombatSimulation sim){sim.Stats.regen=0;sim.Stats.crit=0;sim.Stats.costReduction=0;}
        static void Advance(CombatSimulation sim,int count){for(int n=0;n<count;n++)sim.Tick(.05f);}
        HeroActionState Start(CombatSimulation sim,int skill)
        {
            var target=sim.State.enemies[0];var destination=skill==1?sim.State.position+Vector2.up*6:skill==9?sim.State.position-Vector2.up*6:sim.State.position;
            Call(sim,"StartHeroAction",skill,target,destination,(float)Call(sim,"Cost",catalog.skills[skill]),0,false);return sim.State.heroAction;
        }
        CombatSimulation Restore(CombatSimulation original)
        {
            var account=GameStore.NewAccount();account.selectedHero=(int)original.Hero.heroClass;account.heroes[account.selectedHero]=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(original.Hero));
            var sim=new CombatSimulation(account,catalog,1,1,JsonUtility.FromJson<RunState>(JsonUtility.ToJson(original.State)));Controlled(sim);foreach(string id in original.Stats.specials)sim.Stats.specials.Add(id);return sim;
        }
        [Test]
        public void WhirlwindChargeReservesAtTravelStartAndSurvivesItsFormerExpiry()
        {
            var sim=Fixture(1,"SW");sim.State.itemEffects.whirlwindCharge=.3f;var a=Start(sim,1);Assert.IsFalse(a.whirlwindReserved);
            Advance(sim,2);Assert.Greater(sim.State.itemEffects.whirlwindCharge,0);Advance(sim,1);Assert.IsTrue(a.whirlwindReserved);Assert.AreEqual(0,sim.State.itemEffects.whirlwindCharge);Assert.AreEqual(0,sim.State.dealt);
            Advance(sim,9);Assert.AreEqual(1,sim.State.damageEvents.Count(d=>d.definitionId=="SW4"));Assert.IsFalse(a.whirlwindReserved);Assert.AreEqual(1,sim.State.effectEvents.Count(e=>e.definitionId=="SW4"&&e.kind=="CONSUMED"));
        }
        [Test]
        public void WhirlwindPreparationCancelKeepsChargeButInvalidFlightLosesReservation()
        {
            var sim=Fixture(1,"SW");sim.State.itemEffects.whirlwindCharge=1;Start(sim,1);Advance(sim,2);Call(sim,"InterruptHeroAction","test");Assert.AreEqual(.9f,sim.State.itemEffects.whirlwindCharge,.0001f);
            var a=Start(sim,1);Advance(sim,3);Assert.IsTrue(a.whirlwindReserved);a.destination=new Vector2(1000,1000);Advance(sim,9);
            Assert.AreEqual(0,sim.State.itemEffects.whirlwindCharge);Assert.IsFalse(sim.State.damageEvents.Any(d=>d.definitionId=="SW4"));Assert.IsTrue(sim.State.effectEvents.Any(e=>e.kind=="RESERVATION_LOST"));
        }
        [Test]
        public void InvalidDestinationBeforeTravelDoesNotReserveWhirlwindCharge()
        {
            var sim=Fixture(1,"SW");sim.State.itemEffects.whirlwindCharge=1;var a=Start(sim,1);a.destination=new Vector2(1000,1000);Advance(sim,3);
            Assert.IsFalse(sim.HeroActionBusy);Assert.Greater(sim.State.itemEffects.whirlwindCharge,0);Assert.IsFalse(a.whirlwindReserved);
        }
        [Test]
        public void OnlyPaidChannelWalkingAccumulatesFourMetersAndHeldChargeDoesNotRefresh()
        {
            var sim=Fixture(0,"SW");var a=Start(sim,0);Call(sim,"TrackWalking",4f,1f);Assert.AreEqual(0,sim.State.itemEffects.whirlwindDistance);Assert.AreEqual(0,sim.State.itemEffects.whirlwindCharge);
            a.cost=5;Call(sim,"TrackWalking",3.9f,1f);Assert.AreEqual(0,sim.State.itemEffects.whirlwindCharge);Call(sim,"TrackWalking",.1f,.05f);Assert.AreEqual(6,sim.State.itemEffects.whirlwindCharge);
            Call(sim,"TickCharges",1f);Call(sim,"TrackWalking",10f,1f);Assert.AreEqual(5,sim.State.itemEffects.whirlwindCharge);Assert.Less(sim.State.itemEffects.whirlwindDistance,4);
            Call(sim,"InterruptHeroAction","stop");Assert.AreEqual(0,sim.State.itemEffects.whirlwindDistance);Assert.AreEqual(5,sim.State.itemEffects.whirlwindCharge);
        }
        [TestCase(2,"SWB","SWB4")][TestCase(6,"SAB","SAB4")][TestCase(14,"SMB","M03")]
        public void CastBonusesAreReservedBeforePreparationExpiresAndRestoreExactly(int skill,string set,string definition)
        {
            var sim=Fixture(skill,set);sim.State.itemEffects.crushCharge=sim.State.itemEffects.pierceCharge=sim.State.itemEffects.chainCharge=.1f;sim.State.itemEffects.chainCharges=2;
            if(skill==14)for(int i=1;i<6;i++)sim.State.enemies.Add(new EnemyState{id=900+i,position=sim.State.enemies[0].position+Vector2.right*i*.5f,health=100000,maxHealth=100000,speed=0,cooldown=1000});
            var a=Start(sim,skill);Assert.AreEqual(skill==2,a.crushBonus);Assert.AreEqual(skill==6,a.pierceBonus);Assert.AreEqual(skill==14?2:0,a.chainBonus);
            Advance(sim,1);var restored=Restore(sim);
            for(int n=0;n<40;n++){sim.Tick(.05f);restored.Tick(.05f);Assert.AreEqual(JsonUtility.ToJson(sim.State),JsonUtility.ToJson(restored.State),"tick "+n);}
            Assert.AreEqual(skill==14?6:1,sim.State.damageEvents.Count(d=>d.definitionId==definition));
        }
        [TestCase(2,"SWB")][TestCase(6,"SAB")][TestCase(14,"SMB")]
        public void CancellingAValidPaidCastDoesNotRefundItsReservedBonus(int skill,string set)
        {
            var sim=Fixture(skill,set);sim.State.itemEffects.crushCharge=sim.State.itemEffects.pierceCharge=sim.State.itemEffects.chainCharge=5;sim.State.itemEffects.chainCharges=1;
            float before=sim.State.resource;Start(sim,skill);Call(sim,"InterruptHeroAction","cancel");
            Assert.Less(sim.State.resource,before);Assert.AreEqual(0,skill==2?sim.State.itemEffects.crushCharge:skill==6?sim.State.itemEffects.pierceCharge:sim.State.itemEffects.chainCharge);Assert.IsEmpty(sim.State.projectiles);Assert.AreEqual(0,sim.State.dealt);
        }
        [Test]
        public void EmptyCrushConsumesAtStartAndDoesNotApplyBonusToAnUnrelatedLaterTarget()
        {
            var sim=Fixture(2,"SWB");sim.State.itemEffects.crushCharge=5;Start(sim,2);sim.State.enemies[0].position=RiftMap.Rooms[4];Advance(sim,20);
            Assert.AreEqual(0,sim.State.dealt);Assert.AreEqual(0,sim.State.itemEffects.crushCharge);sim.State.enemies[0].position=sim.State.position+Vector2.up*2;Start(sim,2);Advance(sim,20);
            Assert.IsTrue(sim.State.damageEvents.Any(d=>d.definitionId=="W03"));Assert.IsFalse(sim.State.damageEvents.Any(d=>d.definitionId=="SWB4"));
        }
        [Test]
        public void RetreatLegendCreatesItsTrapAtDepartureAndNeverCreatesItAgainAtLanding()
        {
            var sim=Fixture(9);sim.Stats.specials.Add("LA03");sim.State.build.activeSkills.Add(8);var origin=sim.State.position;var a=Start(sim,9);
            var trap=sim.State.traps.Single();Assert.AreEqual(origin,trap.position);Assert.AreEqual(.5f,trap.arm);Assert.AreEqual("LA03",trap.definitionId);Assert.AreEqual(a.retreatTrapId,trap.id);
            var restored=Restore(sim);Advance(sim,10);Advance(restored,10);Assert.AreEqual(1,sim.State.traps.Count);Assert.AreEqual(JsonUtility.ToJson(sim.State),JsonUtility.ToJson(restored.State));Assert.AreEqual(origin-Vector2.up*6,sim.State.position);
        }
        [Test]
        public void FailedRetreatRemovesOnlyItsDepartureTrapAndRequiresTrapEquipped()
        {
            var sim=Fixture(9);sim.Stats.specials.Add("LA03");Start(sim,9);Assert.IsEmpty(sim.State.traps);Call(sim,"InterruptHeroAction","cancel");
            sim.State.build.activeSkills.Add(8);var a=Start(sim,9);Assert.AreEqual(1,sim.State.traps.Count);a.destination=new Vector2(1000,1000);Advance(sim,10);Assert.IsEmpty(sim.State.traps);
        }
        [Test]
        public void DisciplineCountsOnlyThreeSameTargetHitsOutsideChargeAndCooldown()
        {
            var sim=Fixture(6);sim.Stats.specials.Add("LC02");Call(sim,"BasicResource",900);Call(sim,"BasicResource",900);Assert.AreEqual(2,sim.State.itemEffects.basicCount);
            Call(sim,"BasicResource",901);Assert.AreEqual(1,sim.State.itemEffects.basicCount);Call(sim,"BasicResource",901);Call(sim,"BasicResource",901);Assert.AreEqual(5,sim.State.itemEffects.lc02Charge);Assert.IsTrue(sim.State.itemEffects.reducedNext);
            for(int n=0;n<10;n++)Call(sim,"BasicResource",901);Assert.AreEqual(0,sim.State.itemEffects.basicCount);Assert.AreEqual(5,sim.State.itemEffects.lc02Charge);
            Call(sim,"ConsumeCostEffects",5f,new HeroActionState{id=11});for(int n=0;n<10;n++)Call(sim,"BasicResource",901);Assert.AreEqual(0,sim.State.itemEffects.basicCount);
        }
        [Test]
        public void DisciplineExpiresAtFiveSecondsAndDeadTargetResetsOnlyUnfinishedHits()
        {
            var sim=Fixture(6);sim.Stats.specials.Add("LC02");Call(sim,"BasicResource",900);Call(sim,"BasicResource",900);sim.State.enemies[0].dead=true;Call(sim,"TickCharges",.05f);Assert.AreEqual(0,sim.State.itemEffects.basicCount);
            sim.State.enemies[0].dead=false;for(int i=0;i<3;i++)Call(sim,"BasicResource",900);Advance(sim,99);Assert.IsTrue(sim.State.itemEffects.reducedNext);Advance(sim,1);Assert.IsFalse(sim.State.itemEffects.reducedNext);Assert.AreEqual(0,sim.State.itemEffects.lc02Charge);
        }
        [Test]
        public void OtherSkillKeepsUnfinishedBasicHitCountAndFreeCastKeepsReadyDiscount()
        {
            var sim=Fixture(9);sim.Stats.specials.Add("LC02");Call(sim,"BasicResource",900);Call(sim,"BasicResource",900);Start(sim,9);Assert.AreEqual(2,sim.State.itemEffects.basicCount);Advance(sim,10);
            Call(sim,"BasicResource",900);Assert.IsTrue(sim.State.itemEffects.reducedNext);float charge=sim.State.itemEffects.lc02Charge;Start(sim,9);Assert.AreEqual(charge,sim.State.itemEffects.lc02Charge);
        }
        [Test]
        public void PassiveRequiresContinuousWalkingExcludesTravelAndCooldownStartsOnPaidUse()
        {
            var sim=Fixture(9,movementPassive:true);Start(sim,9);Advance(sim,10);Assert.AreEqual(0,sim.State.itemEffects.ap05Movement);Assert.IsFalse(sim.State.itemEffects.ap05Ready);
            for(int n=0;n<19;n++)Call(sim,"TrackWalking",.1f,.05f);Assert.IsFalse(sim.State.itemEffects.ap05Ready);Call(sim,"TrackWalking",0f,.05f);Assert.AreEqual(0,sim.State.itemEffects.ap05Movement);
            for(int n=0;n<20;n++)Call(sim,"TrackWalking",.1f,.05f);Assert.IsTrue(sim.State.itemEffects.ap05Ready);Assert.AreEqual(0,sim.State.itemEffects.ap05Cooldown);
            Call(sim,"ConsumeCostEffects",0f,new HeroActionState{id=1});Assert.IsTrue(sim.State.itemEffects.ap05Ready);Call(sim,"ConsumeCostEffects",5f,new HeroActionState{id=2});Assert.IsFalse(sim.State.itemEffects.ap05Ready);Assert.AreEqual(4,sim.State.itemEffects.ap05Cooldown);
            for(int n=0;n<20;n++)Call(sim,"TrackWalking",.1f,.05f);Assert.AreEqual(0,sim.State.itemEffects.ap05Movement);
        }
        [Test]
        public void CostBonusesStackToFiftyPercentAndInsufficientResourceConsumesNeither()
        {
            var sim=Fixture(6,movementPassive:true);sim.Stats.specials.Add("LC02");sim.State.itemEffects.ap05Ready=true;sim.State.itemEffects.lc02Charge=5;sim.State.itemEffects.reducedNext=true;
            Assert.AreEqual(catalog.skills[6].cost*.5f,(float)Call(sim,"Cost",catalog.skills[6]));sim.State.resource=0;sim.State.decisionTime=0;sim.Tick(.05f);
            Assert.IsFalse(sim.HeroActionBusy);Assert.IsTrue(sim.State.itemEffects.ap05Ready);Assert.IsTrue(sim.State.itemEffects.reducedNext);
            sim.State.resource=100;sim.State.decisionTime=0;sim.Tick(.05f);Assert.IsTrue(sim.HeroActionBusy);Assert.AreEqual(catalog.skills[6].cost*.5f,sim.State.heroAction.cost);Assert.IsFalse(sim.State.itemEffects.ap05Ready);Assert.IsFalse(sim.State.itemEffects.reducedNext);
            Assert.AreEqual(1,sim.State.effectEvents.Count(e=>e.definitionId=="LC02"&&e.kind=="CONSUMED"));Assert.AreEqual(1,sim.State.effectEvents.Count(e=>e.definitionId=="AP05"&&e.kind=="CONSUMED"));
        }
        [Test]
        public void ActualWalkingGrantsPassiveAndRemovingItThroughTrainingBuildClearsPendingState()
        {
            var sim=Fixture(6,movementPassive:true);sim.State.targetId=900;sim.State.movementRule=0;sim.State.movementAction=RuleAction.Skill;sim.State.build.movement=MovementMode.Retreat;
            Advance(sim,20);Assert.IsTrue(sim.State.itemEffects.ap05Ready);Assert.Greater(sim.State.moveDistance,4);
            var build=sim.State.build.Copy();build.passives=Array.Empty<int>();Assert.IsTrue(sim.ApplyBuild(build));Assert.IsFalse(sim.State.itemEffects.ap05Ready);
        }
        [Test]
        public void PendingCostBonusesAndInternalCooldownsRestoreAndFreezeWithTheRun()
        {
            var sim=Fixture(6,movementPassive:true);sim.Stats.specials.Add("LC02");sim.State.itemEffects.ap05Ready=true;sim.State.itemEffects.lc02Charge=2.5f;sim.State.itemEffects.reducedNext=true;sim.State.itemEffects.procCooldown=1;
            var restored=Restore(sim);Advance(sim,20);Advance(restored,20);Assert.AreEqual(JsonUtility.ToJson(sim.State),JsonUtility.ToJson(restored.State));
            sim.State.paused=true;string before=JsonUtility.ToJson(sim.State);sim.Tick(1);Assert.AreEqual(before,JsonUtility.ToJson(sim.State));sim.State.paused=false;sim.State.portal=true;before=JsonUtility.ToJson(sim.State);sim.Tick(1);Assert.AreEqual(before,JsonUtility.ToJson(sim.State));
        }
        [Test]
        public void LegacyPendingChargesMigrateOnceWithoutRepayingOrReplayingReleasedActions()
        {
            var sim=Fixture(2,"SWB");sim.State.effectVersion=1;sim.State.itemEffects.crushCharge=2;sim.State.itemEffects.reducedNext=true;
            sim.State.heroAction=new HeroActionState{id=99,skill=2,phase=HeroActionPhase.Preparing,cost=20};float resource=sim.State.resource;
            GameStore.NormalizeRun(sim.State);Assert.AreEqual(CombatEffects.Version,sim.State.effectVersion);Assert.IsTrue(sim.State.heroAction.crushBonus);Assert.AreEqual(0,sim.State.itemEffects.crushCharge);Assert.AreEqual(5,sim.State.itemEffects.lc02Charge);Assert.AreEqual(resource,sim.State.resource);
            string first=JsonUtility.ToJson(sim.State);GameStore.NormalizeRun(sim.State);Assert.AreEqual(first,JsonUtility.ToJson(sim.State));
            sim.State.effectVersion=1;sim.State.heroAction=new HeroActionState{id=100,skill=6,phase=HeroActionPhase.Recovering,released=true};sim.State.itemEffects.pierceCharge=3;GameStore.NormalizeRun(sim.State);Assert.IsFalse(sim.State.heroAction.pierceBonus);Assert.AreEqual(3,sim.State.itemEffects.pierceCharge);
        }
        [Test]
        public void MovementDuringTheLastCooldownStepDoesNotCountTowardTheNextPassive()
        {
            var sim=Fixture(6,movementPassive:true);sim.State.targetId=900;sim.State.movementRule=0;sim.State.movementAction=RuleAction.Skill;sim.State.build.movement=MovementMode.Retreat;sim.State.itemEffects.ap05Cooldown=.05f;
            Advance(sim,20);Assert.IsFalse(sim.State.itemEffects.ap05Ready);Assert.AreEqual(.95f,sim.State.itemEffects.ap05Movement,.0001f);Advance(sim,1);Assert.IsTrue(sim.State.itemEffects.ap05Ready);
        }
        [Test]
        public void AThirdBasicHitThatKillsTheTargetStillEarnsItsCompletedCharge()
        {
            var sim=Fixture(6);sim.Stats.specials.Add("LC02");sim.State.itemEffects.lastBasic=900;sim.State.itemEffects.basicCount=2;var enemy=sim.State.enemies[0];enemy.health=1;
            Call(sim,"StartHeroAction",-1,enemy,sim.State.position,0f,0,false);Advance(sim,20);
            Assert.IsTrue(enemy.dead);Assert.IsTrue(sim.State.itemEffects.reducedNext);Assert.AreEqual(1,sim.State.effectEvents.Count(e=>e.definitionId=="LC02"&&e.kind=="CHARGE"));
        }
    }
}
