using System;
using System.IO;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class FirstPlayGuideTests
    {
        GameCatalog catalog;
        AccountSave account;
        [SetUp]public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();account=GameStore.NewAccount(catalog);}
        [TearDown]public void Teardown(){UnityEngine.Object.DestroyImmediate(catalog);}
        RunState Run(int training=-1)=>new RunState{id=Guid.NewGuid().ToString("N"),heroId=account.Hero.id,training=training,trainingUsesOwnedHero=training>=0,build=account.Hero.build.Copy()};
        void ApplyDistance(float distance=4)
        {var before=account.Hero.build.Copy();account.Hero.build.distance=distance;Assert.IsTrue(FirstPlayGuide.Applied(account,account.Hero,before,account.Hero.build,catalog));}
        static void Selected(RunState r)=>r.decisions.Add(new RuleDecision{code="SELECTED",ruleId=r.build.rules[0].id});
        static string WithoutGuidance(AccountSave a)
        {
            var copy=JsonUtility.FromJson<AccountSave>(JsonUtility.ToJson(a));copy.guide=new AccountGuide();foreach(var h in copy.heroes)h.guide=new HeroGuide();return JsonUtility.ToJson(copy);
        }
        [Test]public void NewAndLegacyAccountsDoNotInferCompletionFromLevelOrClears()
        {
            account.guide=null;foreach(var h in account.heroes){h.guide=null;h.level=30;h.highestClear=99;}
            FirstPlayGuide.Normalize(account);foreach(var h in account.heroes)Assert.AreEqual(0,FirstPlayGuide.Count(account,h));
        }
        [Test]public void CommonControlsAndHiddenHintsPersistAcrossHeroesWithoutCopyingSkillProgress()
        {
            FirstPlayGuide.ReadControls(account);FirstPlayGuide.ReadBuild(account.Hero);FirstPlayGuide.HideHints(account,true);
            account.selectedHero=1;Assert.IsTrue(FirstPlayGuide.Done(account,account.Hero,GuideStep.Controls));Assert.IsFalse(FirstPlayGuide.Done(account,account.Hero,GuideStep.Build));Assert.IsTrue(account.guide.hintsHidden);
            FirstPlayGuide.HideHints(account,false);Assert.AreEqual(1,FirstPlayGuide.Count(account,account.Hero));account.selectedHero=0;Assert.AreEqual(2,FirstPlayGuide.Count(account,account.Hero));
        }
        [Test]public void RepeatedReadsAndHideDoNotChangeEconomyBuildOrInventory()
        {
            string before=WithoutGuidance(account);FirstPlayGuide.HideHints(account,true);Assert.IsTrue(FirstPlayGuide.ReadControls(account));Assert.IsFalse(FirstPlayGuide.ReadControls(account));
            FirstPlayGuide.ReadBuild(account.Hero);Assert.IsTrue(FirstPlayGuide.ReadEquipmentExplanation(account.Hero));Assert.IsFalse(FirstPlayGuide.ReadEquipmentExplanation(account.Hero));Assert.AreEqual(before,WithoutGuidance(account));
        }
        [TestCase(-1,true)][TestCase(0,false)][TestCase(1,false)][TestCase(2,false)]
        public void OnlyRealRiftsCountAsEntry(int training,bool expected)
        {Assert.AreEqual(expected,FirstPlayGuide.Enter(account,Run(training),false));Assert.AreEqual(expected,FirstPlayGuide.Done(account,account.Hero,GuideStep.Rift));}
        [Test]public void EmptyUnselectedAndForeignDecisionsDoNotCount()
        {
            var r=Run();Assert.IsFalse(FirstPlayGuide.ReadDecision(account,r));r.decisions.Add(new RuleDecision{code="RESOURCE"});Assert.IsFalse(FirstPlayGuide.ReadDecision(account,r));Selected(r);
            r.heroId="foreign";Assert.IsFalse(FirstPlayGuide.ReadDecision(account,r));r.heroId=account.Hero.id;r.training=1;Assert.IsFalse(FirstPlayGuide.ReadDecision(account,r));r.training=-1;Assert.IsTrue(FirstPlayGuide.ReadDecision(account,r));Assert.IsFalse(FirstPlayGuide.ReadDecision(account,r));
        }
        [TestCase(RunPhase.Cleared)][TestCase(RunPhase.Failed)]
        public void ActualTerminalResultsCountOnce(RunPhase phase)
        {
            var r=Run();r.phase=phase;r.time=17;Assert.IsTrue(FirstPlayGuide.ReadResult(account,r));Assert.IsFalse(FirstPlayGuide.ReadResult(account,r));Assert.AreEqual(r.id,account.Hero.guide.firstResultRun);
        }
        [Test]public void RunningOrZeroTimeResultsDoNotCount()
        {
            var r=Run();r.time=5;Assert.IsFalse(FirstPlayGuide.ReadResult(account,r));r.phase=RunPhase.Failed;r.time=0;Assert.IsFalse(FirstPlayGuide.ReadResult(account,r));
        }
        [Test]public void EquipmentExplanationDoesNotInventLootAndOwnedComparisonRequiresRealCandidate()
        {
            string before=WithoutGuidance(account);Assert.IsFalse(FirstPlayGuide.ReadComparison(account.Hero,account.Hero.inventory[0]));Assert.IsTrue(FirstPlayGuide.ReadEquipmentExplanation(account.Hero));Assert.IsTrue(account.Hero.guide.equipmentExplanation);Assert.AreEqual(before,WithoutGuidance(account));
            account.Hero.guide=new HeroGuide();uint rng=77;var item=Economy.CreateItem(account.Hero.heroClass,0,1,1,ref rng);Assert.IsFalse(FirstPlayGuide.ReadComparison(account.Hero,item));account.Hero.inventory.Add(item);Assert.IsFalse(FirstPlayGuide.ReadEquipmentExplanation(account.Hero));Assert.IsTrue(FirstPlayGuide.ReadComparison(account.Hero,item));Assert.AreEqual(item.id,account.Hero.guide.comparedItem);Assert.IsFalse(account.Hero.guide.equipmentExplanation);
        }
        [Test]public void MetadataAndRepeatPolicyChangesAreNotCombatConditionEdits()
        {
            var before=account.Hero.build.Copy();var after=before.Copy();after.name="rename";after.version="new";after.equipmentIds.Add("reference");after.rules[0].id="other-id";after.rules[0].threshold=7;after.autoRepeat=true;
            Assert.IsEmpty(FirstPlayGuide.DescribeChange(before,after,catalog));Assert.IsFalse(FirstPlayGuide.Applied(account,account.Hero,before,after,catalog));Assert.IsFalse(FirstPlayGuide.Done(account,account.Hero,GuideStep.Edit));
        }
        [TestCase(0)][TestCase(1)][TestCase(2)][TestCase(3)][TestCase(4)]
        public void MeaningfulCombatChangesAreDescribedBeforeApplication(int kind)
        {
            var before=account.Hero.build.Copy();var after=before.Copy();
            if(kind==0)after.distance=6;else if(kind==1)after.potionThreshold=60;else if(kind==2)after.target=TargetMode.Dense;else if(kind==3)after.rules[0].target=RuleTarget.LowHealth;else after.rules[0].enabled=!after.rules[0].enabled;
            Assert.IsNotEmpty(FirstPlayGuide.DescribeChange(before,after,catalog));Assert.IsFalse(FirstPlayGuide.Done(account,account.Hero,GuideStep.Edit));Assert.IsTrue(FirstPlayGuide.Applied(account,account.Hero,before,after,catalog));
            if(kind==3)StringAssert.Contains("낮은 HP",account.Hero.guide.changeSummary);
            Assert.AreEqual(FirstPlayGuide.Signature(after),account.Hero.guide.changedBuild);
        }
        [TestCase("developer")][TestCase("abandoned")][TestCase("different")][TestCase("no-decision")]
        public void TrainingNeedsOwnedCompletedMatchingSettings(string invalid)
        {
            ApplyDistance();var r=Run(1);r.phase=RunPhase.Cleared;r.time=60;r.health=100;Selected(r);
            if(invalid=="developer")r.trainingUsesOwnedHero=false;else if(invalid=="abandoned"){r.time=1;r.phase=RunPhase.Failed;}else if(invalid=="different")r.build.distance=8;else r.decisions.Clear();
            Assert.IsFalse(FirstPlayGuide.ReadResult(account,r));Assert.IsFalse(FirstPlayGuide.Done(account,account.Hero,GuideStep.Training));
        }
        [Test]public void AnotherAppliedEditRequiresTrainingThatNewSetting()
        {
            ApplyDistance();var r=Run(1);r.phase=RunPhase.Cleared;r.time=60;Selected(r);Assert.IsTrue(FirstPlayGuide.ReadResult(account,r));ApplyDistance(5);Assert.IsFalse(FirstPlayGuide.Done(account,account.Hero,GuideStep.Training));Assert.IsFalse(FirstPlayGuide.ReadResult(account,r));
        }
        [Test]public void ResumeSameRunAndMismatchedSettingsDoNotCountAsRetry()
        {
            var result=Run();result.time=5;result.phase=RunPhase.Failed;FirstPlayGuide.ReadResult(account,result);ApplyDistance();var training=Run(1);training.time=60;training.phase=RunPhase.Cleared;Selected(training);FirstPlayGuide.ReadResult(account,training);
            var retry=Run();FirstPlayGuide.Enter(account,retry,true);Assert.IsFalse(FirstPlayGuide.Done(account,account.Hero,GuideStep.Retry));retry.id=result.id;FirstPlayGuide.Enter(account,retry,false);Assert.IsFalse(FirstPlayGuide.Done(account,account.Hero,GuideStep.Retry));retry.id="new";retry.build.distance=8;FirstPlayGuide.Enter(account,retry,false);Assert.IsFalse(FirstPlayGuide.Done(account,account.Hero,GuideStep.Retry));retry.build=account.Hero.build.Copy();FirstPlayGuide.Enter(account,retry,false);Assert.IsTrue(FirstPlayGuide.Done(account,account.Hero,GuideStep.Retry));
        }
        [Test]public void DiskRestartKeepsGuideAndEconomyWithoutMarkingOtherHeroes()
        {
            string dir=Path.Combine(Path.GetTempPath(),"hellscript-guide-"+Guid.NewGuid().ToString("N"));try
            {
                var store=new GameStore(dir,catalog);FirstPlayGuide.ReadControls(store.Data);FirstPlayGuide.ReadBuild(store.Data.Hero);FirstPlayGuide.HideHints(store.Data,true);Assert.IsTrue(store.Save());var expected=JsonUtility.FromJson<AccountSave>(JsonUtility.ToJson(store.Data));
                expected.lastSeenUtc-=10;File.WriteAllText(Path.Combine(dir,"hellscript-local-v1.json"),JsonUtility.ToJson(expected));long started=DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                var loaded=new GameStore(dir,catalog);Assert.IsTrue(loaded.Data.guide.hintsHidden);Assert.AreEqual(2,FirstPlayGuide.Count(loaded.Data,loaded.Data.Hero));Assert.AreEqual(1,FirstPlayGuide.Count(loaded.Data,loaded.Data.heroes[1]));Assert.That(loaded.Data.lastSeenUtc,Is.InRange(started,DateTimeOffset.UtcNow.ToUnixTimeSeconds()));expected.lastSeenUtc=loaded.Data.lastSeenUtc;Assert.AreEqual(WithoutGuidance(expected),WithoutGuidance(loaded.Data));
            }finally{if(Directory.Exists(dir))Directory.Delete(dir,true);}
        }
        [TestCase(0)][TestCase(1)][TestCase(2)]
        public void FreshHeroRealRiftThenOwnedTrainingCanReachRetryWithoutInjectedRewards(int hero)
        {
            account.selectedHero=hero;FirstPlayGuide.ReadControls(account);FirstPlayGuide.ReadBuild(account.Hero);var sim=new CombatSimulation(account,catalog,1,seed:91367);FirstPlayGuide.Enter(account,sim.State,false);
            for(int i=0;i<6500&&sim.State.phase!=RunPhase.Cleared&&sim.State.phase!=RunPhase.Failed;i++)sim.Tick(CombatSimulation.Step);
            Assert.That(sim.State.phase,Is.EqualTo(RunPhase.Cleared).Or.EqualTo(RunPhase.Failed));Assert.IsTrue(FirstPlayGuide.ReadDecision(account,sim.State));Assert.IsTrue(FirstPlayGuide.ReadResult(account,sim.State));
            var item=FirstPlayGuide.ComparisonCandidate(account.Hero);if(item==null)FirstPlayGuide.ReadEquipmentExplanation(account.Hero);else FirstPlayGuide.ReadComparison(account.Hero,item);
            ApplyDistance(account.Hero.build.distance==4?5:4);var training=new CombatSimulation(account,catalog,1,1,ownedTraining:true);string economy=WithoutGuidance(account);
            for(int i=0;i<1200;i++)training.Tick(CombatSimulation.Step);Assert.IsTrue(FirstPlayGuide.ReadResult(account,training.State));Assert.AreEqual(economy,WithoutGuidance(account));
            var retry=new CombatSimulation(account,catalog,1,seed:91368);FirstPlayGuide.Enter(account,retry.State,false);Assert.IsTrue(FirstPlayGuide.Complete(account,account.Hero));
            TestContext.WriteLine($"Hero {hero}: first rift {sim.State.phase}, t={sim.State.time:0.0}, level={account.Hero.level}, kills={sim.State.kills}, items={account.Hero.inventory.Count}, equipment={(item==null?"explanation":"owned comparison")}");
        }
    }
}
