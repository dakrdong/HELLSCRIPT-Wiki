using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace Hellscript.Tests
{
    public sealed class FieldContentTests
    {
        GameCatalog catalog;
        [SetUp]public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown]public void Teardown(){UnityEngine.Object.DestroyImmediate(catalog);}
        CombatSimulation Find(AccountSave account,Func<RunState,bool> predicate)
        {
            // Clearing guards in these field fixtures must not also complete a carrier objective.
            for(uint seed=1;seed<=100;seed++){var sim=new CombatSimulation(account,catalog,5,seed:seed,forcedObjective:RiftObjectiveKind.Seals);if(predicate(sim.State))return sim;}
            throw new InvalidOperationException("No fixture matched.");
        }
        static void Quiet(CombatSimulation sim)
        {
            foreach(var e in sim.State.enemies)e.dead=true;sim.State.targetId=-1;sim.State.build.rules.Clear();sim.State.build.rules.Add(BehaviorRules.Utility(RuleAction.Chest));sim.State.build.rules.Add(BehaviorRules.Utility(RuleAction.Explore));sim.State.build.potionThreshold=0;
            sim.State.build.openChests=false;sim.State.build.useShrines=false;sim.State.meter=70;sim.State.resource=40;sim.State.health=sim.Stats.hp*.5f;
        }
        static void ReadyShrine(CombatSimulation sim)
        {
            Quiet(sim);var shrine=sim.State.layout.shrines[0];shrine.discovered=true;sim.State.position=shrine.openingPosition;sim.State.build.useShrines=true;
        }
        static void ReadyCurse(CombatSimulation sim,bool enabled=true)
        {
            Quiet(sim);var evt=sim.State.layout.events[0];var chest=sim.State.layout.chests.Single(c=>c.id==evt.chestId);
            chest.discovered=true;chest.phase=ChestPhase.Approaching;sim.State.exploration.chestId=chest.id;sim.State.position=chest.openingPosition;
            sim.State.build.openChests=true;sim.State.build.allowCursedChests=enabled;
        }
        [Test]
        public void OptionalContentPreservesBudgetsAndReservesUsableSpace()
        {
            int shrines=0,curses=0;
            for(uint seed=1;seed<=150;seed++)
            {
                var map=RiftGenerator.Generate(seed,"field-budget",5,HeroClass.Warrior);var nav=new RiftNavigation(map,gatesOpen:true);shrines+=map.shrines.Count;curses+=map.events.Count;
                Assert.AreEqual(157,map.chests.Sum(c=>c.gold));Assert.AreEqual(1,map.chests.Sum(c=>c.materials));Assert.AreEqual(2,map.chests.Count(c=>c.reward!=null));
                Assert.LessOrEqual(map.shrines.Count,1);Assert.LessOrEqual(map.events.Count,1);
                foreach(var chest in map.chests){Assert.IsFalse(nav.Walkable(chest.position));Assert.IsTrue(chest.accessPoints.All(nav.Reachable));}
                foreach(var shrine in map.shrines){Assert.AreNotEqual(0,shrine.room);Assert.IsFalse(map.rooms[shrine.room].boss);Assert.IsFalse(nav.Walkable(shrine.position));Assert.IsTrue(shrine.accessPoints.All(nav.Reachable));}
                foreach(var evt in map.events)
                {
                    var chest=map.chests.Single(c=>c.id==evt.chestId);Assert.AreEqual("CH03",chest.definitionId);Assert.IsNotNull(chest.reward);Assert.IsFalse(map.rooms[chest.room].boss);
                    Assert.GreaterOrEqual(evt.spawnCandidates.Count,4);Assert.IsTrue(evt.spawnCandidates.All(nav.Reachable));Assert.IsEmpty(evt.enemyIds);
                    Assert.IsTrue(map.chests.Where(c=>c.definitionId=="CH01").All(c=>c.reward==null));
                }
                if(seed<=20)Assert.IsEmpty(RiftGenerator.Generate(seed,"below-gate",4,HeroClass.Warrior).events);
            }
            Assert.That(shrines,Is.InRange(45,105));Assert.That(curses,Is.InRange(16,60));
        }
        [TestCase("SH01")][TestCase("SH02")]
        public void ShrineAppliesOnceWithoutRefillAndRestoresRemainingDuration(string definition)
        {
            var account=GameStore.NewAccount();var sim=Find(account,s=>s.layout.shrines.Any(x=>x.definitionId==definition));ReadyShrine(sim);
            sim.State.cooldowns[1]=10;float hp=sim.State.health;
            for(int tick=0;tick<13;tick++)sim.Tick(.05f);
            Assert.AreEqual(ShrinePhase.Used,sim.State.layout.shrines[0].phase);Assert.AreEqual(hp,sim.State.health);Assert.Less(sim.State.resource,55);Assert.That(sim.State.cooldowns[1],Is.InRange(9,10));
            float duration=definition=="SH01"?sim.State.guideShrineTime:sim.State.resolveShrineTime;Assert.That(duration,Is.InRange(19.8f,20));Assert.AreEqual(1,account.transactions.Count);
            sim.State.paused=true;string before=JsonUtility.ToJson(sim.State);sim.Tick(.5f);Assert.AreEqual(before,JsonUtility.ToJson(sim.State));
            sim.State.paused=false;sim.State.portal=true;before=JsonUtility.ToJson(sim.State);sim.Tick(.5f);Assert.AreEqual(before,JsonUtility.ToJson(sim.State));
            var saved=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(sim.State));var restored=new CombatSimulation(account,catalog,5,restore:saved);
            Assert.AreEqual(duration,definition=="SH01"?restored.State.guideShrineTime:restored.State.resolveShrineTime);Assert.AreEqual(ShrinePhase.Used,restored.State.layout.shrines[0].phase);
            restored.State.portal=false;for(int n=0;n<410;n++)restored.Tick(.05f);Assert.AreEqual(0,restored.State.guideShrineTime+restored.State.resolveShrineTime);Assert.AreEqual(1,account.transactions.Count);
        }
        [Test]
        public void MovementBonusesUseOneCapAndCombatRemovesConditionalBenefits()
        {
            var sim=Find(GameStore.NewAccount(),s=>s.layout.shrines.Count>0);Quiet(sim);sim.Tick(.05f);sim.State.guideShrineTime=20;sim.Stats.specials.Add("LC01");sim.Stats.bonuses[21]=10;
            Assert.IsTrue(sim.OutOfCombat);Assert.AreEqual(5,sim.MovementSpeed(false),.001);Assert.AreEqual(5.6f,sim.MovementSpeed(true),.001);
            sim.Stats.bonuses[21]=40;Assert.AreEqual(6,sim.MovementSpeed(true),.001);
            sim.Stats.bonuses[21]=10;sim.State.lastOutgoingDamageTime=sim.State.time;Assert.IsFalse(sim.OutOfCombat);Assert.AreEqual(4.4f,sim.MovementSpeed(true),.001);
            sim.State.resolveShrineTime=20;sim.State.itemEffects.leapDefense=2;Assert.AreEqual(.25f,sim.BuffDamageReduction,.001);
            float hp=sim.State.health;sim.State.effects.Add(new GroundEffect{id=90000,position=sim.State.position,radius=1,hostile=true,damage=100,duration=.1f});sim.Tick(.05f);
            float reduction=Mathf.Min(.75f,sim.Stats.armor/(sim.Stats.armor+150));Assert.AreEqual(100*(1-reduction)*.75f,hp-sim.State.health,.001);
        }
        [Test]
        public void DamageInterruptsShrineAndDoesNotCreateABlessing()
        {
            var sim=Find(GameStore.NewAccount(),s=>s.layout.shrines.Count>0);ReadyShrine(sim);sim.Tick(.05f);sim.Tick(.05f);
            var shrine=sim.State.layout.shrines[0];Assert.Greater(shrine.progress,0);
            sim.State.effects.Add(new GroundEffect{id=90001,position=sim.State.position,radius=1,hostile=true,damage=1,duration=.1f});sim.Tick(.05f);
            Assert.AreEqual(ShrinePhase.Available,shrine.phase);Assert.AreEqual(0,shrine.progress);Assert.GreaterOrEqual(shrine.retryAfter,sim.State.time+1.99f);Assert.AreEqual(0,sim.State.guideShrineTime+sim.State.resolveShrineTime);
        }
        [Test]
        public void CursedEventRequiresOptInAndAtLeastNinetySeconds()
        {
            var sim=Find(GameStore.NewAccount(),s=>s.layout.events.Count>0);ReadyCurse(sim,false);sim.Tick(.05f);Assert.AreEqual(RiftEventPhase.Dormant,sim.State.layout.events[0].phase);
            ReadyCurse(sim);sim.State.time=211;sim.Tick(.05f);Assert.AreEqual(RiftEventPhase.Dormant,sim.State.layout.events[0].phase);
            ReadyCurse(sim);sim.State.time=209.9f;sim.Tick(.05f);Assert.AreEqual(RiftEventPhase.Active,sim.State.layout.events[0].phase);Assert.AreEqual(4,sim.State.layout.events[0].enemyIds.Count);
        }
        [Test]
        public void EchoKillsPayNoCombatRewardsAndSuccessfulChestUsesReservedLoot()
        {
            var account=GameStore.NewAccount();var sim=Find(account,s=>s.layout.events.Count>0);ReadyCurse(sim);sim.Tick(.05f);
            var evt=sim.State.layout.events[0];Assert.AreEqual(RiftEventPhase.Active,evt.phase);int inventory=account.Hero.inventory.Count,xp=account.Hero.xp,meter=sim.State.meter;
            foreach(var enemy in sim.State.enemies.Where(e=>e.eventId==evt.id)){enemy.poison=1;enemy.poisonDamage=1000000;}
            sim.State.build.openChests=false;sim.Tick(.05f);Assert.AreEqual(RiftEventPhase.Succeeded,sim.State.layout.events[0].phase);
            Assert.AreEqual(meter,sim.State.meter);Assert.AreEqual(xp,account.Hero.xp);Assert.AreEqual(0,account.gold);Assert.AreEqual(0,account.materials);Assert.AreEqual(inventory,account.Hero.inventory.Count);Assert.IsEmpty(sim.State.drops);
            var chest=sim.State.layout.chests.Single(c=>c.id==evt.chestId);string reward=chest.reward.id;sim.State.build.openChests=true;sim.State.position=chest.openingPosition;
            for(int n=0;n<40;n++)sim.Tick(.05f);
            Assert.AreEqual(ChestPhase.Opened,sim.State.layout.chests.Single(c=>c.id==evt.chestId).phase);Assert.AreEqual(chest.gold,account.gold);Assert.AreEqual(1,account.Hero.inventory.Count(i=>i.id==reward));
            int count=account.Hero.inventory.Count;sim.Tick(.05f);Assert.AreEqual(count,account.Hero.inventory.Count);Assert.AreEqual(4,sim.State.enemies.Count(e=>e.eventId==evt.id));
        }
        [Test]
        public void FailedEventExpiresWhileAwayAndCannotRestartAfterReload()
        {
            var account=GameStore.NewAccount();var sim=Find(account,s=>s.layout.events.Count>0);ReadyCurse(sim);sim.Tick(.05f);
            foreach(var enemy in sim.State.enemies.Where(e=>!string.IsNullOrEmpty(e.eventId))){enemy.attack=0;enemy.health=enemy.maxHealth=1000000;}
            sim.State.paused=true;float remaining=sim.State.layout.events[0].remaining;sim.Tick(.5f);Assert.AreEqual(remaining,sim.State.layout.events[0].remaining);
            sim.State.paused=false;sim.State.portal=true;sim.Tick(.5f);Assert.AreEqual(remaining,sim.State.layout.events[0].remaining);sim.State.portal=false;sim.State.position=sim.State.layout.start;
            for(int n=0;n<250;n++)sim.Tick(.05f);
            var evt=sim.State.layout.events[0];Assert.AreEqual(RiftEventPhase.Failed,evt.phase);Assert.IsTrue(sim.State.enemies.Where(e=>e.eventId==evt.id).All(e=>e.dead));Assert.AreEqual(0,account.gold);
            var copy=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(sim.State));var restored=new CombatSimulation(account,catalog,5,restore:copy);restored.Tick(.05f);
            Assert.AreEqual(RiftEventPhase.Failed,restored.State.layout.events[0].phase);Assert.AreEqual(4,restored.State.enemies.Count(e=>e.eventId==evt.id));Assert.AreEqual(ChestPhase.Exhausted,restored.State.layout.chests.Single(c=>c.id==evt.chestId).phase);
        }
        [Test]
        public void FieldDiskFailureAndRetryDoNotDuplicateEnemiesOrSpendResources()
        {
            string dir=Path.Combine(Path.GetTempPath(),"HellscriptField-"+Guid.NewGuid());
            try
            {
                var store=new GameStore(dir);var sim=Find(store.Data,s=>s.layout.events.Count>0);ReadyCurse(sim);store.Data.suspendedRun=sim.State;
                sim.CommitRunChange=(id,operation,change)=>store.CommitRunMutation(sim.State,id,operation,change);Directory.CreateDirectory(Path.Combine(dir,"hellscript-local-v1.json.tmp"));
                LogAssert.Expect(LogType.Error,new Regex("저장하지 못했습니다:"));sim.Tick(.05f);Assert.IsNotEmpty(sim.State.navigationError);Assert.AreEqual(RiftEventPhase.Dormant,sim.State.layout.events[0].phase);Assert.IsEmpty(sim.State.layout.events[0].enemyIds);Assert.AreEqual(0,store.Data.gold);
                Directory.Delete(Path.Combine(dir,"hellscript-local-v1.json.tmp"));Assert.IsTrue(sim.RetryRiftFault());sim.Tick(.05f);Assert.AreEqual(RiftEventPhase.Active,sim.State.layout.events[0].phase);Assert.AreEqual(4,sim.State.layout.events[0].enemyIds.Count);
                var ids=sim.State.layout.events[0].enemyIds.ToArray();var loaded=new GameStore(dir);var restored=new CombatSimulation(loaded.Data,catalog,5,restore:loaded.Data.suspendedRun);
                CollectionAssert.AreEqual(ids,restored.State.layout.events[0].enemyIds);Assert.AreEqual(4,restored.State.enemies.Count(e=>!string.IsNullOrEmpty(e.eventId)));Assert.AreSame(store.Data.suspendedRun,sim.State);
                Assert.AreEqual(1,store.Data.transactions.Count(t=>t.operation.StartsWith("event-start:")));
            }finally{if(Directory.Exists(dir))Directory.Delete(dir,true);}
        }
        [Test]
        public void ShrineDiskFailurePreservesPendingUseAndRetriesOneBlessing()
        {
            string dir=Path.Combine(Path.GetTempPath(),"HellscriptShrine-"+Guid.NewGuid());
            try
            {
                var store=new GameStore(dir);var sim=Find(store.Data,s=>s.layout.shrines.Count>0);ReadyShrine(sim);store.Data.suspendedRun=sim.State;
                sim.CommitRunChange=(id,op,change)=>store.CommitRunMutation(sim.State,id,op,change);Directory.CreateDirectory(Path.Combine(dir,"hellscript-local-v1.json.tmp"));
                LogAssert.Expect(LogType.Error,new Regex("저장하지 못했습니다:"));for(int n=0;n<13;n++)sim.Tick(.05f);
                Assert.IsNotEmpty(sim.State.navigationError);Assert.AreEqual(ShrinePhase.Invoking,sim.State.layout.shrines[0].phase);Assert.AreEqual(0,sim.State.guideShrineTime+sim.State.resolveShrineTime);Assert.IsEmpty(store.Data.transactions);
                string frozen=JsonUtility.ToJson(sim.State);sim.Tick(.5f);Assert.AreEqual(frozen,JsonUtility.ToJson(sim.State));
                Directory.Delete(Path.Combine(dir,"hellscript-local-v1.json.tmp"));Assert.IsTrue(sim.RetryRiftFault());Assert.AreEqual(ShrinePhase.Used,sim.State.layout.shrines[0].phase);Assert.AreEqual(20,sim.State.guideShrineTime+sim.State.resolveShrineTime);
                var loaded=new GameStore(dir);Assert.AreEqual(20,loaded.Data.suspendedRun.guideShrineTime+loaded.Data.suspendedRun.resolveShrineTime);Assert.AreEqual(1,loaded.Data.transactions.Count);
            }finally{if(Directory.Exists(dir))Directory.Delete(dir,true);}
        }
        [Test]
        public void EventCompletionDiskFailureKeepsSameOutcomeOnRetry()
        {
            string dir=Path.Combine(Path.GetTempPath(),"HellscriptEvent-"+Guid.NewGuid());
            try
            {
                var store=new GameStore(dir);var sim=Find(store.Data,s=>s.layout.events.Count>0);ReadyCurse(sim);store.Data.suspendedRun=sim.State;
                sim.CommitRunChange=(id,op,change)=>store.CommitRunMutation(sim.State,id,op,change);sim.Tick(.05f);
                foreach(var enemy in sim.State.enemies.Where(e=>!string.IsNullOrEmpty(e.eventId))){enemy.poison=1;enemy.poisonDamage=1000000;}
                Directory.CreateDirectory(Path.Combine(dir,"hellscript-local-v1.json.tmp"));LogAssert.Expect(LogType.Error,new Regex("저장하지 못했습니다:"));sim.Tick(.05f);
                Assert.IsNotEmpty(sim.State.navigationError);Assert.AreEqual(RiftEventPhase.Active,sim.State.layout.events[0].phase);Assert.AreEqual(1,store.Data.transactions.Count);
                Directory.Delete(Path.Combine(dir,"hellscript-local-v1.json.tmp"));Assert.IsTrue(sim.RetryRiftFault());Assert.AreEqual(RiftEventPhase.Succeeded,sim.State.layout.events[0].phase);Assert.AreEqual(2,store.Data.transactions.Count);
                var loaded=new GameStore(dir);Assert.AreEqual(RiftEventPhase.Succeeded,loaded.Data.suspendedRun.layout.events[0].phase);Assert.AreEqual(4,loaded.Data.suspendedRun.enemies.Count(e=>!string.IsNullOrEmpty(e.eventId)));Assert.AreEqual(0,loaded.Data.gold);
            }finally{if(Directory.Exists(dir))Directory.Delete(dir,true);}
        }
        [Test]
        public void VersionOneRunKeepsItsManifestAndFutureVersionIsRejected()
        {
            var account=GameStore.NewAccount();var sim=Find(account,s=>s.layout.shrines.Count>0&&s.layout.events.Count>0);var map=sim.State.layout;
            map.version=1;map.shrines.Clear();map.events.Clear();map.obstacles.RemoveAll(o=>o.kind=="Chest"||o.kind=="Shrine");foreach(var c in map.chests)if(c.definitionId=="CH03")c.definitionId="CH01";
            string manifest=JsonUtility.ToJson(map);var saved=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(sim.State));var restored=new CombatSimulation(account,catalog,5,restore:saved);
            Assert.AreEqual(manifest,JsonUtility.ToJson(restored.State.layout));Assert.AreEqual(1,restored.State.layout.version);Assert.IsEmpty(restored.State.layout.shrines);Assert.IsEmpty(restored.State.layout.events);
            saved.layout.version=RiftLayout.CurrentVersion+1;Assert.Throws<NotSupportedException>(()=>GameStore.NormalizeRun(saved));
        }
        [Test]
        public void LeavingRunEndsUnusedFieldContentAndRemovesBuffs()
        {
            var sim=Find(GameStore.NewAccount(),s=>s.layout.events.Count>0&&s.layout.shrines.Count>0);ReadyCurse(sim);sim.Tick(.05f);sim.State.guideShrineTime=10;sim.State.resolveShrineTime=10;sim.Abandon();
            Assert.AreEqual(RiftEventPhase.Cancelled,sim.State.layout.events[0].phase);Assert.AreEqual(ShrinePhase.Exhausted,sim.State.layout.shrines[0].phase);Assert.AreEqual(0,sim.State.guideShrineTime+sim.State.resolveShrineTime);
        }
        [Test]
        public void EnemyMemoryDoesNotFollowHiddenLivePositions()
        {
            var sim=new CombatSimulation(GameStore.NewAccount(),catalog,1,training:0);var enemy=sim.State.enemies[0];var original=enemy.position;
            RiftExploration.ObserveEnemies(sim.State,new[]{enemy});enemy.position=sim.State.layout.rooms[4].position;
            Assert.AreEqual(original,sim.State.exploration.enemies[0].position);Assert.AreEqual(original,RiftExploration.RememberedTarget(sim.State,sim.Map));
            var copy=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(sim.State));Assert.AreEqual(original,copy.exploration.enemies[0].position);
        }
    }
}
