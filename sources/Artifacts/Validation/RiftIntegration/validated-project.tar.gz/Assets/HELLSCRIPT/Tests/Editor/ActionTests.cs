using System;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class ActionTests
    {
        GameCatalog catalog;
        [SetUp]public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown]public void TearDown(){UnityEngine.Object.DestroyImmediate(catalog);}
        CombatSimulation Fixture(int skill,HeroClass basicClass=HeroClass.Warrior)
        {
            var account=GameStore.NewAccount();account.selectedHero=skill<0?(int)basicClass:skill/6;account.Hero.level=30;account.Hero.build.passives=Array.Empty<int>();
            account.Hero.build.rules.Clear();if(skill>=0)account.Hero.build.rules.Add(new Rule(skill,ConditionKind.Always,0,skill==9));
            account.Hero.build.activeSkills.Clear();if(skill>=0)account.Hero.build.activeSkills.Add(skill);else account.Hero.build.rules.Add(BehaviorRules.Utility(RuleAction.Basic));
            account.Hero.build.potionThreshold=0;account.Hero.build.movement=MovementMode.Stand;account.Hero.build.distance=2;
            var sim=new CombatSimulation(account,catalog,1,1,seed:9812);sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();sim.Stats.regen=0;sim.Stats.crit=0;
            float distance=skill==0||skill==2||skill==3||skill==9||skill==17||skill<0&&basicClass==HeroClass.Warrior?2:6;
            sim.State.enemies.Add(new EnemyState{id=900,position=sim.State.position+Vector2.up*distance,health=1000000,maxHealth=1000000,cooldown=1000,attack=0,speed=0});return sim;
        }
        static void Advance(CombatSimulation sim,int ticks)
        {sim.State.decisionTime=100;for(int n=0;n<ticks;n++)sim.Tick(.05f);}
        CombatSimulation Restore(CombatSimulation original)
        {
            var account=GameStore.NewAccount();account.selectedHero=(int)original.Hero.heroClass;account.heroes[account.selectedHero]=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(original.Hero));
            var sim=new CombatSimulation(account,catalog,1,1,JsonUtility.FromJson<RunState>(JsonUtility.ToJson(original.State)));sim.Stats.regen=0;sim.Stats.crit=0;return sim;
        }
        [Test]
        public void EveryNonChannelActionWaitsForItsDeclaredReleaseAndUsesAttackSpeedOnlyWhereAllowed()
        {
            for(int skill=1;skill<18;skill++)
            {
                var sim=Fixture(skill);sim.Tick(.05f);var action=sim.State.heroAction;Assert.AreEqual(skill,action.skill,"skill "+skill);Assert.IsFalse(action.released);Assert.AreEqual(0,sim.State.dealt);Assert.IsEmpty(sim.State.projectiles);Assert.IsEmpty(sim.State.traps);
                var normal=CombatActions.Timing(skill,sim.Hero.heroClass,1);var faster=CombatActions.Timing(skill,sim.Hero.heroClass,1.5f);
                bool scaled=new[]{2,6,7,12,14}.Contains(skill);Assert.AreEqual(normal.prepare/(scaled?1.5f:1),faster.prepare,.0001f);Assert.AreEqual(normal.travel,faster.travel);
                int steps=Mathf.CeilToInt((action.prepare+action.travel)/.05f);Advance(sim,steps-1);Assert.IsFalse(action.released,"early release "+skill);
                Advance(sim,1);Assert.IsTrue(action.released,"missing release "+skill);Assert.AreEqual(1,sim.State.actionEvents.Count(e=>e.skill==skill&&e.kind=="ACTION_RELEASE"));
            }
        }
        [TestCase(1)][TestCase(2)][TestCase(6)][TestCase(7)][TestCase(8)][TestCase(9)][TestCase(12)][TestCase(13)][TestCase(14)][TestCase(15)][TestCase(16)][TestCase(17)]
        public void PreparationOrFlightRestoresExactlyAndAllClocksFreeze(int skill)
        {
            var original=Fixture(skill);
            if(skill==14)original.State.enemies.Add(new EnemyState{id=901,position=original.State.enemies[0].position+Vector2.right*2,health=1000000,maxHealth=1000000,cooldown=1000,speed=0});
            original.Tick(.05f);Advance(original,2);
            original.State.paused=true;string before=JsonUtility.ToJson(original.State);original.Tick(.5f);Assert.AreEqual(before,JsonUtility.ToJson(original.State));
            original.State.paused=false;original.State.portal=true;before=JsonUtility.ToJson(original.State);original.Tick(.5f);Assert.AreEqual(before,JsonUtility.ToJson(original.State));original.State.portal=false;
            var restored=Restore(original);
            for(int n=0;n<50;n++){Advance(original,1);Advance(restored,1);Assert.AreEqual(JsonUtility.ToJson(original.State),JsonUtility.ToJson(restored.State),"replay tick "+n);}
        }
        [Test]
        public void LeapDoesNotTeleportAtStartOrTakeOverMovementTwice()
        {
            var sim=Fixture(1);Vector2 origin=sim.State.position;sim.Tick(.05f);Assert.AreEqual(origin,sim.State.position);Assert.AreEqual(8,sim.State.cooldowns[1]);Advance(sim,3);
            Assert.AreEqual(HeroActionPhase.Travelling,sim.State.heroAction.phase);Assert.AreEqual(origin,sim.State.position);
            Advance(sim,4);Assert.Greater(sim.CombatDistanceFrom(origin),0);Assert.Less(sim.CombatDistanceFrom(origin),6);Assert.AreEqual(0,sim.State.dealt);
            Advance(sim,5);Assert.Greater(sim.State.dealt,0);Assert.AreEqual(origin+Vector2.up*6,sim.State.position);Assert.AreEqual(1,sim.State.actionEvents.Count(e=>e.kind=="ACTION_RELEASE"));
        }
        [Test]
        public void HigherSurvivalRuleInterruptsPreparationWithoutRefundButNeverInterruptsFlight()
        {
            var sim=Fixture(2);sim.State.build.activeSkills.Add(1);sim.State.build.rules.Insert(0,new Rule(1,ConditionKind.HealthBelow,30,true));sim.Tick(.05f);Assert.AreEqual(2,sim.State.heroAction.skill);float paid=sim.State.resource;
            sim.State.health=sim.Stats.hp*.2f;sim.State.decisionTime=0;sim.Tick(.05f);Assert.AreEqual(1,sim.State.heroAction.skill);Assert.AreEqual(paid,sim.State.resource);Assert.IsTrue(sim.State.actionEvents.Any(e=>e.skill==2&&e.kind=="ACTION_INTERRUPTED"));Assert.AreEqual(0,sim.State.dealt);
            Advance(sim,3);Assert.IsTrue(sim.HeroTravelling);sim.State.cooldowns[1]=0;sim.State.decisionTime=0;sim.Tick(.05f);Assert.AreEqual(1,sim.State.actionEvents.Count(e=>e.skill==1&&e.kind=="ACTION_START"));
        }
        [Test]
        public void FireballFliesBeforeImpactKeepsItsSnapshotAndSurvivesAnActionEdit()
        {
            var sim=Fixture(12);sim.Tick(.05f);Advance(sim,14);Assert.AreEqual(1,sim.State.projectiles.Count);Assert.AreEqual(0,sim.State.dealt);
            float damage=sim.State.projectiles[0].snapshot.damage;sim.ApplyBuild(sim.State.build);sim.Stats.damage=999999;sim.Stats.regen=0;sim.Stats.crit=0;Advance(sim,2);
            Assert.Greater(sim.State.projectiles[0].position.y,sim.State.projectiles[0].origin.y);Assert.AreEqual(0,sim.State.dealt);
            var restored=Restore(sim);sim.Stats.damage=restored.Stats.damage;Advance(sim,8);Advance(restored,8);Assert.IsEmpty(sim.State.projectiles);Assert.Greater(sim.State.dealt,0);Assert.Less(sim.State.dealt,damage*3);Assert.AreEqual(sim.State.dealt,restored.State.dealt);
        }
        [TestCase(false,5)][TestCase(true,7)]
        public void PiercingProjectileHitsOnlyItsOrderedTargetBudget(bool passive,int hits)
        {
            var sim=Fixture(6);sim.State.enemies.Clear();sim.Stats.passives[2]=passive;
            for(int n=1;n<=7;n++)sim.State.enemies.Add(new EnemyState{id=900+n,position=sim.State.position+Vector2.up*n,health=1000000,maxHealth=1000000,speed=0,cooldown=1000});
            sim.Tick(.05f);Advance(sim,30);Assert.AreEqual(hits,sim.State.enemies.Count(e=>e.health<e.maxHealth));Assert.IsEmpty(sim.State.projectiles);
            Assert.IsTrue(sim.State.enemies.Take(hits).All(e=>e.health<e.maxHealth));
        }
        [Test]
        public void MultishotHasThreePhysicalArrowsAndSharedHitLimitAndOneShadowCharge()
        {
            float[] dealt=new float[2];for(int variant=0;variant<2;variant++)
            {
                var sim=Fixture(7);sim.State.enemies[0].position=sim.State.position+Vector2.up*1.8f;if(variant==1)sim.Stats.specials.Add("LA02");sim.State.shadowCharges=3;sim.State.shadowTime=8;
                sim.Tick(.05f);Advance(sim,13);Assert.AreEqual(3,sim.State.projectiles.Count);Assert.AreEqual(2,sim.State.shadowCharges);Advance(sim,12);dealt[variant]=sim.State.dealt;Assert.AreEqual(2,sim.State.shadowCharges);
            }
            Assert.AreEqual(dealt[0]*3,dealt[1],.05f);
        }
        [Test]
        public void TrapWaitsForArmingThenTicksForItsDurationAndUntriggeredTrapExpires()
        {
            var sim=Fixture(8);sim.Tick(.05f);Advance(sim,6);Assert.AreEqual(1,sim.State.traps.Count);Assert.AreEqual(.5f,sim.State.traps[0].arm);Advance(sim,9);Assert.IsFalse(sim.State.traps[0].triggered);Assert.AreEqual(0,sim.State.dealt);
            Advance(sim,1);Assert.IsTrue(sim.State.traps[0].triggered);Assert.AreEqual(0,sim.State.dealt);Advance(sim,9);Assert.AreEqual(0,sim.State.dealt);Advance(sim,1);Assert.Greater(sim.State.dealt,0);
            float tick=sim.State.dealt;Advance(sim,90);Assert.IsEmpty(sim.State.traps);Assert.AreEqual(tick*10,sim.State.dealt,.1f);
            sim=Fixture(8);sim.Tick(.05f);Advance(sim,6);sim.State.enemies[0].position=RiftMap.Rooms[4];Advance(sim,169);Assert.AreEqual(1,sim.State.traps.Count);Advance(sim,1);Assert.IsEmpty(sim.State.traps);Assert.AreEqual(0,sim.State.dealt);
        }
        [Test]
        public void EnemyArrowPersistsAfterShooterDiesAndRestoresItsFlight()
        {
            var sim=Fixture(12);sim.State.decisionTime=100;var enemy=sim.State.enemies[0];enemy.kind=2;enemy.windup=.05f;enemy.aim=sim.State.position;enemy.attack=100;sim.Tick(.05f);Assert.AreEqual(1,sim.State.projectiles.Count);
            enemy.dead=true;sim.State.training=-1;Advance(sim,1);Assert.AreEqual(1,sim.State.projectiles.Count);Assert.IsTrue(sim.State.projectiles[0].hostile);
            var restored=Restore(sim);Assert.AreEqual(JsonUtility.ToJson(sim.State.projectiles[0]),JsonUtility.ToJson(restored.State.projectiles[0]));
        }
        [Test]
        public void WhirlwindBeginsWithinThreeMetersMovesIntoAttackRangeAndConsumesFirstTickDiscountOnce()
        {
            var sim=Fixture(0);sim.State.enemies[0].position=sim.State.position+Vector2.up*2.8f;sim.State.build.movement=MovementMode.Orbit;
            sim.State.itemEffects.reducedNext=true;sim.State.itemEffects.lc02Charge=5;sim.Tick(.05f);Assert.AreEqual(HeroActionPhase.Channeling,sim.State.heroAction.phase);Assert.AreEqual(100,sim.State.resource);
            Advance(sim,4);Assert.AreEqual(100,sim.State.resource);Advance(sim,1);Assert.AreEqual(97,sim.State.resource);Assert.IsFalse(sim.State.itemEffects.reducedNext);
            Advance(sim,5);Assert.AreEqual(91,sim.State.resource);Assert.Greater(sim.State.dealt,0);Assert.That(Vector2.Distance(sim.State.position,sim.State.enemies[0].position),Is.InRange(1.8f,2.5f));
            sim.State.enemies[0].position=RiftMap.Rooms[4];Advance(sim,9);Assert.IsTrue(sim.HeroActionBusy);Advance(sim,1);Assert.IsFalse(sim.HeroActionBusy);
        }
        [Test]
        public void ProjectileWidthStopsAtThinBlockerWithoutApplyingDamageThroughIt()
        {
            var sim=Fixture(6);sim.State.layout.legacy=false;sim=Restore(sim);
            sim.Tick(.05f);Advance(sim,13);Assert.AreEqual(1,sim.State.projectiles.Count);
            sim.State.layout.obstacles.Add(new RiftObstacle{id="test-projectile-wall",position=sim.State.position+Vector2.up*3,halfSize=new Vector2(2,.025f),blocksSight=false,blocksWalk=false,blocksProjectile=true});
            Assert.IsTrue(sim.Map.LineClear(sim.State.position,sim.State.enemies[0].position));
            Advance(sim,10);Assert.IsEmpty(sim.State.projectiles);Assert.AreEqual(0,sim.State.dealt);
        }
        [Test]
        public void BlockedShotRepositionsWithoutSpendingAndRestoresTheSameRoute()
        {
            var sim=Fixture(6);sim.State.layout.legacy=false;sim.State.build.movement=MovementMode.KeepDistance;sim.State.build.distance=6;
            sim.State.layout.obstacles.Add(new RiftObstacle{id="shot-cover",position=sim.State.position+Vector2.up*3,halfSize=new Vector2(2,.1f),blocksSight=false,blocksWalk=true,blocksProjectile=true});sim=Restore(sim);
            Vector2 origin=sim.State.position;sim.Tick(.05f);Assert.AreEqual(100,sim.State.resource);Assert.IsFalse(sim.HeroActionBusy);Assert.IsEmpty(sim.State.projectiles);
            Assert.Greater(Vector2.Distance(origin,sim.State.position),0);var restored=Restore(sim);
            for(int n=0;n<200&&sim.State.dealt<=0;n++){sim.Tick(.05f);restored.Tick(.05f);Assert.AreEqual(JsonUtility.ToJson(sim.State),JsonUtility.ToJson(restored.State));}
            Assert.Greater(sim.State.dealt,0);Assert.Greater(Vector2.Distance(origin,sim.State.position),1);
        }
        [Test]
        public void RiftPresetCannotChangeLoadoutResetCombatOrCancelExistingProjectile()
        {
            var sim=Fixture(6);sim.Tick(.05f);Advance(sim,13);sim.State.training=-1;
            sim.State.build.passives=new[]{0,2,5};sim.State.build.equipmentIds.Add("equipped-item");
            var proposed=GameCatalog.Preset(HeroClass.Ranger,1);proposed.version="edited";proposed.passives=new[]{1,3,4};proposed.equipmentIds.Add("different-item");proposed.distance=8;
            float hp=sim.State.health,resource=sim.State.resource;var cooldowns=(float[])sim.State.cooldowns.Clone();var stats=sim.Stats;string shots=JsonUtility.ToJson(sim.State.projectiles[0]);
            sim.ApplyBuild(proposed);Assert.AreSame(stats,sim.Stats);Assert.AreEqual(hp,sim.State.health);Assert.AreEqual(resource,sim.State.resource);CollectionAssert.AreEqual(cooldowns,sim.State.cooldowns);
            CollectionAssert.AreEqual(new[]{6},sim.State.build.activeSkills);CollectionAssert.AreEqual(new[]{0,2,5},sim.State.build.passives);CollectionAssert.AreEqual(new[]{"equipped-item"},sim.State.build.equipmentIds);
            Assert.AreEqual(8,sim.State.build.distance);Assert.AreEqual("edited",sim.State.build.version);Assert.AreEqual(shots,JsonUtility.ToJson(sim.State.projectiles[0]));
            Assert.AreEqual(JsonUtility.ToJson(sim.State.build),JsonUtility.ToJson(sim.Hero.build));
            var omitted=proposed.Copy();omitted.rules.RemoveAll(r=>r.skill==6);sim.ApplyBuild(omitted);CollectionAssert.AreEqual(new[]{6},sim.State.build.activeSkills);Assert.IsFalse(sim.State.build.rules.Any(r=>r.action==RuleAction.Skill&&r.skill==6));
        }
        [Test]
        public void TrainingLoadoutChangesStayInsideTheTrainingCopy()
        {
            var sim=Fixture(6);string saved=JsonUtility.ToJson(sim.Hero.build);var proposed=GameCatalog.Preset(HeroClass.Ranger,1);proposed.passives=new[]{1,3,4};
            sim.ApplyBuild(proposed);CollectionAssert.AreEqual(proposed.rules.Select(r=>r.skill),sim.State.build.rules.Select(r=>r.skill));CollectionAssert.AreEqual(proposed.passives,sim.State.build.passives);
            Assert.AreEqual(saved,JsonUtility.ToJson(sim.Hero.build));var restored=Restore(sim);CollectionAssert.AreEqual(sim.Stats.passives,restored.Stats.passives);
        }
        [TestCase(HeroClass.Warrior,10)][TestCase(HeroClass.Ranger,6)][TestCase(HeroClass.Mage,5)]
        public void BasicAttackRestoresResourceOnActualHitOnly(HeroClass hero,int gain)
        {
            var sim=Fixture(-1,hero);sim.State.resource=50;sim.Tick(.05f);Assert.AreEqual(50,sim.State.resource);Advance(sim,3);Assert.AreEqual(0,sim.State.dealt);Assert.AreEqual(50,sim.State.resource);
            Advance(sim,16);Assert.Greater(sim.State.dealt,0);Assert.AreEqual(50+gain,sim.State.resource);
        }
        [Test]
        public void OldAlreadyAppliedActionMigratesAsRecoveryWithoutRepeatingItsEffect()
        {
            var sim=Fixture(4);sim.State.combatVersion=0;sim.State.effectVersion=0;sim.State.activeSkill=4;sim.State.actionCd=.15f;sim.State.shield=123;sim.State.shieldTime=3;
            GameStore.NormalizeRun(sim.State);Assert.AreEqual(HeroActionPhase.Recovering,sim.State.heroAction.phase);Advance(sim,3);Assert.AreEqual(123,sim.State.shield);Assert.IsFalse(sim.HeroActionBusy);Assert.IsFalse(sim.State.actionEvents.Any(e=>e.kind=="ACTION_RELEASE"));
            sim.State.combatVersion=CombatActions.Version+1;Assert.Throws<NotSupportedException>(()=>GameStore.NormalizeRun(sim.State));
        }
    }
    static class ActionTestDistance
    {public static float CombatDistanceFrom(this CombatSimulation sim,Vector2 point)=>Vector2.Distance(sim.State.position,point);}
}
