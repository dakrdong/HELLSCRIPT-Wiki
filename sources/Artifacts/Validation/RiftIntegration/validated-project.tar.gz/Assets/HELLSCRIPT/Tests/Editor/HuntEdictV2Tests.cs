using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class HuntEdictV2Tests
    {
        GameCatalog catalog;
        static string Json(object value)=>JsonUtility.ToJson(value);
        [SetUp]public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown]public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        static HeroSave Hero(HeroClass hero,int level=30){var a=GameStore.NewAccount();a.selectedHero=(int)hero;a.Hero.level=level;a.Hero.inventory.Clear();a.Hero.build.passives=Array.Empty<int>();return a.Hero;}
        static void Equip(HeroSave hero,string id)
        {
            var definition=ItemCatalog.Unique(id);uint rng=883921;foreach(var item in hero.inventory.Where(i=>i.slot==definition.slot))item.equipped=false;
            var gear=ItemGenerator.Create(hero.heroClass,definition.slot,3,30,ref rng,uniqueId:id);gear.equipped=true;hero.inventory.Add(gear);
        }
        static string Wrap(byte[] bytes)
        {using(var sha=SHA256.Create())return "HED2."+Convert.ToBase64String(bytes).TrimEnd('=').Replace('+','-').Replace('/','_')+"."+string.Concat(sha.ComputeHash(bytes).Select(b=>b.ToString("x2")));}
        static string Wrap(string json)=>Wrap(Encoding.UTF8.GetBytes(json));
        [Test]
        public void EveryCoreOptionMatchesTheAuthoritativeDesignTableIncludingChoicesAndDefaults()
        {
            var path=Path.Combine(Application.dataPath,"../Docs/Design/HELLSCRIPT_Hunt_Edict_Skill_Option_Catalog.md");
            var rows=File.ReadAllLines(path).Where(l=>l.StartsWith("| HEC-",StringComparison.Ordinal)).Select(l=>l.Split('|').Skip(1).Select(c=>c.Trim()).ToArray()).ToArray();
            var definitions=HuntEdictV2Options.All.ToArray();Assert.AreEqual(89,rows.Length);Assert.AreEqual(89,definitions.Length);CollectionAssert.AreEquivalent(rows.Select(r=>r[0]),definitions.Select(d=>d.id));
                foreach(var row in rows)
                {
                    var d=definitions.Single(x=>x.id==row[0]);Assert.AreEqual(row[1],d.label,d.id);
                    string text=row[2].Replace("**","");var defaultMatch=Regex.Match(text,@"[.·]\s*기본\s+(.+)$");Assert.IsTrue(defaultMatch.Success,d.id);
                    string choices=text.Substring(0,defaultMatch.Index).Trim(' ','.','·'),initial=defaultMatch.Groups[1].Value.Trim(' ','.','·');
                    Assert.AreEqual(initial,d.Describe(d.initial),d.id+" default");
                    if(d.Numeric){Assert.AreEqual("HEC-W02-04",d.id);Assert.That(choices,Does.Contain("2–8m").And.Contain("0.5m"));Assert.AreEqual(2,d.min);Assert.AreEqual(8,d.max);Assert.AreEqual(.5m,d.step);}
                    else CollectionAssert.AreEqual(choices.Split('/').Select(c=>c.Trim()),d.choiceLabels,d.id+" choices");
                }
            foreach(string hero in HuntEdict.ClassIds)foreach(string skill in HuntEdictV2.SkillIds(hero))Assert.That(HuntEdictV2Options.ForSkill(skill,hero).Count,Is.InRange(4,5));
        }
        [TestCase(HeroClass.Warrior)][TestCase(HeroClass.Ranger)][TestCase(HeroClass.Mage)]
        public void EveryChoiceAndNumberBoundaryRoundTripsWithoutAddingHiddenRules(HeroClass hero)
        {
            var d=HuntEdictV2.Create(hero);string before=Json(d);var code=HuntEdictV2Codec.Encode(d);
            Assert.AreEqual(code,HuntEdictV2Codec.Encode(HuntEdictV2Codec.Decode(code)));Assert.AreEqual(before,Json(d));
            foreach(string skill in HuntEdictV2.SkillIds(d.heroClass))foreach(var option in HuntEdictV2Options.ForSkill(skill,d.heroClass))
            {
                var choices=option.Numeric?new[]{"2","2.5","4","7.5","8"}:option.choices;
                foreach(string value in choices)
                {
                    int n=int.Parse(option.id.Substring(option.id.Length-2),CultureInfo.InvariantCulture);
                    var variant=HuntEdictV2.WithOption(d,skill,n,value);string encoded=HuntEdictV2Codec.Encode(variant);var restored=HuntEdictV2Codec.Decode(encoded);
                    Assert.AreEqual(value,HuntEdictV2.Value(restored,skill,n),option.id);Assert.AreEqual(encoded,HuntEdictV2Codec.Encode(restored));Assert.AreEqual(before,Json(d));
                }
            }
            var fields=typeof(HuntEdictV2Document).GetFields().Select(f=>f.Name).ToArray();Assert.IsFalse(fields.Any(f=>f=="rules"||f=="actions"||f=="health"||f=="resource"||f=="cooldowns"||f=="passives"||f=="equipmentIds"));
            CollectionAssert.AreEquivalent(new[]{"id","options"},typeof(EdictCoreSkill).GetFields().Select(f=>f.Name));
        }
        [TestCase(HeroClass.Warrior)][TestCase(HeroClass.Ranger)][TestCase(HeroClass.Mage)]
        public void CanonicalCodesPreserveAllValuesAndStayCompactAtMaximumContent(HeroClass hero)
        {
            var d=HuntEdictV2.Create(hero);d.slots=HuntEdict.SkillIds(d.heroClass).Take(4).ToArray();d.skillOrder=d.skillOrder.Reverse().ToArray();
            foreach(var option in d.global)
            {
                var def=EdictOptions.Global.Single(o=>o.id==option.id);
                option.value=def.kind==EdictOptionKind.Toggle?"ON":def.kind==EdictOptionKind.Number?def.max.ToString(CultureInfo.InvariantCulture):
                    def.kind==EdictOptionKind.Choice?def.choices.Last():def.kind==EdictOptionKind.Set||def.kind==EdictOptionKind.Order?string.Join(",",def.choices):def.choices.LastOrDefault(s=>HuntEdict.SkillIds(d.heroClass).Contains(s))??"";
            }
            foreach(var skill in d.skills)foreach(var option in skill.options)
            {var def=HuntEdictV2Options.ForSkill(skill.id,d.heroClass).Single(o=>o.id==option.id);option.value=def.Numeric?def.max.ToString(CultureInfo.InvariantCulture):def.choices.Last();}
            var canonical=HuntEdictV2.Canonical(d);string code=HuntEdictV2Codec.Encode(d);int bytes=Encoding.UTF8.GetByteCount(HuntEdictV2Codec.CanonicalJson(d));
            Assert.Less(code.Length,6000,"A share code should remain practical without dropping any stored choices.");
            Assert.AreEqual(Json(canonical),Json(HuntEdictV2Codec.Decode(code)));Assert.Less(bytes,HuntEdictV2Codec.MaxJsonBytes);
            d.global.Reverse();d.skills.Reverse();foreach(var skill in d.skills)skill.options.Reverse();Assert.AreEqual(code,HuntEdictV2Codec.Encode(d));
            var culture=CultureInfo.CurrentCulture;try{CultureInfo.CurrentCulture=new CultureInfo("ko-KR");Assert.AreEqual(code,HuntEdictV2Codec.Encode(d));CultureInfo.CurrentCulture=new CultureInfo("de-DE");Assert.AreEqual(code,HuntEdictV2Codec.Encode(d));}finally{CultureInfo.CurrentCulture=culture;}
            var directory=Path.Combine(Application.dataPath,"../Artifacts/Validation/EdictV2Codes");Directory.CreateDirectory(directory);
            File.WriteAllText(Path.Combine(directory,d.heroClass+"-maximum.txt"),code);File.WriteAllText(Path.Combine(directory,d.heroClass+"-maximum.json"),Json(canonical));
            TestContext.WriteLine(d.heroClass+": max JSON bytes="+bytes+", code characters="+code.Length);
        }
        [TestCase(HeroClass.Warrior)][TestCase(HeroClass.Ranger)][TestCase(HeroClass.Mage)]
        public void SlotMovesRemovalAndReequippingPreserveInactiveOptionsAndSharedOrder(HeroClass heroClass)
        {
            var hero=Hero(heroClass);var d=HuntEdictV2.Create(heroClass);var skills=HuntEdict.SkillIds(d.heroClass);
            d=HuntEdictV2.WithOption(d,skills[0],1,"OFF");d=HuntEdictV2.WithSlot(d,0,skills[0],hero,catalog);d=HuntEdictV2.WithSlot(d,1,skills[1],hero,catalog);
            var state=Json(d.skills[0]);var order=d.skillOrder.ToArray();string before=Json(d);
            var swapped=HuntEdictV2.WithSlot(d,1,skills[0],hero,catalog);CollectionAssert.AreEqual(new[]{skills[1],skills[0],"",""},swapped.slots);Assert.AreEqual(before,Json(d));
            var removed=HuntEdictV2.WithSlot(swapped,1,"",hero,catalog);var restored=HuntEdictV2Codec.Decode(HuntEdictV2Codec.Encode(removed));restored=HuntEdictV2.WithSlot(restored,3,skills[0],hero,catalog);
            Assert.AreEqual(state,Json(restored.skills.Single(s=>s.id==skills[0])));CollectionAssert.AreEqual(order,restored.skillOrder);Assert.IsFalse(HuntEdictV2.Automatic(restored,skills[0]));
            hero.level=1;Assert.Throws<ArgumentException>(()=>HuntEdictV2.WithSlot(d,2,skills[5],hero,catalog));Assert.AreEqual(before,Json(d));
        }
        [TestCase(HeroClass.Warrior)][TestCase(HeroClass.Ranger)][TestCase(HeroClass.Mage)]
        public void PartialImportKeepsOriginalSlotsReferencesAndAllInactiveChoices(HeroClass heroClass)
        {
            var hero=Hero(heroClass,1);var d=HuntEdictV2.Create(heroClass);var skills=HuntEdict.SkillIds(d.heroClass);d.slots=new[]{skills[1],skills[0],skills[5],skills[2]};
            d.global.Single(o=>o.id=="survival.escapeSkill").value=heroClass==HeroClass.Warrior?"W02":heroClass==HeroClass.Ranger?"A04":"M04";
            d=HuntEdictV2.WithOption(d,skills[5],1,"OFF");string code=HuntEdictV2Codec.Encode(d),before=Json(hero);var preview=HuntEdictV2Import.Prepare(code,hero,catalog);
            CollectionAssert.AreEqual(new[]{"",skills[0],"",""},preview.Draft.slots);Assert.AreEqual(3,preview.MissingSkills.Count);Assert.IsTrue(preview.Partial);
            Assert.AreEqual(code,preview.OriginalCode);Assert.AreEqual(code,HuntEdictV2Codec.Encode(preview.Original));Assert.AreEqual(before,Json(hero));
            CollectionAssert.AreEqual(d.skillOrder,preview.Draft.skillOrder);Assert.AreEqual(Json(d.skills[5]),Json(preview.Draft.skills[5]));
            Assert.AreEqual(d.global.Single(o=>o.id=="survival.escapeSkill").value,preview.Draft.global.Single(o=>o.id=="survival.escapeSkill").value);
            var independent=preview.Original;independent.skills.Clear();Assert.AreEqual(7,preview.Original.skills.Count);
            Assert.AreNotEqual(code,HuntEdictV2Codec.Encode(preview.Draft));Assert.AreEqual(before,Json(hero));
        }
        [TestCase("future-schema")][TestCase("future-content")][TestCase("future-global")][TestCase("future-options")][TestCase("future-policy")]
        [TestCase("duplicate-root")][TestCase("missing-root")][TestCase("unknown-root")][TestCase("missing-values")][TestCase("unknown-skill")]
        [TestCase("unknown-choice")][TestCase("legacy-rules")][TestCase("json-whitespace")][TestCase("bad-depth")][TestCase("wrong-class-slot")]
        public void MalformedEvenCorrectlyChecksummedWireDataIsRejected(string kind)
        {
            string original=HuntEdictV2Codec.CanonicalJson(HuntEdictV2.Create(HeroClass.Warrior)),json=original;
            switch(kind)
            {
                case "future-schema":json=json.Replace("\"schema\":2","\"schema\":3");break;
                case "future-content":json=json.Replace("\"contentVersion\":1","\"contentVersion\":2");break;
                case "future-global":json=json.Replace("\"globalVersion\":1","\"globalVersion\":2");break;
                case "future-options":json=json.Replace("\"optionVersion\":2","\"optionVersion\":3");break;
                case "future-policy":json=json.Replace("\"policyVersion\":1","\"policyVersion\":2");break;
                case "duplicate-root":json=json.Insert(1,"\"schema\":2,");break;
                case "missing-root":json=json.Replace("\"schema\":2,","");break;
                case "unknown-root":json=json.Insert(1,"\"unknown\":false,");break;
                case "missing-values":json=json.Replace("\"ON\",\"ANY\",\"GLOBAL\",\"CONTINUE\"","\"ON\",\"ANY\",\"GLOBAL\"");break;
                case "unknown-skill":json=json.Replace("\"id\":\"W01\"","\"id\":\"W99\"");break;
                case "unknown-choice":json=json.Replace("\"CONTINUE\"","\"SECRET\"");break;
                case "legacy-rules":json=json.Insert(1,"\"rules\":[{\"groups\":[]}],");break;
                case "json-whitespace":json=" "+json;break;
                case "bad-depth":json="["+new string('[',20)+"0"+new string(']',21);break;
                case "wrong-class-slot":json=json.Replace("\"slots\":[\"\",\"\",\"\",\"\"]","\"slots\":[\"A01\",\"\",\"\",\"\"]");break;
            }
            Assert.AreNotEqual(original,json,"Fixture did not mutate the payload.");Assert.IsFalse(HuntEdictV2Codec.TryDecode(Wrap(json),out var value,out string error));Assert.IsNull(value);Assert.IsNotEmpty(error);
        }
        [TestCase("NaN")][TestCase("Infinity")][TestCase("1.5")][TestCase("8.5")][TestCase("2.1")][TestCase("")][TestCase("1,5")]
        public void NumericOptionsRejectInvalidValuesWithoutMutatingTheDraft(string value)
        {var d=HuntEdictV2.Create(HeroClass.Warrior);string before=Json(d);Assert.Throws<ArgumentException>(()=>HuntEdictV2.WithOption(d,"W02",4,value));Assert.AreEqual(before,Json(d));}
        [Test]
        public void CodecRejectsInvalidUtf8ChecksumLargeInputAndOldFormatWithoutReinterpretingIt()
        {
            Assert.IsFalse(HuntEdictV2Codec.TryDecode(Wrap(new byte[]{0xff,0xfe}),out _,out _));
            Assert.IsFalse(HuntEdictV2Codec.TryDecode(new string('x',HuntEdictV2Codec.MaxCodeCharacters+1),out _,out _));
            string code=HuntEdictV2Codec.Encode(HuntEdictV2.Create(HeroClass.Mage));Assert.IsFalse(HuntEdictV2Codec.TryDecode(code.Substring(0,code.Length-1)+(code.EndsWith("0")?"1":"0"),out _,out _));
            string old=HuntEdictCodec.Encode(HuntEdict.Create(HeroClass.Mage));Assert.IsFalse(HuntEdictV2Codec.TryDecode(old,out _,out _));Assert.AreEqual(old,HuntEdictCodec.Encode(HuntEdictCodec.Decode(old)));
        }
        [Test]
        public void NoncanonicalNumberAndDuplicateNestedFieldsCannotAcquireNewMeaning()
        {
            var d=HuntEdictV2.Create(HeroClass.Warrior);var normalized=HuntEdictV2.WithOption(d,"W02",4,"4.00");Assert.AreEqual("4",HuntEdictV2.Value(normalized,"W02",4));
            string json=HuntEdictV2Codec.CanonicalJson(d),numeric=json.Replace("\"TARGET\",\"4\",\"GLOBAL\"","\"TARGET\",\"4.00\",\"GLOBAL\"");
            Assert.AreNotEqual(json,numeric);Assert.IsFalse(HuntEdictV2Codec.TryDecode(Wrap(numeric),out _,out _));
            string duplicate=json.Replace("\"id\":\"W01\"","\"id\":\"W01\",\"id\":\"W01\"");Assert.IsFalse(HuntEdictV2Codec.TryDecode(Wrap(duplicate),out _,out _));
            string added=json.Replace("\"id\":\"W01\"","\"id\":\"W01\",\"automatic\":true");Assert.IsFalse(HuntEdictV2Codec.TryDecode(Wrap(added),out _,out _));
            var definition=HuntEdictV2Options.ForSkill("W01","WARRIOR")[1];Assert.Throws<NotSupportedException>(()=>((IList<string>)definition.choices).Add("HIDDEN"));
        }
        [Test]
        public void InvalidStructureWrongReceiverAndConflictingCatalogDoNotChangeInputs()
        {
            var hero=Hero(HeroClass.Warrior);var d=HuntEdictV2.Create(HeroClass.Mage);string before=Json(hero),source=Json(d);
            Assert.Throws<ArgumentException>(()=>HuntEdictV2Import.Prepare(HuntEdictV2Codec.Encode(d),hero,catalog));Assert.AreEqual(before,Json(hero));Assert.AreEqual(source,Json(d));
            d=HuntEdictV2.Create(HeroClass.Warrior);catalog.skills.Add(catalog.skills[0]);Assert.Throws<ArgumentException>(()=>HuntEdictV2Import.Prepare(HuntEdictV2Codec.Encode(d),hero,catalog));
            d.skills[0].options.Add(new EdictOption("hidden","ON"));Assert.Throws<ArgumentException>(()=>HuntEdictV2Codec.Encode(d));
            d=HuntEdictV2.Create(HeroClass.Warrior);d.skills.RemoveAt(6);Assert.Throws<ArgumentException>(()=>HuntEdictV2Codec.Encode(d));
            d=HuntEdictV2.Create(HeroClass.Warrior);d.skillOrder[1]=d.skillOrder[0];Assert.Throws<ArgumentException>(()=>HuntEdictV2Codec.Encode(d));
        }
        [Test]
        public void MissingEquipmentProducesSpecificFallbackOrUnavailableReasonsWithoutChangingSourceValues()
        {
            var hero=Hero(HeroClass.Mage);var d=HuntEdictV2.Create(HeroClass.Mage);d.slots=new[]{"M02","M03","M06","M01"};
            d=HuntEdictV2.WithOption(d,"M02",5,"FOLLOW");d=HuntEdictV2.WithOption(d,"M03",4,"TOTAL_HITS");d=HuntEdictV2.WithOption(d,"M03",2,"SAVE_CHARGE");d=HuntEdictV2.WithOption(d,"M01",2,"EXPOSURE");
            string code=HuntEdictV2Codec.Encode(d);var issues=HuntEdictV2Availability.Inspect(d,hero,catalog);
            Assert.AreEqual("FIXED",issues.Single(i=>i.optionId=="HEC-M02-05").fallbackValue);Assert.AreEqual("UNIQUE",issues.Single(i=>i.optionId=="HEC-M03-04").fallbackValue);Assert.AreEqual("LINKED",issues.Single(i=>i.optionId=="HEC-M03-02").fallbackValue);
            Assert.AreEqual("STEADY",issues.Single(i=>i.optionId=="HEC-M01-02").fallbackValue);Assert.AreEqual(code,HuntEdictV2Codec.Encode(d));
            Equip(hero,"LM01");issues=HuntEdictV2Availability.Inspect(d,hero,catalog);Assert.IsFalse(issues.Any(i=>i.optionId=="HEC-M02-05"));Assert.AreEqual(code,HuntEdictV2Codec.Encode(d));
        }
        [Test]
        public void RangerRetreatTrapUsesActualGearAndEquippedTrapEvenWhenAutomaticInstallationIsOff()
        {
            var hero=Hero(HeroClass.Ranger);var d=HuntEdictV2.Create(HeroClass.Ranger);d.slots=new[]{"A03","A04","A01","A06"};
            d=HuntEdictV2.WithOption(d,"A04",2,"TRAP_LINK");d=HuntEdictV2.WithOption(d,"A03",1,"OFF");
            Assert.IsTrue(HuntEdictV2Availability.Inspect(d,hero,catalog).Any(i=>i.optionId=="HEC-A04-02"));Equip(hero,"LA03");
            Assert.IsFalse(HuntEdictV2Availability.Inspect(d,hero,catalog).Any(i=>i.optionId=="HEC-A04-02"));d=HuntEdictV2.WithSlot(d,0,"",hero,catalog);
            Assert.IsTrue(HuntEdictV2Availability.Inspect(d,hero,catalog).Any(i=>i.optionId=="HEC-A04-02"));Assert.AreEqual("TRAP_LINK",HuntEdictV2.Value(d,"A04",2));
        }
        [Test]
        public void ConflictsAndUnavailableReferencesAreReadableWithoutDiscardingStoredSelections()
        {
            var hero=Hero(HeroClass.Warrior);var d=HuntEdictV2.Create(HeroClass.Warrior);d.slots[0]="W03";d=HuntEdictV2.WithOption(d,"W03",3,"ISOLATED");d=HuntEdictV2.WithOption(d,"W03",4,"GROUP");
            Assert.IsTrue(HuntEdictV2Availability.Inspect(d,hero,catalog).Any(i=>i.kind==EdictConfigurationIssueKind.Conflict));Assert.DoesNotThrow(()=>HuntEdictV2Codec.Encode(d));
            hero=Hero(HeroClass.Ranger);d=HuntEdictV2.Create(HeroClass.Ranger);d.slots[0]="A06";d=HuntEdictV2.WithOption(d,"A06",3,"A01");
            var issue=HuntEdictV2Availability.Inspect(d,hero,catalog).Single(i=>i.optionId=="HEC-A06-03");Assert.AreEqual(EdictConfigurationIssueKind.Unavailable,issue.kind);Assert.AreEqual("A01",issue.originalValue);
            d=HuntEdictV2.WithSlot(d,1,"A01",hero,catalog);Assert.IsFalse(HuntEdictV2Availability.Inspect(d,hero,catalog).Any(i=>i.optionId=="HEC-A06-03"));
            d=HuntEdictV2.WithOption(d,"A01",1,"OFF");Assert.IsTrue(HuntEdictV2Availability.Inspect(d,hero,catalog).Any(i=>i.optionId=="HEC-A06-03"));
        }
        [Test]
        public void WarriorChargeLinkRequiresTheActualFourPieceSetAndAvailableFollowup()
        {
            var hero=Hero(HeroClass.Warrior);var d=HuntEdictV2.Create(HeroClass.Warrior);d.slots=new[]{"W01","W02","",""};d=HuntEdictV2.WithOption(d,"W01",4,"LEAP_CHARGE");
            Assert.AreEqual("CONTINUE",HuntEdictV2Availability.Inspect(d,hero,catalog).Single(i=>i.optionId=="HEC-W01-04").fallbackValue);
            for(int n=1;n<=4;n++)Equip(hero,"SW"+n);Assert.AreEqual(4,new HeroStats(hero).SetPieces("SW"));
            Assert.IsFalse(HuntEdictV2Availability.Inspect(d,hero,catalog).Any(i=>i.optionId=="HEC-W01-04"));
            d=HuntEdictV2.WithOption(d,"W02",1,"OFF");Assert.AreEqual("CONTINUE",HuntEdictV2Availability.Inspect(d,hero,catalog).Single(i=>i.optionId=="HEC-W01-04").fallbackValue);Assert.AreEqual("LEAP_CHARGE",HuntEdictV2.Value(d,"W01",4));
        }
        [Test]
        public void MissingFocusWeaponDoesNotInventAFallbackAndAmbushConflictKeepsBothChoices()
        {
            var hero=Hero(HeroClass.Ranger);var d=HuntEdictV2.Create(HeroClass.Ranger);d.slots=new[]{"A02","A03","",""};d=HuntEdictV2.WithOption(d,"A02",2,"FOCUS");
            var issue=HuntEdictV2Availability.Inspect(d,hero,catalog).Single(i=>i.optionId=="HEC-A02-02");Assert.AreEqual(EdictConfigurationIssueKind.Unavailable,issue.kind);Assert.AreEqual("",issue.fallbackValue);
            Equip(hero,"LA02");Assert.IsFalse(HuntEdictV2Availability.Inspect(d,hero,catalog).Any(i=>i.optionId=="HEC-A02-02"));Assert.AreEqual(4,d.skills.Single(s=>s.id=="A02").options.Count);
            d=HuntEdictV2.WithOption(d,"A03",3,"AMBUSH");Assert.AreEqual(EdictConfigurationIssueKind.Conflict,HuntEdictV2Availability.Inspect(d,hero,catalog).Single(i=>i.optionId=="HEC-A03-03").kind);
            d=HuntEdictV2.WithOption(d,"A03",2,"SELF");Assert.IsFalse(HuntEdictV2Availability.Inspect(d,hero,catalog).Any(i=>i.optionId=="HEC-A03-03"));Assert.AreEqual(EdictConfigurationIssueKind.Inactive,HuntEdictV2Availability.Inspect(d,hero,catalog).Single(i=>i.optionId=="HEC-A03-05").kind);Assert.AreEqual("NEW_TARGET",HuntEdictV2.Value(d,"A03",5));
        }
        [Test]
        public void FrostChargeChoiceRetainsItsOriginalValueWhenItsEquippedFollowupIsSwitchedOff()
        {
            var hero=Hero(HeroClass.Mage);for(int n=1;n<=4;n++)Equip(hero,"SMB"+n);Assert.AreEqual(4,new HeroStats(hero).SetPieces("SMB"));
            var d=HuntEdictV2.Create(HeroClass.Mage);d.slots=new[]{"M03","M06","",""};d=HuntEdictV2.WithOption(d,"M06",2,"CHAIN_CHARGE");
            Assert.IsFalse(HuntEdictV2Availability.Inspect(d,hero,catalog).Any(i=>i.optionId=="HEC-M06-02"));d=HuntEdictV2.WithOption(d,"M03",1,"OFF");
            Assert.AreEqual("CONTROL",HuntEdictV2Availability.Inspect(d,hero,catalog).Single(i=>i.optionId=="HEC-M06-02").fallbackValue);Assert.AreEqual("CHAIN_CHARGE",HuntEdictV2.Value(d,"M06",2));
        }
        [Test]
        public void LegacyPreviewRetainsOriginalAndRequiresExplicitDraftAcceptanceWithItemizedChanges()
        {
            var hero=Hero(HeroClass.Mage,1);var old=HuntEdict.Create(HeroClass.Mage);old.slots=new[]{"M02","M01","M06","M03"};
            var rule=old.rules.Single(r=>r.actionId=="M02");rule.areaAim="Self";rule.blizzardMode="Follow";rule.options.Single(o=>o.id=="area.preserve").value="WAIT_AT_CAP";
            old.actions.Single(a=>a.id=="M01").automatic=false;old.global.Single(o=>o.id=="bag.cleanupAt").value="OFF";
            string code=HuntEdictCodec.Encode(old),before=Json(hero);var preview=HuntEdictV2LegacyPreview.Prepare(code,hero,catalog);
            Assert.AreEqual(code,preview.OriginalCode);Assert.AreEqual(code,HuntEdictCodec.Encode(preview.Original));Assert.AreEqual(before,Json(hero));Assert.AreEqual(3,preview.MissingSkills.Count);
            Assert.IsTrue(preview.Changes.Any(c=>c.target=="HEC-M02-03"&&c.copiedValue));Assert.IsTrue(preview.Changes.Any(c=>c.target=="기존 규칙 제외"));Assert.IsTrue(preview.Changes.Any(c=>c.detail.Contains("새 기본값")));
            var draft=preview.AcceptAsDraft();Assert.AreEqual("SELF",HuntEdictV2.Value(draft,"M02",3));Assert.AreEqual("FOLLOW",HuntEdictV2.Value(draft,"M02",5));Assert.AreEqual("KEEP",HuntEdictV2.Value(draft,"M02",4));Assert.IsFalse(HuntEdictV2.Automatic(draft,"M01"));
            Assert.AreEqual("OFF",draft.global.Single(o=>o.id=="bag.cleanupAt").value);draft.skills.Clear();Assert.AreEqual(7,preview.Proposal.skills.Count);Assert.AreEqual(before,Json(hero));
        }
    }
}
