using System.Linq;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class GatePassageTests
    {
        GameCatalog catalog;
        [SetUp] public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown] public void Teardown()=>Object.DestroyImmediate(catalog);
        CombatSimulation Fixture()
        {
            var account=GameStore.NewAccount(catalog);account.Hero.level=30;
            account.Hero.build=BehaviorPresets.ForLevel(account.Hero.heroClass,0,30,catalog);
            return new CombatSimulation(account,catalog,10,seed:7,forcedObjective:RiftObjectiveKind.Seals);
        }
        [Test]
        public void ClosedGatePreventsEntryThroughEveryArenaDoor()
        {
            var sim=Fixture();var room=sim.State.layout.rooms[sim.State.layout.bossRoom];
            foreach(var door in room.doors.Where(d=>d.corridor>=0))
            {
                Vector2 outside=door.position+door.direction*3,inside=door.position-door.direction*3;
                Assert.IsFalse(sim.Map.TravelClear(outside,inside),"Unblocked arena entrance: "+door.index);
                Assert.AreNotEqual(inside,sim.Map.MoveDirect(outside,inside,10));
                Assert.IsFalse(sim.Map.CanLand(door.position),"A movement skill must not land inside the gate.");
            }
        }
        [Test]
        public void ClosedGateAlsoBlocksSightAndProjectiles()
        {
            var sim=Fixture();var room=sim.State.layout.rooms[sim.State.layout.bossRoom];
            foreach(var door in room.doors.Where(d=>d.corridor>=0))
            {
                Vector2 outside=door.position+door.direction*3,inside=door.position-door.direction*3;
                Assert.IsFalse(sim.Map.LineClear(outside,inside));
                Assert.IsFalse(sim.Map.ProjectileClear(outside,inside,.3f));
            }
        }
        [Test]
        public void ArenaIsUnreachableWhileOtherRoomsAndSealsStayReachable()
        {
            var sim=Fixture();var map=sim.State.layout;
            foreach(var room in map.rooms.Where(r=>r.index!=map.bossRoom))
                foreach(var p in room.groupAnchors)Assert.IsTrue(sim.Map.Reachable(p),"Gate stranded room "+room.index);
            foreach(var seal in map.seals)foreach(var p in seal.accessPoints)Assert.IsTrue(sim.Map.Reachable(p));
            foreach(var point in map.bossPoints)
            {
                Assert.IsFalse(sim.Map.Reachable(point));
                Assert.IsNull(sim.Map.FindPath(map.start,point),"No alternate entrance may bypass the objective.");
            }
        }
        [Test]
        public void MeterOpeningImmediatelyRestoresPathsOnTheLiveNavigation()
        {
            var sim=Fixture();var nav=sim.Map;var layout=sim.State.layout;var goal=layout.bossPoints[0];
            int notifications=0;sim.GateOpened+=_=>notifications++;
            Assert.IsNull(nav.FindPath(layout.start,goal));
            nav.Move(layout.start,goal,1,42,sim.State.time);
            foreach(var enemy in sim.State.enemies)enemy.dead=true;
            sim.State.meter=CombatSimulation.GateMeter;sim.Tick(CombatSimulation.Step);
            Assert.IsTrue(layout.gateOpen);Assert.AreSame(nav,sim.Map);
            Assert.IsTrue(nav.Reachable(goal));Assert.IsNotNull(nav.FindPath(layout.start,goal));
            Assert.AreNotEqual(layout.start,nav.Move(layout.start,goal,1,42,sim.State.time));
            for(int i=0;i<10;i++)sim.Tick(CombatSimulation.Step);
            Assert.AreEqual(1,sim.State.logs.Count(l=>l.Contains("GATE_OPEN")));
            Assert.AreEqual(1,notifications);
        }
        [TestCase(0)] [TestCase(1)]
        public void GeneratedEntrancesRemainSealedAcrossThemesSizesAndExtraConnections(int theme)
        {
            int extra=0,wings=0;var counts=new HashSet<int>();
            for(uint seed=1;seed<=50;seed++)
            {
                var map=RiftGenerator.Generate(73100+seed,"gated-sample",5,HeroClass.Warrior,forcedTheme:theme,forcedCount:6+(int)(seed%3));
                var nav=new RiftNavigation(map);var arena=map.rooms[map.bossRoom];counts.Add(map.rooms.Count);
                Assert.AreEqual(arena.doors.Count(d=>d.corridor>=0),map.gates.Count);
                foreach(var point in map.bossPoints)Assert.IsNull(nav.FindPath(map.start,point));
                foreach(var door in arena.doors.Where(d=>d.corridor>=0))
                {
                    Assert.IsFalse(nav.TravelClear(door.position+door.direction*3,door.position-door.direction*3));
                    Assert.IsFalse(nav.LineClear(door.position+door.direction*3,door.position-door.direction*3));
                }
                foreach(var spawn in map.spawns)Assert.AreEqual(spawn.room!=map.bossRoom,nav.Reachable(spawn.position));
                extra+=map.corridors.Count(c=>c.extra);wings+=map.rooms.Count(r=>r.role==RiftRoomRole.Wing);
                map.gateOpen=true;
                foreach(var point in map.bossPoints)Assert.IsNotNull(nav.FindPath(map.start,point));
            }
            CollectionAssert.AreEquivalent(new[]{6,7,8},counts);Assert.Greater(extra,0);Assert.Greater(wings,0);
        }
        [TestCase(0,0)] [TestCase(0,1)] [TestCase(0,2)]
        [TestCase(1,0)] [TestCase(1,1)] [TestCase(1,2)]
        public void EveryFixedFallbackHasWorkingClosedAndOpenGates(int theme,int fallback)
        {
            var map=RiftGenerator.Fallback(84910,"gate-fallback",10,HeroClass.Mage,theme,fallback);
            RiftGates.Validate(map);var nav=new RiftNavigation(map);
            Assert.IsFalse(nav.Reachable(map.bossPoints[0]));map.gateOpen=true;
            Assert.IsTrue(nav.Reachable(map.bossPoints[0]));
        }
        [TestCase(false)] [TestCase(true)]
        public void SaveRestoresGeometryDiscoveryAndBothPassageStates(bool open)
        {
            var sim=Fixture();var run=sim.State;run.layout.gateOpen=open;run.layout.gates[0].discovered=true;
            string expected=JsonUtility.ToJson(run.layout);
            var restored=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(run));GameStore.NormalizeRun(restored);
            Assert.AreEqual(expected,JsonUtility.ToJson(restored.layout));
            var nav=new RiftNavigation(restored.layout);
            Assert.AreEqual(open,nav.Reachable(restored.layout.bossPoints[0]));
            Assert.AreEqual(open,nav.FindPath(restored.position,restored.layout.bossPoints[0])!=null);
            Assert.IsTrue(restored.layout.gates[0].discovered);
        }
        [Test]
        public void OldObjectiveSaveDoesNotReceiveNewObstaclesOnLoad()
        {
            var run=Fixture().State;run.layout.version=2;run.layout.gates.Clear();
            string json=JsonUtility.ToJson(run).Replace("\"gates\":[],","");
            Assert.IsFalse(json.Contains("\"gates\""));
            var restored=JsonUtility.FromJson<RunState>(json);GameStore.NormalizeRun(restored);
            Assert.AreEqual(2,restored.layout.version);Assert.IsEmpty(restored.layout.gates);
            Assert.IsTrue(new RiftNavigation(restored.layout).Reachable(restored.layout.bossPoints[0]));
        }
        [Test]
        public void CompletingTheLastSealOpensPassageWithoutFillingTheMeter()
        {
            var sim=Fixture();var run=sim.State;var nav=sim.Map;var seals=run.layout.seals;
            foreach(var first in seals.Take(seals.Count-1)){first.phase=SealPhase.Broken;first.progress=RiftSeal.Duration;}
            var last=seals.Last();last.phase=SealPhase.Available;last.discovered=true;run.visited.Add(last.room);
            run.build.openChests=false;run.build.useShrines=false;run.build.rules=new List<Rule>{BehaviorRules.Utility(RuleAction.Explore)};
            int notifications=0;sim.GateOpened+=_=>notifications++;
            Assert.IsFalse(nav.Reachable(run.layout.bossPoints[0]));
            for(int i=0;i<120&&!run.layout.gateOpen;i++)
            {
                foreach(var e in run.enemies)e.dead=true;
                run.meter=0;run.position=last.accessPoints[0];sim.Tick(CombatSimulation.Step);
            }
            Assert.AreEqual(SealPhase.Broken,last.phase);Assert.IsTrue(run.layout.gateOpen);
            Assert.IsFalse(run.layout.gateOpenedByMeter);Assert.AreEqual(1,notifications);
            Assert.IsTrue(nav.Reachable(run.layout.bossPoints[0]));
        }
        [Test]
        public void SeeingAGateDoesNotRevealTheArena()
        {
            var sim=Fixture();var run=sim.State;var gate=run.layout.gates[0];
            Assert.IsFalse(gate.discovered);run.position=gate.barrier.position+gate.outward*3;
            RiftExploration.Discover(run,sim.Map);
            Assert.IsTrue(gate.discovered);Assert.IsFalse(run.visited.Contains(run.layout.bossRoom));
            Assert.IsFalse(run.layout.gates.Skip(1).Any(g=>g.discovered));
        }
        [Test]
        public void EarlyTiersKeepTheirUngatedPassages()
        {
            var map=RiftGenerator.Generate(7,"early-gate",4,HeroClass.Warrior);
            Assert.IsEmpty(map.gates);Assert.IsTrue(new RiftNavigation(map).Reachable(map.bossPoints[0]));
        }
    }
}
