using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace Hellscript.Tests
{
    public sealed class LocalizationTests
    {
        string directory;
        LanguageStore store;
        [SetUp] public void Setup()
        { directory = Path.Combine(Path.GetTempPath(), "hellscript-language-test-" + Guid.NewGuid().ToString("N")); store = new LanguageStore(directory); }
        [TearDown] public void Teardown()
        { Loc.UseSource(); if (Directory.Exists(directory)) Directory.Delete(directory, true); }
        LanguageSession Session(Func<string, bool> save = null, Func<string, LocalizationTable.Result> load = null)
            => new LanguageSession(store.Read(), save ?? store.Write, load ?? (code => new LocalizationTable.Result()));
        static LocalizationTable.Result Table(params string[] pairs)
        {
            var result = new LocalizationTable.Result();
            for (int i = 0; i < pairs.Length; i += 2) result.Entries[pairs[i]] = pairs[i + 1];
            return result;
        }

        [Test] public void TheSourceLanguageIsListedFirstAndNeedsNoTable()
        {
            Assert.AreEqual(LanguageOptions.Source, LanguageOptions.All.First().Code);
            Assert.AreEqual(LanguageOptions.Source, LanguageOptions.Default);
            Assert.IsFalse(LanguageOptions.Find(LanguageOptions.Source).NeedsTable);
            CollectionAssert.AllItemsAreUnique(LanguageOptions.All.Select(o => o.Code));
            foreach (var option in LanguageOptions.All)
            { Assert.IsNotEmpty(option.Code); Assert.IsNotEmpty(option.NativeName); Assert.IsNotEmpty(option.EnglishName); }
            Assert.IsTrue(LanguageOptions.IsSupported("ko"));
            Assert.IsTrue(LanguageOptions.IsSupported("en"));
        }
        [TestCase(null)] [TestCase("")] [TestCase("jp")] [TestCase("KO")] [TestCase("en-GB")]
        public void AnUnknownCodeBecomesTheDefault(string code)
        { Assert.IsFalse(LanguageOptions.IsSupported(code)); Assert.AreEqual(LanguageOptions.Default, LanguageOptions.Nearest(code)); }

        [Test] public void EscapesSurviveAWriteAndReadOfTheSameLine()
        {
            const string value = "첫 줄\n두 번째\t칸\\끝";
            var parsed = LocalizationTable.Parse("키\t" + LocalizationTable.Escape(value));
            Assert.AreEqual(value, parsed.Entries["키"]);
            Assert.AreEqual(0, parsed.Malformed);
        }
        [Test] public void NotesBlankLinesAndDamagedLinesAreCountedAndSkipped()
        {
            var parsed = LocalizationTable.Parse("# note\n\n키\t값\n탭이 없는 줄\n키\t다른 값\n빈 값\t\n");
            Assert.AreEqual(2, parsed.Entries.Count);
            Assert.AreEqual("값", parsed.Entries["키"]);
            Assert.AreEqual("", parsed.Entries["빈 값"]);
            Assert.AreEqual(1, parsed.Malformed);
            Assert.AreEqual(1, parsed.Duplicates);
            Assert.AreEqual(1, parsed.Blank);
        }
        [Test] public void ReadingAStringWithoutATableReturnsTheSource()
        {
            Loc.UseSource();
            Assert.IsTrue(Loc.IsSource);
            Assert.AreEqual("성소", Loc.T("성소"));
            Assert.AreEqual("처치 7", Loc.F("처치 {0}", 7));
            Assert.AreEqual(0, Loc.MissingCount);
        }
        [Test] public void AMissingEntryKeepsTheSourceAndIsRecordedOnce()
        {
            Loc.Use("en", Table("성소", "Sanctuary").Entries);
            Assert.AreEqual("Sanctuary", Loc.T("성소"));
            Assert.AreEqual("균열", Loc.T("균열"));
            Assert.AreEqual("균열", Loc.T("균열"));
            CollectionAssert.AreEquivalent(new[] { "균열" }, Loc.Missing.ToArray());
        }
        [Test] public void FormatSpecifiersAndEscapedBracesSurviveTranslation()
        {
            Loc.Use("en", Table("남은 {0:0.0}초 · {{고정}}", "{0:0.0}s left · {{fixed}}").Entries);
            Assert.AreEqual("1.5s left · {fixed}", Loc.F("남은 {0:0.0}초 · {{고정}}", 1.5f));
        }
        [Test] public void ATranslationThatLostAPlaceholderFallsBackToTheSourceLine()
        {
            Loc.Use("en", Table("처치 {0} · 게이지 {1}", "Kills {0} · gauge {2}").Entries);
            Assert.AreEqual("처치 3 · 게이지 40", Loc.F("처치 {0} · 게이지 {1}", 3, 40));
        }
        [Test] public void StringArgumentsAreTranslatedSoAComposedLineIsNotHalfKorean()
        {
            Loc.Use("en", Table("{0} · 준비", "{0} · preparing", "회오리", "Whirlwind").Entries);
            Assert.AreEqual("Whirlwind · preparing", Loc.F("{0} · 준비", "회오리"));
        }
        [Test] public void SelectingALanguageAndReturningToTheSourceIsRepeatable()
        {
            var entries = Table("성소", "Sanctuary").Entries;
            Loc.Use("en", entries); Assert.AreEqual("en", Loc.Language); Assert.IsFalse(Loc.IsSource);
            Loc.Use("en", entries); Assert.AreEqual("Sanctuary", Loc.T("성소"));
            Loc.UseSource(); Assert.AreEqual(LanguageOptions.Source, Loc.Language); Assert.IsTrue(Loc.IsSource);
            Assert.AreEqual("성소", Loc.T("성소"));
        }

        [Test] public void MissingPreferenceStartsAtTheDefaultWithoutCreatingFiles()
        { Assert.AreEqual(LanguageOptions.Default, store.Read()); Assert.IsEmpty(store.Error); Assert.IsFalse(Directory.Exists(directory)); }
        [Test] public void AChosenLanguageSurvivesANewStoreAndLeavesTheOtherSettingsAlone()
        {
            Directory.CreateDirectory(directory);
            var account = Path.Combine(directory, "hellscript-local-v1.json"); File.WriteAllText(account, "unchanged account bytes");
            var display = new DeviceDisplayStore(directory); Assert.IsTrue(display.Write(DeviceScreenDirection.Landscape)); string displayBytes = File.ReadAllText(display.Path);
            var scale = new InterfaceScaleStore(directory); Assert.IsTrue(scale.Write(130)); string scaleBytes = File.ReadAllText(scale.Path);
            var session = Session();
            Assert.IsTrue(session.Apply("en"));
            Assert.AreEqual("en", session.Language); Assert.AreEqual("en", session.Saved); Assert.IsFalse(session.CanRetrySave);
            Assert.AreEqual("en", new LanguageStore(directory).Read());
            Assert.AreEqual("unchanged account bytes", File.ReadAllText(account));
            Assert.AreEqual(displayBytes, File.ReadAllText(display.Path));
            Assert.AreEqual(scaleBytes, File.ReadAllText(scale.Path));
            Assert.AreNotEqual(store.Path, display.Path); Assert.AreNotEqual(store.Path, scale.Path);
        }
        [TestCase("{}")] [TestCase("{\"version\":2,\"language\":\"en\"}")] [TestCase("{\"version\":1,\"language\":\"jp\"}")]
        [TestCase("{\"version\":1,\"language\":\"\"}")] [TestCase("malformed")]
        public void InvalidPreferenceUsesTheDefaultWithoutOverwritingTheOriginal(string original)
        {
            Directory.CreateDirectory(directory); File.WriteAllText(store.Path, original);
            Assert.AreEqual(LanguageOptions.Default, store.Read());
            Assert.IsNotEmpty(store.Error);
            Assert.AreEqual(original, File.ReadAllText(store.Path));
        }
        [Test] public void OversizedPreferenceIsPreserved()
        {
            Directory.CreateDirectory(directory); string original = new string('x', 1025); File.WriteAllText(store.Path, original);
            Assert.AreEqual(LanguageOptions.Default, store.Read()); Assert.IsNotEmpty(store.Error);
            Assert.AreEqual(original, File.ReadAllText(store.Path));
        }
        [Test] public void WritingAnUnsupportedLanguageIsRefusedBeforeTouchingTheFile()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => store.Write("jp"));
            Assert.IsFalse(File.Exists(store.Path));
        }
        [Test] public void AFailedSaveKeepsTheChoiceOnScreenAndAllowsOneRetry()
        {
            int attempts = 0;
            var session = Session(code => { attempts++; return attempts > 1; });
            Assert.IsFalse(session.Apply("en"));
            Assert.AreEqual("en", session.Language); Assert.AreEqual(LanguageOptions.Default, session.Saved);
            Assert.IsTrue(session.CanRetrySave); Assert.IsNotEmpty(session.Message);
            Assert.IsTrue(session.RetrySave());
            Assert.AreEqual("en", session.Saved); Assert.IsFalse(session.CanRetrySave);
            Assert.AreEqual(2, attempts);
        }
        [Test] public void ALanguageWhoseTableIsMissingStillAppliesAndSaysSo()
        {
            var session = Session(code => true, code => new LocalizationTable.Result());
            Assert.IsTrue(session.Apply("en"));
            Assert.AreEqual("en", Loc.Language); Assert.AreEqual(0, session.Entries);
            Assert.IsTrue(Loc.IsSource, "With no entries every line has to fall back to the source.");
            StringAssert.Contains("번역", session.Message);
        }
        [Test] public void ALoaderThatThrowsDoesNotStopTheLanguageFromApplying()
        {
            var session = Session(code => true, code => throw new InvalidOperationException("unreadable"));
            Assert.IsTrue(session.Apply("en"));
            Assert.AreEqual("en", Loc.Language); Assert.AreEqual(0, session.Entries);
        }
        [Test] public void TheSessionLoadsTheSavedLanguageWhenItIsCreated()
        {
            Directory.CreateDirectory(directory); Assert.IsTrue(store.Write("en"));
            var session = Session(code => true, code => Table("성소", "Sanctuary"));
            Assert.AreEqual("en", session.Language); Assert.AreEqual(1, session.Entries);
            Assert.AreEqual("Sanctuary", Loc.T("성소"));
        }

        // The shipped table, checked the way the game reads it.
        static string TablePath(string code) => Path.Combine(SourceRoot(), "Resources", "Localization", code + ".txt");
        static string SourceRoot() => Path.Combine(UnityEngine.Application.dataPath, "HELLSCRIPT");
        static LocalizationTable.Result Shipped(string code) => LocalizationTable.Parse(File.ReadAllText(TablePath(code), Encoding.UTF8));

        [Test] public void EveryLanguageThatNeedsATableShipsOne()
        {
            foreach (var option in LanguageOptions.All.Where(o => o.NeedsTable))
                Assert.IsTrue(File.Exists(TablePath(option.Code)), option.Code + " has no table at " + TablePath(option.Code));
        }
        [Test] public void TheEnglishTableParsesWithoutDamagedOrRepeatedLines()
        {
            var table = Shipped("en");
            Assert.AreEqual(0, table.Malformed, "Every entry needs exactly one tab.");
            Assert.AreEqual(0, table.Duplicates, "A key may only appear once.");
            Assert.Greater(table.Entries.Count, 2000);
        }
        [Test] public void EveryEnglishEntryLeavesNoKoreanBehindAndKeepsItsPlaceholders()
        {
            var table = Shipped("en");
            var problems = new List<string>();
            foreach (var pair in table.Entries)
            {
                if (!HasKorean(pair.Key)) problems.Add("key without Korean: " + pair.Key);
                if (HasKorean(pair.Value)) problems.Add("value still Korean: " + pair.Key);
                if (!Holes(pair.Key).OrderBy(x => x).SequenceEqual(Holes(pair.Value).OrderBy(x => x))) problems.Add("placeholders differ: " + pair.Key);
                if (pair.Key.Split('|').Length != pair.Value.Split('|').Length) problems.Add("choice count differs: " + pair.Key);
            }
            Assert.IsEmpty(problems, string.Join("\n", problems.Take(20)));
        }
        [Test] public void KnownLinesFromEveryCornerOfTheGameAreTranslated()
        {
            var table = Shipped("en");
            foreach (string key in new[]
            {
                "행동을 설계하고, 균열을 지배하라", "설정 · 게임 안내", "언어", "글자 크기", "회오리", "전사", "무기",
                "균열 {0}단계", "처치 {0} · 균열 게이지 {1} / 100", "행동 설계", "사냥 칙령 v0.2", "저장 복구가 필요합니다",
                "{0}번 규칙: ", "항상 검사", "일반", "희귀 회수", "켜기", "끄기", "프리셋 저장", "균열 관리자",
            })
                Assert.IsTrue(table.Entries.ContainsKey(key), "missing entry: " + key);
        }

        // Rewording a Korean line changes the key, which would silently drop the translation written
        // for the old wording. An entry above the marker that no source literal holds any more is
        // exactly that, and has to be re-checked rather than left to fall back to Korean.
        [Test] public void NoEntryIsLeftBehindByARewordedLine()
        {
            var literals = new HashSet<string>(StringComparer.Ordinal);
            foreach (string file in RuntimeSources())
                foreach (var literal in KoreanLiterals(File.ReadAllText(file, Encoding.UTF8)))
                    if (!literal.interpolated) literals.Add(literal.text);
            var orphans = SourceSectionKeys("en").Where(k => !literals.Contains(k)).ToList();
            Assert.IsEmpty(orphans, orphans.Count + " entries no longer match a line in the source:\n" + string.Join("\n", orphans.Take(20)));
        }
        const string DerivedMarker = "# --- composed at runtime; no source literal holds these ---";
        static List<string> SourceSectionKeys(string code)
        {
            var keys = new List<string>();
            foreach (string raw in File.ReadAllLines(TablePath(code), Encoding.UTF8))
            {
                if (raw.StartsWith(DerivedMarker, StringComparison.Ordinal)) break;
                if (raw.Length == 0 || raw[0] == '#') continue;
                int tab = raw.IndexOf('\t');
                if (tab > 0) keys.Add(LocalizationTable.Unescape(raw.Substring(0, tab)));
            }
            Assert.Greater(keys.Count, 2000, "The table lost its source section.");
            return keys;
        }

        // Nothing on screen may be written in a way the table cannot reach. Every Korean literal in
        // the runtime assembly is therefore an entry, and a composed line has to go through Loc.F
        // rather than string interpolation, so that its arguments are translated too.
        [Test] public void EveryKoreanLiteralInTheRuntimeHasAnEntry()
        {
            var table = Shipped("en");
            var missing = new List<string>();
            int scanned = 0, literals = 0;
            foreach (string file in RuntimeSources())
            {
                scanned++;
                foreach (var literal in KoreanLiterals(File.ReadAllText(file, Encoding.UTF8)))
                {
                    literals++;
                    if (literal.interpolated) missing.Add(Path.GetFileName(file) + " interpolates Korean instead of calling Loc.F: " + literal.text);
                    else if (!table.Entries.ContainsKey(literal.text)) missing.Add(Path.GetFileName(file) + " has no entry for: " + literal.text);
                }
            }
            Assert.Greater(scanned, 80); Assert.Greater(literals, 1500);
            Assert.IsEmpty(missing, missing.Count + " untranslated:\n" + string.Join("\n", missing.Take(20)));
        }
        static IEnumerable<string> RuntimeSources() => Directory
            .GetFiles(Path.Combine(SourceRoot(), "Runtime"), "*.cs", SearchOption.AllDirectories)
            .Where(f => !Path.GetFileName(f).Contains("Smoke"))
            // The language names are deliberately written in their own language and are never translated.
            .Where(f => Path.GetFileName(f) != "Localization.cs")
            .OrderBy(f => f, StringComparer.Ordinal);

        static bool HasKorean(string text) => text.Any(c => c >= 0xAC00 && c <= 0xD7A3);
        static IEnumerable<int> Holes(string text)
        {
            for (int i = 0; i < text.Length - 1; i++)
            {
                if (text[i] != '{') continue;
                if (text[i + 1] == '{') { i++; continue; }
                int end = i + 1; while (end < text.Length && char.IsDigit(text[end])) end++;
                if (end > i + 1) yield return int.Parse(text.Substring(i + 1, end - i - 1));
            }
        }

        struct Literal { public string text; public bool interpolated; }
        // A reader over C# source that understands line and block comments, character literals and
        // string literals, including an interpolated one whose holes contain further literals.
        static List<Literal> KoreanLiterals(string source)
        {
            var found = new List<Literal>();
            for (int i = 0; i < source.Length; )
            {
                char c = source[i];
                if (c == '/' && i + 1 < source.Length && source[i + 1] == '/')
                { int end = source.IndexOf('\n', i); i = end < 0 ? source.Length : end + 1; continue; }
                if (c == '/' && i + 1 < source.Length && source[i + 1] == '*')
                { int end = source.IndexOf("*/", i + 2, StringComparison.Ordinal); i = end < 0 ? source.Length : end + 2; continue; }
                if (c == '\'')
                { i++; while (i < source.Length && source[i] != '\'') i += source[i] == '\\' ? 2 : 1; i++; continue; }
                if (c == '"' || ((c == '$' || c == '@') && StartsLiteral(source, i)))
                { i = ReadLiteral(source, i, found); continue; }
                i++;
            }
            return found;
        }
        static bool StartsLiteral(string source, int i)
        { int j = i; while (j < source.Length && (source[j] == '$' || source[j] == '@')) j++; return j < source.Length && source[j] == '"'; }
        static int ReadLiteral(string source, int i, List<Literal> found)
        {
            bool interpolated = false, verbatim = false;
            while (source[i] == '$' || source[i] == '@') { if (source[i] == '$') interpolated = true; else verbatim = true; i++; }
            i++;
            var text = new StringBuilder();
            while (i < source.Length)
            {
                char c = source[i];
                if (verbatim)
                {
                    if (c == '"') { if (i + 1 < source.Length && source[i + 1] == '"') { text.Append('"'); i += 2; continue; } i++; break; }
                }
                else
                {
                    if (c == '\\') { text.Append(Unescape(source, ref i)); continue; }
                    if (c == '"') { i++; break; }
                    if (c == '\n') break;
                }
                if (interpolated && c == '{')
                {
                    if (i + 1 < source.Length && source[i + 1] == '{') { text.Append('{'); i += 2; continue; }
                    i = ReadHole(source, i, found); continue;
                }
                if (interpolated && c == '}' && i + 1 < source.Length && source[i + 1] == '}') { text.Append('}'); i += 2; continue; }
                text.Append(c); i++;
            }
            string value = text.ToString();
            if (HasKorean(value)) found.Add(new Literal { text = value, interpolated = interpolated });
            return i;
        }
        static string Unescape(string source, ref int i)
        {
            char next = source[i + 1]; i += 2;
            switch (next)
            {
                case 'n': return "\n";
                case 't': return "\t";
                case 'r': return "\r";
                case '0': return "\0";
                case 'u': case 'x':
                {
                    var digits = new StringBuilder();
                    while (i < source.Length && digits.Length < 4 && Uri.IsHexDigit(source[i])) digits.Append(source[i++]);
                    return ((char)Convert.ToInt32(digits.ToString(), 16)).ToString();
                }
                default: return next.ToString();
            }
        }
        static int ReadHole(string source, int i, List<Literal> found)
        {
            int depth = 0;
            while (i < source.Length)
            {
                char c = source[i];
                if (c == '{' || c == '(' || c == '[') { depth++; i++; continue; }
                if (c == '}' || c == ')' || c == ']') { depth--; i++; if (depth == 0) return i; continue; }
                if (c == '"' || ((c == '$' || c == '@') && StartsLiteral(source, i))) { i = ReadLiteral(source, i, found); continue; }
                if (c == '\'') { i++; while (i < source.Length && source[i] != '\'') i += source[i] == '\\' ? 2 : 1; i++; continue; }
                i++;
            }
            return i;
        }
    }
}
