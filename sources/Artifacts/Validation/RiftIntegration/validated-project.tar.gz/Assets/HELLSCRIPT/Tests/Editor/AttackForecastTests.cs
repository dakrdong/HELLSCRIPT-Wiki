using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class AttackForecastTests
    {
        GameCatalog catalog;
        [SetUp]public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown]public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        static void Equip(HeroSave hero,string id)
        {
            var definition=ItemCatalog.Unique(id);uint rng=812343;
            foreach(var item in hero.inventory.Where(i=>i.slot==definition.slot))item.equipped=false;
            var gear=ItemGenerator.Create(hero.heroClass,definition.slot,3,30,ref rng,uniqueId:id);gear.equipped=true;hero.inventory.Add(gear);
        }
        CombatSimulation Fixture(int skill,params string[] gear)
        {
            var account=GameStore.NewAccount();account.selectedHero=skill/6;var hero=account.Hero;hero.level=30;hero.inventory.Clear();hero.build.passives=Array.Empty<int>();
            hero.build.rules=new List<Rule>{BehaviorRules.Make(skill)};hero.build.activeSkills=new List<int>{skill};hero.build.potionThreshold=0;hero.build.movement=MovementMode.Stand;
            foreach(string item in gear)Equip(hero,item);
            var sim=new CombatSimulation(account,catalog,1,1,seed:14561);sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();sim.Stats.crit=0;sim.Stats.regen=0;
            return sim;
        }
        static EnemyState Enemy(CombatSimulation sim,float x,float y,int id=0)
        {
            var e=new EnemyState{id=id==0?900+sim.State.enemies.Count:id,position=sim.State.position+new Vector2(x,y),health=1000000,maxHealth=1000000,speed=0,attack=0,cooldown=1000};
            sim.State.enemies.Add(e);return e;
        }
        static HuntEdictV2Document Edict(CombatSimulation sim,string skill)
        {var d=HuntEdictV2.Create(sim.Hero.heroClass);d.slots[0]=skill;return d;}
        static void Advance(CombatSimulation sim,int ticks=60)
        {sim.State.decisionTime=100;for(int i=0;i<ticks;i++)sim.Tick(.05f);}
        static int[] ActualHits(CombatSimulation sim,int root,string definition)=>sim.State.damageEvents.Where(e=>!e.incoming&&e.rootCastId==root&&e.definitionId==definition&&e.kind==DamageKind.Direct).Select(e=>e.targetId).ToArray();

        [Test]
        public void ChainForecastAndRealReleasePreferUnvisitedEnemiesBeforeCloserRevisits()
        {
            var sim=Fixture(14,"LM04");var a=Enemy(sim,0,2);Enemy(sim,0,3);Enemy(sim,3,3);Enemy(sim,6,3);
            var rule=sim.State.build.rules[0];rule.target=RuleTarget.Current;sim.State.targetId=a.id;
            var f=sim.ForecastAttack(rule,a);CollectionAssert.AreEqual(new[]{900,901,902,903},f.hits);Assert.AreEqual(4,sim.PredictedHits(rule,a));
            sim.Tick(.05f);int root=sim.State.heroAction.id;Advance(sim);CollectionAssert.AreEqual(f.hits,ActualHits(sim,root,"M03"));
        }
        [TestCase(false,false,4)][TestCase(true,false,5)][TestCase(false,true,6)][TestCase(true,true,7)]
        public void ChainForecastUsesRealPassiveAndSetChargeLimitsWithoutConsumingThem(bool passive,bool charged,int limit)
        {
            var sim=Fixture(14,"LM04","SMB1","SMB2","SMB3","SMB4");sim.Stats.passives[2]=passive;
            for(int n=0;n<4;n++)Enemy(sim,n*.8f,2);
            sim.State.itemEffects.chainCharges=charged?2:0;sim.State.itemEffects.chainCharge=charged?6:0;
            string before=JsonUtility.ToJson(sim.State);var f=sim.ForecastAttack(sim.State.build.rules[0],sim.State.enemies[0]);
            Assert.AreEqual(limit,f.TotalHits);Assert.AreEqual(before,JsonUtility.ToJson(sim.State));
            sim.Tick(.05f);int root=sim.State.heroAction.id;Advance(sim);CollectionAssert.AreEqual(f.hits,ActualHits(sim,root,"M03"));
        }
        [TestCase(false,2)][TestCase(true,4)]
        public void ChainRevisitsRequireLegendaryAndNeverHitOneTargetConsecutively(bool legendary,int total)
        {
            var sim=legendary?Fixture(14,"LM04"):Fixture(14);var a=Enemy(sim,0,2);Enemy(sim,1,2);
            var f=sim.ForecastAttack(sim.State.build.rules[0],a);Assert.AreEqual(2,f.uniqueTargets);Assert.AreEqual(total,f.TotalHits);
            for(int i=1;i<f.TotalHits;i++)Assert.AreNotEqual(f.hits[i-1],f.hits[i]);
            sim.State.enemies.RemoveAt(1);Assert.AreEqual(1,sim.ForecastAttack(sim.State.build.rules[0],a).TotalHits);
        }
        [Test]
        public void ActualChainReevaluatesDeathsInsteadOfExecutingAForecastAsReservedTargets()
        {
            var sim=Fixture(14,"LM04");var a=Enemy(sim,0,2);Enemy(sim,1,2);a.health=1;
            var forecast=sim.ForecastAttack(sim.State.build.rules[0],a);Assert.AreEqual(4,forecast.TotalHits);
            sim.Tick(.05f);int root=sim.State.heroAction.id;Advance(sim);CollectionAssert.AreEqual(new[]{900,901},ActualHits(sim,root,"M03"));Assert.IsTrue(a.dead);
        }
        [TestCase(false,5)][TestCase(true,7)]
        public void PierceReturnsCollisionOrderAndStopsAtActualHitCap(bool passive,int cap)
        {
            var sim=Fixture(6);sim.Stats.passives[2]=passive;
            for(int i=0;i<8;i++)Enemy(sim,0,.8f+i*.8f,920-i);
            var a=sim.State.enemies[0];var f=sim.ForecastAttack(sim.State.build.rules[0],a);Assert.AreEqual(cap,f.uniqueTargets);CollectionAssert.AreEqual(Enumerable.Range(0,cap).Select(i=>920-i),f.hits);
            sim.Tick(.05f);int root=sim.State.heroAction.id;Advance(sim);CollectionAssert.AreEqual(f.hits,ActualHits(sim,root,"A01"));
        }
        [TestCase(false,1)][TestCase(true,3)]
        public void MultiCountsAcceptedArrowsSeparatelyFromUniqueTargets(bool focused,int arrows)
        {
            var sim=focused?Fixture(7,"LA02"):Fixture(7);var target=Enemy(sim,0,.8f);Enemy(sim,0,3);
            var f=sim.ForecastAttack(sim.State.build.rules[0],target);Assert.AreEqual(1,f.uniqueTargets);Assert.AreEqual(arrows,f.TotalHits);Assert.AreEqual(arrows,f.HitsOn(target.id));
            sim.Tick(.05f);int root=sim.State.heroAction.id;Advance(sim);CollectionAssert.AreEquivalent(f.hits,ActualHits(sim,root,"A02"));
        }
        [Test]
        public void FireballCountsAtItsFirstCollisionInsteadOfAtTheIntendedTarget()
        {
            var sim=Fixture(12);var blocker=Enemy(sim,0,2);var target=Enemy(sim,0,6);
            var rule=sim.State.build.rules[0];rule.target=RuleTarget.Current;sim.State.targetId=target.id;
            var f=sim.ForecastAttack(rule,target);CollectionAssert.AreEqual(new[]{blocker.id},f.hits);Assert.Less(f.impact.y,blocker.position.y);
            sim.Tick(.05f);int root=sim.State.heroAction.id;Advance(sim);CollectionAssert.AreEqual(f.hits,ActualHits(sim,root,"M01"));
        }
        [Test]
        public void CallerSuppliedListsCannotExposeHiddenOrDetachedEnemyPositions()
        {
            var sim=Fixture(6);var visible=Enemy(sim,0,2);var hidden=Enemy(sim,0,6);var distant=Enemy(sim,0,20);sim.State.layout.legacy=false;
            sim.State.layout.obstacles.Add(new RiftObstacle{id="screen",position=sim.State.position+Vector2.up*4,halfSize=new Vector2(4,.1f),blocksSight=true,blocksProjectile=false,blocksWalk=false});
            var detached=new EnemyState{id=visible.id,position=sim.State.position+Vector2.right*5};
            var f=sim.ForecastAttack(sim.State.build.rules[0],visible,observed:new[]{detached,hidden,distant,visible});
            CollectionAssert.AreEqual(new[]{visible.id},f.hits);Assert.AreEqual(0,sim.ForecastAttack(sim.State.build.rules[0],hidden,observed:sim.State.enemies.ToArray()).TotalHits);
        }
        [Test]
        public void ProjectileBlockingTerrainTruncatesTheForecastEvenWhenSightIsClear()
        {
            var sim=Fixture(6);var first=Enemy(sim,0,2);Enemy(sim,0,6);sim.State.layout.legacy=false;
            sim.State.layout.obstacles.Add(new RiftObstacle{id="projectile",position=sim.State.position+Vector2.up*4,halfSize=new Vector2(4,.1f),blocksSight=false,blocksProjectile=true,blocksWalk=false});
            var f=sim.ForecastAttack(sim.State.build.rules[0],first);CollectionAssert.AreEqual(new[]{first.id},f.hits);Assert.Less(f.impact.y,sim.State.position.y+4);
        }
        [Test]
        public void ForecastValuesAreDetachedAndDoNotMutateCombatOrConsumeRandomNumbers()
        {
            var sim=Fixture(14,"LM04");var target=Enemy(sim,0,2);Enemy(sim,1,2);string before=JsonUtility.ToJson(sim.State);
            var f=sim.ForecastAttack(sim.State.build.rules[0],target);Assert.AreEqual(before,JsonUtility.ToJson(sim.State));
            Assert.Throws<NotSupportedException>(()=>((IList<int>)f.hits)[0]=100);target.id=999;Assert.AreEqual(900,f.hits[0]);
            Assert.Throws<ArgumentException>(()=>sim.ForecastAttack(sim.State.build.rules[0],target,new Vector2(float.NaN,0)));
        }
        [TestCase(12)][TestCase(-1)]
        public void ObservedAimIncludesPreparationAndFlightWithoutUsingEnemyIntent(int skill)
        {
            var sim=Fixture(12);var target=Enemy(sim,0,6);sim.State.time=2;
            sim.State.exploration.enemies.Add(new EnemyObservation{id=target.id,position=target.position,seenAt=2,motionSampled=true,velocity=Vector2.right*2});
            string before=JsonUtility.ToJson(sim.State);Vector2 aim=sim.ObservedProjectileAim(skill,target);
            float prepare=CombatActions.Timing(skill,HeroClass.Mage,sim.Stats.attackSpeed).prepare,flight=Vector2.Distance(sim.State.position,aim)/14;
            Assert.AreEqual(target.position.x+2*(prepare+flight),aim.x,.002f);Assert.AreEqual(target.position.y,aim.y,.002f);Assert.AreEqual(before,JsonUtility.ToJson(sim.State));
            target.aim=sim.State.position+Vector2.left*7;Assert.AreEqual(aim,sim.ObservedProjectileAim(skill,target));
        }
        [TestCase("missing")][TestCase("stale")][TestCase("future")][TestCase("unsampled")][TestCase("invalid")][TestCase("immobilized")]
        public void UnreliableMovementFallsBackToCurrentPosition(string reason)
        {
            var sim=Fixture(12);var target=Enemy(sim,0,5);sim.State.time=2;
            var observation=new EnemyObservation{id=target.id,position=target.position,seenAt=2,motionSampled=true,velocity=Vector2.right*2};
            if(reason!="missing")sim.State.exploration.enemies.Add(observation);
            if(reason=="stale")observation.seenAt=1.5f;if(reason=="future")observation.seenAt=3;if(reason=="unsampled")observation.motionSampled=false;if(reason=="invalid")observation.velocity=new Vector2(float.NaN,0);
            if(reason=="immobilized")target.statuses.Add(new StatusEffect{kind=StatusKind.Freeze,remaining=1});
            Assert.AreEqual(target.position,sim.ObservedProjectileAim(12,target));
        }
        [Test]
        public void CoreMultiAimCanIncludeTwoArrowsWhenTargetCenterAimIncludesOnlyOne()
        {
            var sim=Fixture(7,"LA02");var target=Enemy(sim,0,4);var d=HuntEdictV2.WithOption(Edict(sim,"A02"),"A02",2,"FOCUS");
            Assert.AreEqual(1,sim.ForecastAttack(sim.State.build.rules[0],target).HitsOn(target.id));string before=JsonUtility.ToJson(sim.State),source=HuntEdictV2Codec.Encode(d);
            var plan=sim.PlanEdictAim(d,"A02",target);Assert.IsTrue(plan.available,plan.reason);Assert.AreEqual(2,plan.forecast.HitsOn(target.id));Assert.Greater(Mathf.Abs(plan.forecast.aim.x-target.position.x),.01f);
            Assert.AreEqual(before,JsonUtility.ToJson(sim.State));Assert.AreEqual(source,HuntEdictV2Codec.Encode(d));
        }
        [Test]
        public void CorePierceRequiresThePreferredTargetInsideTheActualPierceCap()
        {
            var sim=Fixture(6);for(int i=0;i<6;i++)Enemy(sim,0,1+i*.9f);var target=sim.State.enemies.Last();var d=Edict(sim,"A01");
            var plan=sim.PlanEdictAim(d,"A01",target);Assert.IsFalse(plan.available,"A ray through six collinear centers cannot include the last target within the five-hit cap.");
            sim.Stats.passives[2]=true;plan=sim.PlanEdictAim(d,"A01",target);Assert.IsTrue(plan.available,plan.reason);Assert.AreEqual(6,plan.forecast.uniqueTargets);Assert.GreaterOrEqual(plan.forecast.FirstHitIndex(target.id),0);
        }
        [Test]
        public void CoreCrushIsolatedAndGroupConflictCannotBorrowHitsFromAnotherDirection()
        {
            var sim=Fixture(2);var target=Enemy(sim,0,2);Enemy(sim,2,0);var d=Edict(sim,"W03");d=HuntEdictV2.WithOption(d,"W03",3,"ISOLATED");d=HuntEdictV2.WithOption(d,"W03",4,"GROUP");
            Assert.IsFalse(sim.PlanEdictAim(d,"W03",target).available);
            d=HuntEdictV2.WithOption(d,"W03",4,"READY");var plan=sim.PlanEdictAim(d,"W03",target);Assert.IsTrue(plan.available,plan.reason);CollectionAssert.AreEqual(new[]{target.id},plan.forecast.hits);
        }
        [Test]
        public void CoreChainUniqueAndTotalChoicesCompareWithinPreferredFirstTargetGroup()
        {
            var sim=Fixture(14,"LM04");var global=Enemy(sim,-5,0);Enemy(sim,-5,1);var preferred=Enemy(sim,3,0);Enemy(sim,4,0);Enemy(sim,5,0);Enemy(sim,6,0);
            var d=Edict(sim,"M03");var unique=sim.PlanEdictAim(d,"M03",global);Assert.IsTrue(unique.available,unique.reason);Assert.AreEqual(4,unique.forecast.uniqueTargets);Assert.AreNotEqual(global.id,unique.targetId);
            d=HuntEdictV2.WithOption(d,"M03",4,"TOTAL_HITS");var total=sim.PlanEdictAim(d,"M03",global);Assert.IsTrue(total.available,total.reason);Assert.AreEqual(global.id,total.targetId);Assert.AreEqual(2,total.forecast.uniqueTargets);Assert.AreEqual(4,total.forecast.TotalHits);
            preferred.elite=0;d=HuntEdictV2.WithOption(d,"M03",3,"ELITE");Assert.AreEqual(preferred.id,sim.PlanEdictAim(d,"M03",global).targetId);
            sim.Stats.specials.Remove("LM04");var fallback=sim.PlanEdictAim(d,"M03",global);Assert.That(fallback.reason,Does.Contain("고유 대상"));Assert.AreEqual("TOTAL_HITS",HuntEdictV2.Value(d,"M03",4));
        }
        [TestCase(.999f,true)][TestCase(1f,true)][TestCase(1.05f,false)][TestCase(0f,false)]
        public void CoreChainExpiringChargeAllowsOneTargetOnlyAtItsSpecifiedBoundary(float remaining,bool available)
        {
            var sim=Fixture(14,"SMB1","SMB2","SMB3","SMB4");var target=Enemy(sim,0,2);sim.State.itemEffects.chainCharges=2;sim.State.itemEffects.chainCharge=remaining;
            var d=HuntEdictV2.WithOption(Edict(sim,"M03"),"M03",2,"SAVE_CHARGE");Assert.AreEqual(available,sim.PlanEdictAim(d,"M03",target).available);Assert.AreEqual(remaining,sim.State.itemEffects.chainCharge);
        }
        [Test]
        public void AimStageIsNotCastAuthorizationAndNeverStartsOrReservesAnAction()
        {
            var sim=Fixture(14);var target=Enemy(sim,0,2);var d=Edict(sim,"M03");sim.State.resource=0;sim.State.cooldowns[14]=10;sim.State.paused=true;
            string before=JsonUtility.ToJson(sim.State);Assert.IsTrue(sim.PlanEdictAim(d,"M03",target).available);Assert.AreEqual(before,JsonUtility.ToJson(sim.State));
            d=HuntEdictV2.WithOption(d,"M03",1,"OFF");Assert.IsFalse(sim.PlanEdictAim(d,"M03",target).available);
            d=HuntEdictV2.WithOption(d,"M03",1,"ON");d.slots[0]="";Assert.IsFalse(sim.PlanEdictAim(d,"M03",target).available);
            Assert.IsFalse(sim.PlanEdictAim(d,"M01",target).supported);
        }
        [Test]
        public void StrictFocusRequiresActualGearAndKeepsTheChosenValueWhenUnavailable()
        {
            var sim=Fixture(7);var target=Enemy(sim,0,2);var d=HuntEdictV2.WithOption(Edict(sim,"A02"),"A02",2,"FOCUS");
            var plan=sim.PlanEdictAim(d,"A02",target);Assert.IsFalse(plan.available);Assert.That(plan.reason,Does.Contain("LA02"));Assert.AreEqual("FOCUS",HuntEdictV2.Value(d,"A02",2));
        }
        [Test]
        public void HypotheticalOriginUsesTheSameOriginForGroundPlacementAndHitCounting()
        {
            var sim=Fixture(13);var target=Enemy(sim,6,0);var rule=sim.State.build.rules[0];rule.areaAim=AreaAim.Self;
            Assert.AreEqual(0,sim.ForecastAttack(rule,null).uniqueTargets);
            Vector2 candidateOrigin=sim.State.position+Vector2.right*4;string before=JsonUtility.ToJson(sim.State);
            var f=sim.ForecastAttack(rule,null,origin:candidateOrigin);Assert.AreEqual(candidateOrigin,f.aim);Assert.AreEqual(candidateOrigin,f.impact);CollectionAssert.AreEqual(new[]{target.id},f.hits);Assert.AreEqual(before,JsonUtility.ToJson(sim.State));
        }
        [Test]
        public void LeapForecastUsesFreshObservedEnemiesAndTheExactSelectedLandingPoint()
        {
            var sim=Fixture(1);var target=Enemy(sim,0,6);Enemy(sim,1,6);Enemy(sim,-1,6);
            var rule=sim.State.build.rules[0];rule.positionPurpose=PositionPurpose.Dense;
            string before=JsonUtility.ToJson(sim.State);var f=sim.ForecastAttack(rule,target);Assert.AreEqual(before,JsonUtility.ToJson(sim.State));Assert.GreaterOrEqual(f.uniqueTargets,1);
            sim.Tick(.05f);Assert.AreEqual(f.impact,sim.State.heroAction.destination);int root=sim.State.heroAction.id;Advance(sim);CollectionAssert.AreEquivalent(f.hits,ActualHits(sim,root,"W02"));
        }
        [Test]
        public void FireballForecastExplodesAtBlockingTerrainWithoutReadingThroughIt()
        {
            var sim=Fixture(12);var target=Enemy(sim,0,6);var adjacent=Enemy(sim,1.5f,2.5f);sim.State.layout.legacy=false;
            sim.State.layout.obstacles.Add(new RiftObstacle{id="wall",position=sim.State.position+Vector2.up*4,halfSize=new Vector2(4,.1f),blocksSight=false,blocksProjectile=true,blocksWalk=false});
            var f=sim.ForecastAttack(sim.State.build.rules[0],target);Assert.Less(f.impact.y,sim.State.position.y+4);Assert.Contains(adjacent.id,f.hits.ToArray());
        }
        [Test]
        public void CoreAimSurvivesSaveRestoreWithoutChangingTheSelectedCandidate()
        {
            var sim=Fixture(7,"LA02");var target=Enemy(sim,0,4);var d=HuntEdictV2.WithOption(Edict(sim,"A02"),"A02",2,"FOCUS");
            var before=sim.PlanEdictAim(d,"A02",target);var account=GameStore.NewAccount();account.selectedHero=1;account.heroes[1]=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(sim.Hero));
            var restored=new CombatSimulation(account,catalog,1,1,JsonUtility.FromJson<RunState>(JsonUtility.ToJson(sim.State)));
            var after=restored.PlanEdictAim(HuntEdictV2Codec.Decode(HuntEdictV2Codec.Encode(d)),"A02",target);Assert.IsTrue(after.available,after.reason);Assert.AreEqual(before.targetId,after.targetId);Assert.AreEqual(before.forecast.aim,after.forecast.aim);CollectionAssert.AreEqual(before.forecast.hits,after.forecast.hits);
        }
        [Test]
        public void LegacyChainHitConditionStillAllowsApproachBeforeTheSeparateRangeCheck()
        {
            var sim=Fixture(14);sim.State.position+=Vector2.down*4;var target=Enemy(sim,0,11);Enemy(sim,1,10);
            var rule=BehaviorRules.Make(14,BehaviorRules.C("SC06",Comparison.AtLeast,2,predicted:true));rule.target=RuleTarget.Current;sim.State.build.rules[0]=rule;sim.State.targetId=target.id;
            Assert.AreEqual(2,sim.PredictedHits(rule,target),"The legacy condition asks about the chain shape; the next step owns range and approach.");
            var d=Edict(sim,"M03");d=HuntEdictV2.WithOption(d,"M03",3,"ELITE");target.elite=0;
            // The v2 aim stage compares first targets that can actually receive the first hit.
            Assert.IsFalse(sim.PlanEdictAim(d,"M03",target).available);
            Vector2 before=sim.State.position;sim.Tick(.05f);Assert.IsFalse(sim.HeroActionBusy);Assert.IsTrue(sim.State.decisions.Any(x=>x.skill==14&&x.code=="RANGE"));Assert.Greater(sim.State.position.y,before.y);
        }
    }
}
