using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace Hellscript.Tests
{
    public sealed class InventoryManagementTests
    {
        string directory;
        GameStore store;
        uint rng;
        static string Json(object value)=>JsonUtility.ToJson(value);
        [SetUp] public void Setup(){directory=Path.Combine(Path.GetTempPath(),"hellscript-inventory-"+Guid.NewGuid().ToString("N"));store=new GameStore(directory);rng=773311;}
        [TearDown] public void Teardown(){if(Directory.Exists(directory))Directory.Delete(directory,true);}
        Item Add(int rarity=2,int slot=1,int level=10,string unique=null,HeroClass hero=HeroClass.Warrior)
        {var item=ItemGenerator.Create(hero,slot,rarity,level,ref rng,uniqueId:unique);Assert.IsTrue(Economy.AddItem(store.Data.Hero,item,BagPolicy.Ignore,store.Data));return item;}
        [Test] public void AcquisitionOrderSurvivesStorageOtherHeroAndRestartWithoutRestamping()
        {
            Item a=Add(),b=Add();long first=a.acquiredOrder,last=b.acquiredOrder;Assert.Greater(last,first);
            store.Data.Hero.inventory.Remove(a);store.Data.warehouse.Add(a);Assert.IsTrue(store.Save());
            var loaded=new GameStore(directory);a=loaded.Data.warehouse.Single();loaded.Data.warehouse.Remove(a);loaded.Data.selectedHero=1;
            Assert.IsTrue(Economy.AddItem(loaded.Data.Hero,a,BagPolicy.Ignore,loaded.Data));Assert.AreEqual(first,a.acquiredOrder);Assert.AreEqual(last,loaded.Data.itemSequence);
            var c=ItemGenerator.Create((HeroClass)1,2,2,10,ref rng);Assert.IsTrue(Economy.AddItem(loaded.Data.Hero,c,BagPolicy.Ignore,loaded.Data));Assert.Greater(c.acquiredOrder,last);
        }
        [Test] public void FailedOrDuplicateAcquisitionDoesNotSpendSequenceOrChangeAnItem()
        {
            var item=Add();long sequence=store.Data.itemSequence;Assert.IsFalse(Economy.AddItem(store.Data.Hero,item,BagPolicy.Ignore,store.Data));Assert.AreEqual(sequence,store.Data.itemSequence);
            store.Data.Hero.capacity=1;var next=ItemGenerator.Create(HeroClass.Warrior,2,2,10,ref rng);Assert.IsFalse(Economy.AddItem(store.Data.Hero,next,BagPolicy.Ignore,store.Data));Assert.AreEqual(0,next.acquiredOrder);Assert.AreEqual(sequence,store.Data.itemSequence);
        }
        [Test] public void UnknownLegacyOrderStaysUnknownAndSortsAfterRecordedItems()
        {
            Item old=Add(),recent=Add();old.acquiredOrder=0;old.reviewed=false;store.Save();var restored=new GameStore(directory);
            var query=new InventoryQuery{slot=1,order=InventoryOrder.Newest};var list=query.Apply(restored.Data.Hero.inventory).ToArray();Assert.AreEqual(recent.id,list[0].id);Assert.AreEqual(0,list[1].acquiredOrder);
            query.unreadOnly=true;Assert.IsFalse(query.Apply(restored.Data.Hero.inventory).Any(i=>i.id==old.id));
        }
        [Test] public void TransactionAdoptsTheSequenceAndRetryDoesNotIssueAnotherItem()
        {
            long before=store.Data.itemSequence;string request="purchase-sequence";
            bool Purchase(AccountSave staged){var item=ItemGenerator.Create(HeroClass.Warrior,1,2,10,ref rng);return Economy.AddItem(staged.Hero,item,BagPolicy.Ignore,staged);}
            Assert.IsTrue(store.Transact(request,"purchase",Purchase));Assert.AreEqual(before+1,store.Data.itemSequence);
            Assert.IsTrue(store.Transact(request,"purchase",Purchase));Assert.AreEqual(before+1,store.Data.itemSequence);
        }
        [Test] public void QueryCombinesSlotGradeClassSetAffixAndUnreadWithoutMutatingInventory()
        {
            var set=Add(3,1,30,"SW1");Add(3,1,30,"SM1",HeroClass.Mage);Add(2,1);Add(3,0,30,"LW01");
            var q=new InventoryQuery{slot=1,grade=InventoryGrade.Set,heroClass=0,setId="SW",affixId=set.rolls[0].affixId,unreadOnly=true};string before=Json(store.Data);
            CollectionAssert.AreEqual(new[]{set.id},q.Apply(store.Data.Hero.inventory).Select(i=>i.id).ToArray());Assert.AreEqual(before,Json(store.Data));
            set.reviewed=true;Assert.IsEmpty(q.Apply(store.Data.Hero.inventory));
        }
        [TestCase(InventoryGrade.Normal,0)] [TestCase(InventoryGrade.Magic,1)] [TestCase(InventoryGrade.Rare,2)]
        public void OrdinaryGradeFiltersDoNotIncludeOtherGrades(InventoryGrade grade,int rarity)
        {for(int r=0;r<4;r++)Add(r);var items=new InventoryQuery{grade=grade}.Apply(store.Data.Hero.inventory).ToArray();Assert.IsNotEmpty(items);Assert.IsTrue(items.All(i=>i.rarity==rarity));}
        [Test] public void LegendaryAndSetFiltersAreSeparateAndClassIncludesCommonGear()
        {
            Item legend=Add(3,0,30,"LW01"),set=Add(3,1,30,"SW1"),common=Add(2,2),mage=Add(3,0,30,"LM01",HeroClass.Mage);
            var all=store.Data.Hero.inventory;
            CollectionAssert.AreEqual(new[]{legend.id,mage.id},new InventoryQuery{grade=InventoryGrade.Legendary}.Apply(all).Select(i=>i.id).ToArray());
            CollectionAssert.AreEqual(new[]{set.id},new InventoryQuery{grade=InventoryGrade.Set}.Apply(all).Select(i=>i.id).ToArray());
            Assert.IsTrue(new InventoryQuery{heroClass=0}.Matches(common));Assert.IsFalse(new InventoryQuery{heroClass=0}.Matches(mage));Assert.IsFalse(new InventoryQuery{heroClass=-1}.Matches(legend));
        }
        [TestCase(InventoryOrder.Newest)] [TestCase(InventoryOrder.Oldest)] [TestCase(InventoryOrder.Level)] [TestCase(InventoryOrder.Grade)]
        public void SortUsesRecordedOrderAndStableTiesWithoutReorderingTheSave(InventoryOrder order)
        {
            Item a=Add(1,2,3),b=Add(2,2,20);string before=Json(store.Data);
            var items=new InventoryQuery{slot=2,order=order}.Apply(store.Data.Hero.inventory).ToArray();Assert.AreEqual(order==InventoryOrder.Oldest?a.id:b.id,items[0].id);Assert.AreEqual(before,Json(store.Data));
        }
        [Test] public void NamedUniqueEffectFilterKeepsTheRequestedItemAndCombinesWithSetChoice()
        {
            Item first=Add(3,1,30,"SW1"),second=Add(3,2,30,"SW2");var query=new InventoryQuery{uniqueId="SW1",setId="SW"};
            CollectionAssert.AreEqual(new[]{first.id},query.Apply(store.Data.Hero.inventory).Select(i=>i.id));query.setId="SM";Assert.IsEmpty(query.Apply(store.Data.Hero.inventory));
        }
        [TestCase(InventoryBulkOperation.Sell)] [TestCase(InventoryBulkOperation.Dismantle)]
        public void BulkPreviewExcludesAllProtectionKindsAndExactRewardsMatchCommit(InventoryBulkOperation operation)
        {
            Item eligible=Add(),locked=Add(),referenced=Add(),legend=Add(3,0,30,"LW01");locked.locked=true;store.Data.heroes[1].presets[0]=store.Data.heroes[1].build.Copy();store.Data.heroes[1].presets[0].equipmentIds.Add(referenced.id);
            eligible.enhancement=2;eligible.investedMaterials=60;
            var plan=new InventoryBulkPlan(store.Data,store.Data.Hero.inventory.Select(i=>i.id),operation);Assert.AreEqual(1,plan.Count);Assert.AreEqual(store.Data.Hero.inventory.Count-1,plan.entries.Count(e=>e.excludedReason!=""));
            Assert.AreEqual(operation==InventoryBulkOperation.Sell?eligible.Price:0,plan.Gold);Assert.AreEqual(operation==InventoryBulkOperation.Dismantle?53:0,plan.Materials);
            int gold=store.Data.gold,mats=store.Data.materials;Assert.IsTrue(store.Transact(plan.requestId,plan.operationKey,plan.Apply),store.Error);
            Assert.AreEqual(gold+plan.Gold,store.Data.gold);Assert.AreEqual(mats+plan.Materials,store.Data.materials);Assert.IsFalse(store.Data.Hero.inventory.Any(i=>i.id==eligible.id));
            Assert.IsTrue(store.Transact(plan.requestId,plan.operationKey,plan.Apply));Assert.AreEqual(gold+plan.Gold,store.Data.gold);Assert.AreEqual(mats+plan.Materials,store.Data.materials);
        }
        [TestCase("lock")] [TestCase("reference")] [TestCase("enhance")] [TestCase("remove")] [TestCase("hero")]
        public void StalePreviewRejectsWholeTransactionWithoutPartialDisposal(string change)
        {
            Item first=Add(),second=Add();var plan=new InventoryBulkPlan(store.Data,new[]{first.id,second.id},InventoryBulkOperation.Dismantle);
            if(change=="lock")second.locked=true;else if(change=="reference")store.Data.heroes[1].build.equipmentIds.Add(second.id);
            else if(change=="enhance"){second.enhancement=1;second.investedMaterials=20;}else if(change=="remove")store.Data.Hero.inventory.Remove(second);else store.Data.selectedHero=1;
            string before=Json(store.Data);Assert.IsFalse(store.Transact(plan.requestId,plan.operationKey,plan.Apply));Assert.AreEqual(before,Json(store.Data));
        }
        [Test] public void FilteredPlanNeverConsumesAnItemOutsideItsPreview()
        {
            Item first=Add(1),outside=Add(2);var query=new InventoryQuery{grade=InventoryGrade.Magic};
            var plan=new InventoryBulkPlan(store.Data,query.Apply(store.Data.Hero.inventory).Select(i=>i.id),InventoryBulkOperation.Sell);Assert.IsTrue(store.Transact(plan.requestId,plan.operationKey,plan.Apply));
            Assert.IsTrue(store.Data.Hero.inventory.Any(i=>i.id==outside.id));Assert.IsFalse(store.Data.Hero.inventory.Any(i=>i.id==first.id));
        }
        [Test] public void WriteFailureRetainsPreviewInputsAndRetryCommitsOnce()
        {
            Add();var plan=new InventoryBulkPlan(store.Data,store.Data.Hero.inventory.Select(i=>i.id),InventoryBulkOperation.Dismantle);Assert.IsTrue(store.Save());string before=Json(store.Data),disk=File.ReadAllText(Path.Combine(directory,"hellscript-local-v1.json"));
            string temp=Path.Combine(directory,"hellscript-local-v1.json.tmp");Directory.CreateDirectory(temp);LogAssert.Expect(LogType.Error,new Regex("저장하지 못했습니다:"));
            Assert.IsFalse(store.Transact(plan.requestId,plan.operationKey,plan.Apply));Assert.AreEqual(before,Json(store.Data));Assert.AreEqual(disk,File.ReadAllText(Path.Combine(directory,"hellscript-local-v1.json")));
            Directory.Delete(temp);Assert.IsTrue(store.Transact(plan.requestId,plan.operationKey,plan.Apply));Assert.IsTrue(store.Transact(plan.requestId,plan.operationKey,plan.Apply));
        }
        [TestCase(InventoryBulkOperation.Sell)] [TestCase(InventoryBulkOperation.Dismantle)]
        public void CurrencyOverflowRejectsWithoutRemovingItems(InventoryBulkOperation operation)
        {
            Add();Add();store.Data.gold=store.Data.materials=int.MaxValue-1;var plan=new InventoryBulkPlan(store.Data,store.Data.Hero.inventory.Select(i=>i.id),operation);string before=Json(store.Data);
            Assert.IsFalse(store.Transact(plan.requestId,plan.operationKey,plan.Apply));Assert.AreEqual(before,Json(store.Data));
        }
    }
}
