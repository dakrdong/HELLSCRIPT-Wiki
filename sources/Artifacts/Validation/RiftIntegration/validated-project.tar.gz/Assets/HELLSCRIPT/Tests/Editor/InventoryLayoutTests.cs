using NUnit.Framework;

namespace Hellscript.Tests
{
    public sealed class InventoryLayoutTests
    {
        [TestCase(360,640)] [TestCase(390,844)] [TestCase(640,360)] [TestCase(720,1280)]
        [TestCase(818,390)] [TestCase(820,390)] [TestCase(844,390)]
        [TestCase(958,640)] [TestCase(960,640)] [TestCase(1280,720)] [TestCase(1438,720)]
        [TestCase(1440,720)] [TestCase(1920,1080)] [TestCase(1920,1200)] [TestCase(3440,1440)]
        public void PanelsKeepPositiveSpaceAndFixedActionsWithinEachWindow(int width,int height)
        {
            var layout=new InventoryLayout(width,height,true);Assert.Greater(layout.tool.height,0);Assert.Greater(layout.list.width,0);Assert.Greater(layout.detail.width,0);
            Assert.Less(layout.header.yMax,layout.tool.yMin);Assert.Less(layout.tool.yMax,layout.footer.yMin);Assert.AreEqual(height,layout.footer.yMax);
            if(layout.split)Assert.Less(layout.list.xMax,layout.detail.xMin);
            if(layout.three){Assert.Less(layout.detail.xMax,layout.comparison.xMin);Assert.LessOrEqual(layout.comparison.xMax,width);}
        }
    }
}
