using System;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class EffectTests
    {
        GameCatalog catalog;
        [SetUp]public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown]public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        static object Call(CombatSimulation sim,string name,params object[] arguments)
        {
            var method=typeof(CombatSimulation).GetMethod(name,BindingFlags.Instance|BindingFlags.NonPublic);
            var parameters=method.GetParameters();var filled=new object[parameters.Length];
            for(int i=0;i<filled.Length;i++)filled[i]=i<arguments.Length?arguments[i]:parameters[i].DefaultValue;
            return method.Invoke(sim,filled);
        }
        static void ControlledStats(CombatSimulation sim)
        {sim.Stats.hp=1000;sim.Stats.damage=100;sim.Stats.armor=sim.Stats.resistance=sim.Stats.regen=sim.Stats.crit=0;sim.Stats.shieldMultiplier=sim.Stats.healing=1;}
        CombatSimulation Fixture(HeroClass hero=HeroClass.Mage)
        {
            var account=GameStore.NewAccount();account.selectedHero=(int)hero;account.Hero.level=30;account.Hero.build.passives=Array.Empty<int>();account.Hero.build.potionThreshold=0;
            var sim=new CombatSimulation(account,catalog,1,1,seed:92);sim.State.build.rules.Clear();sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();sim.State.decisionTime=100;
            sim.State.enemies.Add(new EnemyState{id=900,position=sim.State.position+Vector2.up*2,health=10000,maxHealth=10000,cooldown=1000,speed=0});
            ControlledStats(sim);sim.State.health=1000;return sim;
        }
        static DamageSnapshot Snapshot(float damage=100)=>new DamageSnapshot{damage=damage,level=30,critDamage=1.5f,elements=new float[6],passives=new bool[6]};
        static void Advance(CombatSimulation sim,int ticks){for(int i=0;i<ticks;i++)sim.Tick(.05f);}
        CombatSimulation Restore(CombatSimulation original)
        {
            var account=GameStore.NewAccount();account.selectedHero=(int)original.Hero.heroClass;account.heroes[account.selectedHero]=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(original.Hero));
            var sim=new CombatSimulation(account,catalog,1,1,JsonUtility.FromJson<RunState>(JsonUtility.ToJson(original.State)));ControlledStats(sim);
            foreach(var special in original.Stats.specials)sim.Stats.specials.Add(special);return sim;
        }
        [TestCase(0,.75f)][TestCase(1,.7f)][TestCase(2,.7f)][TestCase(3,.7f)][TestCase(4,.7f)][TestCase(5,.7f)]
        public void DamageBucketsUseOneAdditiveGroupAndElementSpecificCaps(int element,float cap)
        {
            var n=DamageMath.Calculate(100,.3f,2,1.5f,1000000,30,element,.9f);
            Assert.AreEqual(390,n.beforeDefense,.001f);Assert.AreEqual(cap,n.defenseReduction,.00001f);Assert.AreEqual(.5f,n.buffReduction);
            Assert.AreEqual(390*(1-cap)*.5f,n.final,.001f);
        }
        [Test]
        public void ShieldSourcesCoexistAndShortestThenOldestAbsorbsFirst()
        {
            var sim=Fixture();Call(sim,"AddShield","M05",300f,4f,1);Call(sim,"AddShield","LC03",100f,3f,2);Call(sim,"Hurt",150f);
            Assert.AreEqual(250,sim.State.shield);Assert.AreEqual(1000,sim.State.health);Assert.AreEqual("M05",sim.State.shields.Single().definitionId);
            CollectionAssert.AreEqual(new[]{"LC03","M05"},sim.State.effectEvents.Where(e=>e.kind=="ABSORB").Select(e=>e.definitionId));
            Call(sim,"AddShield","OTHER",100f,4f,3);Call(sim,"Hurt",260f);Assert.AreEqual(90,sim.State.shields.Single().amount);Assert.AreEqual("OTHER",sim.State.shields.Single().definitionId);
        }
        [Test]
        public void SameSourceReplacesItsInstanceAndTotalShieldNeverExceedsMaxHp()
        {
            var sim=Fixture();Call(sim,"AddShield","M05",700f,4f,1);int prior=sim.State.shields.Single().id;Call(sim,"Hurt",50f);
            Call(sim,"AddShield","M05",100f,4f,2);Assert.AreEqual(650,sim.State.shield);Assert.AreNotEqual(prior,sim.State.shields.Single().id);Assert.AreEqual(0,sim.State.shields.Single().absorbed);
            Call(sim,"AddShield","LC03",500f,3f,3);Assert.AreEqual(1000,sim.State.shield);Assert.AreEqual(350,sim.State.shields.Single(s=>s.definitionId=="LC03").amount);
        }
        [Test]
        public void ShieldScalingUsesWillAndShieldPassiveButNotReceivedHealing()
        {
            var account=GameStore.NewAccount();account.selectedHero=2;account.Hero.level=30;account.Hero.build.passives=new[]{3};var stats=new HeroStats(account.Hero);
            Assert.AreEqual(1.239f,stats.shieldMultiplier,.0001f);
            var sim=Fixture();sim.Stats.shieldMultiplier=stats.shieldMultiplier;sim.Stats.healing=99;Call(sim,"AddShield","M05",100f,4f,1);Assert.AreEqual(123.9f,sim.State.shield,.001f);
        }
        [Test]
        public void ManaLegendCountsOnlyItsOwnActualAbsorptionCumulativelyOnce()
        {
            var sim=Fixture();sim.Stats.specials.Add("LM03");sim.State.resource=0;Call(sim,"AddShield","M05",300f,4f,1);Call(sim,"AddShield","LC03",100f,3f,2);
            Call(sim,"Hurt",200f);Assert.AreEqual(0,sim.State.resource);Assert.AreEqual(100,sim.State.shields.Single().absorbed);
            Call(sim,"Hurt",50f);Assert.AreEqual(20,sim.State.resource);Call(sim,"Hurt",100f);Assert.AreEqual(20,sim.State.resource);
            Assert.AreEqual(1,sim.State.effectEvents.Count(e=>e.definitionId=="LM03"&&e.kind=="RESOURCE"));
        }
        [TestCase(false,false,20)][TestCase(true,false,0)][TestCase(false,true,0)]
        public void QualifiedShieldWaitsForCooldownOnlyWhileTheInstanceSurvives(bool expires,bool depleted,int reward)
        {
            var sim=Fixture();sim.Stats.specials.Add("LM03");sim.State.resource=0;sim.State.itemEffects.lm03Cooldown=1;
            Call(sim,"AddShield","M05",depleted?150f:300f,expires?1f:4f,1);Call(sim,"Hurt",150f);Assert.AreEqual(0,sim.State.resource);
            Call(sim,"TickShields",1f);Assert.AreEqual(reward,sim.State.resource);
        }
        [Test]
        public void ManaThresholdUsesCreationMaxHpAndCanPayOnTheDepletingHit()
        {
            var sim=Fixture();sim.Stats.specials.Add("LM03");sim.State.resource=0;Call(sim,"AddShield","M05",150f,4f,1);sim.Stats.hp=2000;Call(sim,"Hurt",150f);
            Assert.AreEqual(20,sim.State.resource);Assert.IsEmpty(sim.State.shields);
        }
        [TestCase(200,true)][TestCase(200.1f,false)][TestCase(0,false)]
        public void PotionLegendChecksLivingHpBeforeHealing(float hp,bool shield)
        {
            var sim=Fixture();sim.Stats.specials.Add("LC03");sim.State.build.potionThreshold=50;sim.State.health=hp;Call(sim,"UsePotion");
            Assert.AreEqual(shield,sim.State.shields.Any(s=>s.definitionId=="LC03"));if(hp==0)Assert.AreEqual(0,sim.State.health);else Assert.AreEqual(hp+350,sim.State.health,.001f);
        }
        [Test]
        public void PotionLegendHasIndependentCooldownAndDoesNotChangePotionPolicy()
        {
            var sim=Fixture();sim.Stats.specials.Add("LC03");sim.State.build.potionThreshold=45;sim.State.health=100;Call(sim,"UsePotion");
            int id=sim.State.shields.Single().id;sim.State.potionCd=0;sim.State.health=100;Call(sim,"UsePotion");
            Assert.AreEqual(id,sim.State.shields.Single().id);Assert.AreEqual(20,sim.State.itemEffects.lc03Cooldown);Assert.AreEqual(45,sim.State.build.potionThreshold);
        }
        [TestCase(310,20,4,true,true)][TestCase(300,20,4,true,false)][TestCase(310,400,4,true,false)][TestCase(310,20,0,true,false)][TestCase(310,20,4,false,false)]
        public void EmergencyLeapResetRequiresALivingThresholdCrossingAndEquippedCoolingLeap(float hp,float damage,float cd,bool equipped,bool reset)
        {
            var sim=Fixture(HeroClass.Warrior);sim.State.build.activeSkills.Clear();if(equipped)sim.State.build.activeSkills.Add(1);sim.Stats.specials.Add("LW04");sim.State.itemEffects.procCooldown=3;
            sim.State.health=hp;sim.State.cooldowns[1]=cd;Call(sim,"Hurt",damage);
            Assert.AreEqual(reset?0:cd,sim.State.cooldowns[1]);Assert.AreEqual(reset?30:0,sim.State.itemEffects.lw04Cooldown);Assert.AreEqual(3,sim.State.itemEffects.procCooldown);
        }
        [Test]
        public void NonphysicalIncomingDamageUsesResistanceAndRecordsHpSeparatelyFromShield()
        {
            var sim=Fixture();sim.Stats.armor=10000;sim.Stats.resistance=110;Call(sim,"AddShield","M05",25f,4f,7);Call(sim,"Hurt",100f,2,"901","FROST",88,99);
            var hit=sim.State.damageEvents.Single();Assert.AreEqual(50,hit.finalDamage,.001f);Assert.AreEqual(25,hit.absorbed);Assert.AreEqual(25,hit.hpLoss,.001f);Assert.AreEqual(975,sim.State.health,.001f);Assert.AreEqual(88,hit.rootCastId);Assert.AreEqual("901",hit.casterId);
        }
        [Test]
        public void ShadowAndSpreadUseShadowResistanceWithoutReusingPostPhysicalDamage()
        {
            var sim=Fixture(HeroClass.Ranger);sim.Stats.specials.Add("LA04");var enemy=sim.State.enemies[0];Call(sim,"ApplyStatus",enemy,StatusKind.Poisoned,"A03",2f,1,1f);
            sim.State.enemies.Add(new EnemyState{id=901,position=enemy.position+Vector2.right,health=10000,maxHealth=10000,cooldown=1000});
            var snap=Snapshot();snap.elements[0]=.4f;snap.elements[5]=.8f;
            Call(sim,"Hit",enemy,1f,0,true,0f,snap,false,true,"A01",77,78,DamageKind.Direct);
            var direct=sim.State.damageEvents.Single(e=>e.definitionId=="A01");var shadow=sim.State.damageEvents.Single(e=>e.definitionId=="A06");var spread=sim.State.damageEvents.Single(e=>e.definitionId=="LA04");
            Assert.AreEqual(140,direct.attackBeforeDefense,.001f);Assert.AreEqual(45,shadow.attackBeforeDefense,.001f);Assert.AreEqual(45*400f/405,shadow.finalDamage,.001f);Assert.AreEqual(22.5f*400/405,spread.finalDamage,.001f);
            Call(sim,"Hit",enemy,1f,0,true,0f,snap,false,true,"A01",77,79,DamageKind.Direct);Assert.AreEqual(1,sim.State.damageEvents.Count(e=>e.definitionId=="LA04"));
        }
        [Test]
        public void AnonymousForeignAndSetPoisonNeverCountAsOwnTrapPoison()
        {
            var sim=Fixture(HeroClass.Ranger);var e=sim.State.enemies[0];e.poison=10;
            e.statuses.Add(new StatusEffect{definitionId="A03",casterId="foreign",kind=StatusKind.Poisoned,remaining=4});e.statuses.Add(new StatusEffect{definitionId="SA4",casterId=sim.State.heroId,kind=StatusKind.Poisoned,remaining=4});
            Assert.IsTrue(CombatEffects.Has(e,StatusKind.Poisoned));Assert.IsFalse(CombatEffects.OwnTrapPoison(e,sim.State.heroId));
            Call(sim,"ApplyStatus",e,StatusKind.Poisoned,"LA03",1f,8,1f);Assert.IsTrue(CombatEffects.OwnTrapPoison(e,sim.State.heroId));
        }
        [Test]
        public void OverlappingBlizzardsUseOnlyStrongerFrozenAttackAndCannotCrit()
        {
            var sim=Fixture();var weak=Snapshot(60);var strong=Snapshot(100);strong.bonus=.3f;strong.elements[2]=.4f;strong.crit=1;strong.passives[1]=true;
            foreach(var snap in new[]{weak,strong})sim.State.effects.Add(new GroundEffect{id=sim.State.nextId++,kind=13,position=sim.State.enemies[0].position,radius=3,duration=6,damage=snap.damage*.65f,snapshot=snap,definitionId="M02",rootCastId=50});
            sim.Stats.damage=999999;Advance(sim,10);var hit=sim.State.damageEvents.Single(e=>e.definitionId=="M02");Assert.IsFalse(hit.critical);Assert.AreEqual(32.5f*1.7f*400/405,hit.finalDamage,.001f);
            Assert.AreEqual(.55f,(float)Call(sim,"SlowRatio",sim.State.enemies[0]),.0001f);Advance(sim,110);Assert.AreEqual(12,sim.State.damageEvents.Count(e=>e.definitionId=="M02"));Assert.IsEmpty(sim.State.effects);
        }
        [Test]
        public void RepeatedControlFromOneCastCreditsOnceAndBossStaggersThenBecomesImmune()
        {
            var sim=Fixture();var e=sim.State.enemies[0];e.boss=true;e.windup=1;
            Call(sim,"ApplyStatus",e,StatusKind.Root,"A03",1f,1,1f);Call(sim,"ApplyStatus",e,StatusKind.Root,"A03",1f,1,1f);Assert.AreEqual(10,e.bossControl.meter);Assert.IsFalse(CombatEffects.Has(e,StatusKind.Root));
            for(int i=2;i<=10;i++)Call(sim,"ApplyStatus",e,StatusKind.Root,"A03",1f,i,1f);
            Assert.AreEqual(3,e.bossControl.staggered);Assert.AreEqual(0,e.windup);Assert.GreaterOrEqual(e.cooldown,6);Assert.AreEqual(0,e.bossControl.meter);
            for(int i=0;i<60;i++)Call(sim,"TickStatuses",.05f);Assert.AreEqual(0,e.bossControl.staggered);Assert.AreEqual(10,e.bossControl.immunity);
            Call(sim,"ApplyStatus",e,StatusKind.Freeze,"M06",1.5f,11,1f);Assert.AreEqual(0,e.bossControl.meter);
            for(int i=0;i<200;i++)Call(sim,"TickStatuses",.05f);Call(sim,"ApplyStatus",e,StatusKind.Freeze,"M06",1.5f,12,1f);Assert.AreEqual(15,e.bossControl.meter);
        }
        [Test]
        public void BossSlowUsesOnlyTheStrongestRatioAndNeverAlsoSlowsItsMovement()
        {
            var sim=Fixture();var e=sim.State.enemies[0];e.boss=true;
            Call(sim,"ApplyStatus",e,StatusKind.Slow,"FIRST",2f,1,.35f);Call(sim,"ApplyStatus",e,StatusKind.Slow,"SECOND",2f,2,.55f);
            Call(sim,"TickStatuses",1f);Assert.AreEqual(5.5f,e.bossControl.meter,.001f);Assert.AreEqual(0,(float)Call(sim,"SlowRatio",e));
        }
        [Test]
        public void SourceEffectsCooldownsAndDamageReceiptsRestoreExactlyAndFreeze()
        {
            var sim=Fixture();sim.Stats.specials.Add("LM03");sim.State.resource=0;sim.State.itemEffects.lm03Cooldown=1;Call(sim,"AddShield","M05",300f,4f,9);Call(sim,"Hurt",160f);
            var enemy=sim.State.enemies[0];enemy.boss=true;Call(sim,"ApplyStatus",enemy,StatusKind.Root,"A03",1.5f,3,1f);Call(sim,"ApplyStatus",enemy,StatusKind.Slow,"M02",3f,4,.55f);
            var restored=Restore(sim);for(int i=0;i<30;i++){sim.Tick(.05f);restored.Tick(.05f);Assert.AreEqual(JsonUtility.ToJson(sim.State),JsonUtility.ToJson(restored.State),"tick "+i);}
            Assert.AreEqual(20,sim.State.resource);sim.State.paused=true;string before=JsonUtility.ToJson(sim.State);sim.Tick(1);Assert.AreEqual(before,JsonUtility.ToJson(sim.State));sim.State.paused=false;sim.State.portal=true;before=JsonUtility.ToJson(sim.State);sim.Tick(1);Assert.AreEqual(before,JsonUtility.ToJson(sim.State));
        }
        [Test]
        public void LegacyShieldMigrationIsIdempotentAndCannotEarnM05Mana()
        {
            var sim=Fixture();sim.State.effectVersion=0;sim.State.shield=160;sim.State.shieldTime=3;sim.Stats.specials.Add("LM03");sim.State.resource=0;
            GameStore.NormalizeRun(sim.State);string first=JsonUtility.ToJson(sim.State);GameStore.NormalizeRun(sim.State);Assert.AreEqual(first,JsonUtility.ToJson(sim.State));
            Call(sim,"Hurt",160f);Assert.AreEqual(0,sim.State.resource);sim.State.effectVersion=99;Assert.Throws<NotSupportedException>(()=>GameStore.NormalizeRun(sim.State));
        }
        [Test]
        public void FireballAftershockSnapshotsImpactStatsAndExplodesOnlyOnceWithoutConsumingFrostMark()
        {
            var sim=Fixture();sim.Stats.specials.Add("LM02");var enemy=sim.State.enemies[0];
            var p=new CombatProjectile{id=70,actionId=71,skill=12,position=enemy.position,coefficient=2.1f,explosionRadius=2.5f,snapshot=Snapshot(10)};
            sim.Stats.damage=200;Call(sim,"FireballImpact",p);Assert.AreEqual(140,sim.State.effects.Single().damage,.001f);
            sim.Stats.damage=9000;enemy.frostMarkTime=4;Advance(sim,7);Assert.IsFalse(sim.State.damageEvents.Any(e=>e.definitionId=="LM02"));Advance(sim,1);
            var hit=sim.State.damageEvents.Single(e=>e.definitionId=="LM02");Assert.AreEqual(140,hit.baseAttack,.001f);Assert.AreEqual(71,hit.rootCastId);Assert.Greater(enemy.frostMarkTime,0);Assert.IsEmpty(sim.State.effects);
            Advance(sim,20);Assert.AreEqual(1,sim.State.damageEvents.Count(e=>e.definitionId=="LM02"));
        }
        [Test]
        public void ChainVisitsUnvisitedTargetsBeforeRevisitingANearerOne()
        {
            var sim=Fixture();sim.Stats.specials.Add("LM04");var origin=sim.State.position;
            sim.State.enemies.Add(new EnemyState{id=901,position=origin+Vector2.up*3,health=10000,maxHealth=10000});sim.State.enemies.Add(new EnemyState{id=902,position=origin+Vector2.up*6,health=10000,maxHealth=10000});
            Call(sim,"ResolveSkill",new HeroActionState{id=22,skill=14,targetId=900,origin=origin,snapshot=Snapshot()});
            CollectionAssert.AreEqual(new[]{900,901,902,901},sim.State.damageEvents.Select(d=>d.targetId));Assert.AreEqual(28.16f,sim.State.damageEvents.Last().baseAttack,.001f);
        }
        [Test]
        public void TrapPassiveExtendsRootByTwentyFivePercentAndStatusKeepsItsSource()
        {
            var sim=Fixture(HeroClass.Ranger);var snap=Snapshot();snap.passives[3]=true;
            Call(sim,"CreateTrap",new HeroActionState{id=51,skill=8,snapshot=snap},sim.State.enemies[0].position,5f);Advance(sim,10);
            var root=sim.State.enemies[0].statuses.Single(s=>s.kind==StatusKind.Root);Assert.AreEqual(1.875f,root.remaining,.0001f);Assert.AreEqual("A03",root.definitionId);Assert.AreEqual(51,root.rootCastId);
        }
        [Test]
        public void FollowingBlizzardKeepsItsCreationModeAndMovesAtMostFourMeters()
        {
            var sim=Fixture();var target=sim.State.enemies[0];target.position=sim.State.position+Vector2.up*6;sim.State.targetId=target.id;sim.Stats.specials.Add("LM01");
            Call(sim,"AddGround",sim.State.position,3f,0f,6f,65f,false,13);var fx=sim.State.effects.Single();sim.Stats.specials.Remove("LM01");Advance(sim,90);
            Assert.IsTrue(fx.followsTarget);Assert.AreEqual(4,fx.moved,.001f);Assert.AreEqual(4,Vector2.Distance(fx.position,sim.State.position),.001f);
        }
        [Test]
        public void KillHealingAppliesReceivedHealingOnceAndHasOneSecondCooldown()
        {
            var sim=Fixture(HeroClass.Warrior);sim.Stats.passives[3]=true;sim.Stats.healing=1.5f;sim.State.health=500;
            for(int i=0;i<2;i++)
            {var e=new EnemyState{id=950+i,position=sim.State.position,health=1,maxHealth=1,add=true};sim.State.enemies.Add(e);Call(sim,"Hit",e,1f,0,false,0f,Snapshot(),false);}
            Assert.AreEqual(500,sim.State.health,"Kill healing waits for death settlement.");sim.Tick(.05f);
            Assert.AreEqual(530,sim.State.health);Assert.AreEqual(0,sim.State.itemEffects.lastHeal);
        }
        [Test]
        public void WeakerSlowBecomesEffectiveAfterStrongerCastExpires()
        {
            var sim=Fixture();var e=sim.State.enemies[0];Call(sim,"ApplyStatus",e,StatusKind.Slow,"M02",.5f,1,.55f);Call(sim,"ApplyStatus",e,StatusKind.Slow,"M02",2f,2,.35f);
            Assert.AreEqual(.55f,(float)Call(sim,"SlowRatio",e),.00001f);Call(sim,"TickStatuses",.5f);Assert.AreEqual(.35f,(float)Call(sim,"SlowRatio",e),.00001f);
            e.boss=true;Call(sim,"ApplyStatus",e,StatusKind.Freeze,"CONTROL",1f,3,1f);Call(sim,"ApplyStatus",e,StatusKind.Root,"CONTROL",1f,3,1f);Assert.AreEqual(10,e.bossControl.meter);
        }
    }
}
