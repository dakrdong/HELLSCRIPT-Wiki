using System;
using System.IO;
using System.Linq;
using NUnit.Framework;

namespace Hellscript.Tests
{
    public sealed class InterfaceScaleTests
    {
        string directory;
        InterfaceScaleStore store;
        [SetUp] public void Setup() { directory = Path.Combine(Path.GetTempPath(), "hellscript-scale-test-" + Guid.NewGuid().ToString("N")); store = new InterfaceScaleStore(directory); }
        [TearDown] public void Teardown() { if (Directory.Exists(directory)) Directory.Delete(directory, true); }
        InterfaceScaleSession Session(Func<int, bool> save = null) => new InterfaceScaleSession(store.Read(), save ?? store.Write);

        [Test] public void StepsCoverThePlannedRangeInOrder()
        {
            Assert.AreEqual(InterfaceScaleOptions.Minimum, InterfaceScaleOptions.Steps.First());
            Assert.AreEqual(InterfaceScaleOptions.Maximum, InterfaceScaleOptions.Steps.Last());
            CollectionAssert.AreEqual(InterfaceScaleOptions.Steps.OrderBy(x => x).ToArray(), InterfaceScaleOptions.Steps);
            CollectionAssert.AllItemsAreUnique(InterfaceScaleOptions.Steps);
            Assert.AreEqual(1f, InterfaceScaleOptions.Factor(InterfaceScaleOptions.Default));
            Assert.AreEqual(1.4f, InterfaceScaleOptions.Factor(140), .0001f);
        }
        [TestCase(0, 100)] [TestCase(90, 100)] [TestCase(101, 100)] [TestCase(118, 115)] [TestCase(133, 130)] [TestCase(200, 140)]
        public void AnUnknownSizeSnapsToTheNearestStep(int asked, int expected) => Assert.AreEqual(expected, InterfaceScaleOptions.Nearest(asked));

        [Test] public void MissingPreferenceStartsAtTheDefaultWithoutCreatingFiles()
        { Assert.AreEqual(InterfaceScaleOptions.Default, store.Read()); Assert.IsEmpty(store.Error); Assert.IsFalse(Directory.Exists(directory)); }

        [TestCase(100)] [TestCase(115)] [TestCase(130)] [TestCase(140)]
        public void AppliedSizeSurvivesANewStoreAndLeavesAccountBytesAlone(int percent)
        {
            Directory.CreateDirectory(directory); var account = Path.Combine(directory, "hellscript-local-v1.json"); File.WriteAllText(account, "unchanged account bytes");
            var session = Session();
            Assert.IsTrue(session.Apply(percent));
            Assert.AreEqual(percent, session.Percent); Assert.AreEqual(percent, session.Saved); Assert.IsFalse(session.CanRetrySave);
            Assert.AreEqual(percent, new InterfaceScaleStore(directory).Read());
            Assert.AreEqual("unchanged account bytes", File.ReadAllText(account));
        }
        [Test] public void TheDisplayDirectionFileIsNotTouched()
        {
            Directory.CreateDirectory(directory); var display = new DeviceDisplayStore(directory);
            Assert.IsTrue(display.Write(DeviceScreenDirection.Landscape)); string before = File.ReadAllText(display.Path);
            Assert.IsTrue(Session().Apply(130));
            Assert.AreNotEqual(display.Path, store.Path);
            Assert.AreEqual(before, File.ReadAllText(display.Path));
            Assert.AreEqual(DeviceScreenDirection.Landscape, new DeviceDisplayStore(directory).Read());
        }
        [TestCase("{}")] [TestCase("{\"version\":2,\"percent\":100}")] [TestCase("{\"version\":1,\"percent\":200}")]
        [TestCase("{\"version\":1,\"percent\":0}")] [TestCase("malformed")]
        public void InvalidPreferenceUsesTheDefaultWithoutOverwritingTheOriginal(string original)
        {
            Directory.CreateDirectory(directory); File.WriteAllText(store.Path, original);
            Assert.AreEqual(InterfaceScaleOptions.Default, store.Read()); Assert.IsNotEmpty(store.Error); Assert.AreEqual(original, File.ReadAllText(store.Path));
        }
        [Test] public void OversizedPreferenceIsPreserved()
        {
            Directory.CreateDirectory(directory); string original = new string('x', 1025); File.WriteAllText(store.Path, original);
            Assert.AreEqual(InterfaceScaleOptions.Default, store.Read()); Assert.IsNotEmpty(store.Error); Assert.AreEqual(original, File.ReadAllText(store.Path));
        }
        [Test] public void WritingAValueOutsideTheStepsIsRejectedBeforeAnyFileIsCreated()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => store.Write(120));
            Assert.IsFalse(File.Exists(store.Path));
        }
        [Test] public void AFailedSaveKeepsTheChosenSizeOnScreenAndOffersARetry()
        {
            Assert.IsTrue(store.Write(115)); string before = File.ReadAllText(store.Path);
            var session = new InterfaceScaleSession(store.Read(), _ => throw new IOException("device is full"));
            Assert.IsFalse(session.Apply(140));
            Assert.AreEqual(140, session.Percent); Assert.AreEqual(115, session.Saved); Assert.IsTrue(session.CanRetrySave); Assert.IsNotEmpty(session.Message);
            Assert.AreEqual(before, File.ReadAllText(store.Path));
        }
        [Test] public void RetryingAfterAFailedSaveStoresTheSizeThatIsAlreadyOnScreen()
        {
            bool broken = true;
            var session = new InterfaceScaleSession(InterfaceScaleOptions.Default, percent => broken ? false : store.Write(percent));
            Assert.IsFalse(session.Apply(130)); Assert.IsFalse(File.Exists(store.Path));
            broken = false;
            Assert.IsTrue(session.RetrySave());
            Assert.AreEqual(130, session.Saved); Assert.IsFalse(session.CanRetrySave); Assert.AreEqual(130, new InterfaceScaleStore(directory).Read());
            Assert.IsFalse(session.RetrySave());
        }
        [Test] public void ASessionStartedFromADamagedPreferenceStillWritesACleanValue()
        {
            Directory.CreateDirectory(directory); File.WriteAllText(store.Path, "malformed");
            var session = Session(); Assert.AreEqual(InterfaceScaleOptions.Default, session.Percent);
            Assert.IsTrue(session.Apply(140)); Assert.AreEqual(140, new InterfaceScaleStore(directory).Read());
        }
    }
}
