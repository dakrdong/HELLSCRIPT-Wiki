using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class EdictTargetIntegrationTests
    {
        GameCatalog catalog;
        [SetUp] public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown] public void Teardown()=>Object.DestroyImmediate(catalog);
        CombatSimulation Fixture(params (string id,string value)[] settings)
        {
            var a=GameStore.NewAccount(catalog);a.selectedHero=2;var hero=a.Hero;hero.level=30;
            hero.build=BehaviorPresets.ForLevel(HeroClass.Mage,0,30,catalog);
            hero.build.rules=new List<Rule>{BehaviorRules.Utility(RuleAction.Basic)};
            hero.edict=HuntEdictV2Storage.CreateForHero(hero);hero.useEdict=true;
            foreach(var setting in settings)hero.edict=HuntEdictV2Editing.WithGlobal(hero.edict,setting.id,setting.value);
            var sim=new CombatSimulation(a,catalog,1,0,seed:719);
            sim.State.enemies.Clear();sim.State.position=RiftMap.Rooms[0];return sim;
        }
        static EnemyState Enemy(CombatSimulation sim,float x,float y=0,int kind=0,int elite=-1,bool boss=false,float hp=10000)
        {
            var e=new EnemyState{id=sim.State.nextId++,position=RiftMap.Rooms[0]+new Vector2(x,y),kind=kind,elite=elite,boss=boss,
                health=hp,maxHealth=10000,attack=0,speed=0,cooldown=1000};
            sim.State.enemies.Add(e);return e;
        }
        static void Decide(CombatSimulation sim)
        {sim.State.decisionTime=0;sim.State.heroAction=new HeroActionState();sim.State.activeSkill=-1;sim.State.actionCd=0;sim.Tick(CombatSimulation.Step);}

        [Test] public void HighHealthUsesHealthRatioBeforeDistance()
        {var s=Fixture(("target.default","HIGH_HP"));Enemy(s,1,hp:3000);var high=Enemy(s,7,hp:9000);Decide(s);Assert.AreEqual(high.id,s.State.targetId);}
        [Test] public void LowHealthUsesHealthRatioBeforeDistance()
        {var s=Fixture(("target.default","LOW_HP"));Enemy(s,1,hp:3000);var low=Enemy(s,7,hp:1000);Decide(s);Assert.AreEqual(low.id,s.State.targetId);}
        [TestCase("BOSS,ELITE,SUPPORT,RANGED",true)] [TestCase("ELITE,BOSS,SUPPORT,RANGED",false)]
        public void BossAndEliteHaveSeparateOrderedRanks(string order,bool bossFirst)
        {
            var s=Fixture(("target.specialEnabled","BOSS,ELITE"),("target.specialOrder",order));
            var elite=Enemy(s,bossFirst?1:7,elite:0);var boss=Enemy(s,bossFirst?7:1,boss:true);Decide(s);
            Assert.AreEqual(bossFirst?boss.id:elite.id,s.State.targetId);
        }
        [TestCase(2)] [TestCase(3)] [TestCase(8)] [TestCase(9)]
        public void RangedArchersAndCastersPrecedeSupportWhenRequested(int kind)
        {
            var s=Fixture(("target.specialEnabled","SUPPORT,RANGED"),("target.specialOrder","RANGED,SUPPORT,BOSS,ELITE"));
            Enemy(s,1,kind:4);var ranged=Enemy(s,7,kind:kind);Decide(s);Assert.AreEqual(ranged.id,s.State.targetId);
        }
        [Test] public void AnAbsentSpecialFallsBackToTheExactDefault()
        {var s=Fixture(("target.default","HIGH_HP"),("target.specialEnabled","BOSS"));Enemy(s,1,hp:2000);var high=Enemy(s,7);Decide(s);Assert.AreEqual(high.id,s.State.targetId);}
        [Test] public void UntilDeathRetainsTheObservedTargetDespiteANewBoss()
        {
            var s=Fixture(("target.switch","UNTIL_DEATH"),("target.specialEnabled","BOSS"));var current=Enemy(s,7);Decide(s);
            Enemy(s,1,boss:true);s.State.time+=1;Decide(s);Assert.AreEqual(current.id,s.State.targetId);
        }
        [Test] public void PrioritySwitchDoesNotWaitForTheLegacyHysteresis()
        {
            var s=Fixture(("target.switch","PRIORITY"),("target.specialEnabled","BOSS"));Enemy(s,2);Decide(s);
            var boss=Enemy(s,7,boss:true);Decide(s);Assert.AreEqual(boss.id,s.State.targetId);
        }
        [Test] public void BossAddsMustActuallyBelongToTheCurrentBoss()
        {
            var s=Fixture(("target.bossFight","ADDS"));var boss=Enemy(s,1,boss:true);s.State.phase=RunPhase.Boss;s.State.bossId=boss.id;
            var unrelated=Enemy(s,2);unrelated.add=true;var add=Enemy(s,7);add.add=true;add.summonerId=boss.id;
            Decide(s);Assert.AreEqual(add.id,s.State.targetId);
        }
        [Test] public void BossFightCanPreferSupportOverTheBoss()
        {
            var s=Fixture(("target.bossFight","DANGEROUS_SUPPORT"));var boss=Enemy(s,1,boss:true);s.State.phase=RunPhase.Boss;s.State.bossId=boss.id;
            var support=Enemy(s,7,kind:10);Decide(s);Assert.AreEqual(support.id,s.State.targetId);
        }
        [Test] public void AnUnobservedPriorityTargetIsNotSelected()
        {var s=Fixture(("target.specialEnabled","BOSS"));var current=Enemy(s,2);Enemy(s,30,boss:true);Decide(s);Assert.AreEqual(current.id,s.State.targetId);}
        [Test] public void AnExplicitLegacyRuleTargetStillHasItsOwnMeaning()
        {
            var s=Fixture(("target.default","HIGH_HP"));s.State.build.rules[0].target=RuleTarget.Nearest;
            var near=Enemy(s,1,hp:2000);Enemy(s,7);Decide(s);Assert.AreEqual(near.id,s.State.targetId);
        }
        [Test] public void DenseGroupsRankBeforeTheirDistance()
        {
            var s=Fixture(("target.default","DENSE"));var near=Enemy(s,1);Enemy(s,8);Enemy(s,8,1);Enemy(s,8,-1);
            Decide(s);Assert.AreNotEqual(near.id,s.State.targetId);
        }
        [Test] public void StoppingOnLostSightDoesNotFollowAnObservation()
        {
            var s=Fixture(("target.lostSight","STOP"));var target=Enemy(s,5);Decide(s);var position=s.State.position;
            target.position=RiftMap.Rooms[0]+Vector2.right*30;Decide(s);
            Assert.AreEqual(-1,s.State.targetId);Assert.AreEqual(position,s.State.position);Assert.AreEqual(-1,s.State.edictTarget.enemyId);
        }
        [Test] public void InvestigatingUsesTheLastObservationAndNeverTheHiddenPosition()
        {
            var s=Fixture(("target.lostSight","LAST_SEEN"));var target=Enemy(s,5);Decide(s);Vector2 known=target.position;
            target.position=RiftMap.Rooms[0]+Vector2.right*30;Decide(s);
            Assert.AreEqual(-1,s.State.targetId);Assert.IsTrue(s.State.edictTarget.searching);Assert.AreEqual(known,s.State.destination);
            target.position=RiftMap.Rooms[0]+Vector2.up*30;Decide(s);Assert.AreEqual(known,s.State.destination);
        }
        [Test] public void ReachingTheLastObservationEndsTheSearch()
        {
            var s=Fixture(("target.lostSight","LAST_SEEN"));var target=Enemy(s,5);Decide(s);var known=target.position;
            target.position=RiftMap.Rooms[0]+Vector2.right*30;s.State.position=known;Decide(s);
            Assert.AreEqual(-1,s.State.edictTarget.enemyId);Assert.IsFalse(s.State.edictTarget.searching);
        }
        [Test] public void ThePursuitTimeLimitCannotImmediatelyRestartForTheSameVisibleEnemy()
        {
            var s=Fixture(("target.chaseTime","1"));var enemy=Enemy(s,11);
            for(int i=0;i<24;i++){enemy.position=s.State.position+Vector2.right*11;Decide(s);}
            Assert.AreEqual(-1,s.State.targetId);CollectionAssert.Contains(s.State.edictTarget.excluded,enemy.id);
            Assert.IsTrue(s.State.logs.Any(l=>l.Contains("추적 시간 한도")));
            var stopped=s.State.position;Decide(s);Assert.AreEqual(stopped,s.State.position);
            enemy.position=s.State.position+Vector2.right*2;Decide(s);Assert.AreEqual(enemy.id,s.State.targetId,"An enemy that approaches can be attacked again.");
        }
        [Test] public void PursuitNeverCrossesTheEngagementDistanceLimit()
        {
            var s=Fixture(("target.chaseDistance","1"));var origin=s.State.position;var enemy=Enemy(s,11);
            for(int i=0;i<30;i++){enemy.position=s.State.position+Vector2.right*11;Decide(s);Assert.LessOrEqual(Vector2.Distance(origin,s.State.position),1.0001f);}
            Assert.AreEqual(-1,s.State.targetId);Assert.IsTrue(s.State.logs.Any(l=>l.Contains("추적 거리 한도")));
        }
        [Test] public void TimeSpentAttackingInRangeDoesNotConsumePursuitTime()
        {
            var s=Fixture(("target.chaseTime","1"));var enemy=Enemy(s,2);
            for(int i=0;i<80;i++)s.Tick(CombatSimulation.Step);
            Assert.AreEqual(enemy.id,s.State.targetId);Assert.AreEqual(0,s.State.edictTarget.pursuitSeconds);
        }
        [Test] public void ACheckpointKeepsThePursuitClockAndFutureDecisions()
        {
            var s=Fixture(("target.chaseTime","1"));var target=Enemy(s,11);
            for(int i=0;i<6;i++){target.position=s.State.position+Vector2.right*11;Decide(s);}
            var a=GameStore.NewAccount(catalog);a.selectedHero=2;a.heroes[2]=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(s.Hero));
            var restored=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(s.State));GameStore.NormalizeRun(restored);
            var copy=new CombatSimulation(a,catalog,1,restore:restored);
            Assert.AreEqual(JsonUtility.ToJson(s.State.edictTarget),JsonUtility.ToJson(copy.State.edictTarget));
            for(int i=0;i<20;i++)
            {
                target.position=s.State.position+Vector2.right*11;copy.State.enemies.Single(e=>e.id==target.id).position=target.position;
                Decide(s);Decide(copy);Assert.AreEqual(JsonUtility.ToJson(s.State),JsonUtility.ToJson(copy.State));
            }
        }
        [Test] public void ARunningChannelKeepsItsOriginalExactTargetPolicy()
        {
            var a=GameStore.NewAccount(catalog);var hero=a.Hero;hero.level=30;hero.build=BehaviorPresets.ForLevel(HeroClass.Warrior,0,30,catalog);
            hero.build.rules=new List<Rule>{BehaviorRules.Make(0)};hero.useEdict=true;
            hero.edict=HuntEdictV2Editing.WithGlobal(HuntEdictV2Storage.CreateForHero(hero),"target.default","HIGH_HP");
            var s=new CombatSimulation(a,catalog,1,0,seed:371);s.State.enemies.Clear();s.State.position=RiftMap.Rooms[0];
            Enemy(s,1,hp:2000);var high=Enemy(s,2);s.Tick(CombatSimulation.Step);
            Assert.AreEqual(HeroActionPhase.Channeling,s.State.heroAction.phase);Assert.AreEqual("HIGH_HP",s.State.heroAction.policy.edictTarget.basis);
            hero.edict=HuntEdictV2Editing.WithGlobal(hero.edict,"target.default","LOW_HP");s.RefreshEdict();
            s.State.decisionTime=0;s.Tick(CombatSimulation.Step);
            Assert.AreEqual(high.id,s.State.targetId);Assert.AreEqual("HIGH_HP",s.State.heroAction.policy.edictTarget.basis);
        }
        [TestCase(true,false,1f,false,true)] [TestCase(false,false,1f,false,false)] [TestCase(true,true,1f,false,false)] [TestCase(true,false,.01f,false,false)] [TestCase(true,false,1f,true,false)]
        public void CasterPriorityRequiresAnEnabledReadyControlThatCanArriveInTime(bool automatic,bool cooldown,float remaining,bool controlled,bool preferred)
        {
            var s=Fixture(("target.interruptCaster","ON"));var ordinary=Enemy(s,1);var caster=Enemy(s,2,kind:3);
            caster.brain.action=new EnemyActionState{id=500,phase=EnemyActionPhase.Preparing,kind=3,origin=caster.position,aim=s.State.position,remaining=remaining};
            if(controlled)caster.statuses.Add(new StatusEffect{kind=StatusKind.Freeze,remaining=1});
            s.State.build.activeSkills=new List<int>{12,13,14,17};s.State.build.rules.Add(BehaviorRules.Make(17));
            s.Hero.build=s.State.build.Copy();s.Hero.edict=HuntEdictV2Editing.WithGlobal(HuntEdictV2Storage.CreateForHero(s.Hero),"target.interruptCaster","ON");
            if(!automatic)s.Hero.edict=HuntEdictV2.WithOption(s.Hero.edict,"M06",1,"OFF");
            s.RefreshEdict();s.State.cooldowns[17]=cooldown?10:0;
            // Exercise the production perception and selector without advancing the incoming attack.
            typeof(CombatSimulation).GetMethod("Sense",BindingFlags.NonPublic|BindingFlags.Instance).Invoke(s,null);
            Assert.AreEqual(preferred?caster.id:ordinary.id,s.State.targetId);
        }
        [TestCase(3,true)] [TestCase(2,false)]
        public void WarriorCasterPriorityUsesTheActualStunAndNotCrush(int skill,bool preferred)
        {
            var a=GameStore.NewAccount(catalog);var hero=a.Hero;hero.level=30;hero.build=BehaviorPresets.ForLevel(HeroClass.Warrior,0,30,catalog);
            hero.build.activeSkills=new List<int>{skill};hero.build.rules=new List<Rule>{BehaviorRules.Utility(RuleAction.Basic),BehaviorRules.Make(skill)};
            hero.useEdict=true;hero.edict=HuntEdictV2Editing.WithGlobal(HuntEdictV2Storage.CreateForHero(hero),"target.interruptCaster","ON");
            var s=new CombatSimulation(a,catalog,1,0,seed:811);s.State.enemies.Clear();s.State.position=RiftMap.Rooms[0];
            var near=Enemy(s,1);var caster=Enemy(s,2,kind:3);caster.brain.action=new EnemyActionState{id=500,phase=EnemyActionPhase.Preparing,kind=3,origin=caster.position,aim=s.State.position,remaining=1};
            typeof(CombatSimulation).GetMethod("Sense",BindingFlags.NonPublic|BindingFlags.Instance).Invoke(s,null);
            Assert.AreEqual(preferred?caster.id:near.id,s.State.targetId);
        }
        [Test] public void EnablingTheEdictDoesNotRetrofitAnAlreadyRunningLegacyChannel()
        {
            var a=GameStore.NewAccount(catalog);var hero=a.Hero;hero.level=30;hero.build=BehaviorPresets.ForLevel(HeroClass.Warrior,0,30,catalog);
            hero.build.target=TargetMode.Nearest;hero.build.rules=new List<Rule>{BehaviorRules.Make(0)};
            hero.edict=HuntEdictV2Editing.WithGlobal(HuntEdictV2Storage.CreateForHero(hero),"target.default","HIGH_HP");
            var s=new CombatSimulation(a,catalog,1,0,seed:299);s.State.enemies.Clear();s.State.position=RiftMap.Rooms[0];
            var near=Enemy(s,1,hp:2000);Enemy(s,2.5f);s.Tick(CombatSimulation.Step);
            Assert.AreEqual(HeroActionPhase.Channeling,s.State.heroAction.phase);Assert.AreEqual(near.id,s.State.targetId);
            hero.useEdict=true;s.RefreshEdict();s.State.decisionTime=0;s.Tick(CombatSimulation.Step);
            Assert.AreEqual(near.id,s.State.targetId);Assert.IsTrue(s.State.edictTarget==null||s.State.edictTarget.enemyId<0);
        }
        [Test] public void ANewerActionTargetPolicyIsNotSilentlyDowngraded()
        {
            var run=new RunState{heroAction=new HeroActionState{policy=new HeroActionPolicy{edictTarget=new EdictTargetPolicy{version=2}}}};
            Assert.Throws<System.NotSupportedException>(()=>GameStore.NormalizeRun(run));
        }
    }
}
