using System;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class EnemyTests
    {
        GameCatalog catalog;
        [SetUp]public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown]public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        static object Call(CombatSimulation sim,string name,params object[] args)
        {
            var method=typeof(CombatSimulation).GetMethod(name,BindingFlags.NonPublic|BindingFlags.Instance);var p=method.GetParameters();var full=new object[p.Length];
            for(int i=0;i<full.Length;i++)full[i]=i<args.Length?args[i]:p[i].DefaultValue;return method.Invoke(sim,full);
        }
        CombatSimulation Fixture(int kind=0)
        {
            var account=GameStore.NewAccount();account.Hero.level=30;account.Hero.build.rules.Clear();account.Hero.build.passives=Array.Empty<int>();account.Hero.build.movement=MovementMode.Stand;account.Hero.build.potionThreshold=0;
            var sim=new CombatSimulation(account,catalog,1,1,seed:7654);sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();sim.State.decisionTime=1000;
            sim.State.enemies.Add(Enemy(900,kind,sim.State.position+Vector2.up*2,0));Controlled(sim);return sim;
        }
        static EnemyState Enemy(int id,int kind,Vector2 position,float cooldown=1000)=>new EnemyState{id=id,kind=kind,position=position,health=10000,maxHealth=10000,attack=100,speed=0,cooldown=cooldown};
        static void Controlled(CombatSimulation sim){sim.State.health=100000;sim.Stats.hp=100000;sim.Stats.armor=sim.Stats.resistance=0;sim.Stats.regen=0;sim.Stats.crit=0;}
        static void Advance(CombatSimulation sim,int steps){for(int i=0;i<steps;i++)sim.Tick(.05f);}
        static void Until(CombatSimulation sim,Func<bool> done,int cap=500){for(int i=0;i<cap&&!done();i++)sim.Tick(.05f);Assert.IsTrue(done(),"Expected enemy state was not reached.");}
        static DamageSnapshot Snapshot()=>new DamageSnapshot{damage=100,level=30,elements=new float[6],passives=new bool[6],critDamage=1};
        CombatSimulation Restore(CombatSimulation original)
        {
            var account=GameStore.NewAccount();account.heroes[0]=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(original.Hero));var sim=new CombatSimulation(account,catalog,1,1,JsonUtility.FromJson<RunState>(JsonUtility.ToJson(original.State)));Controlled(sim);sim.State.health=original.State.health;return sim;
        }
        [TestCase(0,.65f,1.5f)][TestCase(1,.8f,5)][TestCase(2,1,2)][TestCase(3,1.2f,6)][TestCase(4,1,6)][TestCase(5,.65f,1.5f)]
        [TestCase(6,.65f,1.5f)][TestCase(7,.9f,7)][TestCase(8,1.2f,3)][TestCase(9,1.5f,6)][TestCase(11,.65f,1.5f)]
        public void EveryActiveArchetypeHonorsItsPreparationAndStartBasedCooldown(int kind,float preparation,float cooldown)
        {
            var sim=Fixture(kind);var e=sim.State.enemies[0];if(kind==4)e.health=5000;sim.Tick(.05f);Assert.AreEqual(EnemyActionPhase.Preparing,e.brain.action.phase);Assert.AreEqual(preparation,e.windup,.0001f);Assert.AreEqual(cooldown,e.cooldown,.0001f);
            Advance(sim,Mathf.RoundToInt(preparation/.05f)-1);Assert.IsFalse(sim.State.enemyEvents.Any(x=>x.kind=="RELEASE"));Assert.IsFalse(sim.State.damageEvents.Any(x=>x.incoming));
            Advance(sim,1);Assert.AreEqual(1,sim.State.enemyEvents.Count(x=>x.kind=="RELEASE"&&x.definitionId=="N"+(kind+1).ToString("00")));Assert.AreEqual(cooldown-preparation,e.cooldown,.0002f);
        }
        [Test]
        public void MeleePreparationLocksItsFacingAndARealSideStepAvoidsTheSector()
        {
            var sim=Fixture();sim.Tick(.05f);var e=sim.State.enemies[0];var direction=e.brain.facing;sim.State.position=e.position+Vector2.right*2;
            Assert.IsFalse(sim.InDanger);Advance(sim,13);Assert.IsFalse(sim.State.damageEvents.Any(d=>d.incoming));Assert.AreEqual(direction,e.brain.facing);
        }
        [Test]
        public void ChargeSweepsTheTravelPathOnlyOnceAndStopsAtABlockedDestination()
        {
            var sim=Fixture(1);var e=sim.State.enemies[0];e.position=sim.State.position+Vector2.up*6;Until(sim,()=>e.brain.action.phase==EnemyActionPhase.Charging);int root=e.brain.action.id;
            Until(sim,()=>e.brain.action.phase==EnemyActionPhase.Idle);Assert.AreEqual(1,sim.State.damageEvents.Count(d=>d.incoming&&d.rootCastId==root));Assert.AreEqual(150,sim.State.damageEvents.Single(d=>d.incoming).baseAttack);
            sim=Fixture(1);e=sim.State.enemies[0];e.position=RiftMap.Rooms[0]+Vector2.up*5;sim.State.position=RiftMap.Rooms[0]+new Vector2(5,5);Until(sim,()=>e.brain.action.phase==EnemyActionPhase.Charging);Vector2 destination=e.brain.action.aim;Assert.Less(Vector2.Distance(e.position,destination),8);
            Until(sim,()=>e.brain.action.phase==EnemyActionPhase.Idle);Assert.AreEqual(destination,e.position);Assert.IsTrue(sim.Map.CanLand(e.position,.4f));
        }
        [Test]
        public void FortressChargerRewarnsForPointSixSecondsAndUsesANewDirection()
        {
            var sim=Fixture(7);var e=sim.State.enemies[0];e.position=sim.State.position+Vector2.up*6;Until(sim,()=>e.brain.action.phase==EnemyActionPhase.Charging);int root=e.brain.action.id;
            Until(sim,()=>e.brain.action.phase==EnemyActionPhase.Preparing&&e.brain.action.remainingCharges==1);Assert.AreEqual(.6f,e.windup,.0001f);Assert.Greater(e.brain.facing.y,0);Assert.AreEqual(root,e.brain.action.id);
            Advance(sim,11);Assert.AreEqual(EnemyActionPhase.Preparing,e.brain.action.phase);Advance(sim,1);Assert.AreEqual(EnemyActionPhase.Charging,e.brain.action.phase);
            Until(sim,()=>e.brain.action.phase==EnemyActionPhase.Idle);Assert.AreEqual(2,sim.State.damageEvents.Count(d=>d.incoming&&d.rootCastId==root));Assert.AreEqual(1,sim.State.enemyEvents.Count(x=>x.kind=="FOLLOWUP_PREPARE"));
        }
        [TestCase(false)][TestCase(true)]
        public void StunDuringPreparationOrRootDuringChargeCancelsWithoutRefundingCooldown(bool travel)
        {
            var sim=Fixture(7);var e=sim.State.enemies[0];sim.Tick(.05f);if(travel)Until(sim,()=>e.brain.action.phase==EnemyActionPhase.Charging);float cd=e.cooldown;
            Call(sim,"ApplyStatus",e,travel?StatusKind.Root:StatusKind.Stun,"TEST",1f,55);Advance(sim,1);Assert.AreEqual(EnemyActionPhase.Idle,e.brain.action.phase);Assert.AreEqual(cd-.05f,e.cooldown,.0001f);Assert.AreEqual(0,e.windup);Assert.IsFalse(sim.State.damageEvents.Any(d=>d.incoming));
        }
        [TestCase(2,1)][TestCase(8,3)]
        public void ArcherShotsKeepCastIdentityAndPersistAfterTheCasterDies(int kind,int arrows)
        {
            var sim=Fixture(kind);var e=sim.State.enemies[0];e.position=sim.State.position+Vector2.up*6;Until(sim,()=>sim.State.projectiles.Count==arrows);var shots=sim.State.projectiles.ToArray();
            Assert.AreEqual(1,shots.Select(p=>p.actionId).Distinct().Count());Assert.IsTrue(shots.All(p=>p.casterId=="900"&&p.definitionId=="N"+(kind+1).ToString("00")));e.dead=true;e.pendingDeath=true;sim.State.training=-1;
            Advance(sim,20);Assert.AreEqual(1,sim.State.damageEvents.Count(d=>d.incoming));Assert.AreEqual(100,sim.State.damageEvents.Single(d=>d.incoming).baseAttack);
        }
        [TestCase(3,8,4)][TestCase(9,6,1)]
        public void GroundCastersSnapshotPositionAndDeliverTheirFullPeriodicLifetime(int kind,int count,int element)
        {
            var sim=Fixture(kind);var e=sim.State.enemies[0];Until(sim,()=>sim.State.enemyHazards.Count==1);e.cooldown=1000;var hazard=sim.State.enemyHazards[0];Vector2 position=hazard.position;
            e.dead=true;e.pendingDeath=true;sim.State.training=-1;Advance(sim,count*10);
            Assert.AreEqual(count,sim.State.damageEvents.Count(d=>d.incoming&&d.definitionId=="N"+(kind+1).ToString("00")));Assert.IsTrue(sim.State.damageEvents.Where(d=>d.incoming).All(d=>d.element==element));Assert.IsEmpty(sim.State.enemyHazards);Assert.AreEqual(position,sim.State.position);
        }
        [Test]
        public void PredictiveCasterUsesPastMotionCapsFourMetersAndFreezesTheWarning()
        {
            var sim=Fixture(9);var e=sim.State.enemies[0];e.cooldown=.55f;Vector2 start=sim.State.position;for(int i=0;i<10;i++){sim.State.position+=Vector2.right*.3f;sim.Tick(.05f);}sim.Tick(.05f);
            Assert.AreEqual(EnemyActionPhase.Preparing,e.brain.action.phase);Vector2 aim=e.brain.action.aim;Assert.AreEqual(4,Vector2.Distance(aim,sim.State.position),.001f);
            sim.State.position=start+Vector2.left*2;Advance(sim,30);Assert.AreEqual(aim,sim.State.enemyHazards.Single().position);Advance(sim,60);Assert.IsFalse(sim.State.damageEvents.Any(d=>d.incoming));
        }
        [Test]
        public void HealerRecoversLivingBossesAndAddsButNeverResurrectsACorpse()
        {
            var sim=Fixture(4);var e=sim.State.enemies[0];e.health=5000;var ally=Enemy(901,0,e.position+Vector2.right);ally.maxHealth=1000;ally.health=400;ally.boss=true;ally.add=true;sim.State.enemies.Add(ally);
            var corpse=Enemy(902,0,e.position);corpse.dead=true;corpse.health=0;sim.State.enemies.Add(corpse);Advance(sim,21);
            Assert.AreEqual(6500,e.health);Assert.AreEqual(550,ally.health);Assert.AreEqual(0,corpse.health);Assert.IsTrue(corpse.dead);
        }
        [Test]
        public void BellAuraDoesNotStackAndStopsImmediatelyForNewAttacksAfterDeath()
        {
            var sim=Fixture(10);var bell=sim.State.enemies[0];var second=Enemy(901,10,bell.position+Vector2.right);sim.State.enemies.Add(second);var melee=Enemy(902,0,bell.position+Vector2.left);sim.State.enemies.Add(melee);sim.Tick(.05f);
            Assert.AreEqual(900,melee.brain.auraSource);Assert.AreEqual(120,(float)Call(sim,"EnemyAttackValue",melee),.001f);bell.dead=true;bell.pendingDeath=true;
            Assert.AreEqual(120,(float)Call(sim,"EnemyAttackValue",melee),.001f);second.dead=true;second.pendingDeath=true;Assert.AreEqual(100,(float)Call(sim,"EnemyAttackValue",melee));sim.Tick(.05f);Assert.AreEqual(-1,melee.brain.auraSource);
        }
        [TestCase(false,false,0)][TestCase(true,false,.25f)][TestCase(true,true,0)]
        public void IronWraithRearWindowChangesOnlyDirectAttacksFromBehind(bool behind,bool periodic,float expected)
        {
            var sim=Fixture(6);var e=sim.State.enemies[0];Advance(sim,14);e.cooldown=1000;Assert.AreEqual(.8f,e.brain.rearWindow,.0001f);Vector2 origin=e.position+e.brain.facing*(behind?-2:2);
            var damage=(DamageEvent)Call(sim,"Hit",e,1f,0,false,0f,Snapshot(),false,false,"TEST",77,78,periodic?DamageKind.Periodic:DamageKind.Direct,false,origin);Assert.AreEqual(expected,damage.additive,.0001f);
            Advance(sim,16);Assert.AreEqual(0,e.brain.rearWindow,.0001f);
        }
        [TestCase(5,1f)][TestCase(11,.9f)]
        public void DeathPayloadRestoresIndependentlyAndNeverRepeatsItsReward(int kind,float delay)
        {
            var sim=Fixture(kind);var e=sim.State.enemies[0];e.brain.facing=Vector2.down;e.dead=true;e.pendingDeath=true;sim.State.training=-1;sim.Tick(.05f);Assert.AreEqual(1,sim.State.enemyHazards.Count);Assert.AreEqual(1,sim.State.enemyCorpses.Count);Advance(sim,5);var restored=Restore(sim);restored.State.training=-1;
            int corpse=sim.State.enemyCorpses[0].id;
            for(int i=0;i<40;i++){sim.Tick(.05f);restored.Tick(.05f);Assert.AreEqual(JsonUtility.ToJson(sim.State),JsonUtility.ToJson(restored.State),"tick "+i);}
            Assert.AreEqual(1,sim.State.effectEvents.Count(x=>x.kind=="DEATH"&&x.targetId==900));Assert.AreEqual(corpse,sim.State.enemyCorpses.Single().id);Assert.IsEmpty(sim.State.enemyHazards);
            Assert.AreEqual(1,sim.State.damageEvents.Count(d=>d.incoming));Assert.AreEqual(kind==5?"N06_DEATH":"N12_DEATH",sim.State.damageEvents.Single(d=>d.incoming).definitionId);
        }
        [Test]
        public void TwoActiveEliteTraitsUseIndependentTimersWhileTheBaseActionIsCoolingDown()
        {
            var sim=Fixture();var e=sim.State.enemies[0];e.elite=0;e.eliteTraits=new System.Collections.Generic.List<int>{0,1};sim.Tick(.05f);e.cooldown=1000;e.brain.traitCooldowns[0]=e.brain.traitCooldowns[1]=.05f;sim.Tick(.05f);
            Assert.AreEqual(2,sim.State.enemyHazards.Count);Assert.AreEqual(5,e.brain.traitCooldowns[0]);Assert.AreEqual(8,e.brain.traitCooldowns[1]);Assert.AreEqual(999.95f,e.cooldown,.001f);
        }
        [TestCase(0,false)][TestCase(1.99f,false)][TestCase(2,true)][TestCase(3,true)][TestCase(4,true)][TestCase(4.01f,false)]
        public void IceRingDangerAndActualDamageAgreeAtItsInnerAndOuterBoundary(float distance,bool hit)
        {
            var sim=Fixture();var e=sim.State.enemies[0];e.cooldown=1000;Vector2 center=sim.State.position;
            Call(sim,"CreateEnemyHazard",e,"E02",center,1.5f,0f,150f,2,4f,2f,77,.35f,false);sim.State.position=center+Vector2.right*distance;
            Assert.AreEqual(hit,sim.InDanger);Advance(sim,30);Assert.AreEqual(hit,sim.State.damageEvents.Any(d=>d.incoming));Assert.AreEqual(hit?2:0,sim.State.enemySlowTime,.0001f);Assert.IsEmpty(sim.State.enemyHazards);
        }
        [TestCase(0,true,0,.5f)][TestCase(1,true,0,.5f)][TestCase(0,false,0,0)][TestCase(0,true,90,0)][TestCase(0,true,180,0)]
        public void ShotBarrierUsesProjectileClassificationAndIncomingDirection(int element,bool projectile,float degrees,float expected)
        {
            var sim=Fixture();var e=sim.State.enemies[0];e.elite=3;e.brain.facing=Vector2.up;Vector2 origin=e.position+EnemyCombat.Rotate(Vector2.up,degrees)*2;
            var hit=(DamageEvent)Call(sim,"Hit",e,1f,element,false,0f,Snapshot(),false,false,"TEST",70,71,DamageKind.Direct,projectile,origin);Assert.AreEqual(expected,hit.buffReduction,.0001f);Assert.AreEqual(projectile,hit.projectile);Assert.AreEqual(origin,hit.attackOrigin);
        }
        [Test]
        public void LifeLinkRequiresALivingElitePartnerWithinFiveMetersAndOnlyAppliesOnce()
        {
            var sim=Fixture();var e=sim.State.enemies[0];e.elite=0;e.eliteTraits.AddRange(new[]{0,2});e.elitePartner=901;var partner=Enemy(901,0,e.position+Vector2.right*5);partner.elite=2;sim.State.enemies.Add(partner);
            Assert.AreEqual(.2f,(float)Call(sim,"TargetReduction",e,0),.0001f);partner.position+=Vector2.right*.01f;Assert.AreEqual(0,(float)Call(sim,"TargetReduction",e,0));partner.position=e.position;partner.dead=true;Assert.AreEqual(0,(float)Call(sim,"TargetReduction",e,0));
        }
        [Test]
        public void TwoCorpseExplodersClaimOneCorpseOnceAndKeepItsInnateDeathEffect()
        {
            var sim=Fixture(5);var corpse=sim.State.enemies[0];corpse.dead=true;corpse.pendingDeath=true;
            foreach(int id in new[]{901,902}){var elite=Enemy(id,0,corpse.position+Vector2.right*(id-900));elite.elite=4;sim.State.enemies.Add(elite);}sim.Tick(.05f);
            foreach(var elite in sim.State.enemies.Skip(1))elite.brain.traitCooldowns[4]=0;sim.Tick(.05f);
            Assert.AreEqual(901,sim.State.enemyCorpses.Single().consumedBy);Assert.AreEqual(1,sim.State.enemyHazards.Count(h=>h.definitionId=="E05"));Assert.AreEqual(1,sim.State.enemyHazards.Count(h=>h.definitionId=="N06_DEATH"));Advance(sim,30);
            Assert.AreEqual(1,sim.State.enemyEvents.Count(e=>e.kind=="CORPSE_CONSUMED"));Assert.AreEqual(2,sim.State.damageEvents.Count(d=>d.incoming));
        }
        [Test]
        public void RageCountsAliveTimeOutsidePerceptionCapsAtFiveAndSurvivesRestore()
        {
            var sim=Fixture();var e=sim.State.enemies[0];e.elite=5;e.cooldown=1000;e.position=RiftMap.Rooms[4];sim.Tick(.05f);sim.State.time=e.brain.bornAt+49.95f;sim.Tick(.05f);Assert.AreEqual(5,e.brain.rageStacks);Assert.AreEqual(150,(float)Call(sim,"EnemyAttackValue",e),.0001f);
            var restored=Restore(sim);Advance(restored,220);Assert.AreEqual(5,restored.State.enemies[0].brain.rageStacks);Assert.AreEqual(e.brain.bornAt,restored.State.enemies[0].brain.bornAt);
        }
        [Test]
        public void LostSightRetainsOnlyTheLastObservedPositionAndThenStopsChasing()
        {
            var sim=Fixture(9);var e=sim.State.enemies[0];e.cooldown=1000;sim.Tick(.05f);Vector2 known=e.lastSeenPosition;sim.State.position=RiftMap.Rooms[4];Advance(sim,81);
            Assert.AreEqual(known,e.lastSeenPosition);Assert.IsEmpty(e.brain.observations);Assert.AreEqual("목표 상실",e.brain.state);Assert.IsEmpty(sim.State.enemyHazards);
        }
        [Test]
        public void AProjectileOnlyObstaclePreventsAVisibleArcherFromStartingItsShot()
        {
            var sim=Fixture(2);var e=sim.State.enemies[0];e.position=sim.State.position+Vector2.up*6;sim.State.layout.legacy=false;
            sim.State.layout.obstacles.Add(new RiftObstacle{id="arrow-wall",position=sim.State.position+Vector2.up*3,halfSize=new Vector2(2,.1f),blocksProjectile=true,blocksWalk=false,blocksSight=false});sim=Restore(sim);Advance(sim,25);
            Assert.IsEmpty(sim.State.projectiles);Assert.IsFalse(sim.State.enemyEvents.Any(x=>x.kind=="PREPARE"));
        }
        [Test]
        public void ArrowWarningStopsAtTheSameProjectileOnlyWallAsTheActualShot()
        {
            var sim=Fixture(2);var e=sim.State.enemies[0];e.position=sim.State.position+Vector2.up*4;sim.State.layout.legacy=false;
            sim.State.layout.obstacles.Add(new RiftObstacle{id="wall-behind-hero",position=sim.State.position+Vector2.down,halfSize=new Vector2(3,.1f),blocksProjectile=true,blocksSight=false,blocksWalk=false});sim=Restore(sim);e=sim.State.enemies[0];sim.Tick(.05f);
            var threat=EnemyCombat.Threats(sim.State,sim.Map).Single();Assert.Less(Vector2.Distance(threat.origin,threat.end),5);Assert.IsFalse(EnemyCombat.Contains(threat,sim.State.position+Vector2.down*2));
            sim.State.position+=Vector2.down*2;Until(sim,()=>sim.State.projectiles.Count>0);e.cooldown=1000;Advance(sim,25);Assert.IsFalse(sim.State.damageEvents.Any(d=>d.incoming));Assert.IsEmpty(sim.State.projectiles);
        }
        [Test]
        public void PreparationChargeFollowupAndHazardsResumeWithIdenticalFutureState()
        {
            var sim=Fixture(7);var e=sim.State.enemies[0];e.position=sim.State.position+Vector2.up*6;Until(sim,()=>e.brain.action.phase==EnemyActionPhase.Charging&&e.brain.action.moved>1);sim.State.paused=true;var paused=JsonUtility.ToJson(sim.State);Advance(sim,20);Assert.AreEqual(paused,JsonUtility.ToJson(sim.State));sim.State.paused=false;
            var restored=Restore(sim);for(int i=0;i<60;i++){sim.Tick(.05f);restored.Tick(.05f);Assert.AreEqual(JsonUtility.ToJson(sim.State),JsonUtility.ToJson(restored.State),"tick "+i);}
        }
    }
}
