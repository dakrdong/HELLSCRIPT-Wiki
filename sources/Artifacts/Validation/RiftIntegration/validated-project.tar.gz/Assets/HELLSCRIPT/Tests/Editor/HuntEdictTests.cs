using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class HuntEdictTests
    {
        GameCatalog catalog;
        [SetUp] public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown] public void Cleanup(){UnityEngine.Object.DestroyImmediate(catalog);}
        static string Wrap(byte[] bytes)
        {
            string hash;using(var sha=SHA256.Create())hash=string.Concat(sha.ComputeHash(bytes).Select(b=>b.ToString("x2")));
            return "HED1."+Convert.ToBase64String(bytes).TrimEnd('=').Replace('+','-').Replace('/','_')+"."+hash;
        }
        static string Wrap(string json)=>Wrap(Encoding.UTF8.GetBytes(json));
        static void Set(HuntEdictDocument doc,string id,string value)=>doc.global.Single(o=>o.id==id).value=value;
        static void SetAllOptions(List<EdictOption> options,IEnumerable<EdictOptionDefinition> definitions,string hero)
        {
            foreach(var d in definitions)
            {
                string value=d.kind==EdictOptionKind.Toggle?"ON":d.kind==EdictOptionKind.Number?d.max.ToString("0.###",CultureInfo.InvariantCulture):d.kind==EdictOptionKind.Choice?d.choices.Last():d.kind==EdictOptionKind.SkillReference?HuntEdict.SkillIds(hero).FirstOrDefault(s=>d.choices.Length==0||d.choices.Contains(s))??"":string.Join(",",d.choices.Reverse());
                options.Single(o=>o.id==d.id).value=value;
            }
        }
        [Test] public void FullSchemaRoundTripsForEveryClass([Values(0,1,2)]int hero)
        {
            var doc=HuntEdict.Create((HeroClass)hero);doc.slots=HuntEdict.SkillIds(doc.heroClass).Take(4).ToArray();
            SetAllOptions(doc.global,EdictOptions.Global,doc.heroClass);
            foreach(var r in doc.rules)SetAllOptions(r.options,EdictOptions.ForAction(r.actionId,doc.heroClass),doc.heroClass);
            string before=JsonUtility.ToJson(doc),code=HuntEdictCodec.Encode(doc);var copy=HuntEdictCodec.Decode(code);
            Assert.AreEqual(before,JsonUtility.ToJson(doc),"Encoding mutated the draft.");Assert.AreEqual(code,HuntEdictCodec.Encode(copy));
            Assert.AreEqual(HuntEdictCodec.CanonicalJson(doc),JsonUtility.ToJson(copy));
            Assert.AreEqual(9,copy.global.Select(o=>EdictOptions.Global.Single(d=>d.id==o.id).group).Distinct().Count(),"Eight groups plus their common priority are required.");
            CollectionAssert.AreEquivalent(catalog.skills.Where(s=>(int)s.heroClass==hero).Select(s=>s.id),HuntEdict.SkillIds(doc.heroClass));
        }
        [Test] public void UnorderedContainersAreCanonicalButBattleOrderAndSlotHolesAreMeaningful()
        {
            var a=HuntEdict.Create(HeroClass.Mage);a.slots=new[]{"M01","","M05","M04"};string code=HuntEdictCodec.Encode(a);
            var b=a.Copy();b.global.Reverse();b.actions.Reverse();foreach(var r in b.rules)r.options.Reverse();Assert.AreEqual(code,HuntEdictCodec.Encode(b));
            b.rules.Reverse();Assert.AreNotEqual(code,HuntEdictCodec.Encode(b));
            b=a.Copy();b.slots=new[]{"M01","M05","M04",""};Assert.AreNotEqual(code,HuntEdictCodec.Encode(b));
            CollectionAssert.AreEqual(a.slots,HuntEdictCodec.Decode(code).slots);
        }
        [Test] public void SlotMovementAndRemovalKeepTheSkillsOwnUnsavedOptionsAndPriority()
        {
            var draft=HuntEdict.Create(HeroClass.Mage);draft.slots=new[]{"M01","M02","","M04"};
            var rule=draft.rules.Single(r=>r.actionId=="M02");rule.areaAim="Self";rule.options[0].value="WAIT_AT_CAP";draft.actions.Single(a=>a.id=="M02").automatic=false;
            var order=draft.rules.Select(r=>r.Key).ToArray();
            HuntEdict.SelectSlot(draft,1,"");Assert.AreEqual("WAIT_AT_CAP",rule.options[0].value);HuntEdict.SelectSlot(draft,2,"M02");HuntEdict.SelectSlot(draft,0,"M02");
            CollectionAssert.AreEqual(new[]{"M02","","M01","M04"},draft.slots);CollectionAssert.AreEqual(order,draft.rules.Select(r=>r.Key));
            var restored=HuntEdictCodec.Decode(HuntEdictCodec.Encode(draft));Assert.AreEqual("Self",restored.rules.Single(r=>r.actionId=="M02").areaAim);Assert.IsFalse(restored.actions.Single(a=>a.id=="M02").automatic);
            Assert.Throws<ArgumentException>(()=>HuntEdict.SelectSlot(draft,3,"W01"));Assert.Throws<ArgumentException>(()=>HuntEdict.SelectSlot(draft,4,"M01"));
        }
        [Test] public void PartialImportKeepsOriginalSlotsRulesReferencesAndAccountUnchanged([Values(1,3,10,30)]int level)
        {
            var original=HuntEdict.Create(HeroClass.Mage);original.slots=new[]{"M01","M02","M04","M05"};
            var rule=original.rules.Single(r=>r.actionId=="M01");rule.always=false;rule.groups.Add(new EdictConditionGroup{conditions=new List<EdictCondition>{new EdictCondition{id="SC22",comparison="Absent",skillId="M05",value=2}}});
            string code=HuntEdictCodec.Encode(original);var account=GameStore.NewAccount(catalog);account.selectedHero=2;account.Hero.level=level;string before=JsonUtility.ToJson(account);
            var preview=HuntEdictImport.Prepare(code,account.Hero,catalog);int missing=0;
            for(int i=0;i<4;i++)
            {
                var skill=catalog.skills.Single(s=>s.id==original.slots[i]);bool owned=level>=skill.unlock;
                Assert.AreEqual(owned?skill.id:"",preview.Draft.slots[i]);if(!owned){var reason=preview.MissingSkills.Single(m=>m.slot==i);Assert.AreEqual(skill.id,reason.skillId);Assert.AreEqual(skill.unlock,reason.requiredLevel);missing++;}
            }
            Assert.AreEqual(missing,preview.MissingSkills.Count);Assert.AreEqual(code,HuntEdictCodec.Encode(preview.Original));Assert.AreEqual(code,preview.OriginalCode);
            Assert.AreEqual("M05",preview.Draft.rules.Single(r=>r.actionId=="M01").groups[0].conditions[0].skillId);Assert.AreEqual("Absent",preview.Draft.rules.Single(r=>r.actionId=="M01").groups[0].conditions[0].comparison);
            Assert.AreEqual(before,JsonUtility.ToJson(account));string partialCode=HuntEdictCodec.Encode(preview.Draft);Assert.AreEqual(missing>0,code!=partialCode);
            account.Hero.level=30;Assert.AreEqual(partialCode,HuntEdictCodec.Encode(preview.Draft),"Level gain auto-equipped a missing skill.");
            CollectionAssert.AreEqual(original.slots,HuntEdictImport.Prepare(code,account.Hero,catalog).Draft.slots);
            preview.Original.slots[0]="";Assert.AreEqual(code,HuntEdictCodec.Encode(preview.Original));
        }
        [Test] public void ImportCanLeaveAllFourSlotsEmptyAndManualReplacementUsesItsOwnRules()
        {
            var source=HuntEdict.Create(HeroClass.Mage);source.slots=new[]{"M02","M03","M04","M05"};source.rules.Single(r=>r.actionId=="M01").distance=5.5f;
            var account=GameStore.NewAccount(catalog);account.selectedHero=2;var preview=HuntEdictImport.Prepare(HuntEdictCodec.Encode(source),account.Hero,catalog);
            Assert.AreEqual(4,preview.MissingSkills.Count);Assert.IsTrue(preview.Draft.slots.All(s=>s==""));Assert.DoesNotThrow(()=>HuntEdictCodec.Encode(preview.Draft));
            HuntEdict.SelectSlot(preview.Draft,3,"M01");Assert.AreEqual(5.5f,preview.Draft.rules.Single(r=>r.actionId=="M01").distance);Assert.AreEqual("M05",preview.Original.slots[3]);
        }
        [Test] public void ImportRejectsDifferentClassAndUnknownCatalogWithoutChangingTheHero()
        {
            var hero=GameStore.NewAccount(catalog).Hero;string before=JsonUtility.ToJson(hero);string code=HuntEdictCodec.Encode(HuntEdict.Create(HeroClass.Mage));
            Assert.Throws<ArgumentException>(()=>HuntEdictImport.Prepare(code,hero,catalog));Assert.AreEqual(before,JsonUtility.ToJson(hero));
            code=HuntEdictCodec.Encode(HuntEdict.Create(HeroClass.Warrior));catalog.skills.RemoveAt(0);Assert.Throws<InvalidOperationException>(()=>HuntEdictImport.Prepare(code,hero,catalog));Assert.AreEqual(before,JsonUtility.ToJson(hero));
        }
        [Test] public void AllExistingConditionsUseStableChoicesAndSkillIds([Values(0,1,2)]int hero)
        {
            foreach(var d in BehaviorRules.All)
            {
                var c=d.Create();if(c.id=="SC15"||c.id=="SC22")c.skill=hero*6;
                var stored=EdictConditions.FromRuntime(c);EdictConditions.Validate(stored,HuntEdict.ClassId((HeroClass)hero),true);
                Assert.AreEqual(JsonUtility.ToJson(c),JsonUtility.ToJson(EdictConditions.ToRuntime(stored)),d.id);
                if(c.id=="SC15"||c.id=="SC22")Assert.AreEqual(HuntEdict.SkillIds(HuntEdict.ClassId((HeroClass)hero))[0],stored.skillId);
            }
            foreach(string id in new[]{"SC04","SC07","SC11","SC12","SC13","SC20"})
            for(int i=0;i<EdictConditions.Choices(id).Length;i++){var c=BehaviorRules.Definition(id).Create();c.choice=i;Assert.AreEqual(i,EdictConditions.ToRuntime(EdictConditions.FromRuntime(c)).choice);}
        }
        [Test] public void ExtensionConditionsAreStoredButCannotMasqueradeAsExistingRuntimePredicates()
        {
            var d=HuntEdict.Create(HeroClass.Ranger);var r=d.rules.Single(x=>x.actionId=="A01");r.always=false;
            r.groups.Add(new EdictConditionGroup{conditions=new List<EdictCondition>{new EdictCondition{id="OWN_TRAP_POISON",comparison="Present"},new EdictCondition{id="SKILL_READY",comparison="Present",skillId="A03"},new EdictCondition{id="BUFF_CHARGES",comparison="AtMost",choiceId="SAB_CHARGE",value=1}}});
            var copy=HuntEdictCodec.Decode(HuntEdictCodec.Encode(d));Assert.AreEqual("OWN_TRAP_POISON",copy.rules.Single(x=>x.actionId=="A01").groups[0].conditions[0].id);
            Assert.Throws<NotSupportedException>(()=>EdictConditions.ToRuntime(r.groups[0].conditions[0]));
        }
        [TestCase("unknown-root")][TestCase("duplicate-root")][TestCase("missing-root")][TestCase("unknown-rule")][TestCase("missing-rule")][TestCase("future-schema")][TestCase("future-content")][TestCase("duplicate-option")][TestCase("missing-option")][TestCase("unknown-option")][TestCase("unknown-choice")][TestCase("unknown-skill")][TestCase("foreign-skill")][TestCase("duplicate-slot")][TestCase("invalid-number")][TestCase("wrong-step")][TestCase("nan")][TestCase("bad-order")][TestCase("unknown-condition")]
        public void ValidChecksumDoesNotAllowMalformedOrIncompatibleSettings(string kind)
        {
            var d=HuntEdict.Create(HeroClass.Mage);string json=null;
            switch(kind)
            {
                case "unknown-root":json=HuntEdictCodec.CanonicalJson(d).Insert(1,"\"unrecognized\":1,");break;
                case "duplicate-root":json=HuntEdictCodec.CanonicalJson(d).Insert(1,"\"schema\":1,");break;
                case "missing-root":json=HuntEdictCodec.CanonicalJson(d).Replace("\"schema\":1,","");break;
                case "unknown-rule":json=HuntEdictCodec.CanonicalJson(d).Replace("\"actionId\":\"M01\"","\"extra\":true,\"actionId\":\"M01\"");break;
                case "missing-rule":json=HuntEdictCodec.CanonicalJson(d).Replace("\"distance\":2.0,","").Replace("\"distance\":2,","");Assert.AreNotEqual(HuntEdictCodec.CanonicalJson(d),json);break;
                case "future-schema":d.schema=2;break;case "future-content":d.contentVersion=2;break;
                case "duplicate-option":d.global.Add(d.global[0]);break;case "missing-option":d.global.RemoveAt(0);break;case "unknown-option":d.global[0].id="new-option";break;
                case "unknown-choice":Set(d,"dodge.ground.policy","INVENTED");break;
                case "unknown-skill":d.slots[0]="M99";break;case "foreign-skill":d.slots[0]="W01";break;case "duplicate-slot":d.slots[0]=d.slots[2]="M01";break;
                case "invalid-number":Set(d,"survival.potionHpPercent","101");break;case "wrong-step":Set(d,"position.distance","3.7");break;case "nan":Set(d,"position.distance","NaN");break;
                case "bad-order":Set(d,"common.order","ATTACK,ATTACK");break;
                case "unknown-condition":d.rules[0].always=false;d.rules[0].groups.Add(new EdictConditionGroup{conditions=new List<EdictCondition>{new EdictCondition{id="UNKNOWN"}}});break;
            }
            Assert.IsFalse(HuntEdictCodec.TryDecode(Wrap(json??JsonUtility.ToJson(d)),out var result,out string error),kind);Assert.IsNull(result);Assert.IsNotEmpty(error);
        }
        [TestCase("cut")][TestCase("checksum")][TestCase("characters")][TestCase("prefix")][TestCase("utf8")][TestCase("depth")][TestCase("size")][TestCase("whitespace-json")]
        public void CorruptedOrUnboundedInputsFailBeforeImport(string kind)
        {
            string json=HuntEdictCodec.CanonicalJson(HuntEdict.Create(HeroClass.Warrior)),code=Wrap(json);
            switch(kind)
            {
                case "cut":code=code.Substring(0,code.Length-20);break;case "checksum":code=code.Substring(0,code.Length-64)+new string('0',64);break;
                case "characters":code=code.Insert(10,"=");break;case "prefix":code=code.Replace("HED1.","HED2.");break;
                case "utf8":code=Wrap(new byte[]{0xc0,0xaf});break;case "depth":code=Wrap(new string('[',17)+"0"+new string(']',17));break;
                case "size":code=new string('X',HuntEdictCodec.MaxCodeCharacters+1);break;case "whitespace-json":code=Wrap(" "+json);break;
            }
            Assert.IsFalse(HuntEdictCodec.TryDecode(code,out var result,out string error));Assert.IsNull(result);Assert.IsNotEmpty(error);
        }
        [Test] public void NumericSettingsDoNotRoundLargeIntegerAmountsAndCodesIgnoreCulture()
        {
            var doc=HuntEdict.Create(HeroClass.Warrior);Set(doc,"repeat.gold","99999999");string code=HuntEdictCodec.Encode(doc);
            Assert.AreEqual("99999999",HuntEdictCodec.Decode(code).global.Single(o=>o.id=="repeat.gold").value);
            var before=CultureInfo.CurrentCulture;try{CultureInfo.CurrentCulture=new CultureInfo("de-DE");Assert.AreEqual(code,HuntEdictCodec.Encode(doc));Assert.AreEqual(code,HuntEdictCodec.Encode(HuntEdictCodec.Decode(code)));}finally{CultureInfo.CurrentCulture=before;}
            Set(doc,"position.distance","2.00");Assert.AreEqual(code,HuntEdictCodec.Encode(doc));
        }
        [Test] public void InvalidStoredRulesAndActiveLimitAreRejectedWithoutDeletingHiddenRules()
        {
            var d=HuntEdict.Create(HeroClass.Warrior);d.rules.Clear();
            for(int n=1;n<=24;n++)d.rules.Add(HuntEdict.NewRule("LOOT",n,d.heroClass));
            foreach(string skill in HuntEdict.SkillIds(d.heroClass))for(int n=1;n<=3;n++)d.rules.Add(HuntEdict.NewRule(skill,n,d.heroClass));
            Assert.DoesNotThrow(()=>HuntEdictCodec.Encode(d));Assert.AreEqual(42,d.rules.Count);
            d.rules.Add(HuntEdict.NewRule("BASIC",1,d.heroClass));Assert.Throws<ArgumentException>(()=>HuntEdictCodec.Encode(d));d.rules.RemoveAt(d.rules.Count-1);
            d.slots[0]="W01";Assert.Throws<ArgumentException>(()=>HuntEdictCodec.Encode(d));d.actions.Single(a=>a.id=="W01").automatic=false;Assert.DoesNotThrow(()=>HuntEdictCodec.Encode(d));
            d.rules.Add(HuntEdict.NewRule("W02",4,d.heroClass));Assert.Throws<ArgumentException>(()=>HuntEdictCodec.Encode(d));
        }
        [Test] public void BasicAttackHasThreeRulesEvenWhenAutomaticUseIsOff()
        {
            var d=HuntEdict.Create(HeroClass.Warrior);d.rules.RemoveAll(r=>r.actionId=="BASIC");
            for(int n=1;n<=3;n++)d.rules.Add(HuntEdict.NewRule("BASIC",n,d.heroClass));
            Assert.DoesNotThrow(()=>HuntEdictCodec.Encode(d));
            d.actions.Single(a=>a.id=="BASIC").automatic=false;
            d.rules.Add(HuntEdict.NewRule("BASIC",4,d.heroClass));
            Assert.Throws<ArgumentException>(()=>HuntEdictCodec.Encode(d));
            Assert.AreEqual(4,d.rules.Count(r=>r.actionId=="BASIC"),"Rejection must not trim the source.");
        }
        [Test] public void MaximumDocumentFitsMeasuredWireLimit([Values(0,1,2)]int hero)
        {
            var d=HuntEdict.Create((HeroClass)hero);d.rules.Clear();SetAllOptions(d.global,EdictOptions.Global,d.heroClass);
            foreach(string action in HuntEdict.ActionIds(d.heroClass))
            for(int n=1;n<=HuntEdict.RuleLimit(action);n++)
            {
                var rule=HuntEdict.NewRule(action,n,d.heroClass);rule.enabled=false;rule.always=false;SetAllOptions(rule.options,EdictOptions.ForAction(action,d.heroClass),d.heroClass);
                for(int g=0;g<2;g++)rule.groups.Add(new EdictConditionGroup{conditions=Enumerable.Range(0,3).Select(_=>new EdictCondition{id="SKILL_HIT_RECENT",comparison="Absent",skillId=HuntEdict.SkillIds(d.heroClass)[5],value=10,upper=300,radius=100,window=20}).ToList()});
                d.rules.Add(rule);
            }
            Assert.AreEqual(HuntEdict.MaxRules,d.rules.Count);int bytes=Encoding.UTF8.GetByteCount(HuntEdictCodec.CanonicalJson(d));
            TestContext.WriteLine($"{d.heroClass}: maximum configuration UTF8 bytes={bytes}");
            string code=HuntEdictCodec.Encode(d);
            TestContext.WriteLine($"{d.heroClass}: max rules={d.rules.Count}, UTF8 bytes={bytes}, code characters={code.Length}");
            Assert.LessOrEqual(bytes,HuntEdictCodec.MaxJsonBytes);Assert.AreEqual(code,HuntEdictCodec.Encode(HuntEdictCodec.Decode(code)));
        }
    }
}
