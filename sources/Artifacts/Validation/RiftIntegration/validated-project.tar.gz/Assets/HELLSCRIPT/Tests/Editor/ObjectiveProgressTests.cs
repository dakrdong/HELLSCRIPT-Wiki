using System;
using System.IO;
using System.Linq;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using System.Text.RegularExpressions;

namespace Hellscript.Tests
{
    public sealed class ObjectiveProgressTests
    {
        GameCatalog catalog;string directory;
        [SetUp] public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();directory=Path.Combine(Path.GetTempPath(),"hellscript-objectives-"+Guid.NewGuid().ToString("N"));}
        [TearDown] public void Teardown(){UnityEngine.Object.DestroyImmediate(catalog);if(Directory.Exists(directory))Directory.Delete(directory,true);Loc.UseSource();}
        CombatSimulation Fixture(RiftObjectiveKind kind,AccountSave account=null)
        {
            account??=GameStore.NewAccount(catalog);account.Hero.level=30;account.Hero.build=BehaviorPresets.ForLevel(account.Hero.heroClass,0,30,catalog);
            var sim=new CombatSimulation(account,catalog,10,seed:7,forcedObjective:kind);
            foreach(var e in sim.State.enemies){e.speed=0;e.attack=0;e.cooldown=10000;}
            sim.State.time=5;sim.State.lastDamageTime=-10;sim.State.build.openChests=false;sim.State.build.useShrines=false;return sim;
        }
        static void Quiet(CombatSimulation sim)
        {
            foreach(var e in sim.State.enemies){e.dead=true;e.pendingDeath=false;}
            sim.State.targetId=-1;sim.State.activeSkill=-1;sim.State.actionCd=0;sim.State.lastDamageTime=-10;sim.State.drops.Clear();
        }
        static void Collect(CombatSimulation sim,int count=3)
        {
            Quiet(sim);
            for(int i=0;i<count;i++)
            {
                sim.State.position=sim.State.layout.offerings[i].position;
                for(int n=0;n<5&&!sim.State.layout.offerings[i].collected;n++)sim.Tick(.05f);
                Assert.IsTrue(sim.State.layout.offerings[i].collected,"Offering "+i);
            }
        }
        static void AtAltar(CombatSimulation sim)
        {
            var altar=sim.State.layout.altar;altar.discovered=true;altar.phase=OfferingAltarPhase.Approaching;altar.access=altar.accessPoints[0];
            sim.State.position=altar.access;sim.State.targetId=-1;sim.State.actionCd=0;sim.State.activeSkill=-1;
        }
        [Test] public void ACarrierRequiresDeathAndKeepsItsLastObservedPositionPrivate()
        {
            var sim=Fixture(RiftObjectiveKind.EssenceCarriers);var point=sim.State.layout.carriers[0];var e=sim.State.enemies.Single(x=>x.id==point.enemyId);
            Vector2 original=point.position;e.position+=Vector2.one*3;RiftExploration.Discover(sim.State,sim.Map);
            Assert.IsFalse(point.discovered);Assert.AreEqual(original,point.position);
            RiftExploration.ObserveEnemies(sim.State,new[]{e});Assert.IsTrue(point.discovered);Assert.AreEqual(e.position,point.position);
            Vector2 observed=point.position;e.position+=Vector2.one*7;e.health=0;sim.Tick(.05f);
            Assert.IsFalse(sim.State.layout.carriers[0].completed,"Zero HP without settled death is not completion.");
            e=sim.State.enemies.Single(x=>x.id==point.enemyId);e.dead=true;e.pendingDeath=true;sim.Tick(.05f);
            Assert.IsTrue(sim.State.layout.carriers[0].completed);Assert.AreEqual(observed,sim.State.layout.carriers[0].position);
        }
        [Test] public void ThreeCarrierDeathsCommitOnceAndFreezeTheGateRecord()
        {
            var account=GameStore.NewAccount(catalog);var sim=Fixture(RiftObjectiveKind.EssenceCarriers,account);
            var ids=sim.State.layout.carriers.Select(c=>c.enemyId).ToArray();
            foreach(int id in ids){var e=sim.State.enemies.Single(x=>x.id==id);e.dead=true;e.pendingDeath=true;sim.Tick(.05f);}
            Assert.IsTrue(sim.State.layout.gateOpen);Assert.IsFalse(sim.State.layout.gateOpenedByMeter);Assert.IsTrue(sim.Map.Reachable(sim.State.layout.bossPoints[0]));
            Assert.AreEqual(3,account.transactions.Count(r=>r.operation.StartsWith("carrier-complete:")));
            string record=JsonUtility.ToJson(RiftObjectives.Capture(sim.State));sim.State.time+=10;sim.Tick(.05f);
            Assert.AreEqual(record,JsonUtility.ToJson(RiftObjectives.Capture(sim.State)));Assert.AreEqual(3,RiftObjectives.Completed(sim.State.layout));
        }
        [Test] public void CarrierSaveFailurePreservesPendingCompletionAndDeathResultUntilRetry()
        {
            var store=new GameStore(directory);var sim=Fixture(RiftObjectiveKind.EssenceCarriers,store.Data);store.Data.suspendedRun=sim.State;
            sim.CommitRunChange=(id,op,change)=>store.CommitRunMutation(sim.State,id,op,change);store.Save();
            var first=sim.State.layout.carriers[0];sim.State.enemies.Single(e=>e.id==first.enemyId).dead=true;sim.State.health=0;
            Directory.CreateDirectory(Path.Combine(directory,"hellscript-local-v1.json.tmp"));LogAssert.Expect(LogType.Error,new Regex("^저장하지 못했습니다:"));sim.Tick(.05f);
            Assert.IsNotEmpty(sim.State.navigationError);Assert.IsFalse(sim.State.layout.carriers[0].completed);Assert.AreEqual(RunPhase.Exploring,sim.State.phase);
            Directory.Delete(Path.Combine(directory,"hellscript-local-v1.json.tmp"));Assert.IsTrue(sim.RetryRiftFault());
            Assert.AreEqual(RunPhase.Failed,sim.State.phase);Assert.AreEqual(1,store.Data.records[0].objective.completed);
            var loaded=new GameStore(directory);Assert.IsTrue(loaded.Data.suspendedRun.layout.carriers[0].completed);
            Assert.AreEqual(1,loaded.Data.transactions.Count(r=>r.operation.StartsWith("carrier-complete:")));
        }
        [Test] public void GuardsAndDangerPreventPickupEvenAtTheOffering()
        {
            var sim=Fixture(RiftObjectiveKind.Offerings);var point=sim.State.layout.offerings[0];sim.State.position=point.position;sim.Tick(.05f);
            Assert.IsFalse(sim.State.layout.offerings[0].collected);Quiet(sim);
            sim.State.effects.Add(new GroundEffect{id=990001,position=point.position,hostile=true,radius=3,damage=1,duration=1});sim.Tick(.05f);
            Assert.IsTrue(sim.State.layout.offerings[0].available);Assert.IsFalse(sim.State.layout.offerings[0].collected);
            sim.State.effects.Clear();sim.State.lastDamageTime=-10;sim.State.position=point.position;
            for(int n=0;n<5&&!sim.State.layout.offerings[0].collected;n++)sim.Tick(.05f);
            Assert.IsTrue(sim.State.layout.offerings[0].collected);
        }
        [Test] public void ThreePickupsRequireDeliveryAndInterruptedProgressSurvivesRestore()
        {
            var account=GameStore.NewAccount(catalog);var sim=Fixture(RiftObjectiveKind.Offerings,account);Collect(sim);
            Assert.IsFalse(sim.State.layout.gateOpen);AtAltar(sim);sim.Tick(.05f);for(int i=0;i<6;i++)sim.Tick(.05f);
            float partial=sim.State.layout.altar.progress;Assert.Greater(partial,0);Assert.Less(partial,1);
            sim.State.paused=true;string paused=JsonUtility.ToJson(sim.State);sim.Tick(1);Assert.AreEqual(paused,JsonUtility.ToJson(sim.State));sim.State.paused=false;
            sim.State.effects.Add(new GroundEffect{id=990002,position=sim.State.position,hostile=true,radius=1,damage=1,duration=.1f});sim.Tick(.05f);
            Assert.AreEqual(OfferingAltarPhase.Available,sim.State.layout.altar.phase);Assert.AreEqual(partial,sim.State.layout.altar.progress,.0001f);
            var restored=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(sim.State));sim=new CombatSimulation(account,catalog,10,restore:restored);
            Assert.AreEqual(partial,sim.State.layout.altar.progress,.0001f);sim.State.effects.Clear();sim.State.lastDamageTime=-10;sim.State.time+=3;AtAltar(sim);
            for(int i=0;i<30&&!sim.State.layout.gateOpen;i++)sim.Tick(.05f);
            Assert.IsTrue(sim.State.layout.gateOpen);Assert.IsFalse(sim.State.layout.gateOpenedByMeter);Assert.AreEqual(OfferingAltarPhase.Offered,sim.State.layout.altar.phase);
            Assert.AreEqual(4,account.transactions.Count(r=>r.operation.StartsWith("offering-")));Assert.IsTrue(RiftObjectives.Capture(sim.State).delivered);
        }
        [Test] public void AnIncompleteLoadCannotStartDelivery()
        {
            var sim=Fixture(RiftObjectiveKind.Offerings);Collect(sim,2);AtAltar(sim);sim.Tick(.05f);
            Assert.AreEqual(OfferingAltarPhase.Available,sim.State.layout.altar.phase);Assert.AreEqual(0,sim.State.layout.altar.progress);Assert.IsFalse(sim.State.layout.gateOpen);
        }
        [Test] public void ExplorationWalksToEveryKnownOfferingAndDeliversWithoutTeleporting()
        {
            var sim=Fixture(RiftObjectiveKind.Offerings);Quiet(sim);
            sim.State.build.rules=new System.Collections.Generic.List<Rule>{BehaviorRules.Utility(RuleAction.Explore)};
            foreach(var point in sim.State.layout.offerings)point.discovered=true;sim.State.layout.altar.discovered=true;
            for(int n=0;n<5000&&!sim.State.layout.gateOpen&&sim.State.phase==RunPhase.Exploring;n++)sim.Tick(.05f);
            Assert.IsTrue(sim.State.layout.gateOpen,"Autonomous delivery stalled at "+sim.State.position+" / "+sim.State.action);
            Assert.AreEqual(OfferingAltarPhase.Offered,sim.State.layout.altar.phase);Assert.IsFalse(sim.State.layout.gateOpenedByMeter);
            Assert.Greater(sim.State.moveDistance,20);Assert.IsEmpty(sim.State.navigationError);
        }
        [Test] public void TheLastCarrierAndHeroDyingTogetherRecordsTheGoalWithoutAwardingVictory()
        {
            var account=GameStore.NewAccount(catalog);var sim=Fixture(RiftObjectiveKind.EssenceCarriers,account);
            foreach(var point in sim.State.layout.carriers){var e=sim.State.enemies.Single(x=>x.id==point.enemyId);e.dead=true;e.pendingDeath=true;}
            sim.State.health=0;sim.Tick(.05f);
            Assert.AreEqual(RunPhase.Failed,sim.State.phase);Assert.IsTrue(account.records[0].objective.gateOpen);Assert.AreEqual(3,account.records[0].objective.completed);
            Assert.IsFalse(account.records[0].objective.byMeter);
        }
        [Test] public void TheMeterInterruptsDeliveryAndFreezesItsUndeliveredResult()
        {
            var sim=Fixture(RiftObjectiveKind.Offerings);Collect(sim);AtAltar(sim);sim.Tick(.05f);sim.Tick(.05f);
            float partial=sim.State.layout.altar.progress;Assert.Greater(partial,0);
            sim.State.meter=100;sim.Tick(.05f);Assert.AreEqual(partial,sim.State.layout.altar.progress);
            Assert.AreEqual(OfferingAltarPhase.Available,sim.State.layout.altar.phase);Assert.IsFalse(RiftObjectives.Capture(sim.State).delivered);Assert.IsTrue(RiftObjectives.Capture(sim.State).byMeter);
        }
        [TestCase(false)] [TestCase(true)] public void FailedPickupOrDeliveryCanRetryAndReloadWithoutDuplication(bool delivery)
        {
            var store=new GameStore(directory);var sim=Fixture(RiftObjectiveKind.Offerings,store.Data);store.Data.suspendedRun=sim.State;
            sim.CommitRunChange=(id,op,change)=>store.CommitRunMutation(sim.State,id,op,change);
            if(delivery){Collect(sim);AtAltar(sim);sim.State.layout.altar.phase=OfferingAltarPhase.Offering;sim.State.layout.altar.progress=1;}
            else {Quiet(sim);sim.State.position=sim.State.layout.offerings[0].position;}
            store.Save();Directory.CreateDirectory(Path.Combine(directory,"hellscript-local-v1.json.tmp"));LogAssert.Expect(LogType.Error,new Regex("^저장하지 못했습니다:"));sim.Tick(.05f);
            Assert.IsNotEmpty(sim.State.navigationError);Assert.IsFalse(sim.State.layout.gateOpen);
            Assert.AreEqual(delivery?3:0,store.Data.transactions.Count(r=>r.operation.StartsWith("offering-")));
            Directory.Delete(Path.Combine(directory,"hellscript-local-v1.json.tmp"));Assert.IsTrue(sim.RetryRiftFault());
            var loaded=new GameStore(directory);var resumed=new CombatSimulation(loaded.Data,catalog,10,restore:loaded.Data.suspendedRun);resumed.Tick(.05f);
            Assert.AreEqual(delivery?4:1,loaded.Data.transactions.Count(r=>r.operation.StartsWith("offering-")));
            Assert.AreEqual(delivery,resumed.State.layout.gateOpen);Assert.AreEqual(delivery?3:1,RiftObjectives.Completed(resumed.State.layout));
            if(delivery)Assert.IsTrue(resumed.State.layout.objectiveRecord.delivered);
        }
        [TestCase(RiftObjectiveKind.EssenceCarriers)] [TestCase(RiftObjectiveKind.Offerings)] public void TheMeterFreezesPartialProgressAndAbandonKeepsTheSameReport(RiftObjectiveKind kind)
        {
            var account=GameStore.NewAccount(catalog);var sim=Fixture(kind,account);
            if(kind==RiftObjectiveKind.Offerings)Collect(sim,1);else {sim.State.enemies.Single(e=>e.id==sim.State.layout.carriers[0].enemyId).dead=true;sim.Tick(.05f);}
            sim.State.meter=100;sim.Tick(.05f);var record=RiftObjectives.Capture(sim.State);Assert.IsTrue(record.byMeter);Assert.AreEqual(1,record.completed);
            sim.State.time+=10;sim.Abandon();Assert.AreEqual(JsonUtility.ToJson(record),JsonUtility.ToJson(account.records[0].objective));
        }
        [Test] public void OldMapsAndRecordsDoNotInventAnObjectiveTimestamp()
        {
            var sim=Fixture(RiftObjectiveKind.Seals);sim.State.layout.version=3;sim.State.time=40;sim.State.meter=100;sim.Tick(.05f);
            var record=RiftObjectives.Capture(sim.State);Assert.IsFalse(record.timeKnown);StringAssert.Contains("시점 기록 없음",GameUI.ObjectiveSummary(record));
            Assert.AreEqual("",GameUI.ObjectiveSummary(JsonUtility.FromJson<RunRecord>("{}").objective));
        }
        [TestCase(RiftObjectiveKind.EssenceCarriers)] [TestCase(RiftObjectiveKind.Offerings)]
        public void FinishedObjectiveHistorySurvivesAnAccountReload(RiftObjectiveKind kind)
        {
            var store=new GameStore(directory);var sim=Fixture(kind,store.Data);store.Data.suspendedRun=sim.State;
            if(kind==RiftObjectiveKind.Offerings)Collect(sim,1);
            else {sim.State.enemies.Single(e=>e.id==sim.State.layout.carriers[0].enemyId).dead=true;sim.Tick(.05f);}
            sim.State.meter=100;sim.Tick(.05f);string before=JsonUtility.ToJson(RiftObjectives.Capture(sim.State));
            sim.Abandon();Assert.IsTrue(store.Save());var loaded=new GameStore(directory);
            Assert.AreEqual(before,JsonUtility.ToJson(loaded.Data.records[0].objective));
            Assert.AreEqual(GameUI.ObjectiveSummary(store.Data.records[0].objective),GameUI.ObjectiveSummary(loaded.Data.records[0].objective));
            Assert.AreEqual(kind,loaded.Data.records[0].objective.kind);Assert.AreEqual(1,loaded.Data.records[0].objective.completed);
        }
    }
}
