using System;
using System.IO;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class CombatSpeedAccessTests
    {
        string directory, path;
        GameCatalog catalog;
        GameStore store;
        static string Json(object value) => JsonUtility.ToJson(value);
        [SetUp] public void Setup()
        {
            directory=Path.Combine(Path.GetTempPath(),"hellscript-speed-"+Guid.NewGuid().ToString("N"));
            path=Path.Combine(directory,"hellscript-local-v1.json");
            catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();store=new GameStore(directory,catalog);
        }
        [TearDown] public void Teardown() { UnityEngine.Object.DestroyImmediate(catalog); if(Directory.Exists(directory))Directory.Delete(directory,true); }
        [TestCase(1f,true)] [TestCase(1.5f,false)] [TestCase(2f,false)] [TestCase(0f,false)]
        [TestCase(-1f,false)] [TestCase(3f,false)] [TestCase(float.NaN,false)]
        [TestCase(float.PositiveInfinity,false)] [TestCase(float.NegativeInfinity,false)]
        public void EveryUserInputResolvesToNormalSpeed(float requested,bool allowed)
        { Assert.AreEqual(allowed,CombatSpeedAccess.CanSelect(requested));Assert.AreEqual(1f,CombatSpeedAccess.Resolve(requested)); }
        [TestCase(1.5f,false)] [TestCase(2f,false)] [TestCase(1.5f,true)] [TestCase(2f,true)]
        public void OldSaveAndBackupRestoreAtNormalSpeedWithoutResettingTheRift(float speed,bool backup)
        {
            var sim=new CombatSimulation(store.Data,catalog,1,seed:778899);for(int i=0;i<14;i++)sim.Tick(CombatSimulation.Step);
            sim.State.paused=true;store.Data.suspendedRun=sim.State;Assert.IsTrue(store.Save(),store.Error);
            var loaded=new GameStore(directory,catalog);string expectedRun=Json(loaded.Data.suspendedRun),heroes=Json(loaded.Data.Hero);
            loaded.Data.speed=speed;File.WriteAllText(backup?path+".bak":path,Json(loaded.Data));if(backup)File.WriteAllText(path,"invalid primary");
            var restored=new GameStore(directory,catalog);
            Assert.AreEqual(1f,restored.Data.speed);Assert.AreEqual(expectedRun,Json(restored.Data.suspendedRun));Assert.AreEqual(heroes,Json(restored.Data.Hero));
            Assert.AreEqual(1f,JsonUtility.FromJson<AccountSave>(File.ReadAllText(path)).speed);
        }
        [TestCase(1.5f)] [TestCase(2f)]
        public void SavingABypassValuePersistsNormalSpeedWithoutChangingHeroOrRewards(float speed)
        {
            string hero=Json(store.Data.Hero);int gold=store.Data.gold,materials=store.Data.materials;
            store.Data.speed=speed;Assert.IsTrue(store.Save(),store.Error);
            Assert.AreEqual(1f,store.Data.speed);Assert.AreEqual(hero,Json(store.Data.Hero));Assert.AreEqual(gold,store.Data.gold);Assert.AreEqual(materials,store.Data.materials);
            Assert.AreEqual(1f,new GameStore(directory,catalog).Data.speed);
        }
        [Test] public void MissingSpeedInOldJsonDefaultsToNormalSpeed()
        {
            File.WriteAllText(path,Json(store.Data).Replace("\"speed\":1.0,", "").Replace("\"speed\":1,", ""));
            StringAssert.DoesNotContain("\"speed\"",File.ReadAllText(path));
            Assert.AreEqual(1f,new GameStore(directory,catalog).Data.speed);
        }
    }
}
