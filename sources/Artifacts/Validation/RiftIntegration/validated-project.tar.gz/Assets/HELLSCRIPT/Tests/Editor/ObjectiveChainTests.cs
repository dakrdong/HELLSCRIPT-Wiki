using System;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class ObjectiveChainTests
    {
        GameCatalog catalog;
        [SetUp] public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown] public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        CombatSimulation Fixture(RiftObjectiveKind kind)
        {
            var account=GameStore.NewAccount(catalog);account.Hero.level=30;
            account.Hero.build=BehaviorPresets.ForLevel(account.Hero.heroClass,0,30,catalog);
            return new CombatSimulation(account,catalog,10,seed:7,forcedObjective:kind);
        }
        [Test]
        public void TheIndependentObjectiveDrawIsBalancedAcrossTenThousandSeeds()
        {
            var counts=new int[4];
            for(uint seed=1;seed<=10000;seed++)
            {
                Assert.AreEqual(RiftObjectiveKind.None,RiftObjectives.Select(seed,4));
                var kind=RiftObjectives.Select(seed,5);Assert.AreEqual(kind,RiftObjectives.Select(seed,30));counts[(int)kind]++;
            }
            Assert.AreEqual(0,counts[0]);
            for(int i=1;i<=3;i++)Assert.Less(Math.Abs(counts[i]-10000d/3),6*Math.Sqrt(10000d*2/9));
            Debug.Log("OBJECTIVE_DRAWS "+string.Join(",",counts));
        }
        [Test]
        public void ActualGenerationRetainsItsDrawAcrossCandidateRetries()
        {
            var kinds=new System.Collections.Generic.HashSet<RiftObjectiveKind>();
            for(uint seed=1;seed<=36;seed++)
            {
                var map=RiftGenerator.Generate(seed,"objective-mix",10,HeroClass.Warrior);
                Assert.AreEqual(RiftObjectives.Select(seed,10),map.objective);kinds.Add(map.objective);
            }
            CollectionAssert.AreEquivalent(new[]{RiftObjectiveKind.Seals,RiftObjectiveKind.EssenceCarriers,RiftObjectiveKind.Offerings},kinds);
        }
        [TestCase(RiftObjectiveKind.Seals)] [TestCase(RiftObjectiveKind.EssenceCarriers)] [TestCase(RiftObjectiveKind.Offerings)]
        public void EachKindFitsBothThemesAndEveryRoomCount(RiftObjectiveKind kind)
        {
            for(int theme=0;theme<2;theme++)for(int size=6;size<=8;size++)
            {
                var map=RiftGenerator.Generate(84719,"objective-geometry",10,HeroClass.Mage,forcedTheme:theme,forcedCount:size,forcedObjective:kind);
                Assert.AreEqual(kind,map.objective);Assert.AreEqual(size,map.rooms.Count);
                Assert.AreEqual(110,map.spawns.Count(s=>s.elite<0));Assert.AreEqual(8,map.spawns.Count(s=>s.elite>=0));
                Assert.AreEqual(kind==RiftObjectiveKind.Seals?2:3,RiftObjectives.Total(map));RiftGenerator.Validate(map);
                var nav=new RiftNavigation(map);Assert.IsFalse(nav.Reachable(map.bossPoints[0]));
                foreach(var carrier in map.carriers)
                {Assert.IsTrue(nav.Reachable(carrier.position));Assert.IsTrue(RiftObjectives.PointRoom(map.rooms[carrier.room]));Assert.GreaterOrEqual(map.spawns[carrier.spawn].elite,0);}
                foreach(var offering in map.offerings)
                {Assert.IsTrue(nav.Reachable(offering.position));Assert.IsFalse(offering.available||offering.collected);}
                if(kind==RiftObjectiveKind.Offerings)
                {Assert.IsFalse(nav.Walkable(map.altar.position));Assert.IsTrue(map.altar.accessPoints.All(nav.Reachable));}
            }
        }
        [TestCase(RiftObjectiveKind.Seals)] [TestCase(RiftObjectiveKind.EssenceCarriers)] [TestCase(RiftObjectiveKind.Offerings)]
        public void AllFixedFallbacksPreserveTheRequestedObjective(RiftObjectiveKind kind)
        {
            for(int theme=0;theme<2;theme++)for(int index=0;index<3;index++)
            {
                var map=RiftGenerator.Fallback(71822,"objective-fallback",10,HeroClass.Ranger,theme,index,forcedObjective:kind);
                Assert.AreEqual(kind,map.objective);RiftGenerator.Validate(map);
            }
        }
        [Test]
        public void CarrierMarkersUseTheExistingEliteIdsWithoutAddingEnemies()
        {
            var sim=Fixture(RiftObjectiveKind.EssenceCarriers);Assert.AreEqual(118,sim.State.enemies.Count);
            foreach(var carrier in sim.State.layout.carriers)
            {var enemy=sim.State.enemies.Single(e=>e.id==carrier.enemyId);Assert.GreaterOrEqual(enemy.elite,0);Assert.AreEqual(sim.State.layout.spawns[carrier.spawn].group,enemy.group);}
        }
        [Test] public void AnAltarCannotOccupyAReservedCursedEventSpawn()
        {
            var map=RiftGenerator.Fallback(71822,"reserved-echo",10,HeroClass.Ranger,0,0,forcedObjective:RiftObjectiveKind.Offerings);
            Vector2 reserved=map.altar.position;int room=map.altar.room;
            // Objective placement precedes gate construction in the generator.
            map.obstacles.RemoveAll(o=>o.kind=="OfferingAltar");map.altar=null;map.offerings.Clear();map.gates.Clear();
            var nav=new RiftNavigation(map);var points=map.rooms[room].groupAnchors.Where(p=>nav.Reachable(p)&&nav.Walkable(p,.4f)).Take(3).ToList();points.Add(reserved);
            map.events.Clear();map.events.Add(new RiftEvent{id="reserved-echo",chestId=map.chests.First(c=>c.room==room).id,spawnCandidates=points});
            Assert.IsTrue(points.All(nav.Reachable));RiftObjectives.Place(map,nav);
            var after=new RiftNavigation(map);
            Assert.IsTrue(points.All(after.Reachable),"An objective body consumed a previously usable event spawn.");
            Assert.IsTrue(points.All(p=>after.Walkable(p,.4f)),"An event enemy would overlap the altar body.");
        }
    }
}
