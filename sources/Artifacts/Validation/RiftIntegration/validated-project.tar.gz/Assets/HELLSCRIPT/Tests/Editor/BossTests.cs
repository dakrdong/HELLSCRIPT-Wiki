using System;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class BossTests
    {
        GameCatalog catalog;
        [SetUp]public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown]public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        static object Call(CombatSimulation sim,string name,params object[] args)
        {
            var method=typeof(CombatSimulation).GetMethod(name,BindingFlags.NonPublic|BindingFlags.Instance);var parameters=method.GetParameters();var full=new object[parameters.Length];
            for(int i=0;i<full.Length;i++)full[i]=i<args.Length?args[i]:parameters[i].DefaultValue;return method.Invoke(sim,full);
        }
        static void Advance(CombatSimulation sim,int steps){for(int i=0;i<steps;i++)sim.Tick(.05f);}
        static void Until(CombatSimulation sim,Func<bool> done,int cap=400){for(int i=0;i<cap&&!done();i++)sim.Tick(.05f);Assert.IsTrue(done(),"Boss state not reached: "+sim.State.enemies[0].brain.state);}
        static EnemyState Boss(CombatSimulation sim)=>sim.State.enemies[0];
        static void Controlled(CombatSimulation sim){sim.Stats.hp=100000;sim.State.health=100000;sim.Stats.armor=sim.Stats.resistance=sim.Stats.regen=sim.Stats.crit=0;}
        CombatSimulation Fixture(BossAttack attack,float distance=2)
        {
            var account=GameStore.NewAccount();account.Hero.level=30;account.Hero.build.rules.Clear();account.Hero.build.passives=Array.Empty<int>();account.Hero.build.movement=MovementMode.Stand;account.Hero.build.potionThreshold=0;
            var sim=new CombatSimulation(account,catalog,1,1,seed:17853);sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();sim.State.decisionTime=1000;
            int pattern=attack==BossAttack.Summon||attack==BossAttack.Beam?1:attack==BossAttack.Charge||attack==BossAttack.Blasts?2:0;
            var e=new EnemyState{id=900,boss=true,pattern=pattern,position=sim.State.position+Vector2.up*distance,health=10000,maxHealth=10000,attack=100,speed=0,cooldown=1000};sim.State.enemies.Add(e);sim.State.bossId=900;
            Call(sim,"TickEnemyTimers",0f);Array.Fill(e.brain.boss.cooldowns,1000);e.brain.boss.cooldowns[Slot(attack)]=0;Controlled(sim);return sim;
        }
        static int Slot(BossAttack kind)=>kind==BossAttack.Basic?0:kind==BossAttack.Slam||kind==BossAttack.Summon||kind==BossAttack.Charge?1:2;
        CombatSimulation Restore(CombatSimulation source)
        {
            var a=GameStore.NewAccount();a.heroes[0]=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(source.Hero));var restored=new CombatSimulation(a,catalog,1,1,JsonUtility.FromJson<RunState>(JsonUtility.ToJson(source.State)));Controlled(restored);restored.State.health=source.State.health;return restored;
        }
        [TestCase(BossAttack.Basic,.6f,2)][TestCase(BossAttack.Slam,1.2f,6)][TestCase(BossAttack.Hook,1,9)][TestCase(BossAttack.Summon,.8f,14)]
        [TestCase(BossAttack.Beam,1.5f,8)][TestCase(BossAttack.Charge,1,7)][TestCase(BossAttack.Blasts,1.3f,12)]
        public void EachPatternUsesItsOwnPreparationAndStartBasedCooldown(BossAttack attack,float prepare,float cooldown)
        {
            var sim=Fixture(attack);var e=Boss(sim);sim.Tick(.05f);Assert.AreEqual((int)attack,e.brain.action.kind);Assert.AreEqual(prepare,e.windup,.0001f);Assert.AreEqual(cooldown,e.brain.boss.cooldowns[Slot(attack)],.0001f);
            Advance(sim,Mathf.RoundToInt(prepare/.05f)-1);Assert.IsFalse(sim.State.enemyEvents.Any(x=>x.kind=="RELEASE"));Advance(sim,1);
            Assert.AreEqual(1,sim.State.enemyEvents.Count(x=>x.kind=="RELEASE"));Assert.AreEqual(cooldown-prepare,e.brain.boss.cooldowns[Slot(attack)],.001f);
        }
        [Test]
        public void HalfHealthDuringASlamSchedulesTheNextPhaseWithoutChangingTheWarnedAttack()
        {
            var sim=Fixture(BossAttack.Slam);var e=Boss(sim);sim.Tick(.05f);Call(sim,"Deal",e,6000f,false);e.health=9000;
            Until(sim,()=>e.brain.action.phase==EnemyActionPhase.Idle);Assert.AreEqual(1,sim.State.damageEvents.Count(d=>d.incoming));Assert.IsTrue(e.brain.boss.enragePending);Assert.IsFalse(e.brain.boss.enraged);
            e.brain.boss.cooldowns[1]=0;sim.Tick(.05f);Assert.IsTrue(e.brain.boss.enraged);Assert.AreEqual(2,e.brain.action.remainingCharges);Assert.IsTrue(e.brain.action.empowered);
        }
        [Test]
        public void EmpoweredSlamKeepsItsDirectionAndRewarnsForPointSevenSeconds()
        {
            var sim=Fixture(BossAttack.Slam);var e=Boss(sim);e.health=5000;sim.Tick(.05f);Vector2 direction=e.brain.action.direction;int root=e.brain.action.id;
            Advance(sim,24);Assert.AreEqual(.7f,e.windup,.0001f);Assert.AreEqual(1,sim.State.damageEvents.Count(d=>d.incoming));sim.State.position=e.position+Vector2.right*2;
            Advance(sim,13);Assert.AreEqual(EnemyActionPhase.Preparing,e.brain.action.phase);Assert.AreEqual(direction,e.brain.action.direction);Advance(sim,1);
            Assert.AreEqual(EnemyActionPhase.Idle,e.brain.action.phase);Assert.AreEqual(1,sim.State.damageEvents.Count(d=>d.incoming));Assert.AreEqual(2,sim.State.enemyEvents.Count(x=>x.kind=="RELEASE"&&x.actionId==root));
        }
        [TestCase(BossAttack.Slam)][TestCase(BossAttack.Hook)][TestCase(BossAttack.Summon)][TestCase(BossAttack.Beam)][TestCase(BossAttack.Charge)][TestCase(BossAttack.Blasts)]
        public void StaggerCancelsPreparationAndKeepsThatPatternsRemainingCooldown(BossAttack attack)
        {
            var sim=Fixture(attack);var e=Boss(sim);sim.Tick(.05f);Advance(sim,3);float cooldown=e.brain.boss.cooldowns[Slot(attack)];Call(sim,"AddBossControl",e,100f,"TEST",88);
            Assert.AreEqual(EnemyActionPhase.Idle,e.brain.action.phase);Assert.AreEqual(0,e.windup);Assert.AreEqual(cooldown,e.brain.boss.cooldowns[Slot(attack)]);Assert.IsEmpty(e.brain.boss.refuges);
            Advance(sim,40);Assert.IsFalse(sim.State.enemyEvents.Any(x=>x.kind=="RELEASE"));Assert.AreEqual(cooldown-2,e.brain.boss.cooldowns[Slot(attack)],.001f);Assert.IsEmpty(sim.State.projectiles);Assert.IsEmpty(sim.State.enemyHazards);
        }
        [Test]
        public void HookPullsTwoMetersAndInterruptsAnActualChannelWithoutRefundingCost()
        {
            var sim=Fixture(BossAttack.Hook,6);var nearby=new EnemyState{id=901,position=sim.State.position+Vector2.left*2,health=100000,maxHealth=100000,cooldown=1000,speed=0};sim.State.enemies.Add(nearby);
            Until(sim,()=>sim.State.projectiles.Count==1);sim.State.targetId=nearby.id;Call(sim,"StartHeroAction",0,nearby,sim.State.position,0f,0,false);float resource=sim.State.resource;
            Until(sim,()=>sim.State.effectEvents.Any(x=>x.kind=="PULLED"));var interruption=sim.State.actionEvents.LastOrDefault(x=>x.kind=="ACTION_INTERRUPTED"&&x.reason=="갈고리에 끌림");Assert.NotNull(interruption,string.Join(" / ",sim.State.actionEvents.Select(x=>x.kind+":"+x.reason)));Assert.AreEqual(2,Vector2.Distance(interruption.position,sim.State.position),.001f);Assert.AreEqual(2,sim.State.effectEvents.Single(x=>x.kind=="PULLED").value,.001f);Assert.AreEqual(HeroActionPhase.Idle,sim.State.heroAction.phase);
            Assert.Less(sim.State.resource,resource);Assert.AreEqual(1,sim.State.damageEvents.Count(d=>d.incoming&&d.definitionId=="BOSS01_HOOK"));Assert.IsTrue(sim.Map.CanLand(sim.State.position));
        }
        [Test]
        public void HookCanFlyAcrossAWalkOnlyFenceButCannotPullTheHeroThroughIt()
        {
            var sim=Fixture(BossAttack.Hook,6);sim.State.layout.legacy=false;sim.State.layout.obstacles.Add(new RiftObstacle{id="walk-fence",position=sim.State.position+Vector2.up*1.5f,halfSize=new Vector2(3,.1f),blocksWalk=true,blocksLanding=true,blocksProjectile=false,blocksSight=false});sim=Restore(sim);Vector2 from=sim.State.position;
            Until(sim,()=>sim.State.effectEvents.Any(x=>x.kind=="PULLED"));Assert.Less(Vector2.Distance(from,sim.State.position),1);Assert.IsTrue(sim.Map.CanLand(sim.State.position));Assert.IsTrue(sim.Map.TravelClear(from,sim.State.position));
        }
        [Test]
        public void HookDoesNotCancelAnAirborneActionIntoUnwalkableGround()
        {
            var sim=Fixture(BossAttack.Hook);sim.State.layout.legacy=false;sim.State.layout.obstacles.Add(new RiftObstacle{id="air-wall",position=sim.State.position,halfSize=Vector2.one,blocksWalk=true,blocksLanding=true,blocksProjectile=false,blocksSight=false});sim=Restore(sim);
            sim.State.heroAction=new HeroActionState{id=30,skill=1,phase=HeroActionPhase.Travelling};Vector2 position=sim.State.position;var shot=new CombatProjectile{origin=position+Vector2.up*5,pullDistance=2};Call(sim,"PullHero",shot);
            Assert.AreEqual(position,sim.State.position);Assert.AreEqual(HeroActionPhase.Travelling,sim.State.heroAction.phase);Assert.IsFalse(sim.State.effectEvents.Any(x=>x.kind=="PULLED"));
        }
        [Test]
        public void SummonsAreOwnedCappedAtEightAndKilledAddsGiveNoExperienceGaugeOrLoot()
        {
            var sim=Fixture(BossAttack.Summon,4);var e=Boss(sim);Until(sim,()=>sim.State.enemies.Count==5);Assert.IsTrue(sim.State.enemies.Skip(1).All(x=>x.add&&x.summonerId==900));
            e.brain.boss.cooldowns[1]=0;Until(sim,()=>sim.State.enemies.Count==9);e.brain.boss.cooldowns[1]=0;Advance(sim,25);Assert.AreEqual(8,sim.State.enemies.Count(x=>x.add&&!x.dead));
            var account=(AccountSave)typeof(CombatSimulation).GetField("account",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(sim);int gold=account.gold,materials=account.materials;sim.Hero.level=1;int xp=sim.Hero.xp;float gauge=sim.State.meter;int drops=sim.State.drops.Count;uint rewardRng=sim.State.rewardRng;int kills=sim.State.kills;
            var add=sim.State.enemies.Last();Call(sim,"Deal",add,100000f,false);sim.Tick(.05f);Assert.AreEqual(xp,sim.Hero.xp);Assert.AreEqual(gauge,sim.State.meter);Assert.AreEqual(drops,sim.State.drops.Count);Assert.AreEqual(rewardRng,sim.State.rewardRng);Assert.AreEqual(kills+1,sim.State.kills);Assert.AreEqual(gold,account.gold);Assert.AreEqual(materials,account.materials);Assert.IsFalse(sim.State.enemyCorpses.Any(c=>c.enemyId==add.id));
        }
        [Test]
        public void SummonExecutionRechecksReservedLocationsAndDoesNotRelocateBlockedSpawns()
        {
            var sim=Fixture(BossAttack.Summon,4);sim.Tick(.05f);var e=Boss(sim);Vector2 blocked=e.brain.action.points[0];sim.State.enemies.Add(new EnemyState{id=901,position=blocked,health=100000,maxHealth=100000,cooldown=1000,speed=0});
            Advance(sim,16);Assert.AreEqual(3,sim.State.enemies.Count(x=>x.add));Assert.IsFalse(sim.State.enemies.Any(x=>x.add&&x.position==blocked));
        }
        [Test]
        public void ChoirmasterReductionCountsOnlyItsOwnLivingAdds()
        {
            var sim=Fixture(BossAttack.Beam);var e=Boss(sim);var add=new EnemyState{id=901,add=true,summonerId=999,health=100,maxHealth=100};sim.State.enemies.Add(add);
            Assert.AreEqual(0,(float)Call(sim,"TargetReduction",e,0));add.summonerId=900;Assert.AreEqual(.2f,(float)Call(sim,"TargetReduction",e,0),.0001f);add.dead=true;Assert.AreEqual(0,(float)Call(sim,"TargetReduction",e,0));
        }
        [Test]
        public void BeamIsFixedForEightQuarterSecondTicksAndSurvivesStaggerAfterCreation()
        {
            var sim=Fixture(BossAttack.Beam,4);Until(sim,()=>sim.State.enemyHazards.Count==1);var e=Boss(sim);var h=sim.State.enemyHazards.Single();Assert.AreEqual(.25f,h.tick);Assert.IsEmpty(sim.State.damageEvents.Where(d=>d.incoming));
            Vector2 direction=h.direction;Call(sim,"AddBossControl",e,100f,"TEST",88);Advance(sim,40);
            var hits=sim.State.damageEvents.Where(d=>d.incoming&&d.definitionId=="BOSS02_BEAM").ToArray();Assert.AreEqual(8,hits.Length);Assert.IsTrue(hits.All(d=>Mathf.Abs(d.baseAttack-37.5f)<.001f));Assert.IsEmpty(sim.State.enemyHazards);Assert.AreEqual(direction,h.direction);
        }
        [Test]
        public void BeamWarningAndDamageShareAProjectileWallClippedEnd()
        {
            var sim=Fixture(BossAttack.Beam,4);sim.State.layout.legacy=false;sim.State.layout.obstacles.Add(new RiftObstacle{id="beam-wall",position=sim.State.position+Vector2.down,halfSize=new Vector2(4,.1f),blocksProjectile=true,blocksWalk=false,blocksSight=false});sim=Restore(sim);sim.Tick(.05f);var warning=EnemyCombat.Threats(sim.State,sim.Map).Single();
            Assert.Less(Vector2.Distance(warning.origin,warning.end),5);sim.State.position+=Vector2.down*2;Assert.IsFalse(sim.InDanger);Until(sim,()=>sim.State.enemyHazards.Count==1);var field=sim.State.enemyHazards.Single();Assert.AreEqual(warning.end,field.end);Advance(sim,40);Assert.IsFalse(sim.State.damageEvents.Any(d=>d.incoming));
        }
        [Test]
        public void PredatorRewarnsItsSecondChargeForPointEightSecondsAndHitsOncePerPass()
        {
            var sim=Fixture(BossAttack.Charge,6);var e=Boss(sim);e.health=5000;Until(sim,()=>e.brain.action.phase==EnemyActionPhase.Preparing&&e.brain.action.remainingCharges==1);Assert.AreEqual(.8f,e.windup,.0001f);Assert.Greater(e.brain.action.direction.y,0);
            Advance(sim,15);Assert.AreEqual(EnemyActionPhase.Preparing,e.brain.action.phase);Advance(sim,1);Assert.AreEqual(EnemyActionPhase.Charging,e.brain.action.phase);
            Until(sim,()=>e.brain.action.phase==EnemyActionPhase.Idle);Assert.AreEqual(2,sim.State.damageEvents.Count(d=>d.incoming&&d.definitionId=="BOSS03_CHARGE"));Assert.IsTrue(sim.Map.CanLand(e.position,1.2f));
        }
        [TestCase(0)][TestCase(128)][TestCase(256)]
        public void BlastsWarnAllThreeImpactsAndPreserveTwoReachableSafeRefuges(float time)
        {
            var sim=Fixture(BossAttack.Blasts,4);sim.State.time=time;sim.Tick(.05f);var e=Boss(sim);var a=e.brain.action;Assert.AreEqual(3,a.points.Count);Assert.AreEqual(3,EnemyCombat.Threats(sim.State,sim.Map).Count());Assert.AreEqual(2,e.brain.boss.refuges.Count);
            foreach(var refuge in e.brain.boss.refuges){Assert.IsTrue(sim.Map.CanLand(refuge.position,.65f));Assert.LessOrEqual(RiftNavigation.Length(refuge.path),sim.MovementSpeed(false)*1.1f);Assert.IsTrue(a.points.All(p=>Vector2.Distance(p,refuge.position)>2.5f+refuge.radius));}
            sim.State.position=e.brain.boss.refuges[0].position;Advance(sim,40);Assert.IsFalse(sim.State.damageEvents.Any(d=>d.incoming));Assert.IsEmpty(sim.State.enemyHazards);Assert.IsEmpty(e.brain.boss.refuges,"Refuges expire on the same fixed tick as the last blast.");
        }
        [Test]
        public void BlastImpactsUseThreeSeparateTimesAndKeepDelayedImpactsAfterStagger()
        {
            var sim=Fixture(BossAttack.Blasts,4);sim.Tick(.05f);var e=Boss(sim);var points=e.brain.action.points.ToArray();Advance(sim,26);Assert.AreEqual(1,sim.State.damageEvents.Count(d=>d.incoming));float first=sim.State.damageEvents.Single(d=>d.incoming).time;
            Call(sim,"AddBossControl",e,100f,"TEST",99);Assert.AreEqual(2,sim.State.enemyHazards.Count);sim.State.position=points[1];Advance(sim,7);sim.State.position=points[2];Advance(sim,7);
            var hits=sim.State.damageEvents.Where(d=>d.incoming).ToArray();Assert.AreEqual(3,hits.Length);Assert.AreEqual(first+.35f,hits[1].time,.001f);Assert.AreEqual(first+.7f,hits[2].time,.001f);Assert.IsTrue(hits.All(d=>d.baseAttack==150));Assert.IsEmpty(sim.State.enemyHazards);
        }
        [Test]
        public void NoSafeBlastLayoutDefersWithoutSpendingItsCooldownOrFreezingOtherActions()
        {
            var sim=Fixture(BossAttack.Blasts);sim.State.layout.legacy=false;sim.State.layout.obstacles.Add(new RiftObstacle{id="no-refuges",position=sim.State.position,radius=10,blocksLanding=true,blocksWalk=false,blocksSight=false,blocksProjectile=false});sim=Restore(sim);sim.Tick(.05f);var e=Boss(sim);
            Assert.AreEqual(EnemyActionPhase.Idle,e.brain.action.phase);Assert.AreEqual(0,e.brain.boss.cooldowns[2]);Assert.AreEqual(1,e.brain.boss.planRetry);Assert.IsEmpty(e.brain.boss.refuges);Assert.IsFalse(sim.State.enemyEvents.Any(x=>x.kind=="PREPARE"));
            e.brain.boss.cooldowns[0]=0;sim.Tick(.05f);Assert.AreEqual((int)BossAttack.Basic,e.brain.action.kind);
        }
        [TestCase(BossAttack.Slam)][TestCase(BossAttack.Beam)][TestCase(BossAttack.Charge)][TestCase(BossAttack.Blasts)]
        public void MidPatternPauseAndRestoreKeepTheSameFutureState(BossAttack attack)
        {
            var sim=Fixture(attack,4);var e=Boss(sim);e.health=5000;sim.Tick(.05f);
            if(attack==BossAttack.Slam)Until(sim,()=>e.brain.action.remainingCharges==1);else if(attack==BossAttack.Charge)Until(sim,()=>e.brain.action.phase==EnemyActionPhase.Charging&&e.brain.action.moved>=1);else Until(sim,()=>e.brain.action.phase==EnemyActionPhase.Recovering);
            sim.State.paused=true;string before=JsonUtility.ToJson(sim.State);Advance(sim,20);Assert.AreEqual(before,JsonUtility.ToJson(sim.State));sim.State.paused=false;var restored=Restore(sim);
            for(int i=0;i<60;i++){sim.Tick(.05f);restored.Tick(.05f);Assert.AreEqual(JsonUtility.ToJson(sim.State),JsonUtility.ToJson(restored.State),"tick "+i);}
        }
        [Test]
        public void LegacyScalarPreparationFinishesOnceThenSelectsFormalPatterns()
        {
            var sim=Fixture(BossAttack.Slam);var e=Boss(sim);e.brain.boss.initialized=false;e.windup=.4f;e.aim=sim.State.position;e.cooldown=2;sim.State.combatVersion=2;sim=Restore(sim);e=Boss(sim);sim.Tick(.05f);
            Assert.AreEqual((int)BossAttack.Legacy,e.brain.action.kind);Assert.AreEqual(.35f,e.windup,.0001f);Advance(sim,7);Assert.AreEqual(1,sim.State.damageEvents.Count(d=>d.incoming&&d.definitionId=="LEGACY_BOSS"));Assert.IsTrue(e.brain.boss.cooldowns.All(c=>Mathf.Abs(c-6)<.001f));
            e.brain.boss.cooldowns[1]=0;sim.Tick(.05f);Assert.AreEqual((int)BossAttack.Slam,e.brain.action.kind);Assert.AreEqual(CombatActions.Version,sim.State.combatVersion);
        }
        [Test]
        public void AHookAlreadyInFlightRestoresItsPullAndCastIdentityExactlyOnce()
        {
            var sim=Fixture(BossAttack.Hook,6);Until(sim,()=>sim.State.projectiles.Count==1);Advance(sim,3);var restored=Restore(sim);
            for(int i=0;i<40;i++){sim.Tick(.05f);restored.Tick(.05f);Assert.AreEqual(JsonUtility.ToJson(sim.State),JsonUtility.ToJson(restored.State),"tick "+i);}
            Assert.AreEqual(1,sim.State.effectEvents.Count(x=>x.kind=="PULLED"));Assert.AreEqual(1,sim.State.damageEvents.Count(x=>x.incoming));
        }
        [TestCase(0)][TestCase(1)]
        public void GeneratedBossRoomsOfferTwoValidBlastRefugesAcrossTwelveSeeds(int theme)
        {
            for(uint seed=510;seed<522;seed++)
            {
                var sim=Fixture(BossAttack.Blasts);var layout=RiftGenerator.Generate(seed,"boss-plan-"+seed,1,HeroClass.Warrior,forcedTheme:theme);var map=new RiftNavigation(layout);sim.State.layout=layout;sim.State.position=layout.bossPoints[0];Boss(sim).position=layout.bossPoints[1];
                Assert.IsTrue(BossCombat.TryBlastPlan(sim.State,map,Boss(sim),sim.MovementSpeed(false),out var centers,out var refuges),"theme "+theme+" seed "+seed);Assert.AreEqual(2,refuges.Count);
                foreach(var refuge in refuges)
                {Assert.IsTrue(map.CanLand(refuge.position,.65f));Assert.IsTrue(map.Reachable(refuge.position));Assert.IsTrue(centers.All(p=>Vector2.Distance(p,refuge.position)>3.15f));for(int i=1;i<refuge.path.Count;i++)Assert.IsTrue(map.TravelClear(refuge.path[i-1],refuge.path[i]));}
            }
        }
        [Test]
        public void ExistingDangerCanDisqualifyAllOtherwiseWalkableBlastRefuges()
        {
            var sim=Fixture(BossAttack.Blasts);sim.State.enemyHazards.Add(new EnemyHazard{id=90,shape=AttackShape.Circle,position=sim.State.position,radius=30,delay=.5f,duration=4});
            Assert.IsFalse(BossCombat.TryBlastPlan(sim.State,sim.Map,Boss(sim),sim.MovementSpeed(false),out _,out _));
        }
    }
}
