using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace Hellscript.Tests
{
    public sealed class CurrentBuildSaveTests
    {
        string directory,path;
        GameCatalog catalog;
        GameStore store;
        static string Json(object value)=>JsonUtility.ToJson(value);
        [SetUp]public void Setup()
        {
            directory=Path.Combine(Path.GetTempPath(),"hellscript-current-build-"+Guid.NewGuid().ToString("N"));path=Path.Combine(directory,"hellscript-local-v1.json");
            catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();store=new GameStore(directory,catalog);
        }
        [TearDown]public void Teardown(){UnityEngine.Object.DestroyImmediate(catalog);if(Directory.Exists(directory))Directory.Delete(directory,true);}
        CombatSimulation Rift(int skill,int ticks=1)
        {
            store.Data.selectedHero=skill/6;var hero=store.Data.Hero;hero.level=30;var build=hero.build;
            build.passives=Array.Empty<int>();build.activeSkills.Clear();build.activeSkills.Add(skill);build.rules.Clear();build.rules.Add(new Rule(skill,ConditionKind.Always,0,skill==9));
            build.potionThreshold=0;build.movement=MovementMode.Stand;build.distance=2;
            // Deterministic legacy arena avoids unrelated map-generation behavior in the save test.
            var sim=new CombatSimulation(store.Data,catalog,1,1,seed:98342);sim.State.training=-1;sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();
            sim.State.enemies.Add(new EnemyState{id=900,position=sim.State.position+Vector2.up*(skill==0?2:6),health=100000,maxHealth=100000,attack=0,cooldown=1000,speed=0});
            for(int n=0;n<ticks;n++)sim.Tick(CombatSimulation.Step);
            sim.State.paused=true;store.Data.suspendedRun=sim.State;Assert.IsTrue(store.Save(),store.Error);return sim;
        }
        void FailNextWrite(){Directory.CreateDirectory(path+".tmp");LogAssert.Expect(LogType.Error,new Regex("저장하지 못했습니다:"));}
        [Test]public void TownSaveFailureRetainsAccountGuideDraftDiskAndIdentitiesThenRetryPersists()
        {
            var account=store.Data;var hero=account.Hero;var originalBuild=hero.build;var guide=hero.guide;
            var draft=hero.build.Copy();draft.distance=5.5f;draft.version="new";
            string before=Json(account),source=Json(draft),disk=File.ReadAllText(path);FailNextWrite();
            Assert.IsFalse(store.CommitCurrentBuild(draft,catalog));Assert.AreSame(account,store.Data);Assert.AreSame(hero,store.Data.Hero);Assert.AreSame(originalBuild,hero.build);Assert.AreSame(guide,hero.guide);
            Assert.AreEqual(before,Json(account));Assert.AreEqual(source,Json(draft));Assert.AreEqual(disk,File.ReadAllText(path));
            Directory.Delete(path+".tmp");Assert.IsTrue(store.CommitCurrentBuild(draft,catalog),store.Error);
            Assert.AreEqual(5.5f,hero.build.distance);Assert.IsNotEmpty(hero.guide.changeSummary);Assert.AreEqual(source,Json(draft));
            var reopened=new GameStore(directory,catalog);Assert.AreEqual(Json(hero.build),Json(reopened.Data.Hero.build));Assert.AreEqual(Json(hero.guide),Json(reopened.Data.Hero.guide));
            draft.rules.Clear();Assert.IsNotEmpty(hero.build.rules);
        }
        [TestCase(0,1)][TestCase(1,5)][TestCase(12,1)][TestCase(12,15)]
        public void RiftFailurePreservesInFlightStateThenDiskMatchesTheExactSuccessfulTransition(int skill,int ticks)
        {
            var sim=Rift(skill,ticks);var account=store.Data;var hero=store.Data.Hero;var run=sim.State;var action=run.heroAction;var map=sim.Map;var enemy=run.enemies[0];var stats=sim.Stats;
            var draft=run.build.Copy();draft.distance=5.5f;draft.version="changed";
            string before=Json(account),state=Json(run),source=Json(draft),disk=File.ReadAllText(path);FailNextWrite();
            Assert.IsFalse(store.CommitCurrentBuild(draft,catalog,sim));
            Assert.AreEqual(before,Json(account));Assert.AreEqual(state,Json(run));Assert.AreEqual(source,Json(draft));Assert.AreEqual(disk,File.ReadAllText(path));
            Assert.AreSame(account,store.Data);Assert.AreSame(hero,sim.Hero);Assert.AreSame(run,store.Data.suspendedRun);Assert.AreSame(action,run.heroAction);Assert.AreSame(enemy,run.enemies[0]);Assert.AreSame(map,sim.Map);Assert.AreSame(stats,sim.Stats);
            Directory.Delete(path+".tmp");Assert.IsTrue(store.CommitCurrentBuild(draft,catalog,sim),store.Error);
            Assert.AreSame(action,run.heroAction);
            if(action.phase==HeroActionPhase.Channeling)Assert.IsTrue(action.exitChannelForBuild);
            else Assert.AreEqual(Json(JsonUtility.FromJson<RunState>(state).heroAction),Json(action));
            var onDisk=JsonUtility.FromJson<AccountSave>(File.ReadAllText(path));
            Assert.AreEqual(Json(run),Json(onDisk.suspendedRun));Assert.AreEqual(Json(hero.build),Json(onDisk.Hero.build));Assert.AreEqual(Json(hero.guide),Json(onDisk.Hero.guide));
            Assert.AreSame(run,store.Data.suspendedRun);Assert.AreSame(enemy,run.enemies[0]);Assert.AreSame(map,sim.Map);Assert.AreSame(stats,sim.Stats);Assert.AreEqual(source,Json(draft));
        }
        [TestCase(false)][TestCase(true)]public void UnchangedSettingsPreserveTheActionAndRestoreTheRequestedPauseState(bool paused)
        {
            var sim=Rift(1,5);var action=sim.State.heroAction;var expected=JsonUtility.FromJson<RunState>(Json(sim.State));string beforeAction=Json(action),effects=Json(sim.State.itemEffects);
            var draft=sim.State.build.Copy();draft.version="save-time-metadata";
            expected.build.version=draft.version;expected.paused=paused;
            Assert.IsTrue(store.CommitCurrentBuild(draft,catalog,sim,paused),store.Error);
            Assert.AreSame(action,sim.State.heroAction);Assert.AreEqual(beforeAction,Json(action));Assert.AreEqual(Json(expected),Json(sim.State));Assert.AreEqual(effects,Json(sim.State.itemEffects));Assert.AreEqual(paused,sim.State.paused);
            Assert.AreEqual(Json(sim.State),Json(JsonUtility.FromJson<AccountSave>(File.ReadAllText(path)).suspendedRun));
        }
        [TestCase(0)][TestCase(1)][TestCase(2)][TestCase(3)][TestCase(4)]public void InvalidDraftDoesNotChangeTheRunOrWriteARejectionLogIntoIt(int field)
        {
            var sim=Rift(12);string before=Json(store.Data),disk=File.ReadAllText(path);var draft=sim.State.build.Copy();
            if(field==0)draft.distance=float.NaN;else if(field==1)draft.potionThreshold=float.PositiveInfinity;else if(field==2)draft.rules[0].distance=float.NegativeInfinity;
            else if(field==3)draft.chestDetour=float.NaN;else{draft.rules[0].always=false;draft.rules[0].groups.Add(new ConditionGroup{conditions={new RuleCondition{id="SC09",comparison=Comparison.Between,value=1,upper=float.NaN}}});}
            Assert.IsFalse(store.CommitCurrentBuild(draft,catalog,sim));Assert.IsNotEmpty(BehaviorRules.InputValueIssue(draft));Assert.AreEqual(before,Json(store.Data));Assert.AreEqual(disk,File.ReadAllText(path));Assert.IsFalse(BuildEditing.SettingsEqual(draft,sim.State.build));
        }
        [Test]public void ForeignRunPortalAndUnopenedSuspendedRunCannotOverwriteCurrentSettings()
        {
            var sim=Rift(12);var foreign=new CombatSimulation(JsonUtility.FromJson<AccountSave>(Json(store.Data)),catalog,1,restore:JsonUtility.FromJson<RunState>(Json(sim.State)));
            var draft=sim.State.build.Copy();draft.distance=5.5f;string before=Json(store.Data),disk=File.ReadAllText(path);
            Assert.IsFalse(store.CommitCurrentBuild(draft,catalog,foreign));Assert.IsFalse(store.CommitCurrentBuild(draft,catalog));Assert.AreEqual(before,Json(store.Data));Assert.AreEqual(disk,File.ReadAllText(path));
            sim.State.portal=true;before=Json(store.Data);Assert.IsFalse(store.CommitCurrentBuild(draft,catalog,sim));Assert.AreEqual(before,Json(store.Data));Assert.AreEqual(disk,File.ReadAllText(path));
        }
        [Test]public void SettingsComparisonIgnoresPresentationMetadataButIncludesFarmingAndBehaviorValues()
        {
            var a=store.Data.Hero.build;var b=a.Copy();b.version="now";b.name="슬롯 이름";foreach(var r in b.rules)r.id=Guid.NewGuid().ToString("N");Assert.IsTrue(BuildEditing.SettingsEqual(a,b));
            b.autoRepeat=!a.autoRepeat;Assert.IsFalse(BuildEditing.SettingsEqual(a,b));b.autoRepeat=a.autoRepeat;b.distance+=.5f;Assert.IsFalse(BuildEditing.SettingsEqual(a,b));
            b.distance=a.distance;b.rules.Reverse();Assert.IsFalse(BuildEditing.SettingsEqual(a,b));
        }
    }
}
