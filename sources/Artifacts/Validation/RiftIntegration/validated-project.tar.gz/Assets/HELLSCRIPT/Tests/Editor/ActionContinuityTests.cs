using System;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class ActionContinuityTests
    {
        GameCatalog catalog;
        static string Json(object value)=>JsonUtility.ToJson(value);
        [SetUp]public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown]public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        CombatSimulation Fixture(int skill,HeroClass basicClass=HeroClass.Warrior)
        {
            var account=GameStore.NewAccount();account.selectedHero=skill<0?(int)basicClass:skill/6;account.Hero.level=30;
            var build=account.Hero.build;build.version="cast-source";build.passives=Array.Empty<int>();build.activeSkills.Clear();build.rules.Clear();
            if(skill>=0){build.activeSkills.Add(skill);build.rules.Add(new Rule(skill,ConditionKind.Always,0,skill==9));}
            else build.rules.Add(BehaviorRules.Utility(RuleAction.Basic));
            build.potionThreshold=0;build.movement=MovementMode.Stand;build.distance=2;
            var sim=new CombatSimulation(account,catalog,1,1,seed:81921);sim.State.training=-1;sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();
            sim.Stats.regen=0;sim.Stats.crit=0;
            float distance=skill==0||skill==2||skill==3||skill==9||skill==17||skill<0&&basicClass==HeroClass.Warrior?2:6;
            sim.State.enemies.Add(new EnemyState{id=900,position=sim.State.position+Vector2.up*distance,health=1000000,maxHealth=1000000,speed=0,cooldown=1000,attack=0});
            return sim;
        }
        CombatSimulation Restore(CombatSimulation source)
        {
            var account=GameStore.NewAccount();account.selectedHero=(int)source.Hero.heroClass;
            account.heroes[account.selectedHero]=JsonUtility.FromJson<HeroSave>(Json(source.Hero));
            var sim=new CombatSimulation(account,catalog,1,restore:JsonUtility.FromJson<RunState>(Json(source.State)));sim.Stats.regen=0;sim.Stats.crit=0;return sim;
        }
        static void Advance(CombatSimulation sim,int ticks){for(int i=0;i<ticks;i++)sim.Tick(CombatSimulation.Step);}
        static BuildConfig Changed(CombatSimulation sim)
        {
            var draft=sim.State.build.Copy();draft.version="new-policy";draft.distance=7;draft.movement=MovementMode.Retreat;draft.clockwise=!draft.clockwise;
            foreach(var r in draft.rules)r.enabled=false;return draft;
        }
        [TestCase(1)][TestCase(2)][TestCase(3)][TestCase(4)][TestCase(5)][TestCase(6)][TestCase(7)][TestCase(8)][TestCase(9)]
        [TestCase(10)][TestCase(11)][TestCase(12)][TestCase(13)][TestCase(14)][TestCase(15)][TestCase(16)][TestCase(17)]
        [TestCase(-1,HeroClass.Warrior)][TestCase(-1,HeroClass.Ranger)][TestCase(-1,HeroClass.Mage)]
        public void ChangedBuildKeepsStartedActionAndReplaysOneOriginalRelease(int skill,HeroClass basicClass=HeroClass.Warrior)
        {
            var sim=Fixture(skill,basicClass);sim.Tick(.05f);var action=sim.State.heroAction;
            Assert.AreEqual(skill,action.skill);Assert.IsFalse(action.released);string original=Json(action);
            float hp=sim.State.health,resource=sim.State.resource;var cooldowns=(float[])sim.State.cooldowns.Clone();
            var draft=Changed(sim);Assert.IsTrue(sim.ApplyBuild(draft));
            Assert.AreSame(action,sim.State.heroAction);Assert.AreEqual(original,Json(action));Assert.AreEqual(hp,sim.State.health);Assert.AreEqual(resource,sim.State.resource);CollectionAssert.AreEqual(cooldowns,sim.State.cooldowns);
            var restored=Restore(sim);Assert.AreEqual(Json(sim.State),Json(restored.State));
            for(int n=0;n<45;n++){Advance(sim,1);Advance(restored,1);Assert.AreEqual(Json(sim.State),Json(restored.State),"replay "+n);}
            var events=sim.State.actionEvents.Where(e=>e.actionId==action.id).ToArray();
            Assert.AreEqual(1,events.Count(e=>e.kind=="ACTION_START"));Assert.AreEqual(1,events.Count(e=>e.kind=="ACTION_RELEASE"));Assert.AreEqual(1,events.Count(e=>e.kind=="ACTION_END"));Assert.IsFalse(events.Any(e=>e.kind=="ACTION_INTERRUPTED"));
            Assert.IsTrue(events.All(e=>e.buildVersion=="cast-source"));Assert.IsFalse(sim.HeroActionBusy);
        }
        [TestCase(1,5)][TestCase(9,4)][TestCase(-1,10)]
        public void EditsDuringTravelAndRecoveryDoNotRestartTimersOrDoubleRelease(int skill,int ticks)
        {
            var sim=Fixture(skill);Advance(sim,ticks);var action=sim.State.heroAction;
            Assert.That(action.phase,Is.EqualTo(HeroActionPhase.Travelling).Or.EqualTo(HeroActionPhase.Recovering));string before=Json(action);
            Assert.IsTrue(sim.ApplyBuild(Changed(sim)));Assert.AreEqual(before,Json(action));var restored=Restore(sim);
            for(int n=0;n<40;n++){Advance(sim,1);Advance(restored,1);Assert.AreEqual(Json(sim.State),Json(restored.State));}
            Assert.AreEqual(1,sim.State.actionEvents.Count(e=>e.actionId==action.id&&e.kind=="ACTION_RELEASE"));
        }
        [TestCase(0,0)][TestCase(1,0)][TestCase(2,0)][TestCase(3,0)][TestCase(4,0)]
        [TestCase(0,2)][TestCase(1,2)][TestCase(2,2)][TestCase(3,2)][TestCase(4,2)]
        public void ChangedChannelStopsAtTheNextExistingBoundaryWithoutExtraCostOrDamage(int offset,int paidTicks)
        {
            var sim=Fixture(0);Advance(sim,1+paidTicks*5+offset);var action=sim.State.heroAction;
            float tick=sim.State.channelTick,time=sim.State.channelTime,paid=action.cost,resource=sim.State.resource,dealt=sim.State.dealt;
            Assert.IsTrue(sim.ApplyBuild(Changed(sim)));Assert.AreSame(action,sim.State.heroAction);Assert.IsTrue(action.exitChannelForBuild);
            Assert.AreEqual(tick,sim.State.channelTick);Assert.AreEqual(time,sim.State.channelTime);Assert.AreEqual(paid,action.cost);
            var restored=Restore(sim);int remaining=5-offset;
            for(int n=0;n<remaining;n++)
            {
                // Even a different saved version every simulation tick must not extend the exit.
                var edit=Changed(sim);edit.distance=n%2==0?5:6;edit.version="repeat-"+n;
                Assert.IsTrue(sim.ApplyBuild(edit));Assert.IsTrue(restored.ApplyBuild(edit));
                Assert.IsTrue(sim.HeroActionBusy);Advance(sim,1);Advance(restored,1);Assert.AreEqual(Json(sim.State),Json(restored.State));
            }
            Assert.IsFalse(sim.HeroActionBusy);Assert.AreEqual(resource,sim.State.resource);Assert.AreEqual(dealt,sim.State.dealt);Assert.AreEqual(paid,action.cost);
            Assert.AreEqual(0,sim.State.channelTick);Assert.AreEqual(0,sim.State.channelTime);
            Assert.AreEqual(1,sim.State.actionEvents.Count(e=>e.actionId==action.id&&e.kind=="ACTION_END"&&e.buildVersion=="cast-source"));
            Assert.IsFalse(sim.State.actionEvents.Any(e=>e.actionId==action.id&&e.kind=="ACTION_INTERRUPTED"));
        }
        [Test]
        public void PendingChannelUsesOriginalMovementAndTargetPolicyEvenAfterRowReplacement()
        {
            var sim=Fixture(0);sim.State.build.rules[0].overrideMovement=true;sim.State.build.rules[0].movement=MovementMode.Orbit;sim.State.build.rules[0].distance=2;
            sim.Tick(.05f);var control=Restore(sim);var old=sim.State.heroAction.policy;
            var elite=new EnemyState{id=901,position=sim.State.position+Vector2.right*2.8f,elite=0,health=1000000,maxHealth=1000000,speed=0,cooldown=1000};
            sim.State.enemies.Add(elite);control.State.enemies.Add(JsonUtility.FromJson<EnemyState>(Json(elite)));
            var edit=Changed(sim);edit.target=TargetMode.Elite;edit.rules.Clear();edit.rules.Add(BehaviorRules.Utility(RuleAction.Explore));Assert.IsTrue(sim.ApplyBuild(edit));
            sim.State.decisionTime=control.State.decisionTime=0;
            for(int n=0;n<4;n++){Advance(sim,1);Advance(control,1);Assert.AreEqual(control.State.position,sim.State.position);Assert.AreEqual(control.State.targetId,sim.State.targetId);Assert.AreSame(old,sim.State.heroAction.policy);}
            Advance(sim,1);Assert.IsFalse(sim.HeroActionBusy);
        }
        [Test]
        public void SurvivalPriorityFollowsRuleIdentityWhenItsRowMoves()
        {
            var sim=Fixture(2);sim.State.build.activeSkills.Add(4);sim.State.build.rules.Insert(0,new Rule(4,ConditionKind.HealthBelow,30));
            sim.Tick(.05f);Assert.AreEqual(2,sim.State.heroAction.skill);int action=sim.State.heroAction.id;
            var edit=sim.State.build.Copy();var basic=BehaviorRules.Utility(RuleAction.Basic);basic.enabled=false;edit.rules.Insert(0,basic);Assert.IsTrue(sim.ApplyBuild(edit));
            sim.State.health=sim.Stats.hp*.2f;sim.State.decisionTime=0;Advance(sim,1);
            Assert.AreEqual(4,sim.State.heroAction.skill);Assert.IsTrue(sim.State.actionEvents.Any(e=>e.actionId==action&&e.kind=="ACTION_INTERRUPTED"));
        }
        [Test]
        public void ReusedRuleIdForAnotherSkillCannotBecomeTheOldActionsPriorityAnchor()
        {
            var sim=Fixture(2);sim.State.build.activeSkills.AddRange(new[]{4,5});sim.State.build.rules.Insert(0,new Rule(4,ConditionKind.HealthBelow,30));
            sim.Tick(.05f);var action=sim.State.heroAction;var edit=sim.State.build.Copy();edit.rules[1]=new Rule(5){id=action.policy.rule.id};
            Assert.IsTrue(sim.ApplyBuild(edit));sim.State.health=sim.Stats.hp*.2f;sim.State.decisionTime=0;Advance(sim,1);Assert.AreSame(action,sim.State.heroAction);
            Advance(sim,20);Assert.AreEqual(1,sim.State.actionEvents.Count(e=>e.actionId==action.id&&e.kind=="ACTION_RELEASE"));
        }
        [TestCase(0)][TestCase(1)][TestCase(12)]
        public void VersionThreeActionMigrationPreservesTimingCostAndReleaseState(int skill)
        {
            var sim=Fixture(skill);Advance(sim,2);var action=sim.State.heroAction;action.policy=null;sim.State.combatVersion=3;
            var phase=action.phase;float elapsed=action.elapsed,resource=sim.State.resource;int eventCount=sim.State.actionEvents.Count;
            GameStore.NormalizeRun(sim.State);Assert.AreEqual(CombatActions.Version,sim.State.combatVersion);Assert.AreSame(action,sim.State.heroAction);Assert.AreEqual(phase,action.phase);Assert.AreEqual(elapsed,action.elapsed);
            Assert.AreEqual(resource,sim.State.resource);Assert.AreEqual(eventCount,sim.State.actionEvents.Count);Assert.AreEqual("cast-source",action.policy.buildVersion);
            string once=Json(sim.State);GameStore.NormalizeRun(sim.State);Assert.AreEqual(once,Json(sim.State));
            Assert.IsTrue(sim.ApplyBuild(Changed(sim)));var restored=Restore(sim);
            for(int n=0;n<30;n++){Advance(sim,1);Advance(restored,1);Assert.AreEqual(Json(sim.State),Json(restored.State));}
        }
    }
}
