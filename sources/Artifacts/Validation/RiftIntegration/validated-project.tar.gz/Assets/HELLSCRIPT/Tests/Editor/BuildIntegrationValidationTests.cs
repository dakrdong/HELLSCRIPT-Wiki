using System.Linq;
using NUnit.Framework;
using Hellscript.Editor;

namespace Hellscript.Tests
{
    public sealed class BuildIntegrationValidationTests
    {
        [Test]
        public void ArchetypeBalanceSimulationRunnerRunsAcrossAll6ArchetypesWithoutExceptions()
        {
            // Run a targeted simulation (2 seeds per archetype) to verify deterministic stability and zero runtime exceptions
            var summaries = BuildIntegrationValidation.RunMultiSeedBalanceSimulation(seedCount: 2, stage: 1);
            Assert.AreEqual(6, summaries.Count, "Should produce summaries for all 6 core archetype builds");
            foreach (var s in summaries)
            {
                Assert.AreEqual(2, s.totalRuns);
                Assert.IsTrue(s.wins + s.defeats == 2);
                Assert.IsFalse(s.deathCauses.ContainsKey("NavError"), $"Archetype {s.archetypeName} encountered navigation errors");
            }
        }
    }
}
