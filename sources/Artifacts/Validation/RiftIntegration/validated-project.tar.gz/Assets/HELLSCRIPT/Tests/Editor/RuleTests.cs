using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using UnityEngine;
using static Hellscript.BehaviorRules;

namespace Hellscript.Tests
{
    public sealed class RuleTests
    {
        GameCatalog catalog;
        [SetUp]public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown]public void Teardown(){UnityEngine.Object.DestroyImmediate(catalog);}
        CombatSimulation Fixture(HeroClass hero=HeroClass.Mage)
        {
            var account=GameStore.NewAccount();account.selectedHero=(int)hero;account.Hero.level=30;
            account.Hero.build=GameCatalog.Preset(hero,0);account.Hero.build.passives=Array.Empty<int>();account.Hero.build.potionThreshold=0;
            account.Hero.build.movement=MovementMode.Stand;account.Hero.build.rules.Clear();
            var sim=new CombatSimulation(account,catalog,1,1,seed:4211);sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();sim.Stats.regen=0;sim.Stats.crit=0;
            sim.State.enemies.Add(new EnemyState{id=900,kind=0,position=sim.State.position+Vector2.up*2,health=200,maxHealth=1000,elite=0,speed=0,attack=0,cooldown=1000,windup=1,aim=sim.State.position,poison=2});
            sim.State.enemies.Add(new EnemyState{id=901,position=sim.State.position+Vector2.right*2,health=1000,maxHealth=1000,speed=0,attack=0,cooldown=1000});
            return sim;
        }
        static IEnumerable<int> ConditionIds=>Enumerable.Range(1,22);
        [TestCaseSource(nameof(ConditionIds))]
        public void EveryCatalogConditionReadsItsSpecifiedCombatFact(int number)
        {
            var sim=Fixture(number==16?HeroClass.Warrior:HeroClass.Mage);var s=sim.State;var target=s.enemies[0];
            s.time=10;s.health=sim.Stats.hp*.2f;s.resource=30;s.shield=0;s.shoutTime=3;s.noEnemySince=8;
            s.receivedDamage.Add(new DamageReceived{time=9,hp=sim.Stats.hp*.35f,absorbed=sim.Stats.hp*.5f});s.lastSkillStarts[12]=9;
            var condition=All[number-1].Create();var rule=Make(number==16?0:12);
            switch(number)
            {
                case 4:condition.choice=1;break;
                case 8:s.effects.Add(new GroundEffect{id=4,hostile=true,position=s.position,radius=2,duration=2,damage=1});break;
                case 12:condition.choice=1;break;
                case 15:condition.skill=12;break;
                case 16:s.heroAction.phase=HeroActionPhase.Channeling;s.activeSkill=0;s.channelTime=2;break;
                case 17:foreach(var e in s.enemies)e.dead=true;break;
                case 18:s.drops.Add(new DropState{id=99,position=s.position+Vector2.left,discovered=true,item=new Item{id="loot",rarity=3}});break;
                case 19:sim.Hero.capacity=0;break;
                case 21:condition.value=300;break;
                case 22:condition.skill=12;break;
            }
            Assert.IsEmpty(ValidateCondition(condition));Assert.IsTrue(sim.EvaluateCondition(condition,rule,target,out var actual),actual);
        }
        [Test]
        public void OrGroupsAndAndRowsControlRealExecutionWithoutImplicitBossExceptions()
        {
            var sim=Fixture(HeroClass.Warrior);sim.State.health=sim.Stats.hp*.8f;
            sim.State.enemies[0].position=sim.State.position+Vector2.up*6;sim.State.enemies[0].boss=true;sim.State.enemies[1].dead=true;
            var leap=Make(1,C("SC01",Comparison.AtMost,30));leap.groups.Add(new ConditionGroup{conditions={C("SC09",Comparison.AtLeast,5),C("SC06",Comparison.AtLeast,3,predicted:true),C("SC01",Comparison.AtLeast,70)}});
            sim.State.build.rules.Add(leap);sim.Tick(.05f);Assert.IsFalse(sim.HeroActionBusy,"One boss must not satisfy a three-enemy condition.");
            for(int i=0;i<2;i++)sim.State.enemies.Add(new EnemyState{id=910+i,position=sim.State.enemies[0].position+Vector2.right*(i+.5f),health=1000,maxHealth=1000,speed=0,attack=0,cooldown=1000});
            sim.State.decisionTime=0;sim.Tick(.05f);Assert.AreEqual(1,sim.State.heroAction.skill);Assert.AreEqual(HeroActionPhase.Preparing,sim.State.heroAction.phase);
        }
        [Test]
        public void RuleTargetIsChosenBeforeItsTargetCondition()
        {
            var sim=Fixture(HeroClass.Ranger);sim.State.enemies[0].health=1000;sim.State.enemies[0].windup=0;
            var support=sim.State.enemies[1];support.kind=4;support.health=100;support.position=sim.State.position+Vector2.up*7;
            var rule=Make(10,C("SC10",Comparison.AtMost,30));rule.target=RuleTarget.Support;sim.State.build.rules.Add(rule);
            sim.Tick(.05f);Assert.AreEqual(10,sim.State.heroAction.skill);Assert.AreEqual(support.id,sim.State.heroAction.targetId);
            Assert.That(sim.State.decisions.Last().detail,Does.Contain("현재 10"));
        }
        [Test]
        public void HiddenEnemiesAndDistantWarningsDoNotSatisfyPerceptionConditions()
        {
            var sim=Fixture();sim.State.layout.legacy=false;sim.State.enemies[0].position=sim.State.position+Vector2.up*6;sim.State.enemies[1].dead=true;
            sim.State.layout.obstacles.Add(new RiftObstacle{id="vision",position=sim.State.position+Vector2.up*3,halfSize=new Vector2(3,.1f),blocksSight=true,blocksProjectile=true,blocksWalk=false});
            var c=C("SC07",Comparison.Present);Assert.IsFalse(sim.EvaluateCondition(c,Make(12),sim.State.enemies[0],out _));
            Assert.IsFalse(sim.EvaluateCondition(C("SC06",Comparison.AtLeast,1,radius:8),Make(12),sim.State.enemies[0],out _));
            Assert.IsFalse(sim.EvaluateCondition(C("SC08",Comparison.Soon,1.5f),Make(12),sim.State.enemies[0],out _));
            Assert.IsFalse(sim.EvaluateCondition(C("SC14",Comparison.Present,1),Make(12),sim.State.enemies[0],out _));
        }
        [Test]
        public void RecentDamageUsesLostHpSeparatelyFromAbsorptionAndPreservesWindowBoundaries()
        {
            var sim=Fixture();sim.State.build.rules.Clear();sim.State.shield=sim.Stats.hp;sim.State.shieldTime=10;sim.State.health=sim.Stats.hp;
            sim.State.shields.Add(new ShieldEffect{id=9000,definitionId="W05",amount=sim.Stats.hp,remaining=10,createdMaxHp=sim.Stats.hp});
            sim.State.effects.Add(new GroundEffect{id=3,hostile=true,position=sim.State.position,radius=2,duration=.1f,damage=100});sim.Tick(.05f);
            Assert.Greater(sim.State.receivedDamage.Sum(d=>d.absorbed),0);Assert.AreEqual(0,sim.State.receivedDamage.Sum(d=>d.hp));
            var c=C("SC05",Comparison.AtLeast,5);c.window=1;Assert.IsFalse(sim.EvaluateCondition(c,Make(12),sim.State.enemies[0],out _));
            sim.State.time=10;sim.State.receivedDamage.Clear();sim.State.receivedDamage.Add(new DamageReceived{time=9,hp=sim.Stats.hp*.1f});
            Assert.IsTrue(sim.EvaluateCondition(c,Make(12),null,out _));sim.State.time=10.05f;Assert.IsFalse(sim.EvaluateCondition(c,Make(12),null,out _));
            var saved=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(sim.State));Assert.AreEqual(JsonUtility.ToJson(sim.State.receivedDamage[0]),JsonUtility.ToJson(saved.receivedDamage[0]));
        }
        [Test]
        public void NullTargetsDoNotPassAbsentTargetStatesAndBossPresenceDiffersFromEngagement()
        {
            var sim=Fixture();Assert.IsFalse(sim.EvaluateCondition(C("SC13",Comparison.Absent),Make(12),null,out _));
            sim.State.phase=RunPhase.Boss;sim.State.bossId=999;sim.State.enemies.Add(new EnemyState{id=999,boss=true,position=RiftMap.Rooms[4],health=100,maxHealth=100});
            Assert.IsFalse(sim.EvaluateCondition(C("SC20",Comparison.Equal,0,1),Make(12),null,out _));
            Assert.IsFalse(sim.EvaluateCondition(C("SC20",Comparison.Equal,0,0),Make(12),null,out _));
            sim.State.bossRewarded=true;Assert.IsTrue(sim.EvaluateCondition(C("SC20",Comparison.Equal,0,2),Make(12),null,out _));
        }
        [Test]
        public void SkillHistoryUsesStartEvenWhenTheActionIsInterrupted()
        {
            var sim=Fixture();sim.State.build.rules.Add(Make(12));sim.Tick(.05f);float started=sim.State.lastSkillStarts[12];
            var edit=sim.State.build.Copy();edit.distance=5;Assert.IsTrue(sim.ApplyBuild(edit));
            Assert.IsTrue(sim.EvaluateCondition(C("SC22",Comparison.Present,.5f,skill:12),Make(12),null,out _));
            Assert.AreEqual(started,sim.State.lastSkillStarts[12]);Assert.Less(sim.State.lastSkillCompletions[12],0);
            sim.State.time=started+.55f;Assert.IsFalse(sim.EvaluateCondition(C("SC22",Comparison.Present,.5f,skill:12),Make(12),null,out _));
        }
        [Test]
        public void UtilityRulePriorityCanChooseLootBeforeAttackAndDisabledRulesDoNotMove()
        {
            var sim=Fixture();sim.State.drops.Add(new DropState{id=22,position=sim.State.position+Vector2.left*3,discovered=true,item=new Item{id="wanted",rarity=3}});
            sim.State.build.rules.Add(Utility(RuleAction.Loot));sim.State.build.rules.Add(Make(12));Vector2 before=sim.State.position;sim.Tick(.05f);
            Assert.AreEqual(RuleAction.Loot,sim.State.movementAction);Assert.IsFalse(sim.HeroActionBusy);Assert.AreEqual(100,sim.State.resource);Assert.Less(sim.State.position.x,before.x);
            Assert.IsTrue(sim.State.decisions.Any(d=>d.code=="PRIORITY"&&d.skill==12));
            foreach(var r in sim.State.build.rules)r.enabled=false;sim.State.decisionTime=0;before=sim.State.position;sim.Tick(.05f);Assert.AreEqual(before,sim.State.position);
        }
        [Test]
        public void SixPresetsUseTheSameValidLanguageAndIndependentLoadout()
        {
            Assert.AreEqual(22,All.Select(d=>d.id).Distinct().Count());
            foreach(HeroClass hero in Enum.GetValues(typeof(HeroClass)))for(int variant=0;variant<2;variant++)
            {
                var build=GameCatalog.Preset(hero,variant);Assert.IsEmpty(Validate(build,hero),build.name);Assert.AreEqual(4,build.activeSkills.Count);Assert.AreEqual(3,build.passives.Length);
                Assert.IsTrue(build.rules.Any(r=>r.action==RuleAction.Explore));Assert.IsTrue(build.rules.Any(r=>r.action==RuleAction.Basic));
                var restored=JsonUtility.FromJson<BuildConfig>(JsonUtility.ToJson(build));Normalize(restored);Assert.AreEqual(JsonUtility.ToJson(build),JsonUtility.ToJson(restored));
            }
        }
        [Test]
        public void FrostPresetChainsBlizzardAndFireAgainstOneVisibleBoss()
        {
            var account=GameStore.NewAccount();account.selectedHero=2;account.Hero.level=30;account.Hero.build=GameCatalog.Preset(HeroClass.Mage,0);
            var sim=new CombatSimulation(account,catalog,1,1,seed:91367);sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();
            sim.State.enemies.Add(new EnemyState{id=900,boss=true,health=10000,maxHealth=10000,position=sim.State.position+Vector2.up*7,cooldown=1000});
            sim.Tick(CombatSimulation.Step);Assert.AreEqual(13,sim.State.heroAction.skill);
            for(int n=0;n<60;n++)sim.Tick(CombatSimulation.Step);
            Assert.IsTrue(sim.State.damageEvents.Any(d=>d.targetId==900&&d.definitionId=="M02"&&d.hpLoss>0));
            Assert.IsTrue(sim.State.damageEvents.Any(d=>d.targetId==900&&d.definitionId=="M01"&&d.hpLoss>0),"Fireball still needs an actual own blizzard to hit.");
        }
        [TestCase(false)]
        [TestCase(true)]
        public void FrostPresetDoesNotCastBossBlizzardAtOneOrdinaryEnemy(bool hiddenBoss)
        {
            var account=GameStore.NewAccount();account.selectedHero=2;account.Hero.level=30;account.Hero.build=GameCatalog.Preset(HeroClass.Mage,0);
            var sim=new CombatSimulation(account,catalog,1,1,seed:91367);sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();
            sim.State.enemies.Add(new EnemyState{id=900,health=10000,maxHealth=10000,position=sim.State.position+Vector2.up*7,cooldown=1000});
            if(hiddenBoss)sim.State.enemies.Add(new EnemyState{id=901,boss=true,health=10000,maxHealth=10000,position=RiftMap.Rooms[4],cooldown=1000});
            for(int n=0;n<60;n++)sim.Tick(CombatSimulation.Step);
            Assert.IsFalse(sim.State.actionEvents.Any(e=>e.kind=="ACTION_START"&&e.skill==13));
            Assert.IsTrue(sim.State.actionEvents.Any(e=>e.kind=="ACTION_START"&&e.skill<0));
        }
        [Test]
        public void ReloadPreservesSavedFrostConditionsInsteadOfReplacingThemWithNewRecommendation()
        {
            var account=GameStore.NewAccount();account.selectedHero=2;account.Hero.level=30;account.Hero.build=GameCatalog.Preset(HeroClass.Mage,0);
            var rule=account.Hero.build.rules.Single(r=>r.skill==13);rule.groups.RemoveAt(1);rule.groups[0].conditions[0].value=4;
            var sim=new CombatSimulation(account,catalog,1,1,seed:91367);string original=JsonUtility.ToJson(sim.State.build);
            var saved=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(sim.State));var restored=new CombatSimulation(account,catalog,1,1,restore:saved);
            Assert.AreEqual(original,JsonUtility.ToJson(restored.State.build));Assert.AreEqual(1,restored.State.build.rules.Single(r=>r.skill==13).groups.Count);
            Assert.AreEqual(2,GameCatalog.Preset(HeroClass.Mage,0).rules.Single(r=>r.skill==13).groups.Count);
        }
        [Test]
        public void LimitsAndEmptyGroupsRejectApplicationWithoutChangingResourcesOrBuild()
        {
            var sim=Fixture();sim.State.build.rules.Add(Make(12));Normalize(sim.State.build);string original=JsonUtility.ToJson(sim.State.build);float hp=sim.State.health,resource=sim.State.resource;
            var bad=sim.State.build.Copy();bad.rules[0].always=false;Assert.IsFalse(sim.ApplyBuild(bad));Assert.AreEqual(original,JsonUtility.ToJson(sim.State.build));Assert.AreEqual(hp,sim.State.health);Assert.AreEqual(resource,sim.State.resource);
            bad=sim.State.build.Copy();for(int i=0;i<3;i++){var r=bad.rules[0].Copy();r.id="extra-"+i;bad.rules.Add(r);}Assert.IsTrue(Validate(bad,HeroClass.Mage).Any(e=>e.Contains("최대 3개")));
            bad=sim.State.build.Copy();bad.rules[0].always=false;bad.rules[0].groups.Add(new ConditionGroup{conditions={C("SC01",Comparison.AtMost,31)}});Assert.IsNotEmpty(Validate(bad,HeroClass.Mage));
            bad=sim.State.build.Copy();bad.activeSkills.Add(14);Assert.IsTrue(Validate(bad,HeroClass.Mage).Any(e=>e.Contains("최대 4개")));
        }
        [Test]
        public void LegacyBossExceptionBecomesVisibleAndMigrationIsIdempotent()
        {
            var old=new BuildConfig();old.rules.Add(new Rule(0,ConditionKind.EnemiesNear,3));Normalize(old);
            Assert.AreEqual(1,old.activeSkills.Count);Assert.AreEqual(5,old.rules.Count);Assert.AreEqual(2,old.rules[0].groups.Count);Assert.AreEqual("SC12",old.rules[0].groups[1].conditions[0].id);
            string migrated=JsonUtility.ToJson(old);Normalize(old);Assert.AreEqual(migrated,JsonUtility.ToJson(old));
            var clone=old.rules[0].Copy();clone.groups[0].conditions[0].value=9;Assert.AreEqual(3,old.rules[0].groups[0].conditions[0].value);
            old.ruleSchema=BehaviorRules.Version+1;Assert.Throws<NotSupportedException>(()=>Normalize(old));
        }
        [Test]
        public void TwentyFourRuleLimitCountsEnabledRowsAndRejectsEnablingTheTwentyFifth()
        {
            var build=GameCatalog.Preset(HeroClass.Warrior,0);build.rules.Clear();
            for(int i=0;i<25;i++)build.rules.Add(Utility(RuleAction.Explore));
            build.rules[24].enabled=false;Assert.IsEmpty(Validate(build,HeroClass.Warrior));
            build.rules[24].enabled=true;Assert.IsTrue(Validate(build,HeroClass.Warrior).Any(e=>e.Contains("활성 규칙은 최대 24개")));
        }
        [Test]
        public void RuleEvaluationUsesFiveDecisionsPerCombatSecondWithoutAnExtraFloatingPointTick()
        {
            var sim=Fixture();sim.State.build.rules.Add(Utility(RuleAction.Explore));
            for(int n=0;n<20;n++)sim.Tick(.05f);
            var records=sim.State.decisions;Assert.AreEqual(5,records.Sum(d=>d.count));Assert.AreEqual(.05f,records.Min(d=>d.firstTime),.00001);Assert.AreEqual(.85f,records.Max(d=>d.lastTime),.00001);
        }
        [TestCase(.2f,4,false,false,false,900)]
        [TestCase(.8f,7.5f,false,false,false,900)]
        [TestCase(.8f,4,false,false,false,901)]
        [TestCase(.2f,4,true,false,false,901)]
        [TestCase(.2f,4,false,true,false,901)]
        [TestCase(.2f,4,false,false,true,901)]
        public void TargetRetentionUsesTimeHysteresisRuleOwnershipAndSurvival(float age,float alternateDistance,bool differentRule,bool escape,bool dead,int expected)
        {
            var sim=Fixture(HeroClass.Warrior);var rule=Utility(RuleAction.Basic);rule.id="owner";rule.target=RuleTarget.Nearest;rule.escape=escape;
            sim.State.build.rules.Add(rule);sim.State.enemies[0].position=sim.State.position+Vector2.up*8;sim.State.enemies[0].dead=dead;
            sim.State.enemies[1].position=sim.State.position+Vector2.right*alternateDistance;
            sim.State.time=10;sim.State.targetId=900;sim.State.targetRuleId=differentRule?"another":"owner";sim.State.targetSelectedAt=10-age;
            sim.Tick(.05f);Assert.AreEqual(expected,sim.State.targetId);Assert.AreEqual("owner",sim.State.targetRuleId);
        }
        [Test]
        public void InvalidSkillCannotIndexTheCatalogWhileEvaluatingPredictedHits()
        {
            var sim=Fixture();sim.State.build.rules.Add(Make(999,C("SC06",Comparison.AtLeast,1,predicted:true)));
            Assert.DoesNotThrow(()=>sim.Tick(.05f));Assert.AreEqual("NOT_EQUIPPED",sim.State.decisions.Last().code);Assert.IsFalse(sim.HeroActionBusy);
        }
        [Test]
        public void InspectingALowerChestRuleDoesNotStartOrCancelTheChest()
        {
            var account=GameStore.NewAccount();account.Hero.level=30;var sim=new CombatSimulation(account,catalog,1,seed:4211);
            sim.State.enemies.Clear();sim.State.build.rules.Clear();sim.State.build.rules.Add(Make(4));sim.State.build.rules.Add(Utility(RuleAction.Chest));
            sim.State.build.openChests=true;sim.State.build.commonChests=true;sim.State.build.sealedChests=true;sim.State.build.useShrines=false;
            var chest=sim.State.layout.chests.First(c=>c.definitionId!="CH03");chest.discovered=true;chest.phase=ChestPhase.Available;sim.State.meter=70;sim.State.position=chest.openingPosition;
            string phase=chest.phase.ToString();sim.Tick(.05f);
            Assert.AreEqual(4,sim.State.heroAction.skill);Assert.AreEqual(phase,chest.phase.ToString());Assert.AreEqual(0,chest.retryAfter);Assert.AreEqual(0,chest.progress);
            Assert.IsTrue(sim.State.decisions.Any(d=>d.code=="PRIORITY"&&d.row==1));
        }
        [Test]
        public void LegacyRunDoesNotInventUnobservedNoEnemyHistory()
        {
            var run=new RunState{id="legacy-clock",time=123,build=new BuildConfig()};GameStore.NormalizeRun(run);
            Assert.AreEqual(123,run.noEnemySince);Assert.AreEqual(123,run.targetSelectedAt);run.time=124;GameStore.NormalizeRun(run);Assert.AreEqual(123,run.noEnemySince);
        }
        [Test]
        public void RuleDeletionCannotUnequipASkillAndPresetImportKeepsOmittedRulesOnlyWhenRequested()
        {
            var original=GameCatalog.Preset(HeroClass.Warrior,0);var request=original.Copy();request.rules.RemoveAll(r=>r.action==RuleAction.Skill&&r.skill==0);request.activeSkills.Clear();request.passives=new[]{5};
            var edited=BuildEditing.DuringRift(original,request);CollectionAssert.AreEqual(original.activeSkills,edited.activeSkills);CollectionAssert.AreEqual(original.passives,edited.passives);Assert.IsFalse(edited.rules.Any(r=>r.action==RuleAction.Skill&&r.skill==0));
            var loaded=BuildEditing.DuringRift(original,request,true);Assert.IsTrue(loaded.rules.Any(r=>r.action==RuleAction.Skill&&r.skill==0));Assert.IsEmpty(Validate(loaded,HeroClass.Warrior));
        }
        [TestCase(6)][TestCase(7)][TestCase(8)][TestCase(12)][TestCase(13)][TestCase(14)]
        public void PredictedAreaMatchesActualDistinctHitsAgainstStationaryEnemies(int skill)
        {
            var sim=Fixture((HeroClass)(skill/6));sim.State.build.activeSkills.Clear();sim.State.build.activeSkills.Add(skill);sim.State.build.rules.Add(Make(skill));
            sim.State.enemies[0].position=sim.State.position+Vector2.up*5;sim.State.enemies[1].position=sim.State.position+new Vector2(2.5f,4.33f);
            sim.State.enemies.Add(new EnemyState{id=902,position=sim.State.position+new Vector2(-2.5f,4.33f),cooldown=1000});
            foreach(var e in sim.State.enemies){e.health=e.maxHealth=1000;e.windup=0;e.poison=0;e.elite=-1;e.speed=0;e.attack=0;}
            var chosen=sim.State.enemies.OrderBy(e=>Vector2.Distance(sim.State.position,e.position)).ThenBy(e=>e.id).First();
            int expected=sim.PredictedHits(sim.State.build.rules[0],chosen);Assert.Greater(expected,0);sim.Tick(.05f);sim.State.decisionTime=100;
            for(int n=0;n<100;n++)sim.Tick(.05f);
            Assert.AreEqual(expected,sim.State.enemies.Count(e=>e.health<e.maxHealth),"skill "+skill);
        }
    }
}
