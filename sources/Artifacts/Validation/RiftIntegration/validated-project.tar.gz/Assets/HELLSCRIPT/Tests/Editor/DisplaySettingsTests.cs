using System;
using System.IO;
using NUnit.Framework;

namespace Hellscript.Tests
{
    public sealed class DisplaySettingsTests
    {
        string directory;
        DeviceDisplayStore store;
        [SetUp] public void Setup() { directory = Path.Combine(Path.GetTempPath(), "hellscript-display-test-" + Guid.NewGuid().ToString("N")); store = new DeviceDisplayStore(directory); }
        [TearDown] public void Teardown() { if (Directory.Exists(directory)) Directory.Delete(directory, true); }
        DisplaySettingsSession Session(bool mobile = true) => new DisplaySettingsSession(mobile, DeviceScreenDirection.Portrait, store.Read(), store.Write);
        [Test] public void MissingPreferenceStartsPortraitWithoutCreatingOrModifyingAccountFiles()
        { Assert.AreEqual(DeviceScreenDirection.Portrait, store.Read()); Assert.IsFalse(Directory.Exists(directory)); }
        [TestCase(DeviceScreenDirection.Portrait)] [TestCase(DeviceScreenDirection.Landscape)]
        public void ConfirmedDirectionSurvivesANewStoreAndLeavesAccountBytesAlone(DeviceScreenDirection direction)
        {
            Directory.CreateDirectory(directory); var account = Path.Combine(directory, "hellscript-local-v1.json"); File.WriteAllText(account, "unchanged account bytes");
            var session = Session(); var token = session.Request(direction); Assert.IsFalse(File.Exists(store.Path));
            Assert.IsTrue(session.Complete(token, direction, true)); Assert.AreEqual(direction, new DeviceDisplayStore(directory).Read()); Assert.AreEqual("unchanged account bytes", File.ReadAllText(account));
        }
        [TestCase("{}")] [TestCase("{\"version\":2,\"direction\":\"portrait\"}")]
        [TestCase("{\"version\":1,\"direction\":\"automatic\"}")] [TestCase("malformed")]
        public void InvalidPreferenceUsesDefaultWithoutOverwritingTheOriginal(string original)
        { Directory.CreateDirectory(directory); File.WriteAllText(store.Path, original); Assert.AreEqual(DeviceScreenDirection.Portrait, store.Read()); Assert.IsNotEmpty(store.Error); Assert.AreEqual(original, File.ReadAllText(store.Path)); }
        [Test] public void OversizedPreferenceIsPreserved()
        { Directory.CreateDirectory(directory); string original = new string('x', 1025); File.WriteAllText(store.Path, original); Assert.AreEqual(DeviceScreenDirection.Portrait, store.Read()); Assert.IsNotEmpty(store.Error); Assert.AreEqual(original, File.ReadAllText(store.Path)); }
        [Test] public void FailedPlatformApplyDoesNotSaveAnUnappliedPreference()
        {
            Assert.IsTrue(store.Write(DeviceScreenDirection.Portrait)); string before = File.ReadAllText(store.Path); var session = Session(); long id = session.Request(DeviceScreenDirection.Landscape);
            Assert.IsFalse(session.Complete(id, DeviceScreenDirection.Portrait, false)); Assert.AreEqual(before, File.ReadAllText(store.Path)); Assert.AreEqual(DeviceScreenDirection.Portrait, session.Actual); Assert.IsFalse(session.CanRetrySave);
        }
        [Test] public void AcknowledgementWithoutMatchingActualDisplayIsNotSuccess()
        { var session = Session(); Assert.IsFalse(session.Complete(session.Request(DeviceScreenDirection.Landscape), DeviceScreenDirection.Portrait, true)); Assert.IsFalse(File.Exists(store.Path)); }
        [Test] public void AnOldCompletionCannotChangeActualDirectionOrTheNewRequest()
        {
            var session = Session(); long old = session.Request(DeviceScreenDirection.Landscape), current = session.Request(DeviceScreenDirection.Portrait);
            Assert.IsFalse(session.Complete(old, DeviceScreenDirection.Landscape, true)); Assert.AreEqual(current, session.Pending); Assert.AreEqual(DeviceScreenDirection.Portrait, session.Actual); Assert.IsFalse(File.Exists(store.Path));
            Assert.IsTrue(session.Complete(current, DeviceScreenDirection.Portrait, true)); string saved = File.ReadAllText(store.Path);
            Assert.IsFalse(session.Complete(old, DeviceScreenDirection.Landscape, true)); Assert.AreEqual(saved, File.ReadAllText(store.Path));
        }
        [Test] public void DuplicateCompletionWritesExactlyOnce()
        {
            int writes = 0; var session = new DisplaySettingsSession(true, DeviceScreenDirection.Portrait, DeviceScreenDirection.Portrait, _ => { writes++; return true; });
            var token = session.Request(DeviceScreenDirection.Landscape); Assert.IsTrue(session.Complete(token, DeviceScreenDirection.Landscape, true)); Assert.IsFalse(session.Complete(token, DeviceScreenDirection.Landscape, true)); Assert.AreEqual(1, writes);
        }
        [Test] public void FailedAtomicWriteKeepsOldDiskAndActualDirectionThenRetriesWithoutAnotherApply()
        {
            Assert.IsTrue(store.Write(DeviceScreenDirection.Portrait)); string old = File.ReadAllText(store.Path); var session = Session(); Directory.CreateDirectory(store.Path + ".tmp");
            Assert.IsFalse(session.Complete(session.Request(DeviceScreenDirection.Landscape), DeviceScreenDirection.Landscape, true)); Assert.IsTrue(session.CanRetrySave);
            Assert.AreEqual(DeviceScreenDirection.Landscape, session.Actual); Assert.AreEqual(DeviceScreenDirection.Portrait, session.Saved); Assert.AreEqual(old, File.ReadAllText(store.Path));
            Directory.Delete(store.Path + ".tmp"); Assert.IsTrue(session.RetrySave()); Assert.AreEqual(0, session.Pending); Assert.IsFalse(session.CanRetrySave); Assert.AreEqual(DeviceScreenDirection.Landscape, new DeviceDisplayStore(directory).Read()); Assert.IsFalse(session.RetrySave());
        }
        [Test] public void PlatformChangeAfterFailedSaveCannotPersistAnUnconfirmedNewDirection()
        {
            var session = new DisplaySettingsSession(true, DeviceScreenDirection.Portrait, DeviceScreenDirection.Portrait, _ => false);
            session.Complete(session.Request(DeviceScreenDirection.Landscape), DeviceScreenDirection.Landscape, true); session.Observe(DeviceScreenDirection.Portrait);
            Assert.IsFalse(session.CanRetrySave); Assert.IsFalse(session.RetrySave());
        }
        [Test] public void NewApplySupersedesPendingSaveRetry()
        {
            var session = new DisplaySettingsSession(true, DeviceScreenDirection.Portrait, DeviceScreenDirection.Portrait, _ => false);
            session.Complete(session.Request(DeviceScreenDirection.Landscape), DeviceScreenDirection.Landscape, true); session.Request(DeviceScreenDirection.Portrait);
            Assert.IsFalse(session.RetrySave()); Assert.IsFalse(session.CanRetrySave);
        }
        [Test] public void RestoreAppliesPreferenceWithoutRewritingIt()
        {
            store.Write(DeviceScreenDirection.Landscape); string old = File.ReadAllText(store.Path); var session = Session();
            Assert.IsTrue(session.Complete(session.Request(session.Saved, false), DeviceScreenDirection.Landscape, true)); Assert.AreEqual(old, File.ReadAllText(store.Path)); Assert.IsFalse(session.CanRetrySave);
        }
        [Test] public void DesktopIgnoresMobileApplyAndRetryAndOnlyObservesWindowShape()
        { var session = Session(false); Assert.AreEqual(0, session.Request(DeviceScreenDirection.Landscape)); Assert.IsFalse(session.RetrySave()); session.Observe(DeviceScreenDirection.Landscape); Assert.AreEqual(DeviceScreenDirection.Landscape, session.Actual); Assert.IsFalse(File.Exists(store.Path)); }
        [Test] public void StorageExceptionsBecomeRetryableFailure()
        { var session = new DisplaySettingsSession(true, DeviceScreenDirection.Portrait, DeviceScreenDirection.Portrait, _ => throw new IOException()); Assert.IsFalse(session.Complete(session.Request(DeviceScreenDirection.Landscape), DeviceScreenDirection.Landscape, true)); Assert.IsTrue(session.CanRetrySave); }
        [Test] public void InvalidRequestedValueDoesNotStartARequest()
        { var session = Session(); Assert.Throws<ArgumentOutOfRangeException>(() => session.Request((DeviceScreenDirection)9)); Assert.AreEqual(0, session.Pending); Assert.IsFalse(File.Exists(store.Path)); }
    }
}
