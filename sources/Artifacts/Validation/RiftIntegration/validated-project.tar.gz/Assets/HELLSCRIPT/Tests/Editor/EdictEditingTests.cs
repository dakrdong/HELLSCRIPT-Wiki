using System;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class EdictEditingTests
    {
        GameCatalog catalog;
        [SetUp] public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown] public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        static string Json(object o)=>JsonUtility.ToJson(o);
        static EdictOptionDefinition Global(string id)=>EdictOptions.Global.Single(o=>o.id==id);
        static string GlobalValue(HuntEdictV2Document d,string id)=>d.global.Single(o=>o.id==id).value;

        [Test]
        public void WithGlobalSetsOneValueAndLeavesTheSourceUntouched()
        {
            var source=HuntEdictV2.Create(HeroClass.Warrior);string before=Json(source);
            var next=HuntEdictV2Editing.WithGlobal(source,"survival.lowHp","ON");
            Assert.AreEqual("ON",GlobalValue(next,"survival.lowHp"));
            Assert.AreEqual("OFF",GlobalValue(source,"survival.lowHp"));Assert.AreEqual(before,Json(source));
            Assert.DoesNotThrow(()=>HuntEdictV2.Canonical(next));
        }

        [TestCase("survival.lowHpPercent","0")]
        [TestCase("survival.lowHpPercent","30.5")]
        [TestCase("dodge.method","RUN")]
        [TestCase("survival.lowHp","MAYBE")]
        [TestCase("no.such.option","ON")]
        public void WithGlobalRejectsInvalidValuesWithoutChangingTheSource(string id,string value)
        {
            var source=HuntEdictV2.Create(HeroClass.Mage);string before=Json(source);
            Assert.Throws<ArgumentException>(()=>HuntEdictV2Editing.WithGlobal(source,id,value));
            Assert.AreEqual(before,Json(source));
        }

        [Test]
        public void SteppingANumberStaysOnItsGridAndInsideItsRange()
        {
            var window=Global("dodge.window");   // 0.1 to 5 in steps of 0.1
            string v="1";
            for(int i=0;i<3;i++)v=HuntEdictV2Editing.Stepped(window,v,1);
            Assert.AreEqual("1.3",v,"three 0.1 steps must not drift");
            Assert.AreEqual("5",HuntEdictV2Editing.Stepped(window,"5",1),"the maximum is a wall");
            Assert.AreEqual("0.1",HuntEdictV2Editing.Stepped(window,"0.1",-1),"the minimum is a wall");
            var percent=Global("survival.lowHpPercent");
            Assert.AreEqual("29",HuntEdictV2Editing.Stepped(percent,"30",-1));
            Assert.DoesNotThrow(()=>window.CanonicalValue(v,"WARRIOR"));
        }

        [Test]
        public void SteppingASkillNumberUsesTheDecimalStepOfItsDefinition()
        {
            var leap=HuntEdictV2Options.ForSkill("W02","WARRIOR").Single(o=>o.Numeric);   // 2 to 8 by 0.5
            Assert.AreEqual("4.5",HuntEdictV2Editing.Stepped(leap,"4",1));
            Assert.AreEqual("8",HuntEdictV2Editing.Stepped(leap,"8",1));
            Assert.AreEqual("2",HuntEdictV2Editing.Stepped(leap,"2",-1));
        }

        [Test]
        public void ChoicesCycleThroughEveryValueAndWrapAround()
        {
            var d=Global("dodge.method");string v=d.choices[0];
            var seen=new System.Collections.Generic.List<string>();
            for(int i=0;i<d.choices.Length;i++){seen.Add(v);v=HuntEdictV2Editing.NextChoice(d.choices,v);}
            CollectionAssert.AreEquivalent(d.choices,seen);Assert.AreEqual(d.choices[0],v);
            Assert.AreEqual(d.choices[d.choices.Length-1],HuntEdictV2Editing.NextChoice(d.choices,d.choices[0],-1));
        }

        [Test]
        public void OrderMovesSwapNeighboursOnlyAndKeepEveryItem()
        {
            string value="DEFENSE,ESCAPE,WALK";
            Assert.AreEqual("ESCAPE,DEFENSE,WALK",HuntEdictV2Editing.MovedInOrder(value,"ESCAPE",-1));
            Assert.AreEqual("DEFENSE,WALK,ESCAPE",HuntEdictV2Editing.MovedInOrder(value,"ESCAPE",1));
            Assert.AreEqual(value,HuntEdictV2Editing.MovedInOrder(value,"DEFENSE",-1),"the first item cannot move up");
            Assert.AreEqual(value,HuntEdictV2Editing.MovedInOrder(value,"WALK",1),"the last item cannot move down");
            Assert.Throws<ArgumentException>(()=>HuntEdictV2Editing.MovedInOrder(value,"POTION",1));
            var d=HuntEdictV2.Create(HeroClass.Ranger);
            var moved=HuntEdictV2Editing.WithGlobal(d,"survival.order",HuntEdictV2Editing.MovedInOrder(GlobalValue(d,"survival.order"),"WALK",-1));
            Assert.AreEqual("DEFENSE,WALK,ESCAPE",GlobalValue(moved,"survival.order"));
        }

        [Test]
        public void SetTogglesKeepTheDeclaredOrderRegardlessOfClickOrder()
        {
            var d=Global("loot.slots");
            string v=HuntEdictV2Editing.ToggledInSet(d,"","RING");
            v=HuntEdictV2Editing.ToggledInSet(d,v,"WEAPON");
            Assert.AreEqual("WEAPON,RING",v,"canonical order is the declared order");
            v=HuntEdictV2Editing.ToggledInSet(d,v,"RING");
            Assert.AreEqual("WEAPON",v);
            Assert.Throws<ArgumentException>(()=>HuntEdictV2Editing.ToggledInSet(d,v,"HAT"));
            Assert.DoesNotThrow(()=>HuntEdictV2Editing.WithGlobal(HuntEdictV2.Create(HeroClass.Mage),"loot.slots",v));
        }

        [Test]
        public void SkillOrderMovesKeepEveryIdOnceAndStayCanonical()
        {
            var d=HuntEdictV2.Create(HeroClass.Mage);var before=d.skillOrder.ToArray();
            var moved=HuntEdictV2Editing.WithSkillOrderMoved(d,"BASIC",-1);
            CollectionAssert.AreEquivalent(before,moved.skillOrder);
            Assert.AreEqual(before.Length-2,Array.IndexOf(moved.skillOrder,"BASIC"));
            Assert.AreEqual(before,d.skillOrder,"the source is untouched");
            Assert.DoesNotThrow(()=>HuntEdictV2.Canonical(moved));
        }

        [Test]
        public void EveryChoiceSetAndOrderValueOfEveryGlobalOptionHasAReadableLabel()
        {
            var missing=EdictOptions.Global
                .Where(o=>o.kind==EdictOptionKind.Choice||o.kind==EdictOptionKind.Set||o.kind==EdictOptionKind.Order)
                .SelectMany(o=>o.choices.Where(c=>!EdictOptionLabels.HasLabel(o,c)).Select(c=>o.id+"="+c)).ToList();
            Assert.IsEmpty(missing,string.Join(", ",missing));
        }

        [Test]
        public void LabelsReadInKoreanAndContentIdsReadAsThemselves()
        {
            Assert.AreEqual("피해 기준으로 회피",EdictOptionLabels.Item(Global("dodge.ground.policy"),"DAMAGE"));
            Assert.AreEqual("전투 후",EdictOptionLabels.Item(Global("loot.RARE"),"AFTER_COMBAT"));
            Assert.AreEqual("판매",EdictOptionLabels.Item(Global("bag.cleanup.MAGIC"),"SELL"));
            Assert.AreEqual("LW01",EdictOptionLabels.Item(Global("bag.protectEffects"),"LW01"));
            Assert.AreEqual("희귀 회수",EdictOptionLabels.Option(Global("loot.RARE")));
            Assert.AreEqual("무기 · 반지",EdictOptionLabels.Value(Global("loot.slots"),"WEAPON,RING"));
            Assert.AreEqual("선택 없음",EdictOptionLabels.Value(Global("loot.slots"),""));
            Assert.AreEqual("지정 안 함",EdictOptionLabels.Value(Global("survival.escapeSkill"),""));
            Assert.AreEqual("도약",EdictOptionLabels.Value(Global("survival.escapeSkill"),"W02",id=>"도약"));
            foreach(string g in EdictOptionLabels.GroupOrder)Assert.AreNotEqual(g,EdictOptionLabels.Group(g),g+" needs a Korean group name");
            CollectionAssert.AreEquivalent(EdictOptions.Global.Select(o=>o.group).Distinct(),EdictOptionLabels.GroupOrder,"every group is reachable from the editor");
        }

        [Test]
        public void RefreshingAnActiveRunPicksUpADocumentSavedMidRun()
        {
            var a=GameStore.NewAccount(catalog);a.selectedHero=2;a.Hero.level=30;
            a.Hero.build=BehaviorPresets.ForLevel(HeroClass.Mage,0,30,catalog);a.Hero.edict=HuntEdictV2Storage.CreateForHero(a.Hero);
            var sim=new CombatSimulation(a,catalog,1);   // a real run keeps a reference to the account, as the game does
            Assert.IsFalse(sim.EdictActive);
            a.Hero.useEdict=true;a.Hero.edict=HuntEdictV2Editing.WithGlobal(a.Hero.edict,"survival.lowHp","ON");
            Assert.IsFalse(sim.EdictActive,"nothing changes until the run is told");
            sim.RefreshEdict();
            Assert.IsTrue(sim.EdictActive);
            for(int i=0;i<8;i++)sim.Tick(CombatSimulation.Step);
            Assert.IsNotNull(sim.LastEdictPlan);
        }
    }
}
