using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace Hellscript.Tests
{
    public sealed class PresetStorageTests
    {
        string directory,path;
        [SetUp]public void Setup(){directory=Path.Combine(Path.GetTempPath(),"hellscript-preset-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(directory);path=Path.Combine(directory,"hellscript-local-v1.json");}
        [TearDown]public void Teardown(){if(Directory.Exists(directory))Directory.Delete(directory,true);}
        static string Json(object value)=>JsonUtility.ToJson(value);
        [Test]public void ThreeLegacySlotsBecomeFiveWithoutChangingNamesRulesPassivesOrProtection()
        {
            var account=GameStore.NewAccount();
            foreach(var hero in account.heroes)
            {
                var first=hero.build.Copy();first.name="오래 보관한 설정 이름은 새 이름 제한보다 길어도 그대로 남습니다";first.equipmentIds=hero.inventory.Select(i=>i.id).ToList();first.passives=new[]{2,4};
                var third=hero.build.Copy();third.name="세 번째 🏹";third.distance=5.5f;
                hero.presets=new List<BuildConfig>{first,null,third};
            }
            File.WriteAllText(path,Json(account));var store=new GameStore(directory);
            for(int n=0;n<3;n++)
            {
                var old=account.heroes[n];var current=store.Data.heroes[n];Assert.AreEqual(5,current.presets.Count);
                Assert.AreEqual(Json(old.presets[0]),Json(current.presets[0]));Assert.AreEqual(Json(old.presets[2]),Json(current.presets[2]));
                foreach(int empty in new[]{1,3,4})Assert.IsFalse(BuildEditing.HasPreset(current.presets[empty]));
                Assert.IsTrue(Economy.Referenced(current,current.inventory[0]));
            }
            var saved=store.Data.heroes.Select(h=>Json(h.presets[0])).ToArray();var reopened=new GameStore(directory);
            for(int n=0;n<3;n++)Assert.AreEqual(saved[n],Json(reopened.Data.heroes[n].presets[0]));
        }
        [Test]public void EmptyAndMissingLegacyBanksBecomeFiveEmptySlots()
        {
            var account=GameStore.NewAccount();account.heroes[1].presets=null;
            File.WriteAllText(path,Json(account));var store=new GameStore(directory);
            foreach(var hero in store.Data.heroes){Assert.AreEqual(5,hero.presets.Count);Assert.IsTrue(hero.presets.All(p=>!BuildEditing.HasPreset(p)));}
        }
        [TestCase(3)][TestCase(4)]public void NewSlotsSaveIndependentCopiesAndDoNotApplyTheBuild(int slot)
        {
            var store=new GameStore(directory);var hero=store.Data.Hero;string actual=Json(hero.build),progress=Json(hero.inventory);
            var source=hero.build.Copy();source.distance=5.5f;source.equipmentIds=hero.inventory.Select(i=>i.id).ToList();string original=Json(source);
            Assert.IsTrue(store.SaveBuildPreset(hero.id,slot,source,"슬롯 시험 ✨"),store.Error);Assert.AreEqual(original,Json(source));
            Assert.AreEqual(actual,Json(hero.build));Assert.AreEqual(progress,Json(hero.inventory));Assert.AreEqual("슬롯 시험 ✨",hero.presets[slot].name);
            source.distance=9;source.rules.Clear();Assert.AreEqual(5.5f,hero.presets[slot].distance);Assert.IsNotEmpty(hero.presets[slot].rules);
            Assert.AreSame(hero,store.Data.Hero);var restored=new GameStore(directory);Assert.AreEqual(Json(hero.presets[slot]),Json(restored.Data.Hero.presets[slot]));
            Assert.IsTrue(Economy.Referenced(restored.Data.Hero,restored.Data.Hero.inventory[0]));
            foreach(int empty in Enumerable.Range(0,5).Where(i=>i!=slot))Assert.IsFalse(BuildEditing.HasPreset(restored.Data.Hero.presets[empty]));
        }
        [TestCase(false)][TestCase(true)]public void DiskFailureKeepsLiveAccountDiskAndSourceThenRetrySucceeds(bool rename)
        {
            var store=new GameStore(directory);var hero=store.Data.Hero;Assert.IsTrue(store.SaveBuildPreset(hero.id,4,hero.build,"기존 설정"));
            var source=hero.build.Copy();source.distance=5.5f;string before=Json(store.Data),draft=Json(source),disk=File.ReadAllText(path);var bank=hero.presets;
            Directory.CreateDirectory(path+".tmp");LogAssert.Expect(LogType.Error,new Regex("저장하지 못했습니다:"));
            bool Apply()=>rename?store.RenameBuildPresets(hero.id,new Dictionary<int,string>{{4,"바꾼 이름"}}):store.SaveBuildPreset(hero.id,4,source,"바꾼 설정");
            Assert.IsFalse(Apply());Assert.IsNotEmpty(store.Error);Assert.AreSame(bank,hero.presets);Assert.AreEqual(before,Json(store.Data));Assert.AreEqual(draft,Json(source));Assert.AreEqual(disk,File.ReadAllText(path));
            Directory.Delete(path+".tmp");Assert.IsTrue(Apply(),store.Error);Assert.IsEmpty(store.Error);Assert.AreEqual(rename?"바꾼 이름":"바꾼 설정",new GameStore(directory).Data.Hero.presets[4].name);
        }
        [Test]public void BatchRenameValidatesEveryNameBeforeWritingAndOnlyChangesNames()
        {
            var store=new GameStore(directory);var hero=store.Data.Hero;
            foreach(int slot in new[]{0,4})Assert.IsTrue(store.SaveBuildPreset(hero.id,slot,hero.build,"이름 "+slot));
            string before=Json(store.Data),disk=File.ReadAllText(path);
            Assert.IsFalse(store.RenameBuildPresets(hero.id,new Dictionary<int,string>{{0,"첫 이름"},{4,"   "}}));Assert.AreEqual(before,Json(store.Data));Assert.AreEqual(disk,File.ReadAllText(path));
            var expected=JsonUtility.FromJson<AccountSave>(before);expected.Hero.presets[0].name="첫 이름";expected.Hero.presets[4].name="마지막 이름";
            Assert.IsTrue(store.RenameBuildPresets(hero.id,new Dictionary<int,string>{{0,"첫 이름"},{4,"마지막 이름"}}));expected.lastSeenUtc=store.Data.lastSeenUtc;Assert.AreEqual(Json(expected),Json(store.Data));
        }
        [TestCase(-1)][TestCase(5)]public void InvalidSlotCannotWriteOrChangeLiveState(int slot)
        {
            var store=new GameStore(directory);string before=Json(store.Data),disk=File.ReadAllText(path);
            Assert.IsFalse(store.SaveBuildPreset(store.Data.Hero.id,slot,store.Data.Hero.build,"이름"));Assert.AreEqual(before,Json(store.Data));Assert.AreEqual(disk,File.ReadAllText(path));
        }
        [Test]public void WrongHeroInvalidBuildAndEmptyRenameAreRejected()
        {
            var store=new GameStore(directory);string before=Json(store.Data),disk=File.ReadAllText(path);
            Assert.IsFalse(store.SaveBuildPreset(store.Data.heroes[1].id,0,store.Data.Hero.build,"이름"));
            Assert.IsFalse(store.SaveBuildPreset(store.Data.Hero.id,0,new BuildConfig{emptySlot=true},"이름"));
            var wrong=GameCatalog.Preset(HeroClass.Mage,0);Assert.IsFalse(store.SaveBuildPreset(store.Data.Hero.id,0,wrong,"이름"));
            Assert.IsFalse(store.RenameBuildPresets(store.Data.Hero.id,new Dictionary<int,string>{{0,"이름"}}));
            Assert.AreEqual(before,Json(store.Data));Assert.AreEqual(disk,File.ReadAllText(path));
        }
        [Test]public void MoreThanFiveLegacySlotsAreNotSilentlyTruncated()
        {
            var account=GameStore.NewAccount();account.Hero.presets=Enumerable.Range(0,6).Select(_=>account.Hero.build.Copy()).ToList();string original=Json(account);File.WriteAllText(path,original);
            Assert.Throws<NotSupportedException>(()=>new GameStore(directory));Assert.AreEqual(original,File.ReadAllText(path));Assert.IsFalse(File.Exists(path+".bak"));
        }
        [TestCase("가")][TestCase("한")][TestCase("e\u0301")][TestCase("👨‍👩‍👧‍👦")][TestCase("👍🏽")][TestCase("🇰🇷")]
        public void NamesUseDisplayedCharactersAndPreserveUnicode(string element)
        {
            string limit=string.Concat(Enumerable.Repeat(element,24));Assert.AreEqual(limit.Normalize(NormalizationForm.FormC),PresetNames.Validate(limit));
            Assert.Throws<ArgumentException>(()=>PresetNames.Validate(limit+element));
        }
        [TestCase("")][TestCase("  ")][TestCase("줄\n바꿈")][TestCase("탭\t이름")][TestCase("\u200d")]
        public void InvalidNamesCannotBeSaved(string name)=>Assert.Throws<ArgumentException>(()=>PresetNames.Validate(name));
        [Test]public void JoinersDoNotMergeOrdinaryLettersIntoOneDisplayedCharacter()
        {Assert.DoesNotThrow(()=>PresetNames.Validate(string.Concat(Enumerable.Repeat("A\u200dB",12))));Assert.Throws<ArgumentException>(()=>PresetNames.Validate(string.Concat(Enumerable.Repeat("A\u200dB",13))));}
    }
}
