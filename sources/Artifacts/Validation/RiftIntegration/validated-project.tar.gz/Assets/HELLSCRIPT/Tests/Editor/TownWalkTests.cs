using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class TownWalkTests
    {
        static int Walk(TownWalk walk,float seconds,float dt=.05f){int ticks=0;for(float t=0;t<seconds;t+=dt){walk.Tick(dt);ticks++;}return ticks;}

        [Test]
        public void StationsAreUniqueNamedAndInsideThePlaza()
        {
            var stations=TownLayout.Stations;
            Assert.AreEqual(5,stations.Length);
            CollectionAssert.AllItemsAreUnique(stations.Select(s=>s.id));CollectionAssert.AllItemsAreUnique(stations.Select(s=>s.name));
            Assert.IsTrue(stations.All(s=>s.position==TownLayout.Clamp(s.position)),"every station lies inside the walkable rectangle");
            Assert.IsTrue(stations.All(s=>Vector2.Distance(s.position,TownLayout.Spawn)>TownLayout.ArriveRadius),"no station overlaps the spawn point");
            for(int i=0;i<stations.Length;i++)for(int j=i+1;j<stations.Length;j++)
                Assert.Greater(Vector2.Distance(stations[i].position,stations[j].position),2*TownLayout.ArriveRadius,$"{stations[i].id} and {stations[j].id} arrival zones overlap");
        }

        [Test]
        public void AFreshWalkStandsAtTheSpawnWithNoDestination()
        {
            var walk=new TownWalk();
            Assert.AreEqual(TownLayout.Spawn,walk.Position);Assert.IsFalse(walk.Walking);Assert.AreEqual(0,walk.Remaining);
            Assert.IsFalse(walk.TakeArrival(out _));Assert.IsFalse(walk.Tick(.05f),"nothing moves without a destination");
        }

        [Test]
        public void WalkingReachesTheStationAndHandsOverTheArrivalOnce()
        {
            var walk=new TownWalk();walk.Request(TownStation.Blacksmith);
            Assert.IsTrue(walk.Walking);float before=walk.Remaining;
            walk.Tick(.05f);Assert.Less(walk.Remaining,before,"each tick closes the distance");
            Walk(walk,10);
            Assert.IsFalse(walk.Walking);
            Assert.LessOrEqual(Vector2.Distance(walk.Position,TownLayout.Station(TownStation.Blacksmith).position),TownLayout.ArriveRadius);
            Assert.IsTrue(walk.TakeArrival(out var station));Assert.AreEqual(TownStation.Blacksmith,station);
            Assert.IsFalse(walk.TakeArrival(out _),"an arrival is consumed once");
        }

        [Test]
        public void TravelTimeMatchesTheDeclaredSpeed()
        {
            var walk=new TownWalk();walk.Request(TownStation.RiftKeeper);
            float distance=Vector2.Distance(TownLayout.Spawn,TownLayout.Station(TownStation.RiftKeeper).position);
            int ticks=0;while(walk.Walking&&ticks<10000){walk.Tick(.05f);ticks++;}
            float expected=(distance-TownLayout.ArriveRadius)/TownLayout.Speed;
            Assert.AreEqual(expected,ticks*.05f,.15f,"arrival happens when the arrive radius is reached at walking speed");
        }

        [Test]
        public void ANewDestinationReplacesTheOldRequest()
        {
            var walk=new TownWalk();walk.Request(TownStation.Blacksmith);Walk(walk,.5f);
            walk.Request(TownStation.Merchant);
            Assert.AreEqual(TownStation.Merchant,walk.Destination);
            Walk(walk,12);
            Assert.IsTrue(walk.TakeArrival(out var station));Assert.AreEqual(TownStation.Merchant,station,"only the latest destination arrives");
        }

        [Test]
        public void RequestingTheStationYouStandAtArrivesImmediately()
        {
            var walk=new TownWalk();walk.Request(TownStation.Warehouse);Walk(walk,12);
            Assert.IsTrue(walk.TakeArrival(out _));
            walk.Request(TownStation.Warehouse);
            Assert.IsFalse(walk.Walking,"no walk is queued when already there");
            Assert.IsTrue(walk.TakeArrival(out var again));Assert.AreEqual(TownStation.Warehouse,again,"walking is never a waiting time for a service");
        }

        [Test]
        public void CancelStopsWalkingAndDropsAPendingArrival()
        {
            var walk=new TownWalk();walk.Request(TownStation.Reroller);Walk(walk,.3f);var mid=walk.Position;
            walk.Cancel();
            Assert.IsFalse(walk.Walking);Walk(walk,1);Assert.AreEqual(mid,walk.Position,"a cancelled walk stays put");
            walk.Request(TownStation.Reroller);Walk(walk,12);walk.Cancel();
            Assert.IsFalse(walk.TakeArrival(out _),"cancel discards an arrival that was not handed over yet");
        }

        [Test]
        public void ThePositionNeverLeavesThePlazaAndFacingFollowsTheWalk()
        {
            var walk=new TownWalk();walk.Request(TownStation.Blacksmith);
            for(int i=0;i<400;i++){walk.Tick(.05f);Assert.AreEqual(TownLayout.Clamp(walk.Position),walk.Position);}
            var toward=(TownLayout.Station(TownStation.Blacksmith).position-TownLayout.Spawn).normalized;
            Assert.Greater(Vector2.Dot(walk.Facing,toward),.99f,"facing points along the walk");
        }

        [Test]
        public void ATapPicksTheNearestStationInsideTheRadiusAndNothingOutsideIt()
        {
            var projected=new List<(TownStation,Vector2)>{(TownStation.Blacksmith,new Vector2(100,100)),(TownStation.Merchant,new Vector2(300,100)),(TownStation.Warehouse,new Vector2(300,140))};
            Assert.IsTrue(TownPick.Nearest(projected,new Vector2(110,95),40,out var near));Assert.AreEqual(TownStation.Blacksmith,near);
            Assert.IsTrue(TownPick.Nearest(projected,new Vector2(300,125),40,out var closer));Assert.AreEqual(TownStation.Warehouse,closer,"the nearer of two candidates wins");
            Assert.IsFalse(TownPick.Nearest(projected,new Vector2(200,400),40,out _),"a tap far from every station picks nothing");
            Assert.IsTrue(TownPick.Nearest(projected,new Vector2(300,120),40,out var tie));Assert.AreEqual(TownStation.Merchant,tie,"an exact tie keeps the first station");
        }

        [Test]
        public void TwoWalksWithTheSameRequestsAreIdentical()
        {
            TownWalk Make(){var w=new TownWalk();w.Request(TownStation.Merchant);Walk(w,1.35f);w.Request(TownStation.Warehouse);Walk(w,2.2f);return w;}
            var a=Make();var b=Make();
            Assert.AreEqual(a.Position,b.Position);Assert.AreEqual(a.Destination,b.Destination);Assert.AreEqual(a.Elapsed,b.Elapsed);
        }
    }
}
