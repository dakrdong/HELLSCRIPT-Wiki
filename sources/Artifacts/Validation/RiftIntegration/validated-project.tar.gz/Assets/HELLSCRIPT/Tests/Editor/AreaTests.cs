using System;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class AreaTests
    {
        GameCatalog catalog;
        [SetUp]public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown]public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        static object Call(CombatSimulation sim,string name,params object[] args)
        {
            var method=typeof(CombatSimulation).GetMethod(name,BindingFlags.NonPublic|BindingFlags.Instance);var parameters=method.GetParameters();var values=new object[parameters.Length];
            for(int i=0;i<values.Length;i++)values[i]=i<args.Length?args[i]:parameters[i].DefaultValue;return method.Invoke(sim,values);
        }
        CombatSimulation Fixture(HeroClass heroClass=HeroClass.Mage,string set="SM",string legendary="LM01")
        {
            var account=GameStore.NewAccount();account.selectedHero=(int)heroClass;var hero=account.Hero;hero.level=30;
            hero.build=GameCatalog.Preset(heroClass,0);hero.build.passives=Array.Empty<int>();hero.build.rules.Clear();hero.build.activeSkills=heroClass==HeroClass.Mage?new[]{12,13}.ToList():new[]{6,8}.ToList();
            hero.build.movement=MovementMode.Stand;hero.build.distance=2;hero.build.potionThreshold=0;hero.build.autoRepeat=false;
            uint rng=419;hero.inventory.Clear();
            void Equip(string id){var d=ItemCatalog.Unique(id);Assert.IsFalse(hero.inventory.Any(i=>i.equipped&&i.slot==d.slot),"Fixture cannot equip two items in one slot: "+id);var item=ItemGenerator.Create(heroClass,d.slot,3,30,ref rng,uniqueId:id);item.equipped=true;hero.inventory.Add(item);}
            if(set!=null)for(int i=1;i<=4;i++)Equip(set+i);if(legendary!=null)Equip(legendary);
            var sim=new CombatSimulation(account,catalog,1,1,seed:515);sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();sim.State.decisionTime=100;
            sim.State.enemies.Add(Enemy(900,sim.State.position+Vector2.up*2));Controlled(sim);return sim;
        }
        static EnemyState Enemy(int id,Vector2 position)=>new EnemyState{id=id,kind=0,position=position,health=100000,maxHealth=100000,speed=0,cooldown=1000};
        static void Controlled(CombatSimulation sim){sim.Stats.regen=0;sim.Stats.crit=0;sim.Stats.costReduction=0;}
        static void Advance(CombatSimulation sim,int ticks){for(int i=0;i<ticks;i++)sim.Tick(.05f);}
        static DamageSnapshot Snapshot(float damage=100)=>new DamageSnapshot{damage=damage,level=30,critDamage=2,elements=new float[6],passives=new bool[6]};
        static CombatProjectile Shot(int root=71,float damage=100)=>new CombatProjectile{id=root+1,actionId=root,skill=12,coefficient=2.1f,explosionRadius=2.5f,snapshot=Snapshot(damage)};
        GroundEffect Field(CombatSimulation sim,float duration=6,float delay=0,DamageSnapshot snapshot=null,Vector2? position=null)
        {
            var snap=snapshot??Snapshot();var fx=new GroundEffect{id=sim.State.nextId++,rootCastId=sim.State.nextId++,kind=13,definitionId="M02",casterId=sim.State.heroId,
                position=position??sim.State.enemies[0].position,radius=3,duration=duration,delay=delay,createdAt=sim.State.time,damage=snap.damage*.65f,snapshot=snap};sim.State.effects.Add(fx);return fx;
        }
        CombatSimulation Restore(CombatSimulation original)
        {
            var account=GameStore.NewAccount();account.selectedHero=(int)original.Hero.heroClass;account.heroes[account.selectedHero]=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(original.Hero));
            var sim=new CombatSimulation(account,catalog,1,1,JsonUtility.FromJson<RunState>(JsonUtility.ToJson(original.State)));Controlled(sim);return sim;
        }
        static void Select(CombatSimulation sim,int skill,AreaAim aim=AreaAim.Target,BlizzardMode mode=BlizzardMode.Follow)
        {sim.State.build.rules.Clear();var r=BehaviorRules.Make(skill);r.areaAim=aim;r.blizzardMode=mode;sim.State.build.rules.Add(r);sim.State.decisionTime=0;}
        [TestCase(8,HeroClass.Ranger)][TestCase(13,HeroClass.Mage)]
        public void SelfPlacementWorksWithoutAnEnemyAndChargesOnlyOneCast(int skill,HeroClass hero)
        {
            var sim=Fixture(hero,null,null);sim.State.training=-1;sim.State.enemies.Clear();Select(sim,skill,AreaAim.Self);float before=sim.State.resource;Vector2 origin=sim.State.position;sim.Tick(.05f);sim.State.decisionTime=100;
            Assert.AreEqual(skill,sim.State.heroAction.skill);Assert.AreEqual(origin,sim.State.heroAction.aim);Assert.Less(sim.State.resource,before);Advance(sim,12);
            if(skill==13){Assert.AreEqual(1,sim.State.effects.Count);Assert.AreEqual(origin,sim.State.effects[0].position);Assert.IsFalse(sim.State.effects[0].followsTarget);}
            else{Assert.AreEqual(1,sim.State.traps.Count);Assert.AreEqual(origin,sim.State.traps[0].position);}
            Assert.AreEqual(1,sim.State.actionEvents.Count(e=>e.kind=="ACTION_START"));
        }
        [Test]
        public void InvalidGroundPositionBlocksBeforePaymentAndPreparation()
        {
            var sim=Fixture();sim.State.position=new Vector2(1000,1000);Select(sim,13,AreaAim.Self);float before=sim.State.resource;sim.Tick(.05f);
            Assert.AreEqual(before,sim.State.resource);Assert.IsFalse(sim.HeroActionBusy);Assert.IsEmpty(sim.State.effects);Assert.IsTrue(sim.State.decisions.Any(d=>d.code=="LANDING"));
        }
        [Test]
        public void DenseAimAndPredictedHitsUseTheSameValidMidpoint()
        {
            var sim=Fixture();var origin=sim.State.position;sim.State.enemies[0].position=origin+new Vector2(-2.5f,2);sim.State.enemies.Add(Enemy(901,origin+new Vector2(2.5f,2)));
            var rule=BehaviorRules.Make(13,BehaviorRules.C("SC06",Comparison.AtLeast,2,predicted:true));rule.areaAim=AreaAim.Dense;sim.State.build.rules.Add(rule);sim.State.decisionTime=0;
            sim.Tick(.05f);sim.State.decisionTime=100;Assert.AreEqual(origin+Vector2.up*2,sim.State.heroAction.aim);Advance(sim,20);
            Assert.AreEqual(2,sim.State.damageEvents.Where(d=>d.definitionId=="M02").Select(d=>d.targetId).Distinct().Count());
        }
        [Test]
        public void ObservedPathUsesOnlyFreshPlausibleMotionAndStopsAtWalls()
        {
            var sim=Fixture();var enemy=sim.State.enemies[0];enemy.speed=4;var rule=BehaviorRules.Make(13);rule.areaAim=AreaAim.ObservedPath;
            RiftExploration.ObserveEnemies(sim.State,new[]{enemy});Assert.AreEqual(enemy.position,Call(sim,"GroundAim",rule,enemy));
            sim.State.time=.2f;enemy.position+=Vector2.up*.4f;RiftExploration.ObserveEnemies(sim.State,new[]{enemy});Assert.Less(Vector2.Distance(enemy.position+Vector2.up*1.5f,(Vector2)Call(sim,"GroundAim",rule,enemy)),.0001f);
            sim.State.time=.7f;Assert.AreEqual(enemy.position,Call(sim,"GroundAim",rule,enemy));RiftExploration.ObserveEnemies(sim.State,new[]{enemy});Assert.AreEqual(Vector2.zero,sim.State.exploration.enemies[0].velocity);
            sim.State.time=.9f;enemy.position+=Vector2.right*5;RiftExploration.ObserveEnemies(sim.State,new[]{enemy});Assert.AreEqual(Vector2.zero,sim.State.exploration.enemies[0].velocity);
            var memory=sim.State.exploration.enemies[0];memory.velocity=Vector2.down*20;Assert.IsFalse(sim.Map.LineClear(enemy.position,enemy.position+memory.velocity*.75f),"Wall fixture must cross blocked terrain.");
            var aim=(Vector2)Call(sim,"GroundAim",rule,enemy);Assert.IsTrue(sim.Map.CanLand(aim,.1f));Assert.IsTrue(sim.Map.LineClear(enemy.position,aim));Assert.Less(Vector2.Distance(enemy.position,aim),15);
        }
        [TestCase(BlizzardMode.Fixed,false)][TestCase(BlizzardMode.Follow,true)]
        public void PreparationAndCreatedFieldRetainTheSelectedModeAcrossSave(BlizzardMode mode,bool follows)
        {
            var sim=Fixture();Select(sim,13,AreaAim.Self,mode);sim.Tick(.05f);sim.State.decisionTime=100;Assert.AreEqual(mode,sim.State.heroAction.blizzardMode);
            var restored=Restore(sim);Advance(sim,13);Advance(restored,13);Assert.AreEqual(JsonUtility.ToJson(sim.State),JsonUtility.ToJson(restored.State));
            var fx=sim.State.effects.Single();Assert.AreEqual(follows,fx.followsTarget);var edit=sim.State.build.Copy();edit.rules[0].blizzardMode=mode==BlizzardMode.Fixed?BlizzardMode.Follow:BlizzardMode.Fixed;
            Assert.IsTrue(sim.ApplyBuild(edit));Assert.AreEqual(follows,fx.followsTarget);Assert.AreEqual(6,fx.duration+sim.State.time-fx.createdAt,.001f);
        }
        [Test]
        public void FollowChoiceWithoutLegendaryCreatesAFixedField()
        {
            var sim=Fixture(legendary:null);Select(sim,13,AreaAim.Self);sim.Tick(.05f);sim.State.decisionTime=100;Advance(sim,15);Assert.IsFalse(sim.State.effects.Single().followsTarget);
        }
        [Test]
        public void EditingDuringPreparationCompletesThePaidFieldWithItsOriginalAimAndMode()
        {
            var sim=Fixture();Select(sim,13,AreaAim.Self,BlizzardMode.Fixed);sim.Tick(.05f);float paid=sim.State.resource;var action=sim.State.heroAction;
            var edit=sim.State.build.Copy();edit.rules[0].areaAim=AreaAim.Dense;edit.rules[0].blizzardMode=BlizzardMode.Follow;
            Assert.IsTrue(sim.ApplyBuild(edit));Assert.AreSame(action,sim.State.heroAction);Assert.AreEqual(paid,sim.State.resource);sim.State.decisionTime=100;Advance(sim,15);
            Assert.AreEqual(1,sim.State.effects.Count);Assert.AreEqual(action.aim,sim.State.effects[0].position);Assert.IsFalse(sim.State.effects[0].followsTarget);Assert.IsFalse(sim.HeroActionBusy);
            Assert.AreEqual(1,sim.State.actionEvents.Count(e=>e.actionId==action.id&&e.kind=="ACTION_RELEASE"));
        }
        [Test]
        public void NewAreaChoicesCopyMigrateAndProtectTheCombatLoadout()
        {
            var sim=Fixture();Select(sim,13,AreaAim.ObservedPath,BlizzardMode.Fixed);var requested=sim.State.build.Copy();requested.activeSkills.Clear();requested.passives=new[]{3};
            var next=BuildEditing.DuringRift(sim.State.build,requested);Assert.AreEqual(AreaAim.ObservedPath,next.rules[0].areaAim);Assert.AreEqual(BlizzardMode.Fixed,next.rules[0].blizzardMode);
            CollectionAssert.AreEqual(sim.State.build.activeSkills,next.activeSkills);CollectionAssert.AreEqual(sim.State.build.passives,next.passives);
            var old=GameCatalog.Preset(HeroClass.Mage,0);old.ruleSchema=1;foreach(var r in old.rules)r.schema=1;var conditions=JsonUtility.ToJson(old.rules[0].groups[0]);
            BehaviorRules.Normalize(old);Assert.AreEqual(BehaviorRules.Version,old.ruleSchema);Assert.AreEqual(conditions,JsonUtility.ToJson(old.rules[0].groups[0]));Assert.AreEqual(AreaAim.Target,old.rules[0].areaAim);
            var rule=next.rules[0];rule.areaAim=(AreaAim)99;Assert.IsNotEmpty(BehaviorRules.Validate(next,HeroClass.Mage));rule.areaAim=AreaAim.Target;rule.blizzardMode=(BlizzardMode)99;Assert.IsNotEmpty(BehaviorRules.Validate(next,HeroClass.Mage));
        }
        [Test]
        public void FollowingFieldWaitsForTargetReassessmentAndNeverFollowsAnUnseenEnemy()
        {
            var sim=Fixture();var fx=Field(sim,position:sim.State.position);fx.followsTarget=true;var target=sim.State.enemies[0];sim.State.targetId=target.id;
            Advance(sim,10);float before=fx.moved;target.dead=true;sim.State.enemies.Add(Enemy(901,sim.State.position+Vector2.up*6));Advance(sim,4);Assert.AreEqual(before,fx.moved);
            sim.State.decisionTime=0;sim.Tick(.05f);Assert.AreEqual(901,sim.State.targetId);Assert.Greater(fx.moved,before);
            sim.State.enemies[1].position=RiftMap.Rooms[4];before=fx.moved;Advance(sim,5);Assert.AreEqual(before,fx.moved);
        }
        [Test]
        public void ThirdBlizzardReplacesOnlyTheOldestOwnField()
        {
            var sim=Fixture();var foreign=Field(sim);foreign.casterId="foreign";
            for(int n=0;n<3;n++)Call(sim,"AddGround",sim.State.position,3f,0f,6f,65f,false,13);
            Assert.AreEqual(3,sim.State.effects.Count);Assert.Contains(foreign,sim.State.effects);Assert.AreEqual(2,sim.State.effects.Count(f=>f.casterId==sim.State.heroId));
        }
        [Test]
        public void BlizzardCreationDoesNotCountElapsedTimeBeforeItExists()
        {
            var sim=Fixture();Select(sim,13);Advance(sim,9);var fx=sim.State.effects.Single();Assert.AreEqual(sim.State.time,fx.createdAt,.0001f);Assert.AreEqual(6,fx.duration);
            Assert.AreEqual(0,sim.State.enemies[0].exposure);Assert.IsEmpty(sim.State.damageEvents);sim.State.decisionTime=100;Advance(sim,39);Assert.AreEqual(0,sim.State.enemies[0].frostMarkTime);Advance(sim,1);Assert.AreEqual(4,sim.State.enemies[0].frostMarkTime,.001f);
        }
        [Test]
        public void OverlapDoesNotDoubleExposureAndIncompleteDepartureResetsIt()
        {
            var sim=Fixture();Field(sim);Field(sim);var e=sim.State.enemies[0];Advance(sim,30);Assert.AreEqual(1.5f,e.exposure,.001f);Assert.AreEqual(0,e.frostMarkTime);
            var inside=e.position;e.position=sim.State.position+Vector2.down*4;Advance(sim,1);Assert.AreEqual(0,e.exposure);e.position=inside;Advance(sim,39);Assert.AreEqual(0,e.frostMarkTime);Advance(sim,1);Assert.AreEqual(4,e.frostMarkTime,.001f);
            Assert.AreEqual(1,sim.State.effectEvents.Count(x=>x.definitionId=="SM4"&&x.kind=="EXPOSURE_READY"));
        }
        [Test]
        public void PartialCooldownAndDelayedOverlapsCountOnlyTheContinuousRemainder()
        {
            var sim=Fixture();var e=sim.State.enemies[0];e.frostCooldown=.025f;Field(sim,delay:.02f);Field(sim,delay:.04f);Advance(sim,1);
            Assert.AreEqual(.025f,e.exposure,.0001f);Advance(sim,39);Assert.AreEqual(1.975f,e.exposure,.0001f);Advance(sim,1);Assert.AreEqual(3.975f,e.frostMarkTime,.0001f);
        }
        [Test]
        public void AGapBetweenFieldWindowsClearsIncompleteExposure()
        {
            var sim=Fixture();var e=sim.State.enemies[0];e.exposure=1.99f;Field(sim,duration:.005f);Field(sim,delay:.03f);Advance(sim,1);
            Assert.AreEqual(0,e.frostMarkTime);Assert.AreEqual(.02f,e.exposure,.0001f);
        }
        [Test]
        public void MarkCanFinishBeforeAnAreaExpiresAndKeepsItsRemainingLifetimeOutside()
        {
            var sim=Fixture();var e=sim.State.enemies[0];e.exposure=1.99f;Field(sim,duration:.02f);Advance(sim,1);
            Assert.AreEqual(3.96f,e.frostMarkTime,.0001f);Assert.IsEmpty(sim.State.effects);int id=e.frostMarkId;Advance(sim,79);Assert.AreEqual(.01f,e.frostMarkTime,.001f);Advance(sim,1);
            Assert.AreEqual(0,e.frostMarkTime);Assert.AreEqual(0,e.frostMarkId);Assert.AreEqual(1,sim.State.effectEvents.Count(x=>x.instanceId==id&&x.kind=="EXPIRED"));
        }
        [Test]
        public void MarkExpiryWithinAStepAllowsOnlyPostExpiryExposure()
        {
            var sim=Fixture();var e=sim.State.enemies[0];Field(sim);e.frostMarkTime=.025f;e.frostMarkId=79;e.frostCasterId=sim.State.heroId;Advance(sim,1);
            Assert.AreEqual(.025f,e.exposure,.0001f);Assert.AreEqual(0,e.frostMarkId);Assert.IsTrue(sim.State.effectEvents.Any(x=>x.instanceId==79&&x.kind=="EXPIRED"));
        }
        [Test]
        public void ForeignBlizzardsExpireButCannotDamageSlowOrBuildOwnExposure()
        {
            var sim=Fixture();var fx=Field(sim,1);fx.casterId="foreign";Advance(sim,25);Assert.IsEmpty(sim.State.effects);Assert.IsEmpty(sim.State.damageEvents);Assert.AreEqual(0,sim.State.enemies[0].exposure);Assert.IsEmpty(sim.State.enemies[0].statuses);
        }
        [Test]
        public void StrongestDamageAndStrongestSlowAreIndependentAndStatusesStayStable()
        {
            var sim=Fixture();var e=sim.State.enemies[0];var strong=Field(sim,.525f,snapshot:Snapshot(100));var weak=Snapshot(60);weak.passives[1]=true;var slow=Field(sim,snapshot:weak);
            Advance(sim,1);var ids=e.statuses.Select(s=>s.id).OrderBy(x=>x).ToArray();Advance(sim,9);CollectionAssert.AreEqual(ids,e.statuses.Select(s=>s.id).OrderBy(x=>x).ToArray());
            Assert.AreEqual(.55f,(float)Call(sim,"SlowRatio",e),.0001f);Assert.AreEqual(strong.id,sim.State.damageEvents.Single().effectInstanceId);Advance(sim,10);
            Assert.AreEqual(slow.id,sim.State.damageEvents.Last().effectInstanceId);Assert.AreEqual(2,sim.State.damageEvents.Count);Assert.AreEqual(1,e.statuses.Count);Assert.AreEqual(slow.id,e.statuses[0].areaId);
        }
        [Test]
        public void BlizzardHasTwelveHalfSecondTicksAndExactBossSlowCreditWithoutAnExpiryTail()
        {
            var sim=Fixture();var e=sim.State.enemies[0];e.boss=true;Field(sim);Advance(sim,120);
            Assert.AreEqual(12,sim.State.damageEvents.Count(d=>d.definitionId=="M02"));Assert.AreEqual(21,e.bossControl.meter,.002f);Assert.IsEmpty(sim.State.effects);Assert.IsEmpty(e.statuses);Advance(sim,1);Assert.AreEqual(21,e.bossControl.meter,.002f);
        }
        [Test]
        public void BossSlowRespectsDelayedEntryPartialImmunityAndDeparture()
        {
            var sim=Fixture();var e=sim.State.enemies[0];e.boss=true;e.bossControl.immunity=.025f;Field(sim,delay:.02f);Advance(sim,1);Assert.AreEqual(.0875f,e.bossControl.meter,.0001f);
            e.position=sim.State.position+Vector2.down*4;Advance(sim,1);Assert.AreEqual(.0875f,e.bossControl.meter,.0001f);Assert.IsEmpty(e.statuses);
        }
        [Test]
        public void MainFireballConsumesEachOwnMarkOnceAndRejectsForeignMarks()
        {
            var sim=Fixture();var e=sim.State.enemies[0];e.boss=true;sim.State.enemies.Add(Enemy(901,e.position+Vector2.right));Field(sim);Advance(sim,40);
            var p=Shot();p.position=e.position;Call(sim,"FireballImpact",p);Assert.AreEqual(2,sim.State.damageEvents.Count(d=>d.definitionId=="SM4"));Assert.AreEqual(3,e.frostCooldown);Assert.AreEqual(0,e.frostMarkTime);
            Call(sim,"FireballImpact",p);Assert.AreEqual(2,sim.State.damageEvents.Count(d=>d.definitionId=="SM4"));e.frostMarkTime=4;e.frostMarkId=9009;e.frostCasterId="foreign";Call(sim,"FireballImpact",p);
            Assert.AreEqual(9009,e.frostMarkId);Assert.AreEqual(2,sim.State.damageEvents.Count(d=>d.definitionId=="SM4"));
        }
        [Test]
        public void ThreeSecondMarkCooldownCannotAccumulateTheNextTwoSecondExposure()
        {
            var sim=Fixture();Field(sim,10);Advance(sim,40);var e=sim.State.enemies[0];var p=Shot();p.position=e.position;Call(sim,"FireballImpact",p);Advance(sim,60);
            Assert.AreEqual(0,e.frostCooldown,.0001f);Assert.AreEqual(0,e.exposure,.0001f);Advance(sim,39);Assert.AreEqual(0,e.frostMarkTime);Advance(sim,1);Assert.AreEqual(4,e.frostMarkTime,.001f);
        }
        [Test]
        public void LethalMainExplosionConsumesTheMarkWithoutHittingTheCorpseAgain()
        {
            var sim=Fixture();var e=sim.State.enemies[0];Field(sim);Advance(sim,40);e.health=1;var p=Shot();p.position=e.position;Call(sim,"FireballImpact",p);Advance(sim,1);
            Assert.AreEqual(1,sim.State.effectEvents.Count(x=>x.definitionId=="SM4"&&x.kind=="CONSUMED"));Assert.IsFalse(sim.State.damageEvents.Any(d=>d.definitionId=="SM4"));Assert.AreEqual(0,e.frostCooldown);Assert.AreEqual(0,e.frostMarkId);
        }
        [Test]
        public void SetPoisonRefreshKeepsTickPhaseAndOnlyReplacesTheStrongerAttackSnapshot()
        {
            var sim=Fixture(HeroClass.Ranger,"SA",null);var e=sim.State.enemies[0];Call(sim,"ApplySetPoison",e,Shot(70,100));int id=e.setPoisonInstance;Advance(sim,15);
            Call(sim,"ApplySetPoison",e,Shot(80,60));Assert.AreEqual(.25f,e.setPoisonTick,.0001f);Assert.AreEqual(70,e.setPoisonRoot);Call(sim,"ApplySetPoison",e,Shot(90,150));Assert.AreEqual(90,e.setPoisonRoot);Assert.AreEqual(id,e.setPoisonInstance);
            Advance(sim,5);Assert.AreEqual(1,sim.State.damageEvents.Count);Assert.AreEqual(120,sim.State.damageEvents.Single().attackBeforeDefense,.001f);Assert.AreEqual(90,sim.State.damageEvents[0].rootCastId);
            Advance(sim,55);Assert.AreEqual(3,sim.State.damageEvents.Count);Assert.AreEqual(0,e.setPoisonTime);Assert.IsNull(e.setPoisonSnapshot);Assert.AreEqual(0,e.setPoisonInstance);
        }
        [Test]
        public void PoisonExpiryUsesOnlyActualRemainingTimeAndAReapplicationGetsANewInstance()
        {
            var sim=Fixture(HeroClass.Ranger,"SA",null);var e=sim.State.enemies[0];Call(sim,"ApplySetPoison",e,Shot());int old=e.setPoisonInstance;e.setPoisonTime=.02f;e.setPoisonTick=.03f;Advance(sim,1);Assert.IsEmpty(sim.State.damageEvents);
            Call(sim,"ApplySetPoison",e,Shot());Assert.AreNotEqual(old,e.setPoisonInstance);Advance(sim,60);Assert.AreEqual(3,sim.State.damageEvents.Count(d=>d.definitionId=="SA4"));Assert.IsTrue(sim.State.damageEvents.All(d=>!d.critical&&d.kind==DamageKind.Periodic));
        }
        [Test]
        public void LethalSetPoisonRecordsRemovalInsteadOfPrematureExpiry()
        {
            var sim=Fixture(HeroClass.Ranger,"SA",null);var e=sim.State.enemies[0];Call(sim,"ApplySetPoison",e,Shot());int id=e.setPoisonInstance;e.health=1;Advance(sim,20);
            Assert.IsTrue(e.dead);Assert.AreEqual(0,e.setPoisonInstance);Assert.IsNull(e.setPoisonSnapshot);Assert.AreEqual(1,sim.State.effectEvents.Count(x=>x.instanceId==id&&x.kind=="REMOVED"));
            Assert.IsFalse(sim.State.effectEvents.Any(x=>x.instanceId==id&&x.kind=="EXPIRED"));Assert.AreEqual(1,sim.State.effectEvents.Count(x=>x.kind=="DEATH"&&x.targetId==e.id));
        }
        [TestCase("A03",true,false,true)][TestCase("LA03",true,false,true)][TestCase("A03",false,false,false)][TestCase("SA4",true,false,false)][TestCase("A03",true,true,false)]
        public void ActualPierceRequiresOwnTrapPoisonAndADirectHit(string definition,bool own,bool extra,bool applies)
        {
            var sim=Fixture(HeroClass.Ranger,"SA",null);var e=sim.State.enemies[0];e.statuses.Add(new StatusEffect{id=40,definitionId=definition,casterId=own?sim.State.heroId:"foreign",kind=StatusKind.Poisoned,remaining=3});
            var p=Shot();p.skill=6;p.position=sim.State.position;p.direction=Vector2.up;p.speed=30;p.remaining=10;p.radius=.3f;p.maxHits=5;p.explosionRadius=0;p.extra=extra;p.coefficient=1;sim.State.projectiles.Add(p);
            Advance(sim,2);Assert.AreEqual(applies,e.setPoisonTime>0);Assert.AreEqual(applies?1:0,sim.State.effectEvents.Count(x=>x.definitionId=="SA4"&&x.kind=="CREATED"));
            Advance(sim,60);Assert.IsFalse(CombatEffects.OwnTrapPoison(e,sim.State.heroId));Assert.AreEqual(applies?3:0,sim.State.damageEvents.Count(d=>d.definitionId=="SA4"));
        }
        [TestCase(HeroClass.Mage,"SM","LM01")][TestCase(HeroClass.Ranger,"SA",null)]
        public void PendingAreaStatePausesAndRestoresWithIdenticalSubsequentEvents(HeroClass hero,string set,string legendary)
        {
            var sim=Fixture(hero,set,legendary);var e=sim.State.enemies[0];
            if(hero==HeroClass.Mage){Field(sim);Advance(sim,27);}else{Call(sim,"ApplySetPoison",e,Shot());Advance(sim,7);Call(sim,"ApplySetPoison",e,Shot(90,150));}
            sim.State.paused=true;string paused=JsonUtility.ToJson(sim.State);Advance(sim,40);Assert.AreEqual(paused,JsonUtility.ToJson(sim.State));sim.State.paused=false;var restored=Restore(sim);
            for(int i=0;i<100;i++){sim.Tick(.05f);restored.Tick(.05f);Assert.AreEqual(JsonUtility.ToJson(sim.State),JsonUtility.ToJson(restored.State),"tick "+i);}
        }
        [Test]
        public void OlderAreaOwnershipAndStatusIdsMigrateOnceWithoutReplayingEffects()
        {
            var sim=Fixture();var e=sim.State.enemies[0];var field=Field(sim);field.casterId=null;e.frostMarkTime=2;e.setPoisonTime=1;e.setPoisonSnapshot=Snapshot();
            e.statuses.Add(new StatusEffect{id=100,definitionId="M02",rootCastId=field.rootCastId,casterId=sim.State.heroId,kind=StatusKind.Slow,remaining=2,strength=.35f});sim.State.effectVersion=3;
            GameStore.NormalizeRun(sim.State);Assert.AreEqual(sim.State.heroId,e.frostCasterId);Assert.AreEqual(sim.State.heroId,e.setPoisonCasterId);Assert.AreEqual(field.id,e.statuses[0].areaId);Assert.Greater(e.frostMarkId,0);
            string once=JsonUtility.ToJson(sim.State);GameStore.NormalizeRun(sim.State);Assert.AreEqual(once,JsonUtility.ToJson(sim.State));Assert.IsEmpty(sim.State.effectEvents);Assert.IsEmpty(sim.State.damageEvents);
        }
    }
}
