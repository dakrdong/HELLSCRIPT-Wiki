using System;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class PassiveTests
    {
        GameCatalog catalog;
        [SetUp]public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown]public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        static object Call(CombatSimulation sim,string name,params object[] args)
        {
            var m=typeof(CombatSimulation).GetMethod(name,BindingFlags.Instance|BindingFlags.NonPublic);var p=m.GetParameters();var full=new object[p.Length];
            for(int i=0;i<p.Length;i++)full[i]=i<args.Length?args[i]:p[i].DefaultValue;return m.Invoke(sim,full);
        }
        static void Control(CombatSimulation s)
        {s.Stats.hp=1000;s.Stats.damage=100;s.Stats.armor=s.Stats.resistance=s.Stats.regen=s.Stats.crit=s.Stats.costReduction=0;s.Stats.healing=s.Stats.shieldMultiplier=s.Stats.attackSpeed=1;Array.Clear(s.Stats.bonuses,0,24);}
        CombatSimulation Fixture(HeroClass hero,int[] passives,string[] gear=null,bool controlled=true)
        {
            var a=GameStore.NewAccount();a.selectedHero=(int)hero;var h=a.Hero;h.level=30;h.inventory.Clear();h.build=GameCatalog.Preset(hero,0);h.build.passives=passives;
            h.build.rules.Clear();h.build.activeSkills=(hero==HeroClass.Warrior?new[]{0,1,2,4}:hero==HeroClass.Ranger?new[]{6,8,9,11}:new[]{12,13,14,16}).ToList();h.build.movement=MovementMode.Stand;h.build.potionThreshold=0;uint rng=55701;
            for(int slot=0;slot<8;slot++)
            {string id=gear?[slot];var item=ItemGenerator.Create(hero,slot,id==null?2:3,30,ref rng,uniqueId:id);h.inventory.Add(item);Assert.IsTrue(Economy.Equip(h,item),id??"rare slot "+slot);}
            Assert.AreEqual(8,h.inventory.Count(i=>i.equipped));Assert.AreEqual(8,h.inventory.Where(i=>i.equipped).Select(i=>i.slot).Distinct().Count());Assert.IsEmpty(BehaviorRules.Validate(h.build,hero));
            var sim=new CombatSimulation(a,catalog,1,1,seed:57);sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();sim.State.decisionTime=10000;
            if(controlled)Control(sim);sim.State.health=sim.Stats.hp;sim.State.resource=100;Enemy(sim,900,Vector2.up*2);return sim;
        }
        static EnemyState Enemy(CombatSimulation s,int id,Vector2 offset,float hp=100000)
        {var e=new EnemyState{id=id,position=s.State.position+offset,health=hp,maxHealth=hp,cooldown=1000,speed=0,attack=0};s.State.enemies.Add(e);return e;}
        static void Advance(CombatSimulation s,int ticks){for(int n=0;n<ticks;n++)s.Tick(.05f);}
        static DamageSnapshot Snap(CombatSimulation s)=>(DamageSnapshot)Call(s,"CaptureDamage");
        static DamageEvent Hit(CombatSimulation s,EnemyState e,int element=0,float coefficient=1,DamageSnapshot snapshot=null,bool crit=false,DamageKind kind=DamageKind.Direct)
            =>(DamageEvent)Call(s,"Hit",e,coefficient,element,false,0f,snapshot,crit,false,"PASSIVE_TEST",70,71,kind);
        static void Start(CombatSimulation s,int skill,Vector2? destination=null)
        {var target=s.State.enemies.First(e=>!e.dead);s.State.targetId=target.id;Call(s,"StartHeroAction",skill,target,destination??target.position,0f,0,false);}
        CombatSimulation Restore(CombatSimulation s)
        {
            var a=GameStore.NewAccount();a.selectedHero=(int)s.Hero.heroClass;a.heroes[a.selectedHero]=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(s.Hero));
            var run=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(s.State));GameStore.NormalizeRun(run);var copy=new CombatSimulation(a,catalog,1,1,run);Control(copy);return copy;
        }
        [TestCase(2,3f,0f)][TestCase(3,3f,.15f)][TestCase(3,3.01f,0f)]
        public void CrowdCountsLivingEnemiesAtInclusiveThreeMetres(int count,float thirdDistance,float bonus)
        {
            var s=Fixture(HeroClass.Warrior,new[]{0});Enemy(s,901,Vector2.right*2);if(count==3)Enemy(s,902,Vector2.down*thirdDistance);
            Enemy(s,999,Vector2.zero).dead=true;Assert.AreEqual(bonus,Hit(s,s.State.enemies[0]).additive,.0001f);
        }
        [TestCase(false)][TestCase(true)]
        public void SimultaneousAreaKeepsCrowdBonusAfterFirstVictimDies(bool crush)
        {
            var s=Fixture(HeroClass.Warrior,new[]{0});s.State.enemies[0].health=1;Enemy(s,901,new Vector2(.4f,2));Enemy(s,902,new Vector2(-.4f,2));
            if(crush)Call(s,"ResolveSkill",new HeroActionState{id=30,skill=2,origin=s.State.position,aim=s.State.position+Vector2.up*3});
            else Call(s,"AreaHit",s.State.position,3f,1f,0);
            Assert.AreEqual(3,s.State.damageEvents.Count);Assert.IsTrue(s.State.damageEvents.All(d=>Mathf.Abs(d.additive-.15f)<.0001f));
        }
        [Test]
        public void WhirlwindDiscountStartsOnTheTwoSecondPaidTickAndResetsAfterInterrupt()
        {
            var s=Fixture(HeroClass.Warrior,new[]{1});Start(s,0);Advance(s,35);float before=s.State.resource;Advance(s,5);
            Assert.AreEqual(catalog.skills[0].cost*.8f,before-s.State.resource,.0001f);
            Call(s,"InterruptHeroAction","test stop");Start(s,0);before=s.State.resource;Advance(s,5);Assert.AreEqual(catalog.skills[0].cost,before-s.State.resource,.0001f);
        }
        [TestCase(HeroClass.Warrior,2,1,"WP03")][TestCase(HeroClass.Ranger,1,9,"AP02")]
        public void LandingBuffExistsOnlyAfterRealTravelAndExpiresAtTwoSeconds(HeroClass hero,int passive,int skill,string id)
        {
            var s=Fixture(hero,new[]{passive});Start(s,skill,s.State.position+Vector2.right*3);
            for(int n=0;n<100&&!s.State.effectEvents.Any(e=>e.definitionId==id&&e.kind=="BUFF");n++)
            {Assert.AreEqual(0,hero==HeroClass.Warrior?s.State.itemEffects.leapDefense:s.State.itemEffects.moveBuff);s.Tick(.05f);}
            Assert.AreEqual(2,hero==HeroClass.Warrior?s.State.itemEffects.leapDefense:s.State.itemEffects.moveBuff);
            Advance(s,39);Assert.Greater(hero==HeroClass.Warrior?s.BuffDamageReduction:s.MovementSpeed(false)-s.Stats.speed,0);Advance(s,1);
            Assert.AreEqual(0,hero==HeroClass.Warrior?s.State.itemEffects.leapDefense:s.State.itemEffects.moveBuff);Assert.AreEqual(1,s.State.effectEvents.Count(e=>e.definitionId==id&&e.kind=="EXPIRED"));
        }
        [TestCase(HeroClass.Warrior,2,1)][TestCase(HeroClass.Ranger,1,9)]
        public void InterruptedTravelPreparationCannotGrantLandingBuff(HeroClass hero,int passive,int skill)
        {
            var s=Fixture(hero,new[]{passive});Start(s,skill,s.State.position+Vector2.right*3);Call(s,"InterruptHeroAction","cancel preparation");Advance(s,30);
            Assert.AreEqual(0,s.State.itemEffects.leapDefense);Assert.AreEqual(0,s.State.itemEffects.moveBuff);
        }
        [TestCase(0f)][TestCase(128f)][TestCase(256f)]
        public void KillHealingUsesOneSecondTicksAtLateCombatTimes(float start)
        {
            var s=Fixture(HeroClass.Warrior,new[]{3});s.State.time=start;s.State.health=500;
            Action<int> kill=id=>{var e=Enemy(s,id,Vector2.zero,1);e.add=true;Hit(s,e);Call(s,"ResolveCombatDeaths");};
            kill(950);Assert.AreEqual(520,s.State.health);Advance(s,19);kill(951);Assert.AreEqual(520,s.State.health);Advance(s,1);kill(952);Assert.AreEqual(540,s.State.health);
            s.State.health=995;Advance(s,20);kill(953);Assert.AreEqual(1000,s.State.health);Assert.AreEqual(5,s.State.effectEvents.Last(e=>e.definitionId=="WP04").value);
        }
        [TestCase(HeroClass.Warrior,5,.3f,.2f)][TestCase(HeroClass.Warrior,5,.3001f,0f)]
        [TestCase(HeroClass.Ranger,0,7f,.15f)][TestCase(HeroClass.Ranger,0,6.999f,0f)]
        public void ExecuteAndRangeBonusesCheckTheImpactBoundary(HeroClass hero,int passive,float value,float expected)
        {
            var s=Fixture(hero,new[]{passive});var e=s.State.enemies[0];var shot=Snap(s);
            if(hero==HeroClass.Warrior)e.health=e.maxHealth*value;else e.position=s.State.position+Vector2.up*value;
            string boundary=$"HP={e.health:R}, max={e.maxHealth:R}, ratio={e.health/e.maxHealth:R}, threshold={e.maxHealth*.3f:R}, passive={shot.passives[passive]}";
            Assert.AreEqual(expected,Hit(s,e,snapshot:shot).additive,.0001f,boundary);
        }
        [TestCase(.3f,true)][TestCase(.3001f,false)]
        public void ExecuteCritUsesInclusiveHpThresholdAndRespectsSeventyFivePercentCap(float ratio,bool low)
        {
            var s=Fixture(HeroClass.Ranger,new[]{5});var e=s.State.enemies[0];e.health=e.maxHealth*ratio;s.Stats.crit=.7f;var snap=Snap(s);uint seed=1;
            for(;seed<100000;seed++){uint probe=seed;float roll=RandomStream.Unit(ref probe);if(roll>.71f&&roll<.74f)break;}
            s.State.rng=seed;Assert.AreEqual(low,Hit(s,e,snapshot:snap,crit:true).critical);
            for(seed=1;seed<100000;seed++){uint probe=seed;float roll=RandomStream.Unit(ref probe);if(roll>.76f&&roll<.79f)break;}
            e.health=e.maxHealth*.3f;s.State.rng=seed;Assert.IsFalse(Hit(s,e,snapshot:snap,crit:true).critical);
            uint before=s.State.rng;Hit(s,e,kind:DamageKind.Periodic);Assert.AreEqual(before,s.State.rng);
        }
        [TestCase(2,0f)][TestCase(3,.15f)]
        public void FireballCountsImpactVictimsOnceAndDoesNotGiveTheEchoItsDirectBonus(int count,float bonus)
        {
            var gear=new string[8];gear[3]="LM02";var s=Fixture(HeroClass.Mage,new[]{0},gear);var e=s.State.enemies[0];e.health=1;
            for(int n=1;n<count;n++)Enemy(s,900+n,new Vector2(n*.4f,2));
            Call(s,"FireballImpact",new CombatProjectile{id=80,actionId=81,skill=12,position=e.position,explosionRadius=2.5f,coefficient=2.1f,snapshot=Snap(s)});
            Assert.AreEqual(count,s.State.damageEvents.Count);Assert.IsTrue(s.State.damageEvents.All(d=>Mathf.Abs(d.additive-bonus)<.0001f));Advance(s,8);
            Assert.IsTrue(s.State.damageEvents.Any(d=>d.definitionId=="LM02"));Assert.IsTrue(s.State.damageEvents.Where(d=>d.definitionId=="LM02").All(d=>d.additive==0));
        }
        [TestCase(HeroClass.Warrior,4)][TestCase(HeroClass.Mage,3)]
        public void ShieldPassiveAddsTwentyPointsToLegalGearWillScaling(HeroClass hero,int passive)
        {
            var s=Fixture(hero,new[]{passive},controlled:false);float active=s.Stats.shieldMultiplier;var copy=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(s.Hero));copy.build.passives=Array.Empty<int>();var plain=new HeroStats(copy);
            Assert.AreEqual(.2f,active-plain.shieldMultiplier,.0001f);Call(s,"AddShield",hero==HeroClass.Warrior?"W05":"M05",100f,4f,33);Assert.AreEqual(100*active,s.State.shield,.001f);
        }
        [Test]
        public void ManaPassiveMultipliesFlatGearRegenerationAndFreezesWithCombat()
        {
            var s=Fixture(HeroClass.Mage,new[]{4},controlled:false);var copy=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(s.Hero));copy.build.passives=Array.Empty<int>();var plain=new HeroStats(copy);
            Assert.AreEqual(plain.regen*1.2f,s.Stats.regen,.0001f);s.State.resource=0;Advance(s,20);Assert.AreEqual(s.Stats.regen,s.State.resource,.001f);
            s.State.paused=true;Advance(s,20);Assert.AreEqual(s.Stats.regen,s.State.resource,.001f);s.State.paused=false;s.State.portal=true;Advance(s,20);Assert.AreEqual(s.Stats.regen,s.State.resource,.001f);
            s.State.portal=false;s.State.resource=99.9f;s.Tick(.05f);Assert.AreEqual(100,s.State.resource);
        }
        [Test]
        public void LegalWhirlwindGearCombinesPassiveSetAffixesAndOneUseDiscountWithoutExceedingCap()
        {
            var s=Fixture(HeroClass.Warrior,new[]{0,1,2},new[]{"LW01","SW1","SW2","LW03","LW02",null,"LC02","LC01"},false);
            Assert.AreEqual(2,s.Stats.SetPieces("SW"));Assert.IsTrue(s.Stats.specials.Contains("LC02"));s.State.channelTime=2;
            Assert.AreEqual(catalog.skills[0].cost*(1-Mathf.Min(.5f,s.Stats.costReduction+.15f+.2f)),(float)Call(s,"Cost",catalog.skills[0]),.0001f);
            s.State.itemEffects.reducedNext=true;s.State.itemEffects.lc02Charge=5;Assert.AreEqual(catalog.skills[0].cost*.5f,(float)Call(s,"Cost",catalog.skills[0]),.0001f);
        }
        [Test]
        public void LegalPierceGearAddsTwoVictimsAndCapsLegendBonusOnTheFifthVictim()
        {
            var s=Fixture(HeroClass.Ranger,new[]{2,3,4},new[]{"LA01","SA1","SA2","SA3","SA4","LC03","LA04","LC01"});s.State.enemies.Clear();
            for(int n=0;n<8;n++)Enemy(s,900+n,Vector2.up*(1+n));var a=new HeroActionState{id=40,skill=6,origin=s.State.position,aim=s.State.position+Vector2.up*10,snapshot=Snap(s)};
            Call(s,"LaunchPierce",a);Advance(s,14);var hits=s.State.damageEvents.Where(d=>d.definitionId=="A01").ToArray();Assert.AreEqual(7,hits.Length);
            for(int n=0;n<hits.Length;n++){Assert.AreEqual(900+n,hits[n].targetId);Assert.AreEqual(Mathf.Min(.6f,n*.15f),hits[n].additive,.0001f);}
            Assert.AreEqual(4,s.Stats.SetPieces("SA"));
        }
        [Test]
        public void LegalNovaSetAndChainPassiveRetainTotalHitsWithCircuitRevisits()
        {
            var s=Fixture(HeroClass.Mage,new[]{2,3,4},new[]{"LM01","SMB1","SMB2","SMB3","SMB4","LM03","LM04","LC01"});s.State.build.activeSkills=new[]{14,15,16,17}.ToList();
            Enemy(s,901,new Vector2(1,2));Enemy(s,902,new Vector2(-1,2));Enemy(s,903,new Vector2(0,1));
            Call(s,"ResolveSkill",new HeroActionState{id=40,skill=17,origin=s.State.position,snapshot=Snap(s)});Assert.AreEqual(2,s.State.itemEffects.chainCharges);
            Start(s,14);Advance(s,20);var hits=s.State.damageEvents.Where(d=>d.definitionId=="M03").ToArray();Assert.AreEqual(7,hits.Length);Assert.AreEqual(1,s.State.itemEffects.chainCharges);
            Assert.IsTrue(hits.GroupBy(d=>d.targetId).All(g=>g.Count()<=2));for(int n=1;n<hits.Length;n++)Assert.AreNotEqual(hits[n-1].targetId,hits[n].targetId);
        }
        [TestCase(0f)][TestCase(128f)][TestCase(256f)]
        public void ElementCrossUsesTheInclusiveFourSecondHistoryAndRefreshesWithoutStacking(float start)
        {
            var s=Fixture(HeroClass.Mage,new[]{5});var e=s.State.enemies[0];s.State.time=start;Hit(s,e,1);Assert.AreEqual(0,s.State.itemEffects.elementBuff);
            Advance(s,80);var trigger=Hit(s,e,2);Assert.AreEqual(0,trigger.additive);Assert.AreEqual(4,s.State.itemEffects.elementBuff);
            var buffed=Hit(s,e,2);Assert.AreEqual(.1f,buffed.additive,.0001f);Assert.AreEqual(4,s.State.itemEffects.elementBuff);
            Advance(s,1);Hit(s,e,2);Assert.Less(s.State.itemEffects.elementBuff,4,"The older fire hit is now outside the window.");
            Advance(s,79);Assert.AreEqual(0,s.State.itemEffects.elementBuff);Assert.AreEqual(1,s.State.effectEvents.Count(x=>x.definitionId=="MP06"&&x.kind=="EXPIRED"));
        }
        [Test]
        public void ElementHistoryKeepsDifferentRecentHitsAcrossSameElementStreaksAndIgnoresZeroDamage()
        {
            var s=Fixture(HeroClass.Mage,new[]{5});var e=s.State.enemies[0];Hit(s,e,1);Hit(s,e,2,0);Assert.AreEqual(0,s.State.itemEffects.elementBuff);
            Advance(s,20);Hit(s,e,3);Advance(s,20);Hit(s,e,3);Assert.AreEqual(4,s.State.itemEffects.elementBuff);Assert.AreEqual(.1f,Hit(s,e,3).additive,.0001f);
            Advance(s,61);Hit(s,e,3);Assert.Less(s.State.itemEffects.elementBuff,4);Assert.AreEqual(1,s.State.effectEvents.Count(x=>x.definitionId=="MP06"&&x.kind=="BUFF"));
        }
        [Test]
        public void ExpiredElementBuffDoesNotAlterAnAlreadyCreatedAttackSnapshot()
        {
            var s=Fixture(HeroClass.Mage,new[]{5});var e=s.State.enemies[0];Hit(s,e,1);Hit(s,e,2);var shot=Snap(s);Advance(s,81);Assert.AreEqual(0,s.State.itemEffects.elementBuff);
            Assert.AreEqual(.1f,Hit(s,e,3,snapshot:shot).additive,.0001f);Assert.AreEqual(0,Hit(s,e,3).additive,.0001f);
        }
        [TestCase(HeroClass.Warrior,2,1)][TestCase(HeroClass.Ranger,1,9)][TestCase(HeroClass.Mage,5,12)]
        public void RemovingTrainingPassiveClearsHeroBuffButKeepsHpResourceAndSkillCooldowns(HeroClass hero,int passive,int skill)
        {
            var s=Fixture(hero,new[]{passive});if(hero==HeroClass.Mage){Hit(s,s.State.enemies[0],1);Hit(s,s.State.enemies[0],2);}else Call(s,"LandingPassives",new HeroActionState{skill=skill,id=30});
            var oldShot=Snap(s);s.State.cooldowns[skill]=7;s.State.health=500;s.State.resource=43;s.State.itemEffects.lastHeal=s.State.time;
            var b=s.State.build.Copy();b.passives=Array.Empty<int>();Assert.IsTrue(s.ApplyBuild(b));Assert.AreEqual(500,s.State.health);Assert.AreEqual(43,s.State.resource);Assert.AreEqual(7,s.State.cooldowns[skill]);
            Assert.AreEqual(0,s.State.itemEffects.leapDefense+s.State.itemEffects.moveBuff+s.State.itemEffects.elementBuff);Assert.AreEqual(0,s.State.itemEffects.lastHeal);
            if(hero==HeroClass.Mage){Hit(s,s.State.enemies[0],3,snapshot:oldShot);Assert.AreEqual(0,s.State.itemEffects.elementBuff);Assert.IsTrue(s.State.itemEffects.elementHitTicks.All(t=>t<0));}
        }
        [TestCase(HeroClass.Warrior,2,1)][TestCase(HeroClass.Ranger,1,9)][TestCase(HeroClass.Mage,5,12)]
        public void PassiveTimersAndElementJournalHaveIdenticalFutureAfterJsonRestore(HeroClass hero,int passive,int skill)
        {
            var s=Fixture(hero,new[]{passive});if(hero==HeroClass.Mage){Hit(s,s.State.enemies[0],1);Advance(s,20);Hit(s,s.State.enemies[0],2);}else Call(s,"LandingPassives",new HeroActionState{id=31,skill=skill});
            Advance(s,17);var restored=Restore(s);
            for(int n=0;n<90;n++){s.Tick(.05f);restored.Tick(.05f);Assert.AreEqual(JsonUtility.ToJson(s.State),JsonUtility.ToJson(restored.State),"tick "+n);}
            s.State.paused=true;string before=JsonUtility.ToJson(s.State);Advance(s,20);Assert.AreEqual(before,JsonUtility.ToJson(s.State));
        }
        [Test]
        public void LegacyElementMigrationKeepsOnlyKnownHistoryAndPreservesRemainingBuffIdempotently()
        {
            var s=Fixture(HeroClass.Mage,new[]{5});s.State.effectVersion=4;s.State.time=20;s.State.itemEffects.lastElement=2;s.State.itemEffects.lastElementTime=18;s.State.itemEffects.elementBuff=1.25f;s.State.itemEffects.elementHitTicks=null;
            GameStore.NormalizeRun(s.State);Assert.AreEqual(360,s.State.itemEffects.elementHitTicks[2]);Assert.AreEqual(1,s.State.itemEffects.elementHitTicks.Count(t=>t>=0));Assert.AreEqual(1.25f,s.State.itemEffects.elementBuff);
            string before=JsonUtility.ToJson(s.State);GameStore.NormalizeRun(s.State);Assert.AreEqual(before,JsonUtility.ToJson(s.State));Assert.AreEqual(5,s.State.effectVersion);
        }
        [Test]
        public void BlizzardRetainsItsCreationSlowAfterPassiveRemovalAndUsesOnlyStrongestCappedSlow()
        {
            var s=Fixture(HeroClass.Mage,new[]{1});var e=s.State.enemies[0];Call(s,"AddGround",e.position,3f,0f,6f,65f,false,13);Advance(s,1);
            Assert.AreEqual(.55f,(float)Call(s,"SlowRatio",e),.0001f);var b=s.State.build.Copy();b.passives=Array.Empty<int>();Assert.IsTrue(s.ApplyBuild(b));Advance(s,1);
            Assert.AreEqual(.55f,(float)Call(s,"SlowRatio",e),.0001f);Call(s,"ApplyStatus",e,StatusKind.Slow,"TEST_STRONG",.1f,72,.99f);Assert.AreEqual(.8f,(float)Call(s,"SlowRatio",e));
            Advance(s,2);Assert.AreEqual(.55f,(float)Call(s,"SlowRatio",e),.0001f);
        }
        [TestCase(false,1.5f)][TestCase(true,1.875f)]
        public void LegalRetreatTrapAndTwoPieceSetKeepPassiveRootSeparateFromTrapDuration(bool passive,float expectedRoot)
        {
            var s=Fixture(HeroClass.Ranger,passive?new[]{3}:Array.Empty<int>(),new[]{"LA01","SA1","SA2","LA02","LA03","LC03","LA04","LC01"});
            var trap=(CombatTrap)Call(s,"CreateTrap",new HeroActionState{id=52,skill=9,snapshot=Snap(s)},s.State.enemies[0].position,3f);Advance(s,10);
            Assert.AreEqual("LA03",trap.definitionId);Assert.AreEqual(3.5f,trap.radius);Assert.AreEqual(3,trap.duration);Assert.AreEqual(3,trap.remaining);Assert.AreEqual(expectedRoot,s.State.enemies[0].statuses.Single(x=>x.kind==StatusKind.Root).remaining,.0001f);
        }
        [Test]
        public void EveryPassiveHasAPlayerDescriptionAndNoClassCanEquipFour()
        {
            Assert.AreEqual(18,GameCatalog.PassiveDescriptions.Length);Assert.AreEqual(18,GameCatalog.Passives.Length);Assert.IsTrue(GameCatalog.PassiveDescriptions.All(s=>!string.IsNullOrWhiteSpace(s)));
            foreach(HeroClass c in Enum.GetValues(typeof(HeroClass))){var b=GameCatalog.Preset(c,0);b.passives=new[]{0,1,2,3};Assert.IsNotEmpty(BehaviorRules.Validate(b,c));}
        }
    }
}
