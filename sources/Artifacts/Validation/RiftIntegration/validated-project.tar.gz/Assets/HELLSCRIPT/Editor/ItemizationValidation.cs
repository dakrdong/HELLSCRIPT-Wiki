using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Hellscript.Editor
{
    public static class ItemizationValidation
    {
        // Read-only content sampling. Artifacts are reports; no project assets or player saves are mutated.
        public static void Distribution()
        {
            const int count=100000;uint rng=820260908;var watch=Stopwatch.StartNew();
            var report=new StringBuilder("class,slot,rarity,samples,prefix0,prefix1,prefix2,prefix3,tier1,tier2,tier3\n");
            for(int c=0;c<3;c++)for(int slot=0;slot<8;slot++)for(int rarity=0;rarity<4;rarity++)
            {
                var prefixes=new int[4];var tiers=new int[3];int magicOne=0,primaryTotal=0,preferredPrimary=0,elementTotal=0,preferredElement=0;
                var uniqueCounts=new Dictionary<string,int>();
                for(int n=0;n<count;n++)
                {
                    var item=ItemGenerator.Create((HeroClass)c,slot,rarity,30,ref rng,"sample");
                    if(item.rolls.Count!=(rarity==0?0:rarity==1?item.rolls.Count:rarity==2?3:4)||rarity==1&&(item.rolls.Count<1||item.rolls.Count>2))throw new InvalidOperationException("Option count");
                    prefixes[item.rolls.Count(r=>r.side==AffixSide.Prefix)]++;if(rarity==1&&item.rolls.Count==1)magicOne++;
                    foreach(var roll in item.rolls)
                    {
                        tiers[int.Parse(roll.tierId.Substring(1))-1]++;var def=ItemCatalog.Affix(roll.affixId);
                        if(def.group=="PrimaryAttribute"){primaryTotal++;if(def.stat==10+c)preferredPrimary++;}
                        if(def.group=="DamageElement"){elementTotal++;if(def.Weight((HeroClass)c)==def.weight*3)preferredElement++;}
                    }
                    if(rarity==3)uniqueCounts[item.special]=uniqueCounts.TryGetValue(item.special,out int v)?v+1:1;
                }
                Check(tiers[0],tiers.Sum(),.15);Check(tiers[1],tiers.Sum(),.4);Check(tiers[2],tiers.Sum(),.45);
                Check(preferredPrimary,primaryTotal,slot>=6?300d/540:.6);Check(preferredElement,elementTotal,c==0?.375:.75);
                if(rarity==1){Check(magicOne,count,.5);Check(prefixes[0],count,.25);}
                if(rarity==2){Check(prefixes[1],count,.5);Check(prefixes[2],count,.5);}
                if(rarity==3)
                {
                    bool twoGroups=slot==0||slot==4;Check(prefixes[1],count,twoGroups?.25:.2);Check(prefixes[2],count,twoGroups?.75:.6);Check(prefixes[3],count,twoGroups?0:.2);
                    var pool=ItemCatalog.Uniques.Where(u=>u.Fits((HeroClass)c,slot)).ToArray();int total=pool.Sum(u=>u.weight);
                    foreach(var u in pool)Check(uniqueCounts.TryGetValue(u.id,out int v)?v:0,count,(double)u.weight/total);
                }
                report.AppendLine($"{c},{slot},{rarity},{count},{string.Join(",",prefixes)},{string.Join(",",tiers)}");
                Directory.CreateDirectory("Artifacts/Validation");File.WriteAllText("Artifacts/Validation/itemization-distribution.csv",report.ToString());
                UnityEngine.Debug.Log($"ITEM_DISTRIBUTION {c}/{slot}/{rarity} passed; elapsed={watch.Elapsed.TotalSeconds:0.0}s");
            }
            File.WriteAllText("Artifacts/Validation/itemization-distribution-summary.txt",$"PASS: 96 combinations x {count:N0} = {96L*count:N0} items.\nSeed=820260908; item level=30; contentVersion={ItemCatalog.Version}\nChecked exact option count, side/group/slot validity, tier weights, class-conditioned attribute/element weights, magic count, normalized allocation weights, every compatible unique weight.\nEach frequency tolerance = 6 standard deviations + 2 observations.\nElapsed seconds={watch.Elapsed.TotalSeconds:0.00}\n");
        }
        static void Check(int actual,int total,double probability)
        {
            if(total==0)return;double mean=total*probability,tolerance=6*Math.Sqrt(total*probability*(1-probability))+2;
            if(Math.Abs(actual-mean)>tolerance)throw new InvalidOperationException($"Frequency {actual}/{total} outside p={probability} tolerance {tolerance}");
        }
    }
}
