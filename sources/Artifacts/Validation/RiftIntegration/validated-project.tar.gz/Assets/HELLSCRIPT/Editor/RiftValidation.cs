using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using UnityEngine;
using Debug=UnityEngine.Debug;

namespace Hellscript.Editor
{
    public static class RiftValidation
    {
        // Read-only generation audit. No scene, prefab, importer or user save is modified.
        public static void SampleObjectiveChains()
        {
            string directory="Artifacts/Validation/ObjectiveChains";Directory.CreateDirectory(directory);
            var clock=Stopwatch.StartNew();var counts=new int[4];int fallback=0,retried=0;string previous="";int boss=-1;
            using(var csv=new StreamWriter(Path.Combine(directory,"objective-seeds.csv")))
            {
                csv.WriteLine("seed,stage,theme,rooms,objective,points,path_meter,candidate,fallback,fingerprint");
                for(uint n=1;n<=10000;n++)
                {
                    uint seed=1209000+n;int stage=5+(int)(n%26);
                    var map=RiftGenerator.Generate(seed,"objective-audit-"+n,stage,(HeroClass)(n%3),previous,boss);
                    if(map.objective!=RiftObjectives.Select(seed,stage)||map.version!=4)throw new InvalidOperationException("Objective draw changed: "+seed);
                    RiftGenerator.Validate(map);var nav=new RiftNavigation(map);
                    if(nav.Reachable(map.bossPoints[0]))throw new InvalidOperationException("Closed arena reachable: "+seed);
                    var rooms=map.objective==RiftObjectiveKind.Seals?map.seals.Select(p=>p.room):map.objective==RiftObjectiveKind.EssenceCarriers?map.carriers.Select(p=>p.room):map.offerings.Select(p=>p.room);
                    int ante=map.rooms.Single(r=>r.role==RiftRoomRole.Antechamber).index,path=rooms.Concat(new[]{ante}).Distinct().Sum(r=>RiftObjectives.Meter(map,r));
                    if(map.objective==RiftObjectiveKind.Offerings&&(nav.Walkable(map.altar.position)||map.altar.accessPoints.Any(p=>!nav.Reachable(p))))throw new InvalidOperationException("Altar body/access: "+seed);
                    counts[(int)map.objective]++;if(map.fallbackId!="")fallback++;if(map.candidate>0)retried++;
                    csv.WriteLine($"{seed},{stage},{map.theme},{map.rooms.Count},{map.objective},{RiftObjectives.Total(map)},{path},{map.candidate},{map.fallbackId},{map.fingerprint}");
                    previous=map.fingerprint;boss=map.bossKind;
                    if(n%250==0){csv.Flush();Debug.Log($"OBJECTIVE_SAMPLE {n}/10000 seconds={clock.Elapsed.TotalSeconds:F1}");}
                }
            }
            for(int i=1;i<=3;i++)if(Math.Abs(counts[i]-10000d/3)>6*Math.Sqrt(10000d*2/9))throw new InvalidOperationException("Objective frequency outside six-sigma envelope.");
            File.WriteAllText(Path.Combine(directory,"objective-seeds-summary.txt"),$"PASS: 10000 generated version 4 maps; closed/open geometry and objective placement valid.\nseals={counts[1]}\ncarriers={counts[2]}\nofferings={counts[3]}\nfallback={fallback}\nretried={retried}\nseconds={clock.Elapsed.TotalSeconds:F2}\n");
            Debug.Log("OBJECTIVE_10000_PASS");
        }
        public static void SampleFieldContent()
        {
            Directory.CreateDirectory("Artifacts/Validation");var clock=Stopwatch.StartNew();int fallback=0,retried=0,shrines=0,curses=0,eligible=0;string previous="";int lastBoss=-1;
            using(var csv=new StreamWriter("Artifacts/Validation/field-seeds.csv"))
            {
                csv.WriteLine("seed,stage,theme,rooms,extra_edges,candidate,fallback,fingerprint,chests,boss,shrine,event,echo_candidates,gold,materials,items");
                for(uint n=1;n<=10000;n++)
                {
                    int stage=1+(int)(n%30);var map=RiftGenerator.Generate(908000+n,"field-validation-"+n,stage,(HeroClass)(n%3),previous,lastBoss);var nav=new RiftNavigation(map,gatesOpen:true);
                    if(map.version!=RiftLayout.CurrentVersion||map.spawns.Any(s=>!nav.Reachable(s.position)))throw new InvalidOperationException("Field manifest: "+n);
                    foreach(var chest in map.chests)if(nav.Walkable(chest.position)||chest.accessPoints.Count<2||chest.accessPoints.Any(p=>!nav.Reachable(p)))throw new InvalidOperationException("Chest body/access: "+n);
                    foreach(var shrine in map.shrines)if(shrine.room==0||map.rooms[shrine.room].boss||nav.Walkable(shrine.position)||shrine.accessPoints.Count<2||shrine.accessPoints.Any(p=>!nav.Reachable(p)))throw new InvalidOperationException("Shrine body/access: "+n);
                    foreach(var evt in map.events)
                    {
                        var chest=map.chests.Single(c=>c.id==evt.chestId);
                        if(stage<5||chest.definitionId!="CH03"||map.rooms[chest.room].boss||evt.spawnCandidates.Count<4||evt.spawnCandidates.Any(p=>!nav.Reachable(p))||evt.enemyIds.Count!=0||chest.reward==null)throw new InvalidOperationException("Cursed field event: "+n);
                    }
                    int gold=map.chests.Sum(c=>c.gold),materials=map.chests.Sum(c=>c.materials),items=map.chests.Count(c=>c.reward!=null);
                    if(gold!=Mathf.FloorToInt(.15f*(800+50*stage))||materials!=Mathf.Max(1,Mathf.FloorToInt(.2f*(5+stage/5)))||items!=2||map.shrines.Count>1||map.events.Count>1)throw new InvalidOperationException("Field reward/count budget: "+n);
                    if(map.fallbackId!="")fallback++;if(map.candidate>0)retried++;shrines+=map.shrines.Count;curses+=map.events.Count;if(stage>=5)eligible++;
                    csv.WriteLine($"{908000+n},{stage},{map.theme},{map.rooms.Count},{map.corridors.Count-map.rooms.Count},{map.candidate},{map.fallbackId},{map.fingerprint},{map.chests.Count},{map.bossKind},{map.shrines.FirstOrDefault()?.definitionId},{map.events.Count},{map.events.Sum(e=>e.spawnCandidates.Count)},{gold},{materials},{items}");
                    previous=map.fingerprint;lastBoss=map.bossKind;if(n%500==0){csv.Flush();Debug.Log($"FIELD_SAMPLE {n}/10000 seconds={clock.Elapsed.TotalSeconds:F1}");}
                }
            }
            if(Math.Abs(shrines-5000)>6*Math.Sqrt(2500)||Math.Abs(curses-eligible*.25)>6*Math.Sqrt(eligible*.25*.75))throw new InvalidOperationException("Field content frequency outside six-sigma envelope.");
            File.WriteAllText("Artifacts/Validation/field-seeds-summary.txt",$"PASS: 10000 version {RiftLayout.CurrentVersion} maps; all content reachable; gold/material/item budgets preserved.\nfallback={fallback}\nretried={retried}\nshrines={shrines}/10000\ncursed={curses}/{eligible} eligible\nseconds={clock.Elapsed.TotalSeconds:F2}\n");Debug.Log("FIELD_10000_PASS");
        }
        public static void TraceActions()=>TraceBuilds("Artifacts/Validation/ActionTraces");
        public static void TraceBuilds()=>TraceBuilds("Artifacts/Validation/RiftTraces");
        static void TraceBuilds(string directory)
        {
            Directory.CreateDirectory(directory);var catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();
            for(int hero=0;hero<3;hero++)for(int build=0;build<2;build++)
            {
                var a=GameStore.NewAccount();a.selectedHero=hero;a.Hero.level=30;a.Hero.build=GameCatalog.Preset((HeroClass)hero,build);a.Hero.capacity=100;
                var sim=new CombatSimulation(a,catalog,1,seed:(uint)(710+hero*2+build));var trace=new StringBuilder("time,kills,meter,visited,hp,position,goal,target,goal_id,path_length,action,repaths,target_distance,target_hp,shot_clear,phase,resource\n");
                for(int tick=0;tick<6001&&sim.State.phase!=RunPhase.Cleared&&sim.State.phase!=RunPhase.Failed;tick++)
                {
                    sim.Tick(.05f);if(sim.State.portal)sim.Abandon();
                    if(tick%100==0)
                    {var s=sim.State;var target=s.enemies.Find(e=>e.id==s.targetId&&!e.dead);trace.AppendLine($"{s.time:F2},{s.kills},{s.meter},{s.visited.Count},{s.health:F1},\"{s.position}\",\"{s.destination}\",{s.targetId},{s.exploration.goalId},{sim.Map.Length(s.position,s.destination):F2},{s.action},{s.exploration.repaths},{(target==null?-1:Vector2.Distance(s.position,target.position)):F2},{target?.health:F2},{(target==null||sim.Map.ProjectileClear(s.position,target.position,.3f))},{s.heroAction.phase},{s.resource:F2}");}
                }
                string file=$"{directory}/{hero}-{build}";File.WriteAllText(file+".csv",trace.ToString());File.WriteAllText(file+".json",JsonUtility.ToJson(sim.State,true));
                Debug.Log($"RIFT_TRACE {hero}-{build} {sim.State.phase} kills={sim.State.kills} time={sim.State.time}");
            }
            UnityEngine.Object.DestroyImmediate(catalog);
        }
        public static void SampleTenThousand()
        {
            Directory.CreateDirectory("Artifacts/Validation");var clock=Stopwatch.StartNew();int fallback=0,retried=0;string previous="";int lastBoss=-1;
            using(var csv=new StreamWriter("Artifacts/Validation/rift-seeds.csv"))
            {
                csv.WriteLine("seed,theme,rooms,extra_edges,candidate,fallback,fingerprint,groups,chests,boss,junctions");
                for(uint n=1;n<=10000;n++)
                {
                    var map=RiftGenerator.Generate(908000+n,"validation-"+n,1+(int)(n%30),(HeroClass)(n%3),previous,lastBoss);
                    var nav=new RiftNavigation(map,gatesOpen:true);
                    if(map.spawns.Any(s=>!nav.Reachable(s.position))||map.chests.Any(c=>c.accessPoints.Any(p=>!nav.Reachable(p))))throw new InvalidOperationException("Unreachable generated content: "+n);
                    if(map.chests.Sum(c=>c.gold)!=Mathf.FloorToInt(.15f*(800+50*(1+n%30))))throw new InvalidOperationException("Chest budget: "+n);
                    if(map.fallbackId!="")fallback++;if(map.candidate>0)retried++;
                    csv.WriteLine($"{908000+n},{map.theme},{map.rooms.Count},{map.corridors.Count-map.rooms.Count},{map.candidate},{map.fallbackId},{map.fingerprint},{map.groups.Count},{map.chests.Count},{map.bossKind},{map.junctions.Count}");
                    previous=map.fingerprint;lastBoss=map.bossKind;if(n%500==0){csv.Flush();Debug.Log($"RIFT_SAMPLE {n}/10000 seconds={clock.Elapsed.TotalSeconds:F1}");}
                }
            }
            File.WriteAllText("Artifacts/Validation/rift-seeds-summary.txt",$"PASS: 10000 generated maps\nfallback={fallback} ({fallback/100d:F4}%)\nretried={retried}\nseconds={clock.Elapsed.TotalSeconds:F2}\n");
            Debug.Log("RIFT_10000_PASS fallback="+fallback);
        }
    }
}
