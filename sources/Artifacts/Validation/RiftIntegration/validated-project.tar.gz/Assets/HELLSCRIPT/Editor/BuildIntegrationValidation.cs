using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace Hellscript.Editor
{
    public static class BuildIntegrationValidation
    {
        [Serializable]public sealed class Usage {public string id,name;public int starts,interruptions,hits,bossHits;public float damage,bossDamage;}
        [Serializable]public sealed class Entry
        {
            public string preset,hero,gear,result,map,navigationError,runId;
            public int stage,seed,kills,chests,visited,ticks,repaths;
            public float time,damage,hp,hpMaximum,resource,distance,meanTargetDistance,maxStationaryApproach,bossSpawnTime=-1,bossRemainingHp;
            public List<string> equipment=new List<string>();public List<Usage> usage=new List<Usage>();
        }
        [Serializable]public sealed class Report
        {public string scope="Read-only generated-rift comparison. Level 30, eight legal item-level 30 pieces, no combat overrides; not an Android or natural-growth balance claim.";public List<Entry> entries=new List<Entry>();}
        static readonly string[][] Sets={
            new[]{"LW01","SW1","SW2","SW3","SW4","LC03","LC02","LC01"},
            new[]{null,"SWB1","SWB2","SWB3","SWB4","LC03","LW04","LC01"},
            new[]{"LA01","SAB1","SAB2","SAB3","SAB4","LC03","LC02","LC01"},
            new[]{"LA01","SA1","SA2","SA3","SA4","LC03","LA04","LC01"},
            new[]{"LM01","SM1","SM2","SM3","SM4","LM03","LC02","LC01"},
            new[]{null,"SMB1","SMB2","SMB3","SMB4","LM03","LM04","LC01"}};
        [Serializable]
        public sealed class ArchetypeBalanceSummary
        {
            public string archetypeName;
            public string heroClass;
            public int tier;
            public int totalRuns;
            public int wins;
            public int defeats;
            public float winRate;
            public float avgClearTime;
            public float avgDps;
            public int totalResourceStarvations;
            public Dictionary<string,int> deathCauses = new Dictionary<string,int>();
        }

        public static List<ArchetypeBalanceSummary> RunMultiSeedBalanceSimulation(int seedCount = 30, int stage = 10)
        {
            var catalog = ScriptableObject.CreateInstance<GameCatalog>();
            catalog.Populate();
            var summaries = new List<ArchetypeBalanceSummary>();
            try
            {
                for (int c = 0; c < 3; c++)
                {
                    for (int variant = 0; variant < 2; variant++)
                    {
                        var summary = new ArchetypeBalanceSummary
                        {
                            heroClass = ((HeroClass)c).ToString(),
                            archetypeName = $"{((HeroClass)c)} Variant {variant+1}",
                            tier = stage,
                            totalRuns = seedCount
                        };
                        float totalTime = 0, totalDamage = 0;

                        for (int seedIndex = 0; seedIndex < seedCount; seedIndex++)
                        {
                            uint seed = (uint)(54321 + seedIndex * 1337 + c * 97 + variant * 31);
                            var account = GameStore.NewAccount();
                            account.selectedHero = c;
                            var hero = account.Hero;
                            hero.level = 30;
                            hero.capacity = 100;
                            hero.inventory.Clear();
                            hero.build = GameCatalog.Preset(hero.heroClass, variant);

                            uint gearRng = seed;
                            for (int slot = 0; slot < 8; slot++)
                            {
                                string uniqueId = Sets[c * 2 + variant][slot];
                                var item = ItemGenerator.Create(hero.heroClass, slot, uniqueId == null ? 2 : 3, 30, ref gearRng, uniqueId: uniqueId);
                                hero.inventory.Add(item);
                                Economy.Equip(hero, item);
                            }

                            var sim = new CombatSimulation(account, catalog, stage, seed: seed);
                            var run = sim.State;
                            int ticks = 0;

                            while (run.phase != RunPhase.Cleared && run.phase != RunPhase.Failed && ticks < 10000)
                            {
                                if (run.portal || !string.IsNullOrEmpty(run.navigationError)) break;
                                sim.Tick(CombatSimulation.Step);
                                ticks++;
                            }

                            if (run.phase == RunPhase.Cleared)
                            {
                                summary.wins++;
                                totalTime += run.time;
                                totalDamage += run.dealt;
                            }
                            else
                            {
                                summary.defeats++;
                                string cause = string.IsNullOrEmpty(run.navigationError) ? (run.phase == RunPhase.Failed ? "Defeat" : "Timeout") : "NavError";
                                summary.deathCauses[cause] = summary.deathCauses.TryGetValue(cause, out int cnt) ? cnt + 1 : 1;
                            }

                            if (run.statistics != null)
                            {
                                summary.totalResourceStarvations += run.statistics.resourceChecks;
                            }
                        }

                        summary.winRate = summary.totalRuns > 0 ? (float)summary.wins / summary.totalRuns * 100f : 0f;
                        summary.avgClearTime = summary.wins > 0 ? totalTime / summary.wins : 0f;
                        summary.avgDps = summary.wins > 0 ? totalDamage / Mathf.Max(1f, totalTime) : 0f;
                        summaries.Add(summary);

                        Debug.Log($"[BALANCE RUNNER] {summary.archetypeName} (T{stage}): WinRate={summary.winRate:0.0}% ({summary.wins}/{summary.totalRuns}), AvgTime={summary.avgClearTime:0.0}s, Starvations={summary.totalResourceStarvations}");
                    }
                }
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(catalog);
            }
            return summaries;
        }

        [Serializable] public sealed class BalanceDeathCause { public string cause; public int count; }
        [Serializable]
        public sealed class BalanceEntry
        {
            public string archetypeName,heroClass;
            public int tier,totalRuns,wins,defeats,totalResourceStarvations;
            // avgDps pools every winning run: total damage over total time, not the mean of per-run rates.
            public float winRate,avgClearTime,avgDps,totalClearSeconds,totalDealtDamage;
            public List<BalanceDeathCause> deathCauses=new List<BalanceDeathCause>();
        }
        [Serializable]
        public sealed class BalanceReport
        {
            public string scope="Level 30 heroes with item-level 30 gear on generated rifts. Seeds vary by class and variant only, so every tier replays the same layouts at a different difficulty. Not an Android, natural-growth or released-balance claim.";
            public int seedCount;public List<int> tiers=new List<int>();public List<BalanceEntry> entries=new List<BalanceEntry>();
        }

        static BalanceEntry ToEntry(ArchetypeBalanceSummary s,float clearSeconds,float dealt)=>new BalanceEntry
        {
            archetypeName=s.archetypeName,heroClass=s.heroClass,tier=s.tier,totalRuns=s.totalRuns,wins=s.wins,defeats=s.defeats,
            totalResourceStarvations=s.totalResourceStarvations,winRate=s.winRate,avgClearTime=s.avgClearTime,avgDps=s.avgDps,
            totalClearSeconds=clearSeconds,totalDealtDamage=dealt,
            // JsonUtility cannot serialize a Dictionary, so the causes are flattened before the report is written.
            deathCauses=s.deathCauses.OrderBy(kv=>kv.Key).Select(kv=>new BalanceDeathCause{cause=kv.Key,count=kv.Value}).ToList()
        };

        [MenuItem("HELLSCRIPT/밸런스 시뮬레이션 실행")]
        public static void RunBalanceSweep()
        {
            string directory="Artifacts/Validation/BalanceSweep";int seeds=30;var tiers=new List<int>{1,10,20,30};
            var args=Environment.GetCommandLineArgs();
            for(int i=0;i<args.Length-1;i++)
            {
                if(args[i]=="-hellscriptBalanceOutput")directory=args[i+1];
                if(args[i]=="-hellscriptBalanceSeeds"&&int.TryParse(args[i+1],out int parsed)&&parsed>0)seeds=parsed;
                if(args[i]=="-hellscriptBalanceTiers")
                {
                    var chosen=args[i+1].Split(',').Where(x=>int.TryParse(x,out int v)&&v>0).Select(int.Parse).ToList();
                    if(chosen.Count>0)tiers=chosen;
                }
            }
            Directory.CreateDirectory(directory);var report=new BalanceReport{seedCount=seeds,tiers=tiers};
            string path=Path.Combine(directory,"balance-sweep.json");
            foreach(int tier in tiers)
            {
                foreach(var summary in RunMultiSeedBalanceSimulation(seeds,tier))
                    report.entries.Add(ToEntry(summary,summary.avgClearTime*summary.wins,summary.avgDps*summary.avgClearTime*summary.wins));
                // Written after each tier so a long sweep that is interrupted still leaves the finished tiers.
                File.WriteAllText(path,JsonUtility.ToJson(report,true));
            }
            Debug.Log($"HELLSCRIPT_BALANCE_SWEEP_COMPLETE {report.entries.Count} entries, {seeds} seeds, tiers {string.Join("/",tiers)} -> {path}");
        }

        public static void Compare()
        {
            string directory="Artifacts/Validation/BuildComparisonInitial";var args=Environment.GetCommandLineArgs();
            for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptComparisonOutput")directory=args[i+1];
            Directory.CreateDirectory(directory);var catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();var report=new Report();
            try
            {
                for(int c=0;c<3;c++)for(int variant=0;variant<2;variant++)for(int tier=0;tier<2;tier++)
                {
                    var account=GameStore.NewAccount();account.selectedHero=c;var hero=account.Hero;hero.level=30;hero.capacity=100;hero.inventory.Clear();hero.build=GameCatalog.Preset(hero.heroClass,variant);
                    var errors=BehaviorRules.Validate(hero.build,hero.heroClass);if(errors.Count>0)throw new InvalidOperationException(errors[0]);uint gearRng=(uint)(41073+c);
                    var row=new Entry{preset=hero.build.name,hero=hero.heroClass.ToString(),gear=tier==0?"rare":"set",stage=1,seed=91367};
                    for(int slot=0;slot<8;slot++)
                    {
                        string id=tier==0?null:Sets[c*2+variant][slot];var item=ItemGenerator.Create(hero.heroClass,slot,id==null?2:3,30,ref gearRng,uniqueId:id);hero.inventory.Add(item);
                        if(!Economy.Equip(hero,item))throw new InvalidOperationException("Illegal comparison equipment: "+id);row.equipment.Add(item.special+":"+item.baseId+":"+slot);
                    }
                    if(hero.inventory.Count(i=>i.equipped)!=8||hero.inventory.Where(i=>i.equipped).Select(i=>i.slot).Distinct().Count()!=8)throw new InvalidOperationException("Comparison needs eight unique occupied slots.");
                    var sim=new CombatSimulation(account,catalog,1,seed:91367);var run=sim.State;row.runId=run.id;row.map=run.layout.fingerprint;row.hpMaximum=sim.Stats.hp;
                    var starts=new HashSet<int>();var interrupts=new HashSet<int>();var usage=new Dictionary<string,Usage>();int lastDamage=0,targetTicks=0,stationaryTicks=0;float targetDistance=0;
                    Usage Use(string id,string name){if(!usage.TryGetValue(id,out var u)){u=new Usage{id=id,name=name};usage[id]=u;}return u;}
                    while(run.phase!=RunPhase.Cleared&&run.phase!=RunPhase.Failed&&row.ticks<8000)
                    {
                        if(run.portal||!string.IsNullOrEmpty(run.navigationError))break;Vector2 before=run.position;sim.Tick(CombatSimulation.Step);row.ticks++;
                        if(run.bossId>=0&&row.bossSpawnTime<0)row.bossSpawnTime=run.time;
                        // Observation only: separate a motionless, idle approach from normal cast/hold time.
                        bool approaching=run.targetId>=0&&!sim.HeroActionBusy&&run.actionCd<=0&&Vector2.Distance(run.position,run.destination)>.75f;
                        stationaryTicks=approaching&&Vector2.Distance(before,run.position)<.001f?stationaryTicks+1:0;
                        row.maxStationaryApproach=Mathf.Max(row.maxStationaryApproach,stationaryTicks*CombatSimulation.Step);
                        foreach(var e in run.actionEvents)
                        {
                            string id=e.skill<0?"BASIC":catalog.skills[e.skill].id,name=e.skill<0?"기본 공격":catalog.skills[e.skill].name;
                            if(e.kind=="ACTION_START"&&starts.Add(e.actionId))Use(id,name).starts++;
                            if(e.kind=="ACTION_INTERRUPTED"&&interrupts.Add(e.actionId))Use(id,name).interruptions++;
                        }
                        int newest=lastDamage;
                        for(int i=run.damageEvents.Count-1;i>=0&&run.damageEvents[i].id>lastDamage;i--)
                        {
                            var d=run.damageEvents[i];newest=Math.Max(newest,d.id);if(d.incoming)continue;
                            var u=Use(d.definitionId,catalog.skills.Find(s=>s.id==d.definitionId)?.name??d.definitionId);u.hits++;u.damage+=d.hpLoss;
                            if(d.targetId==run.bossId){u.bossHits++;u.bossDamage+=d.hpLoss;}
                        }
                        lastDamage=newest;var target=run.enemies.Find(e=>!e.dead&&e.id==run.targetId);
                        if(target!=null){targetDistance+=Vector2.Distance(run.position,target.position);targetTicks++;}
                    }
                    row.result=run.portal?"Portal":run.phase.ToString();row.navigationError=run.navigationError;row.time=run.time;row.damage=run.dealt;row.hp=run.health;row.resource=run.resource;row.distance=run.moveDistance;
                    row.repaths=run.exploration.repaths;row.bossRemainingHp=run.enemies.Find(e=>e.id==run.bossId)?.health??0;
                    row.meanTargetDistance=targetTicks>0?targetDistance/targetTicks:0;row.kills=run.kills;row.chests=run.layout.chests.Count(ch=>ch.phase==ChestPhase.Opened);row.visited=run.visited.Count;row.usage=usage.Values.OrderBy(u=>u.id).ToList();report.entries.Add(row);
                    File.WriteAllText(Path.Combine(directory,$"{c}-{variant}-{tier}-final.json"),JsonUtility.ToJson(run,true));File.WriteAllText(Path.Combine(directory,"comparison.json"),JsonUtility.ToJson(report,true));
                    Debug.Log($"BUILD_COMPARISON {report.entries.Count}/12 {row.preset}/{row.gear}: {row.result}, t={row.time:F2}, kills={row.kills}, hp={row.hp:F1}, navigation={row.navigationError}");
                }
                if(report.entries.Any(r=>!string.IsNullOrEmpty(r.navigationError)||r.ticks>=8000))throw new InvalidOperationException("Comparison found a navigation or progression failure; inspect saved results.");
                Debug.Log("HELLSCRIPT_BUILD_COMPARISON_COMPLETE");
            }
            finally{UnityEngine.Object.DestroyImmediate(catalog);}
        }
    }
}
