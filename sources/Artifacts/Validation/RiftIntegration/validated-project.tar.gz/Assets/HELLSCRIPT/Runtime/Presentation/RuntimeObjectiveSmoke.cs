using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimeObjectiveSmoke : MonoBehaviour
    {
        GameController game;string directory,saveDirectory;int capture;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if(!Debug.isDebugBuild||!Environment.GetCommandLineArgs().Contains("-hellscriptObjectiveSmoke"))return;
            Application.runInBackground=true;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Objective validation").AddComponent<RuntimeObjectiveSmoke>();
        }
        static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
        static string Json(object value)=>JsonUtility.ToJson(value);
        Transform View(RiftSeal seal)=>GameObject.Find("Rift Runtime").transform.Find("Objective "+seal.id);
        IEnumerator Resize(int width,int height)
        {
            Screen.SetResolution(width,height,FullScreenMode.Windowed);float end=Time.realtimeSinceStartup+6;
            while((Screen.width!=width||Screen.height!=height)&&Time.realtimeSinceStartup<end)yield return null;
            Require(Screen.width==width&&Screen.height==height,"Window size request failed.");yield return new WaitForSecondsRealtime(.2f);
        }
        IEnumerator Capture(string label)
        {
            var run=game.Combat.State;string before=Json(run);game.World.Present(run,.2f);game.UI.RefreshHud();yield return new WaitForSecondsRealtime(.2f);
            Require(before==Json(run),"Rendering changed the objective, exploration, reward or combat state.");
            if(game.UI.Page=="battle"&&run.phase!=RunPhase.Boss&&game.Combat.ObjectiveActive)
                Require(game.UI.GetComponentsInChildren<Text>().Any(t=>t.text==Loc.F("봉인 {0} / {1} · 게이지 {2} / {3}",game.Combat.SealsBroken,run.layout.seals.Count,Mathf.Min(CombatSimulation.GateMeter,run.meter),CombatSimulation.GateMeter)),"The HUD lost the seal count after refresh or resize.");
            foreach(var seal in run.layout.seals)
            {
                var view=View(seal);Require(view!=null,"The objective has no world representation.");
                bool expected=seal.discovered&&run.visited.Contains(seal.room)&&Vector2.Distance(run.position,seal.position)<25;
                Require(view.gameObject.activeSelf==expected,"Objective visibility leaked an unexplored point.");
                if(!expected)continue;
                Require(view.Find("Guard locks").gameObject.activeSelf==(seal.phase==SealPhase.Locked),"Guard locks disagree with simulation.");
                Require(view.Find("Broken seal").gameObject.activeSelf==(seal.phase==SealPhase.Broken),"Broken fragments disagree with simulation.");
                var arc=view.GetComponentsInChildren<LineRenderer>(true).Single(l=>l.name=="Breaking progress");
                Require(arc.gameObject.activeSelf==(seal.progress>0||seal.phase==SealPhase.Broken),"Saved breaking progress has no visible arc.");
            }
            Canvas.ForceUpdateCanvases();
            foreach(var text in game.UI.GetComponentsInChildren<Text>())Require(text.preferredHeight<=text.rectTransform.rect.height+1,"Text clipped: "+text.text);
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,$"{++capture:00}-{label}.png"));yield return new WaitForSecondsRealtime(.2f);
        }
        void CheckCollection()
        {
            var hero=game.Store.Data.Hero;var document=hero.edict.Copy();
            foreach(var setting in new[]{("loot.MAGIC","PASSING"),("loot.RARE","IGNORE"),("loot.LEGENDARY","IGNORE"),("loot.SET","PASSING")})
                document=HuntEdictV2Editing.WithGlobal(document,setting.Item1,setting.Item2);
            Require(game.Store.SaveHeroEdict(hero.id,document,game.catalog,true),"Could not save the runtime collection policy.");game.Combat.RefreshEdict();
            var run=game.Combat.State;uint rng=611999;int before=hero.inventory.Count;
            DropState Add(int rarity,int slot,string unique=null)
            {
                var item=ItemGenerator.Create(hero.heroClass,slot,rarity,30,ref rng,uniqueId:unique);
                var drop=new DropState{id=run.nextId++,position=run.position,item=item,discovered=true};run.drops.Add(drop);return drop;
            }
            var magic=Add(1,0);var rare=Add(2,0);var legendary=Add(3,0,"LW01");var set=Add(3,1,"SW1");
            foreach(var enemy in run.enemies)enemy.dead=true;
            game.Combat.Tick(CombatSimulation.Step);
            Require(magic.claimed&&set.claimed&&!rare.claimed&&!legendary.claimed&&hero.inventory.Count==before+2,"Native collection ignored the per-grade or set policy.");
            Require(game.Store.SetHeroEdictEnabled(hero.id,false,game.catalog),"Could not leave the collection fixture.");game.Combat.RefreshEdict();
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();
            for(int i=0;i<args.Length-1;i++){if(args[i]=="-hellscriptSavePath")saveDirectory=args[i+1];if(args[i]=="-hellscriptScreenshots")directory=args[i+1];}
            Require(!string.IsNullOrEmpty(saveDirectory)&&!string.IsNullOrEmpty(directory),"Use isolated account and evidence paths.");Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1);game=FindAnyObjectByType<GameController>();Require(game.Store!=null,"Account missing.");game.enabled=false;
            if(args.Contains("-hellscriptObjectiveResume"))
            {
                string expected=File.ReadAllText(Path.Combine(directory,"expected-run.json"));
                Require(Json(game.Store.Data.suspendedRun)==expected,"Loading changed the objective checkpoint.");
                game.Begin(resume:true);var run=game.Combat.State;var seal=run.layout.seals[0];float progress=seal.progress;
                Require(seal.phase==SealPhase.Breaking&&progress>0&&progress<RiftSeal.Duration,"Partial seal was not restored.");
                var copy=JsonUtility.FromJson<AccountSave>(Json(game.Store.Data));
                var control=new CombatSimulation(copy,game.catalog,run.stage,restore:JsonUtility.FromJson<RunState>(Json(run)));
                int enemies=run.enemies.Count;
                for(int i=0;i<100&&seal.phase!=SealPhase.Broken;i++){game.Combat.Tick(CombatSimulation.Step);control.Tick(CombatSimulation.Step);}
                Require(seal.phase==SealPhase.Broken&&run.enemies.Count>enemies&&run.enemies.Count<=enemies+3,"Resumed seal did not finish with one response wave.");
                Require(Json(run)==Json(control.State),"Rendered and control simulations diverged after restart.");
                enemies=run.enemies.Count;for(int i=0;i<4;i++)game.Combat.Tick(CombatSimulation.Step);
                Require(run.enemies.Count==enemies,"A completed seal spawned a second response wave.");
                yield return Resize(1920,1080);yield return Capture("resumed-broken-wide");yield return Resize(720,1280);yield return Capture("resumed-broken-portrait");
                File.WriteAllText(Path.Combine(directory,"objective-resume.txt"),"PASS: exact checkpoint restored in a separate process, partial progress completed once, one response wave, control simulation matched, broken geometry in wide and portrait windows.\n");
                Debug.Log("HELLSCRIPT_OBJECTIVE_RESUME_OK");Application.Quit(0);yield break;
            }
            var hero=game.Store.Data.Hero;hero.level=30;hero.highestClear=10;game.SelectedStage=10;game.Store.Data.guide.hintsHidden=true;
            uint objectiveSeed=771199;while(RiftObjectives.Select(objectiveSeed,10)!=RiftObjectiveKind.Seals)objectiveSeed++;game.Begin(seed:objectiveSeed);var state=game.Combat.State;Require(state.layout.seals.Count==2,"Expected the current two-seal objective.");
            yield return Resize(720,1280);yield return Capture("undiscovered-portrait");
            var first=state.layout.seals[0];state.position=first.accessPoints[0];state.visited.Add(first.room);first.discovered=true;
            yield return Resize(1920,1080);yield return Capture("guarded-wide");
            CheckCollection();state.build.openChests=false;state.build.useShrines=false;
            foreach(var rule in state.build.rules)rule.enabled=rule.action==RuleAction.Explore;
            for(int i=0;i<8;i++)game.Combat.Tick(CombatSimulation.Step);
            Require(first.phase==SealPhase.Breaking&&first.progress>0&&first.progress<RiftSeal.Duration,"Could not reach a real partial break.");
            foreach(var size in new[]{new Vector2Int(1920,1080),new Vector2Int(844,390),new Vector2Int(720,1280)})
            {yield return Resize(size.x,size.y);yield return Capture($"breaking-{size.x}x{size.y}");}
            game.UI.ShowRiftMap();Require(state.paused,"Map did not pause combat.");
            game.UI.ShowRiftMap();yield return Resize(1280,720);yield return Capture("map-after-redraw");
            game.UI.GetComponentsInChildren<Button>().Single(b=>b.name=="균열로 돌아가기").onClick.Invoke();
            Require(!state.paused,"Redrawing the map lost the original running state.");
            game.Save();Require(string.IsNullOrEmpty(game.Store.Error),"Checkpoint save failed.");
            File.WriteAllText(Path.Combine(directory,"expected-run.json"),Json(state));
            File.WriteAllText(Path.Combine(directory,"objective-main.txt"),"PASS: saved native per-grade/set collection, discovered-only seal geometry and minimap, locked and partial break, 1920x1080/844x390/720x1280, render-state invariance, map redraw preserves pause, partial checkpoint saved. UI callbacks and Metal; no physical mobile claim.\n");
            Debug.Log("HELLSCRIPT_OBJECTIVE_RUNTIME_OK");Application.Quit(0);
        }
    }
}
