using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;

namespace Hellscript
{
    // uGUI InputField reads these three properties through BaseInput even with Input System UI.
    // Keep the standard text editor, selection and platform keyboard; bridge only its IME access.
    public sealed class HellscriptTextInput : BaseInput
    {
        Keyboard keyboard;
        string composition="";
        IMECompositionMode mode=IMECompositionMode.Auto;
        Vector2 cursor;
        void Connect()
        {
            if(keyboard==Keyboard.current)return;
            if(keyboard!=null)keyboard.onIMECompositionChange-=OnComposition;
            keyboard=Keyboard.current;composition="";
            if(keyboard!=null){keyboard.onIMECompositionChange+=OnComposition;keyboard.SetIMEEnabled(mode==IMECompositionMode.On);}
        }
        protected override void OnEnable(){base.OnEnable();Connect();}
        protected override void OnDisable(){if(keyboard!=null)keyboard.onIMECompositionChange-=OnComposition;keyboard=null;composition="";base.OnDisable();}
        void OnComposition(IMECompositionString value){composition=value.ToString();}
        public override string compositionString {get{Connect();return composition;}}
        public override IMECompositionMode imeCompositionMode
        {get=>mode;set{Connect();mode=value;keyboard?.SetIMEEnabled(value==IMECompositionMode.On);if(value!=IMECompositionMode.On)composition="";}}
        public override Vector2 compositionCursorPos
        {get=>cursor;set{Connect();cursor=value;keyboard?.SetIMECursorPosition(value);}}
    }
}
