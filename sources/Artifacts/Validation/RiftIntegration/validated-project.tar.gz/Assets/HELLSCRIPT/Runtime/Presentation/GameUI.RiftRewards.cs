using System;

namespace Hellscript
{
    public sealed partial class GameUI
    {
        public void ShowRiftRewards()
        {
            var run=game.Store.Data.suspendedRun;
            bool active=run!=null&&run.training<0&&run.phase!=RunPhase.Cleared&&run.phase!=RunPhase.Failed;
            int stage=active?run.stage:game.SelectedStage;
            pageRepaint=ShowRiftRewards;
            Base("rift-rewards","단계별 등급 확률",active?"진행 중인 균열 단계에 적용되는 보상입니다.":"선택한 균열 단계에 적용되는 보상입니다.");
            Note(content,Loc.F("균열 {0}단계 · 장비 1회 추첨 기준",stage),25,60,gold);
            Note(content,"최고 기록과 관계없이 실제 전투 단계의 확률을 적용합니다. 수치는 밸런스 시험안입니다.",19,90,muted);
            RiftRewardNote("일반 몬스터",RiftRewardSource.Normal,stage);
            Note(content,"장비가 드롭될 확률은 처치당 2%입니다. 위 등급 확률은 장비가 드롭된 경우에만 적용됩니다.",19,96,muted);
            RiftRewardNote("정예 몬스터",RiftRewardSource.Elite,stage);
            Note(content,"정예는 장비를 1회 추첨합니다.",19,52,muted);
            RiftRewardNote("보스",RiftRewardSource.Boss,stage);
            var boss=RiftRarity.Get(RiftRewardSource.Boss,stage);
            Note(content,Loc.F("보스는 장비를 3회 추첨하며 위 확률을 각각 적용합니다.\n전설 1개 이상 획득 확률: {0:0.00}%",100*(1-Math.Pow(1-boss.Legendary,3))),19,112,muted);
            int highest=game.Store.Data.Hero.highestClear;
            if(highest>0)
            {
                Note(content,Loc.F("소탕 · 이 영웅의 최고 실클리어 {0}단계",highest),23,68,gold);
                RiftRewardNote("보스",RiftRewardSource.Boss,highest);
                Note(content,"해당 단계 보스 보상 1묶음으로, 장비 3회 각각 같은 확률을 적용합니다. 소탕 전용 가산은 없습니다.",19,96,muted);
            }
            else Note(content,"소탕은 이 영웅의 실제 클리어 기록이 있어야 사용할 수 있습니다.",19,78,muted);
            Note(content,"오프라인 보상에는 장비가 없습니다. 상점·제작·균열 상자는 기존 등급 규칙을 유지합니다. 전설 내부의 구성원 가중치는 바뀌지 않습니다.",19,140,muted);
            FooterButton(0,2,"균열 관리자",ShowRiftKeeper);
            FooterButton(1,2,active?"균열로 돌아가기":"성소 메뉴",()=>{if(active)ShowBattle();else ShowTown();});
        }

        void RiftRewardNote(string source,RiftRewardSource route,int stage)
        {
            var p=RiftRarity.Get(route,stage);
            Note(content,Loc.F("{0}\n일반 {1:0.00}% · 마법 {2:0.00}%\n레어 {3:0.00}% · 전설 {4:0.00}%",source,p.Common*100,p.Magic*100,p.Rare*100,p.Legendary*100),21,126,pale);
        }
    }
}
