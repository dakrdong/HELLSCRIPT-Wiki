using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Native development-player evidence, always using an explicit isolated save directory.
    public sealed class RuntimeGateSmoke:MonoBehaviour
    {
        GameController game;string directory;int capture;
        static void Require(bool value,string message){if(!value)throw new InvalidOperationException(message);}
        static string Json(object value)=>JsonUtility.ToJson(value);
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if(!Debug.isDebugBuild||!Environment.GetCommandLineArgs().Contains("-hellscriptGateSmoke"))return;
            Application.runInBackground=true;Application.logMessageReceived+=(m,s,t)=>{if(t==LogType.Exception)Application.Quit(1);};
            new GameObject("Gate passage validation").AddComponent<RuntimeGateSmoke>();
        }
        IEnumerator Capture(string label,int width,int height,bool showGateLegend=false)
        {
            Screen.SetResolution(width,height,FullScreenMode.Windowed);float end=Time.realtimeSinceStartup+6;
            while((Screen.width!=width||Screen.height!=height)&&Time.realtimeSinceStartup<end)yield return null;
            Require(Screen.width==width&&Screen.height==height,"Native window resize failed.");yield return new WaitForSecondsRealtime(.25f);
            if(showGateLegend)
            {
                var text=game.UI.GetComponentsInChildren<Text>().First(t=>t.text==Loc.T(game.Combat.State.layout.gateOpen?"보스 관문 · 열림":"보스 관문 · 닫힘"));
                DialogReadingAnchor.Show(text.transform.parent as RectTransform);yield return new WaitForSecondsRealtime(.15f);
            }
            var run=game.Combat.State;string before=Json(run);
            game.World.Present(run,.2f);game.UI.RefreshHud();yield return new WaitForSecondsRealtime(.2f);
            Require(before==Json(run),"Rendering changed gate state or exploration.");
            foreach(var gate in run.layout.gates)
            {
                var view=GameObject.Find("Rift Runtime").transform.Find("Boss gate "+gate.barrier.id);
                Require(view!=null,"Missing physical gate representation.");
                Require(view.gameObject.activeSelf==(gate.discovered&&Vector2.Distance(run.position,gate.barrier.position)<25),"Gate visibility leaked an unexplored entrance.");
                Require(view.Find("Closed barrier").gameObject.activeSelf==!run.layout.gateOpen,"Gate appearance disagrees with passage state.");
            }
            Canvas.ForceUpdateCanvases();foreach(var text in game.UI.GetComponentsInChildren<Text>())
                Require(text.preferredHeight<=text.rectTransform.rect.height+1,"Clipped text: "+text.text);
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,$"{++capture:00}-{label}.png"));yield return new WaitForSecondsRealtime(.2f);
        }
        void CloseMap()
        {
            game.UI.GetComponentsInChildren<Button>().Single(b=>b.name=="균열로 돌아가기").onClick.Invoke();
            Require(!game.Combat.State.paused,"Map repaint lost the original pause state.");
        }
        void Checkpoint(string name)
        {
            game.Save();Require(string.IsNullOrEmpty(game.Store.Error),"Could not save gate checkpoint.");
            File.WriteAllText(Path.Combine(directory,name+".json"),Json(game.Combat.State));
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();Require(args.Contains("-hellscriptSavePath"),"Use an isolated account.");
            for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptScreenshots")directory=args[i+1];
            Require(!string.IsNullOrEmpty(directory),"Use a dedicated evidence directory.");Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1);game=FindAnyObjectByType<GameController>();game.enabled=false;
            bool openResume=args.Contains("-hellscriptGateOpenResume"),resume=openResume||args.Contains("-hellscriptGateResume");
            if(resume)
            {
                Require(Json(game.Store.Data.suspendedRun)==File.ReadAllText(Path.Combine(directory,openResume?"opened.json":"closed.json")),"Gate checkpoint changed on load.");
                game.Begin(resume:true);var run=game.Combat.State;var gate=run.layout.gates[0];
                Require(gate.discovered&&run.layout.gateOpen==openResume,"Saved gate state was not restored.");
                Require(game.Combat.Map.Reachable(run.layout.bossPoints[0])==openResume,"Restored navigation disagrees with saved gate state.");
                if(openResume)
                {
                    Require(run.logs.Count(l=>l.Contains("GATE_OPEN"))==1,"Opening was repeated during load.");
                    for(int i=0;i<120&&!run.visited.Contains(run.layout.bossRoom);i++)
                    {
                        foreach(var enemy in run.enemies){enemy.attack=0;enemy.cooldown=1000;enemy.speed=0;}
                        game.Combat.Tick(CombatSimulation.Step);
                    }
                    Require(game.Combat.Map.RoomAt(run.position)==run.layout.bossRoom&&run.visited.Contains(run.layout.bossRoom),"Automatic movement never passed the reopened gate.");
                    yield return Capture("open-resume-arena-wide",1920,1080);yield return Capture("open-resume-arena-portrait",720,1280);
                    Debug.Log("HELLSCRIPT_GATE_OPEN_RESUME_OK");Application.Quit(0);yield break;
                }
                yield return Capture("closed-resume-wide",1280,720);
                var account=JsonUtility.FromJson<AccountSave>(Json(game.Store.Data));var control=new CombatSimulation(account,game.catalog,run.stage,restore:JsonUtility.FromJson<RunState>(Json(run)));
                run.meter=control.State.meter=CombatSimulation.GateMeter;
                for(int i=0;i<4;i++)
                {game.Combat.Tick(CombatSimulation.Step);control.Tick(CombatSimulation.Step);Require(Json(run)==Json(control.State),"Resumed gate opening diverged from the control simulation.");}
                Require(run.layout.gateOpen&&game.Combat.Map.Reachable(run.layout.bossPoints[0]),"The gate opened without restoring passage.");
                Require(game.UI.GetComponentsInChildren<Text>().Any(t=>t.text==Loc.T("처치 게이지 충전 · 보스 관문이 열렸습니다")),"The gate-open notice was not displayed.");
                yield return Capture("opened-wide",1920,1080);game.ApplyLanguage("en");yield return Capture("opened-english-portrait",720,1280);
                game.UI.ShowRiftMap();yield return Capture("opened-map-english",1280,720,true);
                yield return Capture("opened-map-english-compact",640,360,true);CloseMap();game.ApplyLanguage("ko");
                Checkpoint("opened");Debug.Log("HELLSCRIPT_GATE_CLOSED_RESUME_OK");Application.Quit(0);yield break;
            }
            var hero=game.Store.Data.Hero;hero.level=30;hero.highestClear=10;game.SelectedStage=10;game.Store.Data.guide.hintsHidden=true;
            hero.build=BehaviorPresets.ForLevel(hero.heroClass,0,30,game.catalog);hero.build.openChests=false;hero.build.useShrines=false;
            hero.build.rules=new List<Rule>{BehaviorRules.Utility(RuleAction.Explore)};
            uint objectiveSeed=7;while(RiftObjectives.Select(objectiveSeed,10)!=RiftObjectiveKind.Seals)objectiveSeed++;game.Begin(seed:objectiveSeed);var state=game.Combat.State;Require(state.layout.version==RiftLayout.CurrentVersion&&state.layout.gates.Count>=2,"Generated map has no physical entrances.");
            yield return Capture("undiscovered-gates",720,1280);
            foreach(var enemy in state.enemies)enemy.dead=true;
            var first=state.layout.gates[0];state.position=first.barrier.position+first.outward*3;
            game.Combat.Tick(CombatSimulation.Step);
            Require(first.discovered&&!state.visited.Contains(state.layout.bossRoom),"Discovering the gate revealed the arena.");
            Require(!game.Combat.Map.TravelClear(first.barrier.position+first.outward*3,first.barrier.position-first.outward*3),"Native player can walk through a closed gate.");
            yield return Capture("closed-gate-wide",1920,1080);yield return Capture("closed-gate-portrait",720,1280);
            game.ApplyLanguage("en");game.UI.ShowRiftMap();yield return Capture("closed-map-english",1280,720,true);
            yield return Capture("closed-map-english-compact",640,360,true);
            game.UI.ShowRiftMap();CloseMap();game.ApplyLanguage("ko");
            Checkpoint("closed");Debug.Log("HELLSCRIPT_GATE_RUNTIME_OK");Application.Quit(0);
        }
    }
}
