using UnityEngine;

namespace Hellscript
{
    // Screens are authored on a 720x1280 reference that the canvas maps onto the display, so the size
    // of a control in canvas units is the same on every device. That makes the 48dp touch minimum a
    // statement about the authored layout: on a phone measuring 360dp across its short edge the
    // reference is 720 units wide, so one unit is half a dp and 48dp needs 96 units. Battle and other
    // constant pixel screens scale by device density instead, where one unit already is one dp.
    public static class TouchLayout
    {
        public const float MinimumDp = 48f;
        // Reference phone: 20:9 reporting 411dp across its short edge, where the canvas puts 644 units
        // on that width. 48dp is 75.2 units there, and screens are authored at 80 so the check has
        // room. The same 80 units are 40dp on a 16:9 phone reporting 360dp, which the reading size
        // setting lifts past 48dp from 130% upwards.
        public const float PhoneShortEdgeDp = 411f;
        public const float ReferenceAcross = 644f;
        public const float AuthoredMinimum = 80f;
        public static float UnitsFor(float dp, float across = ReferenceAcross, float phoneDp = PhoneShortEdgeDp)
            => Mathf.Max(0, dp) * Mathf.Max(1, across) / Mathf.Max(1, phoneDp);
        public static float DpFor(float units, float across = ReferenceAcross, float phoneDp = PhoneShortEdgeDp)
            => Mathf.Max(0, units) * Mathf.Max(1, phoneDp) / Mathf.Max(1, across);
        public static float ScaledMinimum() => AuthoredMinimum;
        public static float ConstantMinimum() => MinimumDp;
        public static bool Meets(Vector2 size, float minimum) => size.x + .5f >= minimum && size.y + .5f >= minimum;
        public static bool Inside(Rect control, Rect container, float tolerance = 1f)
            => control.xMin >= container.xMin - tolerance && control.xMax <= container.xMax + tolerance
            && control.yMin >= container.yMin - tolerance && control.yMax <= container.yMax + tolerance;
    }
}
