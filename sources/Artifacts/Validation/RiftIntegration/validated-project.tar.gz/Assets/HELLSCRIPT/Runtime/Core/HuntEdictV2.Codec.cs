using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;

namespace Hellscript
{
    public static class HuntEdictV2Codec
    {
        public const int MaxJsonBytes=32768,MaxDepth=8,MaxCodeCharacters=70+((MaxJsonBytes+2)/3)*4;
        static readonly UTF8Encoding Utf8=new UTF8Encoding(false,true);
        [Serializable] sealed class SkillValues {public string id;public string[] values;}
        [Serializable] sealed class Payload
        {
            public int schema,contentVersion,globalVersion,optionVersion,policyVersion;
            public string heroClass;
            public string[] slots,global,skillOrder;
            public SkillValues[] skills;
        }
        static string Hash(byte[] bytes){using(var sha=SHA256.Create())return string.Concat(sha.ComputeHash(bytes).Select(b=>b.ToString("x2")));}
        // Positional values are tied to explicit definition versions, never to recipient defaults.
        // The editable source retains HEC IDs; the wire format omits repeated option keys only.
        public static string CanonicalJson(HuntEdictV2Document source)
        {
            var d=HuntEdictV2.Canonical(source);
            return JsonUtility.ToJson(new Payload{schema=d.schema,contentVersion=d.contentVersion,globalVersion=d.globalVersion,optionVersion=d.optionVersion,policyVersion=d.policyVersion,
                heroClass=d.heroClass,slots=d.slots,global=d.global.Select(o=>o.value).ToArray(),skillOrder=d.skillOrder,
                skills=d.skills.Select(s=>new SkillValues{id=s.id,values=s.options.Select(o=>o.value).ToArray()}).ToArray()});
        }
        public static string Encode(HuntEdictV2Document source)
        {
            byte[] bytes=Utf8.GetBytes(CanonicalJson(source));if(bytes.Length>MaxJsonBytes)throw new ArgumentException("사냥 칙령 코드가 너무 큽니다.");
            return "HED2."+Convert.ToBase64String(bytes).TrimEnd('=').Replace('+','-').Replace('/','_')+"."+Hash(bytes);
        }
        static void CheckDepth(string json)
        {
            int depth=0;bool quoted=false,escaped=false;
            foreach(char c in json)
            {
                if(quoted){if(escaped){escaped=false;continue;}if(c=='\\'){escaped=true;continue;}if(c=='"')quoted=false;continue;}
                if(c=='"'){quoted=true;continue;}
                if(c=='{'||c=='['){if(++depth>MaxDepth)throw new ArgumentException("코드의 중첩이 너무 깊습니다.");}
                else if(c=='}'||c==']'){if(--depth<0)throw new ArgumentException("코드의 자료 구조가 손상되었습니다.");}
            }
            if(depth!=0||quoted||escaped)throw new ArgumentException("코드의 자료 구조가 잘렸습니다.");
        }
        public static HuntEdictV2Document Decode(string code)
        {
            if(code==null||code.Length>MaxCodeCharacters)throw new ArgumentException("공유 코드가 없거나 너무 깁니다.");
            string trimmed=code.Trim();var parts=trimmed.Split('.');
            if(parts.Length!=3||parts[0]!="HED2")throw new ArgumentException("지원하는 HED2 코드가 아닙니다. 기존 HED1 코드는 간소화 미리보기로 확인하세요.");
            string encoded=parts[1];
            if(encoded.Length==0||encoded.Length%4==1||encoded.Any(c=>!(c>='A'&&c<='Z'||c>='a'&&c<='z'||c>='0'&&c<='9'||c=='-'||c=='_')))throw new ArgumentException("공유 코드의 문자가 손상되었습니다.");
            byte[] bytes=Convert.FromBase64String(encoded.Replace('-','+').Replace('_','/')+new string('=',(4-encoded.Length%4)%4));
            if(bytes.Length>MaxJsonBytes||parts[2].Length!=64||parts[2]!=Hash(bytes))throw new ArgumentException("공유 코드가 손상되었습니다. 원본을 다시 복사하세요.");
            string json=Utf8.GetString(bytes);CheckDepth(json);var p=JsonUtility.FromJson<Payload>(json);
            if(p==null||p.schema!=HuntEdictV2.Schema||p.contentVersion!=HuntEdictV2.ContentVersion||p.globalVersion!=HuntEdictV2.GlobalVersion||p.optionVersion!=HuntEdictV2.OptionVersion||p.policyVersion!=HuntEdictV2.PolicyVersion)
                throw new ArgumentException("지원하지 않는 사냥 칙령·옵션·고정 판단 버전입니다.");
            if(HuntEdict.ClassIndex(p.heroClass)<0||p.global==null||p.global.Length!=EdictOptions.Global.Length||p.skills==null||p.skills.Length!=7)throw new ArgumentException("직업·전역·스킬 항목이 누락되거나 추가되었습니다.");
            var d=new HuntEdictV2Document{heroClass=p.heroClass,slots=p.slots,skillOrder=p.skillOrder,
                global=EdictOptions.Global.Select((o,i)=>new EdictOption(o.id,p.global[i])).ToList()};
            foreach(var s in p.skills)
            {
                if(s==null)throw new ArgumentException("스킬 보관 설정이 없습니다.");
                var definitions=HuntEdictV2Options.ForSkill(s.id,p.heroClass);
                if(s.values==null||s.values.Length!=definitions.Count)throw new ArgumentException("스킬 핵심 옵션이 누락되거나 추가되었습니다.");
                d.skills.Add(new EdictCoreSkill{id=s.id,options=definitions.Select((o,i)=>new EdictOption(o.id,s.values[i])).ToList()});
            }
            d=HuntEdictV2.Canonical(d);
            if(CanonicalJson(d)!=json||Encode(d)!=trimmed)throw new ArgumentException("코드에 누락·추가·중복 항목 또는 정규 형식이 아닌 표현이 있습니다.");
            return d;
        }
        public static bool TryDecode(string code,out HuntEdictV2Document source,out string error)
        {
            source=null;error="";
            try{source=Decode(code);return true;}
            catch(Exception e) when(e is ArgumentException||e is FormatException||e is InvalidOperationException){error=e.Message;return false;}
        }
    }
}
