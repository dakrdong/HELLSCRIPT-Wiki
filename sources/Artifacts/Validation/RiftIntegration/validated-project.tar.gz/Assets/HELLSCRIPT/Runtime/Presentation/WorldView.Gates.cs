using System.Collections.Generic;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class WorldView
    {
        sealed class GateView {public GameObject root,barrier,light;}
        readonly Dictionary<string,GateView> gateViews=new Dictionary<string,GateView>();
        void BuildGates(RunState run)
        {
            foreach(var gate in run.layout.gates)
            {
                var body=gate.barrier;float width=Mathf.Max(body.halfSize.x,body.halfSize.y)*2;
                var root=new GameObject("Boss gate "+body.id);root.transform.SetParent(world.transform,false);
                root.transform.position=Position(body.position);root.transform.rotation=Quaternion.LookRotation(Position(gate.outward),Vector3.up);
                foreach(int sign in new[]{-1,1})
                {
                    Shape("Gate pillar",PrimitiveType.Cube,root.transform,new Vector3(sign*width*.5f,1.65f,0),new Vector3(.5f,3.3f,.85f),darkStone);
                    Shape("Gate capital",PrimitiveType.Cube,root.transform,new Vector3(sign*width*.5f,3.3f,0),new Vector3(.75f,.3f,1),trim);
                }
                Shape("Gate lintel",PrimitiveType.Cube,root.transform,Vector3.up*3.4f,new Vector3(width+.6f,.4f,.85f),darkStone);
                var barrier=new GameObject("Closed barrier");barrier.transform.SetParent(root.transform,false);
                Shape("Sealed door",PrimitiveType.Cube,barrier.transform,Vector3.up*1.5f,new Vector3(width,3,.7f),darkStone);
                for(float x=-width*.5f+.4f;x<width*.5f;x+=.55f)
                    Shape("Iron binding",PrimitiveType.Cube,barrier.transform,new Vector3(x,1.5f,.38f),new Vector3(.1f,2.9f,.08f),trim);
                foreach(float y in new[]{.55f,2.45f})Shape("Iron crossbar",PrimitiveType.Cube,barrier.transform,new Vector3(0,y,.42f),new Vector3(width,.15f,.12f),trim);
                var light=Shape("Gate rune",PrimitiveType.Sphere,root.transform,new Vector3(0,3.45f,.48f),new Vector3(.45f,.45f,.18f),purple);
                gateViews.Add(body.id,new GateView{root=root,barrier=barrier,light=light});root.SetActive(false);
            }
        }
        void PresentGates(RunState run)
        {
            foreach(var gate in run.layout.gates)
            {
                if(!gateViews.TryGetValue(gate.barrier.id,out var view))continue;
                view.root.SetActive(gate.discovered&&Vector2.Distance(run.position,gate.barrier.position)<25);
                view.barrier.SetActive(!run.layout.gateOpen);
                view.light.GetComponent<Renderer>().sharedMaterial=run.layout.gateOpen?green:purple;
            }
        }
    }
}
