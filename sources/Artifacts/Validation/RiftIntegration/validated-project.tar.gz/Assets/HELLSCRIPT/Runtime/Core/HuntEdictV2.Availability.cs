using System.Collections.Generic;
using System.Linq;

namespace Hellscript
{
    public enum EdictConfigurationIssueKind { Inactive,Unavailable,Fallback,Conflict }
    public sealed class EdictConfigurationIssue
    {
        public readonly string skillId,optionId,reason,originalValue,fallbackValue;
        public readonly EdictConfigurationIssueKind kind;
        internal EdictConfigurationIssue(string skill,string option,string value,EdictConfigurationIssueKind kind,string reason,string fallback="")
        {skillId=skill;optionId=option;originalValue=value;this.kind=kind;this.reason=reason;fallbackValue=fallback;}
    }
    public static class HuntEdictV2Availability
    {
        // Configuration compatibility only. Runtime target, danger, cooldown and charge checks
        // must still happen when choosing an action; this result never means "ready to cast".
        public static IReadOnlyList<EdictConfigurationIssue> Inspect(HuntEdictV2Document source,HeroSave hero,GameCatalog catalog)
        {
            var d=HuntEdictV2.Canonical(source);HuntEdictV2.ValidateReceiver(d,hero,catalog);var stats=new HeroStats(hero);
            var result=new List<EdictConfigurationIssue>();
            if(d.global.Any(o=>o.id=="target.goblin"&&o.value=="ON"))
                result.Add(new EdictConfigurationIssue("","target.goblin","ON",EdictConfigurationIssueKind.Unavailable,"황금 고블린 콘텐츠가 아직 없어 우선 추적을 실행하지 않습니다. 선택값은 보관합니다."));
            string V(string id,int n)=>HuntEdictV2.Value(d,id,n);
            bool Has(string id,bool automatic=false)=>id=="BASIC"?(!automatic||HuntEdictV2.Automatic(d,id)):
                d.slots.Contains(id)&&catalog.skills.Single(s=>s.id==id).unlock<=hero.level&&(!automatic||HuntEdictV2.Automatic(d,id));
            void Add(string id,int n,EdictConfigurationIssueKind kind,string reason,string fallback="")
            {result.Add(new EdictConfigurationIssue(id,HuntEdictV2Options.ForSkill(id,d.heroClass)[n-1].id,V(id,n),kind,reason,fallback));}
            void Require(string id,int n,bool allowed,string reason,string fallback="")
            {if(!allowed)Add(id,n,fallback==""?EdictConfigurationIssueKind.Unavailable:EdictConfigurationIssueKind.Fallback,reason,fallback);}
            void Inactive(string id,int n,string reason)=>Add(id,n,EdictConfigurationIssueKind.Inactive,reason);
            foreach(string id in HuntEdictV2.SkillIds(d.heroClass))
            {
                if(!Has(id))Inactive(id,1,"미장착 또는 미해금 스킬입니다. 보관한 선택값은 유지합니다.");
                else if(!HuntEdictV2.Automatic(d,id))Inactive(id,1,"자동 사용을 껐습니다. 긴급 생존 요청에도 자동 발동하지 않습니다.");
            }
            foreach(var option in EdictOptions.Global.Where(o=>o.kind==EdictOptionKind.SkillReference))
            {
                string id=d.global.Single(o=>o.id==option.id).value;
                if(id!=""&&!Has(id,true))result.Add(new EdictConfigurationIssue(id,option.id,id,EdictConfigurationIssueKind.Unavailable,"참조 스킬이 미장착·미해금이거나 자동 사용이 꺼져 있습니다."));
            }
            if(d.heroClass=="WARRIOR")
            {
                if(V("W01",4)=="LEAP_CHARGE")Require("W01",4,stats.SetPieces("SW")>=4&&Has("W02",true),"SW 4세트와 자동 사용 가능한 도약이 필요합니다. 현재는 연속 유지로 판단합니다.","CONTINUE");
                if(V("W02",2)=="ESCAPE"){Inactive("W02",3,"생존 이탈의 착지 위치는 전역 안전 판단을 따릅니다.");Inactive("W02",4,"생존 이탈 전용에서는 공격 도약 거리를 사용하지 않습니다.");}
                if(V("W02",5)!="GLOBAL")Require("W02",5,Has(V("W02",5),true),"선호 공격을 사용할 수 없어 전역 공격 선택으로 돌아갑니다.","GLOBAL");
                if(V("W03",4)=="CRUSH_CHARGE")Require("W03",4,stats.SetPieces("SWB")>=4&&Has("W02"),"분쇄 충전 전용 방식에는 SWB 4세트와 도약 장착이 필요합니다.");
                if(V("W03",3)=="ISOLATED"&&V("W03",4)=="GROUP")Add("W03",3,EdictConfigurationIssueKind.Conflict,"한 명만 포함하는 공격은 두 명 이상을 요구하는 무리 처리와 함께 실행할 수 없습니다.");
                if(V("W05",4)=="AFTER"&&!stats.passives[2])Add("W05",4,EdictConfigurationIssueKind.Fallback,"WP03이 없어 도약 방어의 종료를 기다리지 않습니다.","TOGETHER");
                if(V("W06",2)=="RESOURCE"){Inactive("W06",3,"자원 보충 전용에서는 강화할 교전을 제한하지 않습니다.");Inactive("W06",4,"자원 보충 전용에서는 공격 강화 준비 시점을 사용하지 않습니다.");}
                if(V("BASIC",4)=="UNTIL_DISCOUNT")Require("BASIC",4,stats.specials.Contains("LC02"),"절제 충전 대상 유지에는 LC02 장착이 필요합니다.");
            }
            else if(d.heroClass=="RANGER")
            {
                if(V("A02",2)=="FOCUS")Require("A02",2,stats.specials.Contains("LA02"),"단일 집중 사격에는 LA02 장착이 필요합니다.");
                if(V("A02",4)=="FOCUS")Require("A02",4,stats.specials.Contains("LA02"),"집중 명중 위치에는 LA02 장착이 필요합니다.");
                if(V("A03",3)=="AMBUSH")
                {if(V("A03",2)!="SELF")Add("A03",3,EdictConfigurationIssueKind.Conflict,"교전 전 매복은 설치 위치가 자신 아래일 때만 사용할 수 있습니다.");else Inactive("A03",5,"자신 아래 매복에서는 기존 덫과의 겹침 선택을 적용하지 않습니다.");}
                if(V("A04",2)=="TRAP_LINK")Require("A04",2,stats.specials.Contains("LA03")&&Has("A03"),"덫 연계에는 LA03과 A03 장착이 필요합니다. 직접 덫의 자동 설치를 꺼도 연계는 허용합니다.");
                if(V("A04",2)=="PIERCE_LINK")Require("A04",2,stats.SetPieces("SAB")>=4&&Has("A01"),"관통 연계에는 SAB 4세트와 관통 사격 장착이 필요합니다.");
                if(V("A06",2)=="POISON_SPREAD")Require("A06",2,stats.specials.Contains("LA04"),"독 전염 교전에는 LA04 장착이 필요합니다.");
                Require("A06",3,Has(V("A06",3),true),"준비를 확인할 사격이 미장착·미해금이거나 자동 사용이 꺼져 있습니다.");
                if(V("BASIC",2)=="DISCOUNT")Require("BASIC",2,stats.specials.Contains("LC02"),"절제 할인 준비에는 LC02 장착이 필요합니다.");
                if(V("BASIC",4)=="UNTIL_DISCOUNT")Require("BASIC",4,stats.specials.Contains("LC02"),"절제 할인 완성까지 대상 유지에는 LC02 장착이 필요합니다.");
            }
            else
            {
                if(V("M01",2)=="EXPOSURE")Require("M01",2,stats.SetPieces("SM")>=4,"SM 4세트가 없어 우선할 자기 노출 대상을 만들 수 없습니다. 꾸준히 공격 방식으로 판단합니다.","STEADY");
                if(V("M02",5)=="FOLLOW")Require("M02",5,stats.specials.Contains("LM01"),"LM01이 없어 새 눈보라는 위치 고정으로 판단합니다.","FIXED");
                if(V("M03",2)=="SAVE_CHARGE")Require("M03",2,stats.SetPieces("SMB")>=4,"SMB 4세트가 없어 연결되는 적 위주로 판단합니다.","LINKED");
                if(V("M03",4)=="TOTAL_HITS")Require("M03",4,stats.specials.Contains("LM04"),"LM04가 없어 고유 대상 수를 기준으로 판단합니다.","UNIQUE");
                if(V("M05",2)=="EMERGENCY")Inactive("M05",4,"긴급 생존 전용에서는 상대 교전 종류를 제한하지 않습니다.");
                if(V("M06",2)=="CHAIN_CHARGE")
                {Require("M06",2,stats.SetPieces("SMB")>=4,"연쇄 충전 준비에는 SMB 4세트 장착이 필요합니다.");Require("M06",2,Has("M03",true),"연쇄 번개가 미장착·미해금이거나 꺼져 있어 위기 제어로 판단합니다.","CONTROL");}
                if(V("BASIC",2)=="DISCOUNT")Require("BASIC",2,stats.specials.Contains("LC02"),"절제 충전 준비에는 LC02 장착이 필요합니다.");
            }
            return result.AsReadOnly();
        }
    }
}
