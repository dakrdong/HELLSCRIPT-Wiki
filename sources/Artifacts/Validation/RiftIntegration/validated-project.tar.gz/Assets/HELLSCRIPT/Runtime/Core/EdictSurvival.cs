using System;
using System.Collections.Generic;
using System.Linq;

namespace Hellscript
{
    // Runtime memory belongs to a run, never to the shareable edict or its editor draft.
    [Serializable]public sealed class EdictSurvivalState
    {public string heroId,runId;public bool active;}
    public sealed class EdictDodgeReason
    {
        public readonly string sourceKey,code,detail;
        public readonly float hpPercent;
        internal EdictDodgeReason(string key,string code,string detail,float percent=0)
        {sourceKey=key;this.code=code;this.detail=detail;hpPercent=percent;}
    }
    public sealed class EdictSurvivalIntent
    {
        public readonly string role,skillId,reason;
        // Reference qualification only; landing, skill purpose, action lock and cast cost
        // must be rechecked by execution before an intent can be chosen.
        public readonly bool referenceAvailable;
        public readonly float cooldown,cost;
        internal EdictSurvivalIntent(string role,string skill,bool valid,string reason,float cooldown=0,float cost=0)
        {this.role=role;skillId=skill;referenceAvailable=valid;this.reason=reason;this.cooldown=cooldown;this.cost=cost;}
    }
    public sealed class EdictSurvivalAssessment
    {
        public readonly bool emergency,lowHp,lethal,heldForRecovery,potionRequested,preserveEscapeForEmergency;
        public bool DodgeRequested=>dodgeReasons.Count>0;
        public readonly float escapeResource;
        public readonly string dodgeMethod,dodgeInterrupt;
        public readonly IncomingForecast forecast;
        public readonly IReadOnlyList<EdictDodgeReason> dodgeReasons;
        public readonly IReadOnlyList<EdictSurvivalIntent> emergencyOrder;
        public readonly EdictSurvivalIntent escapeFallback;
        public readonly IReadOnlyList<string> limitations;
        readonly string heroId,runId;
        public EdictSurvivalState NextState=>new EdictSurvivalState{heroId=heroId,runId=runId,active=emergency};
        internal EdictSurvivalAssessment(string hero,string run,bool emergency,bool lowHp,bool lethal,bool held,bool potion,bool reserve,float resource,string method,string interrupt,
            IncomingForecast forecast,IEnumerable<EdictDodgeReason> dodge,IEnumerable<EdictSurvivalIntent> order,EdictSurvivalIntent fallback,IEnumerable<string> limitations)
        {heroId=hero;runId=run;this.emergency=emergency;this.lowHp=lowHp;this.lethal=lethal;heldForRecovery=held;potionRequested=potion;preserveEscapeForEmergency=reserve;escapeResource=resource;dodgeMethod=method;dodgeInterrupt=interrupt;this.forecast=forecast;
         dodgeReasons=Array.AsReadOnly(dodge.ToArray());emergencyOrder=Array.AsReadOnly(order.ToArray());escapeFallback=fallback;this.limitations=Array.AsReadOnly(limitations.ToArray());}
    }
}
