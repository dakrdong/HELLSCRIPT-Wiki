using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimePresetSmoke : MonoBehaviour
    {
        string directory,saveDirectory;
        GameController game;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]static void Install()
        {
            if(!Environment.GetCommandLineArgs().Contains("-hellscriptPresetSmoke"))return;
            Application.runInBackground=true;Application.logMessageReceived+=(m,s,t)=>{if(t==LogType.Exception)Application.Quit(1);};
            new GameObject("Preset storage and layout validation").AddComponent<RuntimePresetSmoke>();
        }
        static void Require(bool valid,string reason){if(!valid)throw new InvalidOperationException(reason);}
        static string Snapshot(AccountSave value){var copy=JsonUtility.FromJson<AccountSave>(JsonUtility.ToJson(value));copy.lastSeenUtc=0;return JsonUtility.ToJson(copy);}
        Button Find(string name)=>game.UI.GetComponentsInChildren<Button>().Single(b=>b.name==name);
        void Click(string name){var button=Find(name);Require(button.interactable,"Disabled button: "+name);button.onClick.Invoke();}
        InputField Field()=>game.UI.GetComponentsInChildren<InputField>().Single();
        void ScrollTo(Button button)
        {
            Canvas.ForceUpdateCanvases();var row=(RectTransform)button.transform.parent;var scroll=row.GetComponentInParent<ScrollRect>();if(scroll==null)return;
            scroll.content.anchoredPosition=new Vector2(0,Mathf.Clamp(-(row.localPosition.y+row.rect.yMax),0,Mathf.Max(0,scroll.content.rect.height-scroll.viewport.rect.height)));scroll.StopMovement();
        }
        static Vector3[] Corners(RectTransform rect){var result=new Vector3[4];rect.GetWorldCorners(result);return result;}
        IEnumerator Capture(string name,bool dialog=false)
        {
            yield return new WaitForSecondsRealtime(.2f);Canvas.ForceUpdateCanvases();
            if(dialog)
            {
                var card=game.UI.GetComponentsInChildren<RectTransform>().Single(t=>t.name=="Preset dialog");var safe=UiSafeArea.Current;
                Require(card.GetComponentInParent<Canvas>().isRootCanvas&&card.localScale==Vector3.one,"Dialog still magnifies the legacy portrait canvas.");
                Require(Corners(card).All(c=>c.x>=safe.xMin-1&&c.x<=safe.xMax+1&&c.y>=safe.yMin-1&&c.y<=safe.yMax+1),"Dialog outside safe area at "+Screen.width+"x"+Screen.height);
                var buttons=game.UI.GetComponentsInChildren<Button>().Where(b=>b.transform.parent.name=="Preset actions"||b.transform.parent.name=="Preset exit choices").ToArray();
                Require(buttons.Length==2||buttons.Length==3,"Dialog primary actions missing.");
                foreach(var b in buttons)
                {
                    Require(Corners((RectTransform)b.transform).All(c=>c.x>=safe.xMin-1&&c.x<=safe.xMax+1&&c.y>=safe.yMin-1&&c.y<=safe.yMax+1),"Dialog button clipped: "+b.name);
                    var label=b.GetComponentInChildren<Text>();Require(label.preferredHeight<=label.rectTransform.rect.height+1,"Dialog button text clipped: "+b.name);
                }
                float buttonTop=buttons.SelectMany(b=>Corners((RectTransform)b.transform)).Max(c=>c.y);
                foreach(var scroll in card.GetComponentsInChildren<ScrollRect>())Require(Corners(scroll.viewport).Min(c=>c.y)>buttonTop,"Scrollable body covers fixed actions.");
                foreach(var text in card.GetComponentsInChildren<Text>().Where(t=>t.transform.parent.name=="Content"))Require(text.preferredHeight<=text.rectTransform.rect.height+1,"Dialog paragraph clipped: "+text.text);
                var summary=card.GetComponentsInChildren<RectTransform>(true).Single(t=>t.name=="설정 요약");var entry=card.GetComponentsInChildren<RectTransform>(true).Single(t=>t.name=="이름 입력");
                if(summary.gameObject.activeSelf)Require(Corners(summary).Max(c=>c.x)<Corners(entry).Min(c=>c.x),"Wide dialog did not put summary beside input.");
                File.AppendAllText(Path.Combine(directory,"layout-results.txt"),$"{name}: {Screen.width}x{Screen.height}, split={summary.gameObject.activeSelf}, draft={Field().text}, card={card.rect.size}, actions={buttons.Length}\n");
            }
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,name));yield return new WaitForSecondsRealtime(.2f);
        }
        IEnumerator Resize(int width,int height,string image)
        {
            Screen.SetResolution(width,height,FullScreenMode.Windowed);float end=Time.realtimeSinceStartup+6;
            while((Screen.width!=width||Screen.height!=height)&&Time.realtimeSinceStartup<end)yield return null;
            Require(Screen.width==width&&Screen.height==height,"Requested window size was not applied.");yield return Capture(image,true);
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();for(int i=0;i<args.Length-1;i++){if(args[i]=="-hellscriptScreenshots")directory=args[i+1];if(args[i]=="-hellscriptSavePath")saveDirectory=args[i+1];}
            Require(!string.IsNullOrEmpty(directory)&&!string.IsNullOrEmpty(saveDirectory),"Use isolated preset save and evidence directories.");Directory.CreateDirectory(directory);
            Screen.SetResolution(720,1280,FullScreenMode.Windowed);yield return new WaitForSecondsRealtime(1);game=FindAnyObjectByType<GameController>();Require(game.Store!=null,"Store failed to open.");
            if(args.Contains("-hellscriptPresetResume"))
            {
                var expected=JsonUtility.FromJson<AccountSave>(File.ReadAllText(Path.Combine(directory,"expected-account.json")));Require(Snapshot(expected)==Snapshot(game.Store.Data),"Restart changed preset names, settings, protection or account.");
                Require(game.Store.Data.heroes.All(h=>h.presets.Count==5)&&game.Store.Data.Hero.presets[4].name=="서리 사냥 · 5","The fifth named slot was not restored.");
                game.UI.ShowBuild();ScrollTo(Find("슬롯 5 저장"));yield return Capture("10-restarted-five-slots.png");
                File.WriteAllText(Path.Combine(directory,"runtime-preset-smoke.txt"),"PASS: five slots visible; unsaved combat edits cannot be copied as saved presets; named slot 5; cancel/continue/discard; file write failure keeps name draft, live bank and disk; retry; rename-only preservation; load remains a preview; actual process restart restores names/configuration/protection. Dialog reflows at eight PC render sizes plus a short-wide reading-anchor case while retaining typed text and fixed actions. UI callbacks and native rendering; physical IME/touch, mobile orientation, full app responsiveness and Hunt Edict codec integration are not covered.\nRenderer="+SystemInfo.graphicsDeviceType+"\n");
                Debug.Log("HELLSCRIPT_PRESET_RUNTIME_SMOKE_OK");Application.Quit(0);yield break;
            }
            game.SelectHero(2);var hero=game.Store.Data.Hero;Require(hero.level==1&&hero.presets.All(p=>!BuildEditing.HasPreset(p)),"Use a fresh account.");string initial=Snapshot(game.Store.Data),actual=JsonUtility.ToJson(hero.build);
            game.UI.ShowBuild();Require(Enumerable.Range(1,5).All(n=>Find($"슬롯 {n} 저장")!=null),"Five save slots are not available.");
            var distance=game.UI.GetComponentsInChildren<Slider>().Single(s=>s.transform.parent.GetComponentsInChildren<Text>().Any(t=>t.text.StartsWith("목표 거리",StringComparison.Ordinal)));
            distance.value=5.5f;Require(!Find("슬롯 5 저장").interactable,"An unsaved behavior draft can be exported as a saved preset.");distance.value=hero.build.distance;Require(Find("슬롯 5 저장").interactable,"Returning to the saved values stayed dirty.");
            ScrollTo(Find("슬롯 5 저장"));yield return Capture("01-five-slots.png");Click("슬롯 5 저장");Field().text="다섯 번째 🏹";
            foreach(var size in new[]{new Vector2Int(720,1280),new Vector2Int(1280,720),new Vector2Int(1920,1200),new Vector2Int(900,900),new Vector2Int(640,360),new Vector2Int(862,600),new Vector2Int(864,600),new Vector2Int(1400,900)})
            {yield return Resize(size.x,size.y,$"02-dialog-{size.x}x{size.y}.png");Require(Field().text=="다섯 번째 🏹"&&Snapshot(game.Store.Data)==initial,"Resize lost the draft or changed game data.");}
            // Read the last summary in a short window, then merge and split the panes.
            yield return Resize(900,360,"02-reading-start.png");
            var summary=game.UI.GetComponentsInChildren<DialogScrollRect>().Single(s=>s.name=="설정 요약");summary.verticalNormalizedPosition=0;summary.readingStarted();Canvas.ForceUpdateCanvases();
            var last=summary.content.GetChild(summary.content.childCount-1) as RectTransform;
            var anchor=DialogReadingAnchor.Capture(summary);Require(anchor!=null,"No reading anchor was captured.");
            yield return Resize(640,360,"02-reading-merged.png");
            var merged=last.GetComponentInParent<ScrollRect>();var corners=Corners(last);var bounds=Corners(merged.viewport);
            Require(corners.Min(c=>c.y)<bounds.Max(c=>c.y)&&corners.Max(c=>c.y)>bounds.Min(c=>c.y),"Merging panes lost the paragraph being read.");
            yield return Resize(900,360,"02-reading-split.png");
            Require(last.GetComponentInParent<ScrollRect>()==summary,"Splitting panes moved the summary to the wrong scroll area.");
            corners=Corners(last);bounds=Corners(summary.viewport);Require(corners.Min(c=>c.y)<bounds.Max(c=>c.y)&&corners.Max(c=>c.y)>bounds.Min(c=>c.y),"Splitting panes lost the paragraph being read.");
            Require(Field().text=="다섯 번째 🏹"&&Snapshot(game.Store.Data)==initial,"Reading-anchor reflow changed the draft or game data.");
            yield return Resize(1400,900,"02-reading-restored.png");
            Click("닫기");yield return Capture("03-unsaved-name-choices.png",true);Click("계속 편집하기");Require(Field().text=="다섯 번째 🏹","Continue lost typed name.");Click("닫기");Click("저장하지 않고 닫기");Require(Snapshot(game.Store.Data)==initial,"Discard changed the account.");
            yield return null;Click("슬롯 5 저장");Field().text="다섯 번째 🏹";string disk=File.ReadAllText(Path.Combine(saveDirectory,"hellscript-local-v1.json"));var bank=hero.presets;
            string obstacle=Path.Combine(saveDirectory,"hellscript-local-v1.json.tmp");Directory.CreateDirectory(obstacle);Click("프리셋 저장");
            Require(ReferenceEquals(bank,hero.presets)&&Snapshot(game.Store.Data)==initial&&Field().text=="다섯 번째 🏹"&&File.ReadAllText(Path.Combine(saveDirectory,"hellscript-local-v1.json"))==disk,"Failed write changed data or lost the draft.");
            Directory.Delete(obstacle);Debug.developerConsoleVisible=false;yield return Capture("04-save-failure-keeps-draft.png",true);Click("프리셋 저장");Require(hero.presets[4].name=="다섯 번째 🏹"&&JsonUtility.ToJson(hero.build)==actual,"Slot save changed current behavior.");
            yield return null;ScrollTo(Find("슬롯 5 저장"));yield return Capture("05-saved-slot-five.png");
            var old=hero.presets[4].Copy();game.UI.GetComponentsInChildren<Button>().Single(b=>b.name=="이름 변경"&&b.interactable).onClick.Invoke();Require(!Find("이름 저장").interactable,"Unchanged rename is marked dirty.");Field().text="서리 사냥 · 5";
            yield return Capture("06-rename-only.png",true);Click("이름 저장");old.name="서리 사냥 · 5";Require(JsonUtility.ToJson(old)==JsonUtility.ToJson(hero.presets[4]),"Rename changed preset contents.");
            yield return null;Click("슬롯 5 불러오기");Require(JsonUtility.ToJson(hero.build)==actual,"Loading a preset applied it without confirmation.");game.UI.CancelBuild();game.Save();File.WriteAllText(Path.Combine(directory,"expected-account.json"),JsonUtility.ToJson(game.Store.Data,true));
            Debug.Log("HELLSCRIPT_PRESET_CHECKPOINT_READY");Application.Quit(0);
        }
    }
}
