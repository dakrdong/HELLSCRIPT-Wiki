using System;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class GameController
    {
        public TrainingComparisonSession Comparison {get;private set;}
        public bool ComparisonRun=>Comparison!=null&&Comparison.Current==Combat;
        public string ComparisonError {get;private set;}="";
        void PresentComparison(CombatSimulation simulation)
        {
            if(Combat!=null)Combat.Visual-=World.Effect;Combat=simulation;
            ComparisonError="";Combat.Visual+=World.Effect;World.BuildDungeon(Combat.State);UI.ShowBattle();
            accumulator=0;resultDelay=0;resultShown=false;Save();
        }
        public void BeginComparison(int training)
        {
            if(Active||Store.Data.suspendedRun!=null){Notify("진행 중인 균열이나 훈련을 먼저 마쳐 주세요.");return;}
            try{Comparison=new TrainingComparisonSession(Store.Data,catalog,training);PresentComparison(Comparison.StartA());}
            catch(Exception e){Comparison=null;Notify(e.Message);}
        }
        public void RestartComparisonA()
        {
            if(Comparison==null||Active)return;
            try{PresentComparison(Comparison.StartA());}catch(Exception e){Notify(e.Message);}
        }
        public void BeginComparisonB(BuildConfig build)
        {
            if(Comparison==null||Active)return;
            try{PresentComparison(Comparison.StartB(build));}catch(Exception e){Notify(e.Message);}
        }
        void CompleteComparison()
        {Comparison.AcceptCompleted(Combat,out string error);ComparisonError=error;}
        public bool SaveComparisonPreset(TrainingComparisonRecord record,bool useB,int slot,string name=null)
        {
            if(record==null||!record.Complete||record.heroId!=Store.Data.Hero.id||Active||Store.Data.suspendedRun!=null||slot<0||slot>=HuntEdict.PresetSlots)return false;
            var build=(useB?record.b:record.a).build.Copy();if(BehaviorRules.Validate(build,Store.Data.Hero.heroClass).Count>0)return false;
            var baseline=JsonUtility.FromJson<HeroSave>(record.baselineHeroJson);build.equipmentIds=baseline.inventory.Where(i=>i.equipped).Select(i=>i.id).ToList();
            if(Store.SaveBuildPreset(Store.Data.Hero.id,slot,build,name??build.name))return true;
            Notify(Store.Error);return false;
        }
    }
}
