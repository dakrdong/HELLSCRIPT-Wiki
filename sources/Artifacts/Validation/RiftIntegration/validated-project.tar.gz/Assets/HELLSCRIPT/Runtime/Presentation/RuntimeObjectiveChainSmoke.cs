using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimeObjectiveChainSmoke:MonoBehaviour
    {
        GameController game;string directory,phase;int capture;
        static string Json(object value)=>JsonUtility.ToJson(value);
        static void Require(bool value,string message){if(!value)throw new InvalidOperationException(message);}
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if(!Debug.isDebugBuild||!Environment.GetCommandLineArgs().Contains("-hellscriptChainSmoke"))return;
            Application.runInBackground=true;Application.logMessageReceived+=(m,s,t)=>{if(t==LogType.Exception)Application.Quit(1);};
            new GameObject("Objective chain validation").AddComponent<RuntimeObjectiveChainSmoke>();
        }
        IEnumerator Capture(string label,int width,int height,bool objectiveCard=false)
        {
            Screen.SetResolution(width,height,FullScreenMode.Windowed);float end=Time.realtimeSinceStartup+6;
            while((Screen.width!=width||Screen.height!=height)&&Time.realtimeSinceStartup<end)yield return null;
            Require(Screen.width==width&&Screen.height==height,"Native resize failed.");yield return new WaitForSecondsRealtime(.25f);
            if(objectiveCard)
            {
                string text=GameUI.ObjectiveSummary(RiftObjectives.Capture(game.Combat.State));
                var card=game.UI.GetComponentsInChildren<Text>().Single(t=>t.text==text);
                DialogReadingAnchor.Show(card.transform.parent as RectTransform);yield return new WaitForSecondsRealtime(.2f);
                Require(card.preferredHeight<=card.rectTransform.rect.height+1,"Objective result text clipped.");
            }
            var run=game.Combat.State;string before=Json(run);game.World.Present(run,.2f);game.UI.RefreshHud();yield return new WaitForSecondsRealtime(.2f);
            Require(before==Json(run),"Presentation mutated objective state.");
            if(game.UI.Page=="battle"&&run.phase!=RunPhase.Boss&&game.Combat.ObjectiveActive)
                Require(game.UI.GetComponentsInChildren<Text>().Any(t=>t.text.Contains(GameUI.ObjectiveProgress(run.layout))),"The compact HUD replaced the objective with a seal counter.");
            var world=GameObject.Find("Rift Runtime").transform;
            foreach(var point in run.layout.carriers)
            {
                var view=world.Find("Essence "+point.id);Require(view!=null,"Missing carrier marker.");
                Require(view.gameObject.activeSelf==(point.discovered&&Vector2.Distance(run.position,point.position)<25),"Carrier marker leaked a hidden position.");
            }
            foreach(var point in run.layout.offerings)
            {
                var view=world.Find("Offering "+point.id);Require(view!=null,"Missing offering vessel.");
                Require(view.gameObject.activeSelf==(point.discovered&&!point.collected&&Vector2.Distance(run.position,point.position)<25),"Offering state is not reflected in the world.");
            }
            if(game.UI.Page=="battle"||game.UI.Page=="rift-map")
                foreach(var text in game.UI.GetComponentsInChildren<Text>())Require(text.preferredHeight<=text.rectTransform.rect.height+1,"Clipped field text: "+text.text);
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,$"{phase}-{++capture:00}-{label}.png"));yield return new WaitForSecondsRealtime(.2f);
        }
        void Save(string name)
        {game.Save();Require(string.IsNullOrEmpty(game.Store.Error),"Objective checkpoint save failed.");File.WriteAllText(Path.Combine(directory,name+".json"),Json(game.Combat.State));}
        void Quiet()
        {
            var run=game.Combat.State;foreach(var enemy in run.enemies){enemy.dead=true;enemy.pendingDeath=false;}
            run.targetId=-1;run.activeSkill=-1;run.actionCd=0;run.lastDamageTime=-10;run.drops.Clear();
        }
        void Collect(int index)
        {
            var sim=game.Combat;Quiet();sim.State.position=sim.State.layout.offerings[index].position;
            for(int n=0;n<6&&!sim.State.layout.offerings[index].collected;n++)sim.Tick(.05f);
            Require(sim.State.layout.offerings[index].collected,"Native offering pickup failed.");
        }
        void FinishRecord()
        {
            var run=game.Combat.State;string report=Json(RiftObjectives.Capture(run));game.Combat.Abandon();game.Save();
            Require(Json(game.Store.Data.records[0].objective)==report,"Run history changed the gate report.");
            game.UI.ShowResult();
            Require(!game.UI.GetComponentsInChildren<Button>().Any(b=>b.name=="사망 원인 분석 (최근 5초 기록)"),"An alive objective-run return offers death analysis.");
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();Require(args.Contains("-hellscriptSavePath"),"Use an isolated save directory.");
            for(int i=0;i<args.Length-1;i++){if(args[i]=="-hellscriptScreenshots")directory=args[i+1];if(args[i]=="-hellscriptChainPhase")phase=args[i+1];}
            Require(!string.IsNullOrEmpty(directory)&&!string.IsNullOrEmpty(phase),"Missing chain evidence arguments.");Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1);game=FindAnyObjectByType<GameController>();game.enabled=false;
            bool carriers=phase.StartsWith("carrier",StringComparison.Ordinal),resume=phase.EndsWith("resume",StringComparison.Ordinal)||phase=="offering-finish";
            if(resume)
            {
                string checkpoint=phase=="offering-finish"?"offering-partial":carriers?"carrier-partial":"offering-pickup";
                Require(Json(game.Store.Data.suspendedRun)==File.ReadAllText(Path.Combine(directory,checkpoint+".json")),"Objective checkpoint changed on reload.");
                game.Begin(resume:true);
            }
            else
            {
                var hero=game.Store.Data.Hero;hero.level=30;hero.highestClear=10;game.SelectedStage=10;game.Store.Data.guide.hintsHidden=true;
                hero.build=BehaviorPresets.ForLevel(hero.heroClass,0,30,game.catalog);hero.build.openChests=false;hero.build.useShrines=false;hero.build.rules=new List<Rule>{BehaviorRules.Utility(RuleAction.Explore)};
                var kind=carriers?RiftObjectiveKind.EssenceCarriers:RiftObjectiveKind.Offerings;uint seed=7;while(RiftObjectives.Select(seed,10)!=kind)seed++;
                game.Begin(seed:seed);game.Combat.State.time=5;
                foreach(var enemy in game.Combat.State.enemies){enemy.speed=0;enemy.attack=0;enemy.cooldown=10000;}
            }
            var sim=game.Combat;var state=sim.State;
            if(carriers)
            {
                int start=resume?1:0,end=resume?3:1;
                for(int i=start;i<end;i++)
                {
                    var point=state.layout.carriers[i];var enemy=state.enemies.Single(e=>e.id==point.enemyId);state.position=enemy.position+Vector2.down*2;
                    RiftExploration.Discover(state,sim.Map);RiftExploration.ObserveEnemies(state,new[]{enemy});enemy.dead=true;enemy.pendingDeath=true;sim.Tick(.05f);
                    Require(state.layout.carriers[i].completed,"Native carrier settlement failed.");
                }
                yield return Capture("carrier-world",1920,1080);game.ApplyLanguage("en");game.UI.ShowRiftMap();yield return Capture("carrier-map",720,1280);
                game.UI.GetComponentsInChildren<Button>().Single(b=>b.name=="균열로 돌아가기").onClick.Invoke();Require(!state.paused,"Map did not restore pause state.");game.ApplyLanguage("ko");
                if(resume)
                {
                    Require(state.layout.gateOpen&&!state.layout.gateOpenedByMeter&&state.layout.objectiveRecord.completed==3,"Carriers did not open and record the gate.");
                    FinishRecord();yield return Capture("carrier-result",1280,720,true);game.ApplyLanguage("en");game.UI.ShowResult();yield return Capture("carrier-result-compact",640,360,true);
                    Save("carrier-finished");
                }
                else Save("carrier-partial");
            }
            else if(phase=="offering-main")
            {
                var point=state.layout.offerings[0];state.position=point.position;RiftExploration.Discover(state,sim.Map);
                yield return Capture("guarded-offering",1920,1080);Collect(0);
                Require(!state.layout.gateOpen,"One pickup opened the gate.");yield return Capture("one-collected",720,1280);Save("offering-pickup");
            }
            else if(phase=="offering-resume")
            {
                Require(RiftObjectives.Completed(state.layout)==1,"First pickup did not survive.");Collect(1);Collect(2);
                var altar=state.layout.altar;altar.discovered=true;altar.phase=OfferingAltarPhase.Approaching;altar.access=altar.accessPoints[0];state.position=altar.access;
                for(int i=0;i<8;i++)sim.Tick(.05f);
                Require(state.layout.altar.progress>0&&state.layout.altar.progress<1&&!state.layout.gateOpen,"Partial delivery fixture failed.");
                yield return Capture("altar-partial",1920,1080);game.ApplyLanguage("en");game.UI.ShowRiftMap();yield return Capture("offering-map",640,360);
                game.UI.GetComponentsInChildren<Button>().Single(b=>b.name=="균열로 돌아가기").onClick.Invoke();game.ApplyLanguage("ko");Save("offering-partial");
            }
            else if(phase=="offering-finish")
            {
                float partial=state.layout.altar.progress;Require(partial>0&&partial<1,"Partial altar time was not restored.");state.paused=true;sim.Tick(1);Require(state.layout.altar.progress==partial,"Pause advanced the altar.");state.paused=false;
                for(int i=0;i<30&&!state.layout.gateOpen;i++)sim.Tick(.05f);
                Require(state.layout.gateOpen&&!state.layout.gateOpenedByMeter&&state.layout.objectiveRecord.delivered,"Delivery did not open and record the gate.");
                Require(game.Store.Data.transactions.Count(r=>r.operation.StartsWith("offering-",StringComparison.Ordinal))==4,"Offering transaction replay duplicated progress.");
                yield return Capture("altar-delivered",1920,1080);FinishRecord();yield return Capture("offering-result",720,1280,true);
                game.ApplyLanguage("en");game.UI.ShowResult();yield return Capture("offering-result-compact",640,360,true);Save("offering-finished");
            }
            else throw new InvalidOperationException("Unknown chain phase.");
            Debug.Log("HELLSCRIPT_CHAIN_OK "+phase);Application.Quit(0);
        }
    }
}
