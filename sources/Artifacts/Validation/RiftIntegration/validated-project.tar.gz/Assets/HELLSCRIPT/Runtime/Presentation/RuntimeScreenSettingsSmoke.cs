using System;
using System.Collections;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Opt-in native development-player evidence; always requires an isolated account path.
    public sealed class RuntimeScreenSettingsSmoke : MonoBehaviour
    {
        GameController game;
        string directory, saveDirectory;
        int captureIndex;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if (!Debug.isDebugBuild || !Environment.GetCommandLineArgs().Contains("-hellscriptScreenSettingsSmoke")) return;
            Application.runInBackground = true;
            Application.logMessageReceived += (message, stack, type) => { if (type == LogType.Exception) Application.Quit(1); };
            new GameObject("Screen settings validation").AddComponent<RuntimeScreenSettingsSmoke>();
        }
        static void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
        static string Json(object value) => JsonUtility.ToJson(value);
        static string Account(AccountSave source) { var copy = JsonUtility.FromJson<AccountSave>(Json(source)); copy.lastSeenUtc = 0; return Json(copy); }
        RectTransform Modal => (RectTransform)game.UI.transform.Find("Screen and help modal");
        void Click(string name, Transform parent = null)
        { var button = (parent ?? game.UI.transform).GetComponentsInChildren<Button>().Single(b => b.name == name); Require(button.IsInteractable(), "Disabled: " + name); button.onClick.Invoke(); }
        float ControlHeight(string name)
        {
            Canvas.ForceUpdateCanvases();
            var corners = new Vector3[4]; ((RectTransform)game.UI.transform.GetComponentsInChildren<Button>().Single(b => b.name == name).transform).GetWorldCorners(corners);
            return corners[1].y - corners[0].y;
        }
        T Field<T>(object target, string name) => (T)target.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic).GetValue(target);
        Slider Distance() => game.UI.GetComponentsInChildren<Slider>().Single(s => s.transform.parent.GetComponentsInChildren<Text>().Any(t => t.text.StartsWith("목표 거리", StringComparison.Ordinal)));
        void CheckLayout()
        {
            Canvas.ForceUpdateCanvases(); var modal = Modal; Require(modal != null && modal.GetComponent<Canvas>().isRootCanvas, "Missing independent common canvas.");
            var card = (RectTransform)modal.Find("Common safe area/Common dialog"); var corners = new Vector3[4]; card.GetWorldCorners(corners);
            Require(corners.All(v => v.x >= UiSafeArea.Current.xMin - 1 && v.x <= UiSafeArea.Current.xMax + 1 && v.y >= UiSafeArea.Current.yMin - 1 && v.y <= UiSafeArea.Current.yMax + 1), "Card outside safe area.");
            foreach (var label in modal.GetComponentsInChildren<Text>()) Require(label.preferredHeight <= label.rectTransform.rect.height + 1, "Text clipped: " + label.text);
            var close = modal.GetComponentsInChildren<Button>().Single(b => b.name == "닫기");
            Require(close.transform.parent.name == "Common actions" && close.IsInteractable(), "Close is not a fixed reachable action.");
            Require(!modal.GetComponentsInChildren<Button>().Any(b => b.name == "적용"), "Desktop must not expose mobile orientation apply.");
            var scroll = modal.GetComponentsInChildren<ScrollRect>().Single(); scroll.viewport.GetWorldCorners(corners); float bottom = corners[0].y;
            ((RectTransform)close.transform.parent).GetWorldCorners(corners); Require(bottom >= corners[1].y, "Footer overlaps reading area.");
            Require(game.UI.transform.Find("HELLSCRIPT UI").GetComponent<CanvasGroup>().interactable == false, "Underlying controls accept navigation.");
            File.AppendAllText(Path.Combine(directory, "layout-checks.txt"), $"PASS {Screen.width}x{Screen.height} card={card.rect.size} reading={scroll.viewport.rect.size}\n");
        }
        IEnumerator Capture(string label)
        {
            yield return new WaitForSecondsRealtime(.2f); CheckLayout();
            ScreenCapture.CaptureScreenshot(Path.Combine(directory, $"{++captureIndex:00}-{label}.png")); yield return new WaitForSecondsRealtime(.2f);
        }
        IEnumerator Resize(int width, int height)
        {
            Screen.SetResolution(width, height, FullScreenMode.Windowed); float deadline = Time.realtimeSinceStartup + 6;
            while ((Screen.width != width || Screen.height != height) && Time.realtimeSinceStartup < deadline) yield return null;
            Require(Screen.width == width && Screen.height == height, $"Native window did not reach {width}x{height}; actual {Screen.width}x{Screen.height}.");
            yield return new WaitForSecondsRealtime(.2f);
        }
        IEnumerator Frozen(string label)
        {
            string run = Json(game.Combat.State), account = Account(game.Store.Data); float delay = Field<float>(game, "resultDelay");
            yield return new WaitForSecondsRealtime(.6f);
            Require(run == Json(game.Combat.State) && account == Account(game.Store.Data), label + " changed run or account while open.");
            Require(delay == Field<float>(game, "resultDelay"), label + " advanced repeat delay.");
        }
        IEnumerator Start()
        {
            var args = Environment.GetCommandLineArgs();
            for (int i = 0; i < args.Length - 1; i++) { if (args[i] == "-hellscriptSavePath") saveDirectory = args[i + 1]; if (args[i] == "-hellscriptScreenshots") directory = args[i + 1]; }
            Require(!string.IsNullOrEmpty(saveDirectory) && !string.IsNullOrEmpty(directory), "Use isolated save and evidence paths."); Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1); game = FindAnyObjectByType<GameController>(); Require(game.Store != null, "Account failed to load.");
            string preference = Path.Combine(saveDirectory, "hellscript-display-v1.json"), diskPreference = File.Exists(preference) ? File.ReadAllText(preference) : "";
            if (args.Contains("-hellscriptScreenSettingsResume"))
            {
                Require(Account(game.Store.Data) == File.ReadAllText(Path.Combine(directory, "expected-account.json")), "Desktop restart changed persisted gameplay.");
                Require(game.InterfaceScale.Percent == 140 && game.InterfaceScale.Saved == 140, "Restart lost the saved reading size.");
                Require(string.IsNullOrEmpty(game.InterfaceScaleLoadNotice), "Saved reading size was reported as unreadable: " + game.InterfaceScaleLoadNotice);
                ScreenCapture.CaptureScreenshot(Path.Combine(directory, "00-restart-town-at-140.png")); yield return new WaitForSecondsRealtime(.4f);
                Canvas.ForceUpdateCanvases();
                float plain = Mathf.Sqrt(Screen.width / 720f) * Mathf.Sqrt(Screen.height / 1280f);
                float restored = game.UI.transform.Find("HELLSCRIPT UI").GetComponent<Canvas>().scaleFactor;
                Require(Mathf.Abs(restored - plain * 1.4f) < plain * .05f, $"A restart did not rebuild the town at the saved reading size: canvas scale {restored} against {plain} at 100%.");
                Click("설정·안내"); yield return Capture("restart-desktop");
                Require(!game.DisplaySettings.Mobile && game.DisplaySettings.Pending == 0, "Desktop tried to apply mobile preference.");
                File.WriteAllText(Path.Combine(directory, "runtime-screen-settings-resume.txt"), "PASS: separate native process restored the account and the saved 140% reading size, then opened responsive settings without applying mobile orientation.\n");
                Debug.Log("HELLSCRIPT_SCREEN_SETTINGS_RESUME_OK"); Application.Quit(0); yield break;
            }
            string accountBefore = Account(game.Store.Data); Click("설정·안내"); var initialModal = Modal;
            foreach (var size in new[] { new Vector2Int(720,1280), new Vector2Int(1280,720), new Vector2Int(1920,1080), new Vector2Int(1920,1200), new Vector2Int(900,900), new Vector2Int(640,360), new Vector2Int(842,600), new Vector2Int(844,600), new Vector2Int(900,360), new Vector2Int(1024,768), new Vector2Int(768,1024) })
            {
                yield return Resize(size.x, size.y); yield return Capture($"settings-{size.x}x{size.y}"); Click("게임 안내", Modal); yield return Capture($"help-{size.x}x{size.y}"); Click("화면", Modal);
                Require(Modal == initialModal && game.UI.Page == "town" && Account(game.Store.Data) == accountBefore, "Reflow rebuilt the dialog or changed underlying page/account.");
            }
            Click("게임 안내", Modal); yield return Resize(844, 600);
            var reading = Modal.GetComponentsInChildren<ScrollRect>().Single(); reading.verticalNormalizedPosition = .35f; Canvas.ForceUpdateCanvases(); var anchor = DialogReadingAnchor.Capture(reading);
            var row = Field<RectTransform>(anchor, "row"); yield return Resize(842, 600); Canvas.ForceUpdateCanvases();
            Require(Field<RectTransform>(DialogReadingAnchor.Capture(reading), "row") == row, "Resize lost the paragraph being read.");
            yield return Resize(640, 360); reading.verticalNormalizedPosition = 0; yield return Capture("short-help-last-paragraph");
            var last = (RectTransform)reading.content.GetChild(reading.content.childCount - 1);
            var lastBounds = RectTransformUtility.CalculateRelativeRectTransformBounds(reading.viewport, last);
            Require(lastBounds.min.y >= reading.viewport.rect.yMin - 1 && lastBounds.max.y <= reading.viewport.rect.yMax + 1, "Last help paragraph is unreachable in a short window.");
            Click("닫기", Modal); Require(!game.UI.CommonPanelOpen && game.UI.Page == "town", "Help did not return to town.");
            game.Begin(1, seed: 445533); yield return new WaitForSecondsRealtime(.4f); Click("설정·안내");
            yield return Frozen("Running training"); yield return Capture("training-paused-by-settings"); float time = game.Combat.State.time;
            Click("닫기", Modal); yield return new WaitForSecondsRealtime(.3f); Require(game.Combat.State.time > time && !game.Combat.State.paused, "Running training did not resume.");
            game.TogglePause(); Click("설정·안내"); yield return Frozen("Already paused training"); Click("닫기", Modal);
            Require(game.Combat.State.paused, "Settings cleared manual pause.");
            game.UI.ShowBuild(); Distance().value = 4.5f; var draft = Field<BuildConfig>(game.UI, "editing"); string draftJson = Json(draft);
            Click("설정·안내"); yield return Resize(640, 360); yield return Frozen("Build editor"); yield return Capture("over-unsaved-build"); Click("닫기", Modal);
            Require(game.UI.Page == "build" && ReferenceEquals(draft, Field<BuildConfig>(game.UI, "editing")) && Json(draft) == draftJson && Distance().value == 4.5f && game.Combat.State.paused, "Settings lost the draft or editor pause.");
            game.UI.CancelBuild(); game.ReturnTown(); game.UI.ShowBuild(); yield return Resize(1280, 720); Click("슬롯 1 저장");
            var input = game.UI.GetComponentsInChildren<InputField>().Single(); input.text = "가로·세로 입력 보존"; game.UI.ShowScreenSettings();
            yield return Resize(640, 360); yield return Capture("over-preset-name"); Click("닫기", Modal);
            Require(game.UI.GetComponentsInChildren<InputField>().Single() == input && input.text == "가로·세로 입력 보존", "Settings lost preset text or recreated the field.");
            Require(input.GetComponentInParent<CanvasGroup>().interactable, "Preset controls were not restored.");
            Click("닫기"); Click("저장하지 않고 닫기"); game.UI.CancelBuild();
            game.Begin(seed: 112233); var resizedRun = game.Combat.State; float resizeTime = resizedRun.time;
            yield return Resize(1280, 720); Require(ReferenceEquals(resizedRun, game.Combat.State) && !resizedRun.paused && resizedRun.time > resizeTime, "PC resize paused or reset a live rift.");
            Click("설정·안내"); yield return Frozen("Running rift"); yield return Capture("rift-paused-by-settings"); Click("닫기", Modal);
            game.Combat.Abandon(); game.Combat.State.build.autoRepeat = true; game.Combat.State.build.stopAfterFailures = 99;
            yield return new WaitForSecondsRealtime(1); Require(game.UI.Page == "result", "Missing result page.");
            float before = Field<float>(game, "resultDelay"); var originalRun = game.Combat.State;
            Click("설정·안내"); yield return Frozen("Result repeat"); yield return Capture("repeat-wait-paused"); Click("닫기", Modal);
            yield return new WaitForSecondsRealtime(.3f); Require(ReferenceEquals(originalRun, game.Combat.State) && Field<float>(game, "resultDelay") > before && Field<float>(game, "resultDelay") < before + 1, "Repeat delay reset or skipped ahead.");
            int confirmations = 0;
            typeof(GameUI).GetMethod("Confirm", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(game.UI, new object[] { "반복 대기 중 확인창 보존 검사", (Action)(() => confirmations++) });
            yield return Frozen("Result confirmation"); game.UI.ShowScreenSettings(); yield return Frozen("Settings above confirmation"); Click("닫기", Modal);
            Require(game.UI.transform.Find("HELLSCRIPT UI/Safe area/Confirm") != null && confirmations == 0, "Settings dismissed or executed the underlying confirmation.");
            Click("취소"); yield return new WaitForSecondsRealtime(.2f); Require(confirmations == 0 && ReferenceEquals(originalRun, game.Combat.State), "Confirmation cancel duplicated a command or started a new run.");
            game.Combat.State.build.autoRepeat = false; game.ReturnTown(); game.Save();
            // Reading size: the choice has to change what the window shows, leave every label readable and stay out of the account.
            yield return Resize(1280, 720);
            string scalePreference = Path.Combine(saveDirectory, "hellscript-interface-scale-v1.json");
            Require(!File.Exists(scalePreference) && game.InterfaceScale.Percent == 100, "A default reading size wrote or read a preference.");
            string beforeScale = Account(game.Store.Data); float baseline = ControlHeight("설정·안내");
            Click("설정·안내"); yield return Capture("reading-size-100");
            foreach (int percent in InterfaceScaleOptions.Steps) Require(Modal.GetComponentsInChildren<Button>().Any(b => b.name == percent + "%"), "Missing reading size choice: " + percent);
            Click("140%", Modal); yield return Capture("reading-size-140");
            Require(game.InterfaceScale.Percent == 140 && game.InterfaceScale.Saved == 140 && !game.InterfaceScale.CanRetrySave, "140% was applied without being saved.");
            var choiceRow = (RectTransform)Modal.GetComponentsInChildren<Button>().Single(b => b.name == "140%").transform.parent;
            var choicePane = choiceRow.GetComponentInParent<ScrollRect>(); var rowBounds = RectTransformUtility.CalculateRelativeRectTransformBounds(choicePane.viewport, choiceRow);
            Require(rowBounds.min.y >= choicePane.viewport.rect.yMin - 1 && rowBounds.max.y <= choicePane.viewport.rect.yMax + 1, "The reading size choices left the view after being pressed.");
            yield return Resize(640, 360); yield return Capture("reading-size-140-short"); yield return Resize(1280, 720);
            Click("닫기", Modal);
            float enlarged = ControlHeight("설정·안내");
            Require(enlarged > baseline * 1.35f && enlarged < baseline * 1.45f, $"The same control did not grow with the reading size: {baseline} -> {enlarged}.");
            Require(File.Exists(scalePreference) && File.ReadAllText(scalePreference).Contains("140"), "Reading size was not stored in its own device file.");
            Require(Account(game.Store.Data) == beforeScale, "Reading size changed the account.");
            Require((File.Exists(preference) ? File.ReadAllText(preference) : "") == diskPreference, "Desktop modified device preference.");
            File.WriteAllText(Path.Combine(directory, "expected-account.json"), Account(game.Store.Data));
            File.WriteAllText(Path.Combine(directory, "runtime-screen-settings-smoke.txt"), "PASS: 11 actual macOS window sizes, reading size 100% to 140% applied live with the pressed choice kept in view and stored in its own device file, settings/help geometry and Korean text, fold boundary reading anchor, short-window last paragraph, same overlay and page, live rift and training freeze/resume, running resize, existing pause, unsaved build, preset input, repeat remaining time, confirmation preservation and no duplicate action, device preference isolation. UI callbacks and Metal rendering; no physical touch, keyboard or mobile orientation claim.\n");
            Debug.Log("HELLSCRIPT_SCREEN_SETTINGS_RUNTIME_SMOKE_OK"); Application.Quit(0);
        }
    }
}
