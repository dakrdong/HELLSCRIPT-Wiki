using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Opt-in native evidence for the walkable sanctuary: tap a destination, watch the hero walk,
    // and check that arrival opens the same service the menu offers without touching the account.
    public sealed class RuntimePlazaSmoke : MonoBehaviour
    {
        GameController game;
        string directory,saveDirectory;
        int captureIndex;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if(!Debug.isDebugBuild||!Environment.GetCommandLineArgs().Contains("-hellscriptPlazaSmoke"))return;
            Application.runInBackground=true;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Sanctuary plaza validation").AddComponent<RuntimePlazaSmoke>();
        }
        static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
        static string Account(AccountSave source){var copy=JsonUtility.FromJson<AccountSave>(JsonUtility.ToJson(source));copy.lastSeenUtc=0;return JsonUtility.ToJson(copy);}
        Button Named(string name)=>game.UI.GetComponentsInChildren<Button>().Single(b=>b.name==name);
        void Click(string name){var b=Named(name);Require(b.IsInteractable(),"Disabled: "+name);b.onClick.Invoke();}
        void Note(string line)=>File.AppendAllText(Path.Combine(directory,"runtime-plaza-smoke.txt"),line+"\n");
        IEnumerator Capture(string label)
        {
            yield return new WaitForSecondsRealtime(.2f);Canvas.ForceUpdateCanvases();
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,$"{++captureIndex:00}-{label}.png"));yield return new WaitForSecondsRealtime(.2f);
        }
        // The walk runs on real time in Update; wait for the page to change, never for a fixed delay.
        IEnumerator WaitForPage(string expected,float seconds)
        {
            float deadline=Time.realtimeSinceStartup+seconds;
            while(game.UI.Page!=expected&&Time.realtimeSinceStartup<deadline)yield return null;
            Require(game.UI.Page==expected,$"Expected page {expected} within {seconds}s, still on {game.UI.Page}.");
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();
            for(int i=0;i<args.Length-1;i++){if(args[i]=="-hellscriptScreenshots")directory=args[i+1];if(args[i]=="-hellscriptSavePath")saveDirectory=args[i+1];}
            Require(!string.IsNullOrEmpty(directory)&&!string.IsNullOrEmpty(saveDirectory),"Use isolated save and evidence directories.");Directory.CreateDirectory(directory);
            Screen.SetResolution(1280,720,FullScreenMode.Windowed);yield return new WaitForSecondsRealtime(1);
            game=FindAnyObjectByType<GameController>();Require(game.Store!=null,"Store failed to open.");
            game.SelectHero(0);string account=Account(game.Store.Data);

            Click("성소 거닐기 · NPC 방문");Require(game.UI.Page=="plaza","Plaza did not open.");Require(game.Town!=null&&!game.Town.Walking,"A fresh plaza has no destination.");
            yield return Capture("plaza-1280x720");

            // Walk to the blacksmith: the hero moves, then arrival opens the equipment screen.
            Click("대장장이");Require(game.Town.Walking&&game.Town.Destination==TownStation.Blacksmith,"Destination not set.");
            yield return new WaitForSecondsRealtime(.6f);
            Require(game.Town.Walking&&Vector2.Distance(game.Town.Position,TownLayout.Spawn)>1f,"The hero should have moved from the spawn.");
            yield return Capture("plaza-walking");
            yield return WaitForPage("bag",10);
            Require(Account(game.Store.Data)==account,"Arriving at the blacksmith changed the account.");
            yield return Capture("blacksmith-opens-equipment");

            // Back to the plaza: a new destination replaces the previous request mid-walk.
            game.EnterPlaza();Require(game.UI.Page=="plaza","Plaza did not reopen.");
            Click("수수께끼 상인");yield return new WaitForSecondsRealtime(.4f);Require(game.Town.Destination==TownStation.Merchant,"First destination not set.");
            Click("공유 창고");Require(game.Town.Destination==TownStation.Warehouse,"A new destination must replace the previous one.");
            yield return WaitForPage("warehouse",10);
            Require(Account(game.Store.Data)==account,"Arriving at the warehouse changed the account.");
            yield return Capture("warehouse-opens");

            // Standing at the warehouse, asking for it again opens at once: walking is never a wait.
            game.EnterPlaza();Click("공유 창고");yield return null;yield return null;
            Require(game.UI.Page=="warehouse","Requesting the station you stand at must open immediately.");

            // Tapping the world near a station picks it; tapping empty ground picks nothing.
            game.EnterPlaza();var camera=Camera.main;var merchant=TownLayout.Station(TownStation.Merchant).position;
            var onMerchant=camera.WorldToScreenPoint(new Vector3(merchant.x,1.6f,merchant.y));
            game.TapPlaza(new Vector2(onMerchant.x,onMerchant.y));
            Require(game.Town.Destination==TownStation.Merchant,"A tap on the merchant's post must choose the merchant.");
            game.Town.Cancel();
            var far=camera.WorldToScreenPoint(new Vector3(0,0,-TownLayout.HalfHeight+1));   // open ground near the spawn
            game.TapPlaza(new Vector2(far.x,far.y));
            Require(!game.Town.Walking,"A tap on empty ground must not start a walk.");
            yield return Capture("plaza-tap-picks-station");

            // The rift keeper opens its own screen with the sanctuary's stage, sweep and training actions.
            Click("균열 관리자");yield return WaitForPage("rift-keeper",10);
            foreach(string name in new[]{"균열에 진입","최고 단계 소탕","고정 훈련장","같은 조건으로 A/B 비교","광장으로","성소 메뉴"})Require(Named(name)!=null,"Rift keeper lacks "+name);
            Require(Account(game.Store.Data)==account,"Opening the rift keeper changed the account.");
            yield return Capture("rift-keeper");
            Click("광장으로");Require(game.UI.Page=="plaza","광장으로 returns to the plaza.");
            Click("메뉴");Require(game.UI.Page=="town","Menu returns to the sanctuary.");
            Click("균열 관리자 · 단계·소탕·훈련");Require(game.UI.Page=="rift-keeper","The menu shortcut opens the same screen.");Click("성소 메뉴");
            game.EnterPlaza();Click("메뉴");Require(game.UI.Page=="town"&&!game.Town.Walking,"Menu returns to the sanctuary and cancels the walk.");
            Require(Account(game.Store.Data)==account,"Walking the plaza changed the account.");
            yield return Capture("menu-after-plaza");

            Note("PASS: plaza opens from the menu; walking moves the hero on real time; blacksmith arrival opens the equipment screen; a new destination replaces the previous walk; warehouse arrival opens the account storage; requesting the station you stand at opens immediately; a world tap picks the nearest station and empty ground picks nothing; the rift keeper opens its own screen from the plaza and from the menu with the same actions; the account never changed.");
            Debug.Log("HELLSCRIPT_PLAZA_RUNTIME_SMOKE_OK");Application.Quit(0);
        }
    }
}
