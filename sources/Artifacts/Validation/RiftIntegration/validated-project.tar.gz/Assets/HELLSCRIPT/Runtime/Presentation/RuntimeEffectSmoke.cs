using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimeEffectSmoke : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Install()
        {
            if(!Environment.GetCommandLineArgs().Contains("-hellscriptEffectSmoke"))return;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Effect smoke validation").AddComponent<RuntimeEffectSmoke>();
        }
        static void Require(bool pass,string reason){if(!pass)throw new InvalidOperationException(reason);}
        static RunState Arena(GameController game,string belt)
        {
            if(game.Running)game.ReturnTown();var account=game.Store.Data;account.selectedHero=2;var hero=account.Hero;hero.level=30;
            hero.inventory.RemoveAll(i=>i.slot==5);uint rng=913;var item=ItemGenerator.Create(HeroClass.Mage,5,3,30,ref rng,uniqueId:belt);item.equipped=true;hero.inventory.Add(item);
            hero.build=GameCatalog.Preset(HeroClass.Mage,0);hero.build.rules.Clear();hero.build.rules.Add(new Rule(16));hero.build.activeSkills.Clear();hero.build.activeSkills.Add(16);
            hero.build.passives=Array.Empty<int>();hero.build.movement=MovementMode.Stand;hero.build.distance=2;hero.build.autoRepeat=false;hero.build.potionThreshold=0;
            var fixture=new CombatSimulation(account,game.catalog,1,1,seed:41907);var run=fixture.State;run.training=-1;run.position=RiftMap.Rooms[0];run.enemies.Clear();
            run.enemies.Add(new EnemyState{id=900,kind=0,position=run.position+Vector2.up*2,health=100000,maxHealth=100000,cooldown=1000,speed=0,attack=0});
            account.suspendedRun=run;game.Begin(resume:true);game.SetSpeed(1);game.Combat.State.paused=true;return game.Combat.State;
        }
        static IEnumerator Until(Func<bool> ready,float timeout=5)
        {float end=Time.realtimeSinceStartup+timeout;while(!ready()&&Time.realtimeSinceStartup<end)yield return null;Require(ready(),"Effect fixture did not reach the required state.");}
        static Button Find(string name)=>FindObjectsByType<Button>().First(b=>b.name==name);
        static IEnumerator Capture(GameController game,string directory,string file)
        {game.Combat.State.paused=true;game.UI.RefreshHud();yield return new WaitForSecondsRealtime(.3f);ScreenCapture.CaptureScreenshot(Path.Combine(directory,file));yield return new WaitForSecondsRealtime(.2f);}
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();string directory="";for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptScreenshots")directory=args[i+1];
            Require(args.Contains("-hellscriptSavePath")&&!string.IsNullOrEmpty(directory),"Effect smoke requires isolated save and output paths.");Directory.CreateDirectory(directory);Screen.SetResolution(540,960,FullScreenMode.Windowed);
            yield return new WaitForSecondsRealtime(1);var game=FindAnyObjectByType<GameController>();
            if(!args.Contains("-hellscriptEffectResume"))
            {
                var run=Arena(game,"LC03");run.health=game.Combat.Stats.hp*.19f;run.build.potionThreshold=20;yield return new WaitForSecondsRealtime(.5f);
                run.paused=false;yield return Until(()=>run.shields.Count==2);run.paused=true;
                Require(run.shields.Any(s=>s.definitionId=="M05")&&run.shields.Any(s=>s.definitionId=="LC03"),"Potion shield prevented the independent M05 shield.");
                yield return Capture(game,directory,"01-shield-hud.png");Find("보호막·피해 상세").onClick.Invoke();yield return null;Require(game.UI.Page=="effects","HUD did not open effect details.");
                yield return Capture(game,directory,"02-two-shields.png");Find("전투로 돌아가기").onClick.Invoke();Require(run.paused,"Effect details changed the preceding pause state.");
                run=Arena(game,"LM03");yield return new WaitForSecondsRealtime(.5f);run.paused=false;yield return Until(()=>run.shields.Any(s=>s.definitionId=="M05"));run.paused=true;run.resource=30;
                run.itemEffects.lm03Cooldown=1.25f;float reduction=DamageMath.Calculate(1,0,1,1,game.Combat.Stats.armor,1,0,0).defenseReduction;
                run.effects.Add(new GroundEffect{id=run.nextId++,hostile=true,position=run.position,radius=2,duration=.1f,damage=game.Combat.Stats.hp*.16f/(1-reduction),definitionId="ENEMY_GROUND",casterId="901",rootCastId=901});
                var boss=run.enemies[0];boss.boss=true;run.bossId=boss.id;run.phase=RunPhase.Boss;boss.bossControl.meter=85;
                run.build.activeSkills.Add(17);run.build.rules.Clear();run.build.rules.Add(new Rule(17));run.decisionTime=0;
                // Preserve this controlled boss's visual identity before resuming the actual action scheduler.
                game.World.BuildDungeon(run);yield return new WaitForSecondsRealtime(.5f);
                run.paused=false;yield return Until(()=>boss.bossControl.staggered>0);run.paused=true;
                Require(run.shields.Single().absorbed>=game.Combat.Stats.hp*.15f&&!run.shields.Single().manaPaid&&run.itemEffects.lm03Cooldown>0,"Checkpoint did not retain a qualified, unpaid shield.");
                Require(run.effectEvents.Any(e=>e.kind=="BOSS_STAGGER")&&run.damageEvents.Any(e=>e.incoming&&e.absorbed>0&&e.hpLoss==0),"Nova stagger or incoming absorption was not recorded.");
                yield return Capture(game,directory,"03-boss-stagger.png");Find("보호막·피해 상세").onClick.Invoke();yield return Capture(game,directory,"04-pending-shield-reward.png");
                File.WriteAllText(Path.Combine(directory,"checkpoint.json"),JsonUtility.ToJson(run,true));game.Save();Debug.Log("EFFECT_SMOKE_CHECKPOINT_READY");Application.Quit();yield break;
            }
            var saved=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(directory,"checkpoint.json")));GameStore.NormalizeRun(saved);game.Begin(resume:true);var restored=game.Combat.State;restored.paused=true;
            Require(restored.id==saved.id&&restored.time==saved.time&&restored.rng==saved.rng&&restored.resource==saved.resource,"Effect checkpoint identity or clocks changed.");
            Require(JsonUtility.ToJson(restored.shields[0])==JsonUtility.ToJson(saved.shields[0])&&JsonUtility.ToJson(restored.itemEffects)==JsonUtility.ToJson(saved.itemEffects),"Shield instance or proc cooldown did not survive restart.");
            Require(JsonUtility.ToJson(restored.enemies[0].bossControl)==JsonUtility.ToJson(saved.enemies[0].bossControl)&&restored.damageEvents.Count==saved.damageEvents.Count,"Boss control or damage receipts changed.");
            game.UI.ShowCombatEffects();yield return Capture(game,directory,"05-restored-effects.png");Find("전투로 돌아가기").onClick.Invoke();Require(restored.paused,"Returning from restored details resumed a paused run.");
            game.SetSpeed(1);restored.paused=false;yield return Until(()=>restored.effectEvents.Any(e=>e.definitionId=="LM03"&&e.kind=="RESOURCE")&&restored.enemies[0].bossControl.immunity>0);restored.paused=true;
            var reward=restored.effectEvents.Where(e=>e.definitionId=="LM03"&&e.kind=="RESOURCE").ToArray();Require(reward.Length==1&&Mathf.Abs(reward[0].value-20)<.001f,"Qualified shield did not award exactly 20 resource once.");
            yield return Capture(game,directory,"06-boss-immunity.png");game.UI.ShowCombatEffects();yield return Capture(game,directory,"07-absorption-record.png");
            File.WriteAllText(Path.Combine(directory,"completed.json"),JsonUtility.ToJson(restored,true));game.Save();
            File.WriteAllText(Path.Combine(directory,"runtime-effects-smoke.txt"),$"PASS: normal native player; actual M05 and potion action create independent shields; HP HUD button opens details and preserves pause; M06 action converts 85 meter to stagger; M05 cumulative absorption qualified during LM03 cooldown; actual process restart preserves shield, cooldown, stagger and damage records; the restart resumes, pays exactly 20 resource once and enters 10-second immunity.\nControlled fixture: level 30 Mage, original starter weapon, one real legendary belt per arena (LC03 then LM03), harmless stationary boss, preset 85 control meter and 1.25-second previous-proc cooldown, normalized incoming ground damage at 16% max HP. Training arena persisted through normal save path. No balance or physical-input claim.\nrunId={restored.id}\ncheckpointTime={saved.time:F2}\ncompletionTime={restored.time:F2}\nRenderer={SystemInfo.graphicsDeviceType}\nScreen={Screen.width}x{Screen.height}\n");
            Debug.Log("HELLSCRIPT_EFFECT_RUNTIME_SMOKE_OK");Application.Quit();
        }
    }
}
