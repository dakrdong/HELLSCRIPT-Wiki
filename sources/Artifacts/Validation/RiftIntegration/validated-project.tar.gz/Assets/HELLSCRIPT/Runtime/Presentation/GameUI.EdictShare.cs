using System;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class GameUI
    {
        EdictV2ImportPreview edictImport;
        string edictShareMessage="";

        // The code runs to hundreds of characters, so it moves through the system clipboard rather
        // than a text field nobody would want to proofread.
        public void ShowEdictShare()
        {
            pageRepaint=()=>ShowEdictShare();Base("edict-share","사냥 칙령 공유","현재 원본을 코드로 내보내고, 받은 코드를 확인한 뒤 적용합니다");
            var hero=game.Store.Data.Hero;
            if(HuntEdictV2Storage.IsAbsent(hero.edict))
            {
                Note(content,"이 캐릭터에 저장된 사냥 칙령 원본이 없습니다.",22,70,muted);
                FooterButton(0,1,"돌아가기",ShowTown);return;
            }
            RenderEdictSwitch(hero);
            RenderEdictExport(hero);
            RenderEdictImport(hero);
            if(edictShareMessage!="")Note(content,edictShareMessage,20,80,gold);
            FooterButton(0,2,"돌아가기",()=>{ClearEdictShare();ShowTown();});
            FooterButton(1,2,"항목 편집",()=>{ClearEdictShare();ShowEdictEditor();});
        }

        void ClearEdictShare(){edictImport=null;edictShareMessage="";}

        void RenderEdictSwitch(HeroSave hero)
        {
            Note(content,"자동 판단 사용",24,50,gold);
            Note(content,hero.useEdict
                ?"사냥 칙령 v0.2가 전역 생존 판단을 담당합니다. 조준·공격 순서·회수 정책은 아직 기존 설정을 따릅니다."
                :"꺼져 있습니다. 기존 자동 행동 설계가 단독으로 행동을 결정합니다.",20,86,pale);
            BigButton(content,hero.useEdict?"✓ 사냥 칙령 v0.2 사용 중":"사냥 칙령 v0.2 사용하기",()=>
            {
                bool ok=game.Store.SetHeroEdictEnabled(hero.id,!hero.useEdict,game.catalog);
                edictShareMessage=ok?"":game.Store.Error;
                ShowEdictShare();if(ok)ShowToast(hero.useEdict?"사냥 칙령을 사용합니다.":"사냥 칙령을 끕니다.");
            },hero.useEdict);
        }

        void RenderEdictExport(HeroSave hero)
        {
            Note(content,"내보내기",24,50,gold);
            string code;
            try{code=HuntEdictV2Codec.Encode(hero.edict);}
            catch(Exception e){Note(content,Loc.F("코드를 만들지 못했습니다: {0}", e.Message),20,70,muted);return;}
            Note(content,Loc.F("현재 원본의 공유 코드 · {0}자\n{1}", code.Length, Shorten(code)),20,96,pale);
            BigButton(content,"코드 복사",()=>
            {
                GUIUtility.systemCopyBuffer=code;
                edictShareMessage="";ShowToast("공유 코드를 클립보드에 복사했습니다.");
            });
        }

        void RenderEdictImport(HeroSave hero)
        {
            Note(content,"가져오기",24,50,gold);
            BigButton(content,"클립보드의 코드 확인",()=>
            {
                ClearEdictShare();
                string code=GUIUtility.systemCopyBuffer;
                if(string.IsNullOrWhiteSpace(code)){edictShareMessage="클립보드에 코드가 없습니다. 받은 코드를 복사한 뒤 다시 누르세요.";ShowEdictShare();return;}
                try{edictImport=HuntEdictV2Import.Prepare(code,hero,game.catalog);}
                catch(Exception e){edictShareMessage=Loc.F("코드를 사용할 수 없습니다: {0}", e.Message);}
                ShowEdictShare();
            });
            if(edictImport==null)
            {
                Note(content,"받은 코드를 복사한 뒤 위 버튼을 누르면 적용 전에 바뀌는 내용을 확인할 수 있습니다.",20,70,muted);
                return;
            }
            Note(content,"확인한 코드",22,44,gold);
            foreach(var missing in edictImport.MissingSkills)
                Note(content,Loc.F("• {0}번 칸을 비운 채로 가져옵니다. {1}", missing.slot+1, missing.reason),20,58,new Color(1,.55f,.45f));
            var changes=HuntEdictV2Diff.Describe(hero.edict,edictImport.Draft);
            if(changes.Count==0)Note(content,"현재 원본과 같은 설정입니다. 적용해도 달라지는 값이 없습니다.",20,58,pale);
            else
            {
                Note(content,Loc.F("바뀌는 값 {0}개", changes.Count),21,44,pale);
                foreach(var change in changes.Take(12))Note(content,Loc.F("• {0}",change),19,52,pale);
                if(changes.Count>12)Note(content,Loc.F("… 그 밖에 {0}개가 더 바뀝니다.", changes.Count-12),19,48,muted);
            }
            BigButton(content,"이 코드로 적용",()=>
            {
                var draft=edictImport.Draft;
                if(game.Store.SaveHeroEdict(hero.id,draft,game.catalog))
                {ClearEdictShare();ShowEdictShare();ShowToast("사냥 칙령을 적용했습니다.");}
                else{edictShareMessage=game.Store.Error;ShowEdictShare();}
            },true);
            BigButton(content,"가져오기 취소",()=>{ClearEdictShare();ShowEdictShare();});
        }

        static string Shorten(string code)=>code.Length<=64?code:code.Substring(0,32)+" … "+code.Substring(code.Length-24);
    }
}
