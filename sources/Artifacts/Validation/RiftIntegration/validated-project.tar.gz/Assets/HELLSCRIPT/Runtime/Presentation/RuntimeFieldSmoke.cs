using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Explicit, isolated integration fixture. Never changes a normal player's save.
    public sealed class RuntimeFieldSmoke : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Install()
        {if(Environment.GetCommandLineArgs().Contains("-hellscriptFieldSmoke"))new GameObject("Field smoke validation").AddComponent<RuntimeFieldSmoke>();}
        static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
        static void ScrollTo(string prefix)
        {
            Canvas.ForceUpdateCanvases();var label=FindObjectsByType<Text>().First(t=>t.text.StartsWith(prefix));
            var row=(RectTransform)label.transform.parent;var scroll=row.GetComponentInParent<ScrollRect>();
            float offset=-(row.localPosition.y+row.rect.yMax),max=Mathf.Max(0,scroll.content.rect.height-scroll.viewport.rect.height);
            scroll.content.anchoredPosition=new Vector2(0,Mathf.Clamp(offset,0,max));scroll.StopMovement();
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();string dir="";
            for(int n=0;n<args.Length-1;n++)if(args[n]=="-hellscriptScreenshots")dir=args[n+1];
            Require(!string.IsNullOrEmpty(dir)&&args.Contains("-hellscriptSavePath"),"Field smoke requires isolated save and output directories.");
            Directory.CreateDirectory(dir);yield return new WaitForSecondsRealtime(1);
            var game=FindAnyObjectByType<GameController>();bool resume=args.Contains("-hellscriptFieldResume");
            if(!resume)
            {
                var account=game.Store.Data;var hero=account.Hero;hero.level=30;hero.highestClear=4;hero.capacity=100;hero.build=GameCatalog.Preset(HeroClass.Warrior,0);
                hero.build.openChests=false;hero.build.allowCursedChests=false;hero.build.chestDetour=30;hero.build.useShrines=true;hero.build.autoRepeat=false;
                uint rng=410122;foreach(var item in hero.inventory)item.equipped=false;
                for(int slot=0;slot<8;slot++){var item=ItemGenerator.Create(HeroClass.Warrior,slot,2,30,ref rng);item.equipped=true;hero.inventory.Add(item);}
                uint seed=1;for(;seed<=100;seed++){var map=RiftGenerator.Generate(seed,"field-smoke-probe",5,HeroClass.Warrior);if(map.events.Count==1&&map.shrines.Any(s=>s.definitionId=="SH02"))break;}
                Require(seed<=100,"No generated field fixture found.");game.SelectedStage=5;game.Save();game.Begin(seed:seed);game.SetSpeed(1);
                var run=game.Combat.State;run.paused=true;
                // The fixture starts after room clearance so it can isolate field interactions.
                foreach(var enemy in run.enemies)enemy.dead=true;run.meter=70;run.targetId=-1;run.health=game.Combat.Stats.hp*.5f;run.resource=40;
                var shrine=run.layout.shrines[0];run.position=shrine.openingPosition;shrine.discovered=true;RiftExploration.Discover(run,game.Combat.Map);
                yield return new WaitForSecondsRealtime(.6f);ScreenCapture.CaptureScreenshot(Path.Combine(dir,"01-shrine-ready.png"));yield return new WaitForSecondsRealtime(.2f);
                float health=run.health;run.paused=false;float deadline=Time.realtimeSinceStartup+5;
                while(run.layout.shrines[0].phase!=ShrinePhase.Used&&Time.realtimeSinceStartup<deadline){Require(string.IsNullOrEmpty(run.navigationError),run.navigationError);yield return null;}
                Require(run.layout.shrines[0].phase==ShrinePhase.Used&&run.health==health&&run.resolveShrineTime>19,"Shrine use/refill check failed.");run.paused=true;
                yield return new WaitForSecondsRealtime(.3f);ScreenCapture.CaptureScreenshot(Path.Combine(dir,"02-shrine-blessing.png"));yield return new WaitForSecondsRealtime(.2f);
                game.EditBuild();yield return new WaitForSecondsRealtime(.2f);ScrollTo("저주 상자 참여 안 함");
                yield return new WaitForSecondsRealtime(.3f);ScreenCapture.CaptureScreenshot(Path.Combine(dir,"03-field-policy.png"));yield return new WaitForSecondsRealtime(.2f);
                FindObjectsByType<Button>().First(b=>b.name=="저주 상자 참여 안 함").onClick.Invoke();yield return null;
                FindObjectsByType<Button>().First(b=>b.name=="상자 개봉 꺼짐").onClick.Invoke();yield return null;
                FindObjectsByType<Button>().First(b=>b.name=="설정 적용").onClick.Invoke();run.paused=true;
                Require(run.build.allowCursedChests&&run.build.openChests,"Field UI policy did not apply.");
                var evt=run.layout.events[0];var chest=run.layout.chests.Single(c=>c.id==evt.chestId);chest.discovered=true;run.position=chest.openingPosition;
                RiftExploration.Discover(run,game.Combat.Map);run.paused=false;deadline=Time.realtimeSinceStartup+5;
                while(run.layout.events[0].phase==RiftEventPhase.Dormant&&Time.realtimeSinceStartup<deadline){Require(string.IsNullOrEmpty(run.navigationError),run.navigationError);yield return null;}
                run.paused=true;Require(run.layout.events[0].phase==RiftEventPhase.Active&&run.layout.events[0].enemyIds.Count==4,"Cursed event did not start exactly once.");
                game.UI.RefreshHud();game.Save();File.WriteAllText(Path.Combine(dir,"checkpoint.json"),JsonUtility.ToJson(run,true));
                File.WriteAllText(Path.Combine(dir,"account-checkpoint.json"),JsonUtility.ToJson(account,true));
                yield return new WaitForSecondsRealtime(.6f);ScreenCapture.CaptureScreenshot(Path.Combine(dir,"04-cursed-event.png"));yield return new WaitForSecondsRealtime(.3f);
                Debug.Log("FIELD_SMOKE_CHECKPOINT_READY seed="+seed);Application.Quit();yield break;
            }
            var checkpoint=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(dir,"checkpoint.json")));GameStore.NormalizeRun(checkpoint);
            var accountCheckpoint=JsonUtility.FromJson<AccountSave>(File.ReadAllText(Path.Combine(dir,"account-checkpoint.json")));
            game.Begin(resume:true);var restored=game.Combat.State;
            // App absence is settled independently at GameStore construction, even when a rift is suspended.
            // Combat rewards must be compared with the account after that legitimate settlement.
            int resumedGold=game.Store.Data.gold,resumedMaterials=game.Store.Data.materials,resumedXp=game.Store.Data.Hero.xp;
            int idleGold=resumedGold-accountCheckpoint.gold,idleMaterials=resumedMaterials-accountCheckpoint.materials;
            Require(restored.id==checkpoint.id&&restored.layout.fingerprint==checkpoint.layout.fingerprint&&restored.time==checkpoint.time&&restored.health==checkpoint.health&&restored.rng==checkpoint.rng,"Field checkpoint changed on process restart.");
            Require(restored.resolveShrineTime==checkpoint.resolveShrineTime&&restored.layout.shrines[0].phase==ShrinePhase.Used,"Shrine duration reset on restart.");
            Require(restored.layout.events[0].remaining==checkpoint.layout.events[0].remaining&&restored.layout.events[0].phase==RiftEventPhase.Active&&restored.layout.events[0].enemyIds.SequenceEqual(checkpoint.layout.events[0].enemyIds),"Cursed event restarted on reload.");
            foreach(int id in restored.layout.events[0].enemyIds)Require(JsonUtility.ToJson(restored.enemies.Single(e=>e.id==id))==JsonUtility.ToJson(checkpoint.enemies.Single(e=>e.id==id)),"An echo changed on reload.");
            restored.paused=true;game.UI.ShowRiftMap();yield return new WaitForSecondsRealtime(.5f);ScreenCapture.CaptureScreenshot(Path.Combine(dir,"05-restored-map.png"));yield return new WaitForSecondsRealtime(.2f);
            game.UI.ShowBattle();restored.paused=false;game.SetSpeed(1);float until=Time.realtimeSinceStartup+18;
            while(restored.layout.events[0].phase==RiftEventPhase.Active&&Time.realtimeSinceStartup<until)
            {Require(string.IsNullOrEmpty(restored.navigationError),restored.navigationError);yield return null;}
            Require(restored.layout.events[0].phase==RiftEventPhase.Succeeded,"Cursed event fixture failed: "+restored.layout.events[0].phase+" "+restored.action);
            restored.paused=true;Require(game.Store.Data.gold==resumedGold&&game.Store.Data.materials==resumedMaterials&&game.Store.Data.Hero.xp==resumedXp&&restored.meter==checkpoint.meter,"Echoes paid a combat reward.");
            yield return new WaitForSecondsRealtime(.3f);ScreenCapture.CaptureScreenshot(Path.Combine(dir,"06-event-success.png"));yield return new WaitForSecondsRealtime(.2f);
            restored.paused=false;until=Time.realtimeSinceStartup+12;string chestId=restored.layout.events[0].chestId;
            while(restored.layout.chests.Single(c=>c.id==chestId).phase!=ChestPhase.Opened&&Time.realtimeSinceStartup<until)
            {Require(string.IsNullOrEmpty(restored.navigationError),restored.navigationError);yield return null;}
            var opened=restored.layout.chests.Single(c=>c.id==chestId);Require(opened.phase==ChestPhase.Opened,"Successful cursed chest was not opened.");
            until=Time.realtimeSinceStartup+4;while(!game.Store.Data.Hero.inventory.Any(i=>i.id==opened.reward.id)&&Time.realtimeSinceStartup<until)yield return null;
            restored.paused=true;Require(game.Store.Data.gold==resumedGold+opened.gold&&game.Store.Data.Hero.inventory.Count(i=>i.id==opened.reward.id)==1,"Cursed chest reward was not delivered exactly once.");
            Require(restored.enemies.Count(e=>!string.IsNullOrEmpty(e.eventId))==4&&game.Store.Data.transactions.Count(t=>t.operation.StartsWith("event-start:"))==1&&game.Store.Data.transactions.Count(t=>t.operation.StartsWith("shrine-use:"))==1,"Field transaction repeated.");
            game.Save();game.UI.RefreshHud();yield return new WaitForSecondsRealtime(.5f);ScreenCapture.CaptureScreenshot(Path.Combine(dir,"07-cursed-chest-opened.png"));yield return new WaitForSecondsRealtime(.3f);
            File.WriteAllText(Path.Combine(dir,"completed-field.json"),JsonUtility.ToJson(restored,true));
            File.WriteAllText(Path.Combine(dir,"runtime-field-smoke.txt"),$"PASS: generated stage-5 shrine and cursed event, UI opt-in, actual process restart, active event IDs/timer/HP/RNG and shrine duration preserved, automatic four-echo victory, no echo economy reward, reserved chest reward once.\nFixture: level 30 warrior with eight rare item-level 30 pieces; base room enemies marked cleared and meter set to 70; placed at shrine and chest before interaction. No event enemies weakened or killed by the harness. Flow evidence only, not natural exploration or balance evidence.\nrunId={restored.id}\nmap={restored.layout.fingerprint}\nseed={restored.layout.mapSeed}\neventSeconds={12-restored.layout.events[0].remaining:F2}\nidleGold={idleGold}\nidleMaterials={idleMaterials}\nchestGold={opened.gold}\nitemId={opened.reward.id}\nScreen={Screen.width}x{Screen.height}\n");
            Debug.Log("HELLSCRIPT_FIELD_RUNTIME_SMOKE_OK");Application.Quit();
        }
    }
}
