using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        RiftSeal ActiveSeal=>State.layout.seals.Find(s=>s.id==State.exploration.sealId);
        bool SealBusy=>ActiveSeal!=null&&ActiveSeal.phase==SealPhase.Breaking;
        bool ObjectiveBusy=>SealBusy||OfferingBusy;
        public bool ObjectiveActive=>State.layout.objective!=RiftObjectiveKind.None&&State.training<0;
        public bool ObjectiveComplete=>!ObjectiveActive||State.layout.gateOpen;
        public int SealsBroken=>State.layout.seals.Count(s=>s.phase==SealPhase.Broken);
        // The seals are the short way to the gate. The meter is the way that always works, so a run
        // that cannot reach a seal still ends instead of grinding into the time limit.
        public const int GateMeter=100;
        public event System.Action<string> GateOpened;
        void UpdateGate()
        {
            if(!ObjectiveActive||State.layout.gateOpen)return;
            bool done=State.layout.objective==RiftObjectiveKind.Seals?SealsBroken==State.layout.seals.Count:
                State.layout.objective==RiftObjectiveKind.EssenceCarriers?State.layout.carriers.All(c=>c.completed):State.layout.altar?.phase==OfferingAltarPhase.Offered;
            if(done)OpenGate(false);else if(State.meter>=GateMeter)OpenGate(true);
        }
        void OpenGate(bool byMeter)
        {
            if(State.layout.gateOpen)return;
            RiftObjectives.Open(State,byMeter);AnnounceGate();
        }
        void AnnounceGate()
        {
            Map.RefreshGates();CancelSeal("");CancelOffering("");
            string message=State.layout.gateOpenedByMeter?"처치 게이지 충전 · 보스 관문이 열렸습니다":State.layout.objective==RiftObjectiveKind.Seals?"봉인이 모두 풀렸습니다 · 보스 관문이 열렸습니다":
                State.layout.objective==RiftObjectiveKind.EssenceCarriers?"정수 운반자를 모두 처치했습니다 · 보스 관문이 열렸습니다":"제물을 모두 바쳤습니다 · 보스 관문이 열렸습니다";
            Log("GATE_OPEN",message);GateOpened?.Invoke(message);
        }
        // A seal stays sealed while its room still fights back, so the objective cannot be walked past.
        void UpdateSealAvailability()
        {
            UpdateGate();
            if(!ObjectiveActive)return;
            UpdateOfferingAvailability();
            foreach(var seal in State.layout.seals)
            {
                if(!seal.discovered&&State.visited.Contains(seal.room))seal.discovered=true;
                if(seal.phase!=SealPhase.Locked)continue;
                if(seal.guardGroup>=0&&State.enemies.Any(e=>!e.dead&&e.group==seal.guardGroup))continue;
                seal.phase=SealPhase.Available;
                if(seal.discovered)Log("SEAL_UNLOCK","경비 무리 처치 · 봉인석이 드러났습니다");
            }
        }
        bool ChooseSealGoal(ref Vector2 goal)
        {
            if(!ObjectiveActive||State.layout.gateOpen)return false;
            var active=ActiveSeal;
            if(active!=null&&active.phase==SealPhase.Approaching&&FieldSafe(active.breakingPosition))
            {goal=active.breakingPosition;State.action="봉인석으로 이동";return true;}
            if(SealBusy)return true;
            float best=float.MaxValue;RiftSeal selected=null;Vector2 access=Vector2.zero;
            foreach(var seal in State.layout.seals)
            {
                if(!seal.discovered||seal.phase!=SealPhase.Available||seal.retryAfter>State.time)continue;
                foreach(var p in seal.accessPoints)
                {
                    float length=Map.Length(State.position,p);if(float.IsInfinity(length)||length>=best)continue;
                    best=length;selected=seal;access=p;
                }
            }
            if(selected==null)return false;
            selected.breakingPosition=access;selected.phase=SealPhase.Approaching;State.exploration.sealId=selected.id;
            goal=access;State.action="봉인석으로 이동";return true;
        }
        void TickSeals(float dt)
        {
            var seal=ActiveSeal;if(seal==null)return;
            if(!FieldSafe(seal.breakingPosition)){CancelSeal("전투를 우선합니다");return;}
            if(seal.phase==SealPhase.Approaching)
            {
                if(Vector2.Distance(State.position,seal.breakingPosition)>.25f)return;
                seal.phase=SealPhase.Breaking;State.activeSkill=-1;Log("SEAL_BREAK_START","봉인석 파괴 시작");
            }
            if(seal.phase!=SealPhase.Breaking)return;
            if(Vector2.Distance(State.position,seal.position)>1.8f){CancelSeal("파괴 거리 이탈");return;}
            State.action=Loc.F("봉인석 파괴 {0:0.0} / {1:0.0}초", seal.progress, RiftSeal.Duration);
            CompleteReadySeal();
        }
        void AdvanceSealBreaking(float dt)
        {
            var seal=ActiveSeal;
            if(seal!=null&&seal.phase==SealPhase.Breaking&&FieldSafe(seal.breakingPosition)&&Vector2.Distance(State.position,seal.position)<=1.8f)
                seal.progress=Mathf.Min(RiftSeal.Duration,seal.progress+dt);
        }
        void CompleteReadySeal()
        {
            var seal=ActiveSeal;if(seal==null||seal.phase!=SealPhase.Breaking||seal.progress+.0001f<RiftSeal.Duration)return;
            seal.phase=SealPhase.Broken;State.exploration.sealId="";Visual?.Invoke(seal.position,seal.position,20,1.8f);
            SpawnSealWave(seal);
            int done=SealsBroken,total=State.layout.seals.Count;
            Log("SEAL_BROKEN",Loc.F("봉인 {0} / {1}", done, total));
            State.action=Loc.F("봉인 {0} / {1}", done, total);
            if(done>=total&&!State.layout.gateOpen)
                OpenGate(false);
        }
        // Breaking a seal calls a small answer into the same room, so the reward is never free. They
        // arrive at the room's own group anchors and walk in; landing on top of a hero who just spent
        // 1.5 seconds standing still would be an ambush, not an answer.
        const float SealWaveClearance=8f;
        void SpawnSealWave(RiftSeal seal)
        {
            var room=State.layout.rooms[seal.room];
            var spots=room.groupAnchors.Where(p=>Vector2.Distance(p,State.position)>=SealWaveClearance).OrderByDescending(p=>Vector2.Distance(p,State.position)).ToList();
            if(spots.Count==0)spots=room.groupAnchors.OrderByDescending(p=>Vector2.Distance(p,State.position)).ToList();
            if(spots.Count==0)return;
            for(int n=0;n<3;n++)
            {
                var origin=spots[n%spots.Count];
                for(int attempt=0;attempt<12;attempt++)
                {
                    float angle=(n+attempt*.37f)*Mathf.PI*2/3;
                    Vector2 p=origin+new Vector2(Mathf.Cos(angle),Mathf.Sin(angle))*(1.2f+attempt*.3f);
                    if(!Map.Walkable(p,.4f)||State.enemies.Any(e=>!e.dead&&Vector2.Distance(e.position,p)<.8f))continue;
                    SpawnEnemy(seal.room,State.layout.theme*6+(n==2?2:0),p,-1,false,true);break;
                }
            }
        }
        // Exposed so a test can interrupt a break the way a pack would.
        public void CancelSealForTest(string reason)=>CancelSeal(reason);
        void CancelSeal(string reason)
        {
            var seal=ActiveSeal;if(seal==null)return;
            // Progress is kept. A hero driven off resumes the same seal instead of starting over.
            if(seal.phase==SealPhase.Approaching||seal.phase==SealPhase.Breaking)
            {seal.phase=SealPhase.Available;seal.retryAfter=State.time+2;if(!string.IsNullOrEmpty(reason))Log("SEAL_INTERRUPTED",reason);}
            State.exploration.sealId="";
        }
    }
}
