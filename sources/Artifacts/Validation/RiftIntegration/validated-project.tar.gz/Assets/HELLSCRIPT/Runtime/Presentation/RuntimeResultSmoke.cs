using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Isolated development-player fixture for terminal result navigation.
    public sealed class RuntimeResultSmoke:MonoBehaviour
    {
        const string AnalysisButton="사망 원인 분석 (최근 5초 기록)";
        GameController game;string directory;int capture;
        static void Require(bool value,string message){if(!value)throw new InvalidOperationException(message);}
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if(!Debug.isDebugBuild||!Environment.GetCommandLineArgs().Contains("-hellscriptResultSmoke"))return;
            Application.runInBackground=true;
            Application.logMessageReceived+=(m,s,t)=>{if(t==LogType.Exception)Application.Quit(1);};
            new GameObject("Terminal result validation").AddComponent<RuntimeResultSmoke>();
        }
        IEnumerator Capture(string label,int width,int height,RectTransform focus=null)
        {
            Screen.SetResolution(width,height,FullScreenMode.Windowed);float end=Time.realtimeSinceStartup+6;
            while((Screen.width!=width||Screen.height!=height)&&Time.realtimeSinceStartup<end)yield return null;
            Require(Screen.width==width&&Screen.height==height,"Native result resize failed.");
            yield return new WaitForSecondsRealtime(.3f);
            if(focus!=null){DialogReadingAnchor.Show(focus);yield return new WaitForSecondsRealtime(.2f);}
            Canvas.ForceUpdateCanvases();
            foreach(var button in game.UI.GetComponentsInChildren<Button>())
            {
                var labelText=button.GetComponentInChildren<Text>();
                if(labelText!=null)Require(labelText.preferredHeight<=labelText.rectTransform.rect.height+1,"Clipped result button: "+button.name);
            }
            Require(Loc.MissingCount==0,"Missing result translation: "+string.Join("; ",Loc.Missing));
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,$"{++capture:00}-{label}.png"));
            yield return new WaitForSecondsRealtime(.2f);
        }
        IEnumerator Check(string name,bool death)
        {
            foreach(string language in new[]{"ko","en"})
            {
                game.ApplyLanguage(language);game.UI.ShowResult();yield return null;
                var button=game.UI.GetComponentsInChildren<Button>().SingleOrDefault(b=>b.name==AnalysisButton);
                Require((button!=null)==death,name+" has the wrong death-analysis action.");
                int width=language=="ko"?720:640,height=language=="ko"?1280:360;
                yield return Capture(name+"-"+language,width,height,button==null?null:button.transform as RectTransform);
                if(!death)continue;
                button.onClick.Invoke();Require(game.UI.Page=="defeat-analysis","Death analysis did not open.");
                yield return Capture(name+"-analysis-"+language,width,height);
                game.UI.GetComponentsInChildren<Button>().Single(b=>b.name=="결과 화면으로").onClick.Invoke();
                Require(game.UI.Page=="result","Death analysis did not return to results.");
            }
        }
        CombatSimulation Begin(bool training=false)
        {
            if(game.Combat!=null)game.ReturnTown();game.ApplyLanguage("ko");
            game.Store.Data.Hero.level=30;game.Store.Data.Hero.highestClear=10;game.SelectedStage=10;
            game.Store.Data.Hero.build=BehaviorPresets.ForLevel(game.Store.Data.Hero.heroClass,0,30,game.catalog);
            game.Store.Data.Hero.build.autoRepeat=false;
            game.Begin(training?0:-1,seed:7);
            var sim=game.Combat;
            foreach(var enemy in sim.State.enemies){enemy.speed=0;enemy.attack=0;enemy.cooldown=10000;}
            sim.State.lastDamageTime=-10;return sim;
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();Require(args.Contains("-hellscriptSavePath"),"Use an isolated result account.");
            for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptScreenshots")directory=args[i+1];
            Require(!string.IsNullOrEmpty(directory),"Use a dedicated result evidence directory.");Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1);game=FindAnyObjectByType<GameController>();game.enabled=false;game.Store.Data.guide.hintsHidden=true;

            var sim=Begin();sim.Abandon();
            Require(sim.State.phase==RunPhase.Failed&&sim.State.health>0&&sim.State.statistics.finish==CombatFinish.Abandoned,"Alive return fixture failed.");
            yield return Check("alive-return",false);

            sim=Begin();sim.State.time=299.98f;sim.Tick(.05f);
            Require(sim.State.phase==RunPhase.Failed&&sim.State.health>0&&sim.State.statistics.finish==CombatFinish.Other,"Timeout fixture failed.");
            yield return Check("timeout",false);

            sim=Begin();sim.State.health=0;sim.Tick(.05f);
            Require(sim.State.phase==RunPhase.Failed&&sim.State.statistics.finish==CombatFinish.HeroDeath,"Hero death fixture failed.");
            yield return Check("hero-death",true);

            sim=Begin(true);sim.State.health=0;sim.Tick(.05f);
            Require(sim.State.training>=0&&sim.State.phase==RunPhase.Failed,"Training fixture failed.");
            yield return Check("training-death",false);

            sim=Begin();sim.State.layout.gateOpen=true;sim.State.meter=100;sim.Tick(.05f);
            var boss=sim.State.enemies.Single(e=>e.boss);boss.dead=true;boss.pendingDeath=true;sim.State.health=0;sim.Tick(.05f);
            Require(sim.State.phase==RunPhase.Looting&&sim.State.bossRewarded,"Boss tie fixture failed.");
            sim.Abandon();Require(sim.State.phase==RunPhase.Cleared&&sim.State.health<=0,"Boss tie did not remain a victory.");
            yield return Check("boss-tie-victory",false);

            File.WriteAllText(Path.Combine(directory,"runtime-result-smoke.txt"),"PASS: alive return, live timeout, real terminal hero death, training death, and boss/hero tie victory. Korean and English at 720x1280 and 640x360. Death analysis opens and returns only from the real rift death result. Automated development-player fixtures; not manual combat or mobile touch validation.\n");
            Debug.Log("HELLSCRIPT_RESULT_RUNTIME_OK");Application.Quit(0);
        }
    }
}
