using System.Collections.Generic;
using UnityEngine;

namespace Hellscript
{
    public static class RiftMap
    {
        public static readonly Vector2[] Rooms={new Vector2(-22,-22),new Vector2(0,-22),new Vector2(22,-22),new Vector2(22,0),new Vector2(22,22),new Vector2(0,22),new Vector2(-22,22),new Vector2(-22,0)};
        public static bool Walkable(Vector2 p)
        {
            foreach(var r in Rooms)if(Mathf.Abs(p.x-r.x)<=7.5f&&Mathf.Abs(p.y-r.y)<=7.5f)return true;
            for(int i=0;i<8;i++)
            {
                Vector2 a=Rooms[i],b=Rooms[(i+1)%8],mid=(a+b)*.5f;
                if(a.x==b.x&&Mathf.Abs(p.x-mid.x)<2.5f&&Mathf.Abs(p.y-mid.y)<=11)return true;
                if(a.y==b.y&&Mathf.Abs(p.y-mid.y)<2.5f&&Mathf.Abs(p.x-mid.x)<=11)return true;
            }
            return false;
        }
        public static bool LineClear(Vector2 a,Vector2 b)
        {int n=Mathf.CeilToInt(Vector2.Distance(a,b)*2);for(int i=0;i<=n;i++)if(!Walkable(Vector2.Lerp(a,b,n==0?0:(float)i/n)))return false;return true;}
        public static int ClosestRoom(Vector2 p)
        {int best=0;float d=float.MaxValue;for(int i=0;i<8;i++){float n=(p-Rooms[i]).sqrMagnitude;if(n<d){d=n;best=i;}}return best;}
        public static Vector2 Move(Vector2 p,Vector2 destination,float distance)
        {
            Vector2 goal=destination;
            if(!LineClear(p,goal))
            {
                int from=ClosestRoom(p),to=ClosestRoom(goal);
                if(!LineClear(p,Rooms[from]))return p;
                int clockwise=(to-from+8)%8;
                Vector2 next=Rooms[(from+(clockwise<=4?1:7))%8];
                goal=LineClear(p,next)?next:Rooms[from];
            }
            Vector2 candidate=Vector2.MoveTowards(p,goal,distance);
            if(Walkable(candidate)&&LineClear(p,candidate))return candidate;
            Vector2 x=new Vector2(candidate.x,p.y),y=new Vector2(p.x,candidate.y);
            if(Walkable(x))return x;if(Walkable(y))return y;return p;
        }
        public static Vector2 Escape(Vector2 p,Vector2 target,float range,List<EnemyState> enemies,List<GroundEffect> effects)
        {
            Vector2 best=p;float score=float.MaxValue;
            for(int j=0;j<3;j++)for(int i=0;i<16;i++)
            {
                float angle=i*Mathf.PI/8;Vector2 q=p+new Vector2(Mathf.Cos(angle),Mathf.Sin(angle))*Mathf.Lerp(2,range,j/2f);
                if(!Walkable(q)||!LineClear(p,q))continue;
                float s=0;foreach(var e in enemies)if(!e.dead&&Vector2.Distance(q,e.position)<3)s+=100;
                foreach(var e in effects)if(e.hostile&&Vector2.Distance(q,e.position)<e.radius)s+=300;
                s-=Mathf.Min(8,Vector2.Distance(q,target));
                if(s<score){score=s;best=q;}
            }
            return best;
        }
    }
}
