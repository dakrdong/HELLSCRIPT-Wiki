using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed class RuntimeOutcomeSmoke : MonoBehaviour
    {
        [Serializable]sealed class EconomyStamp{public int gold,materials,idleGold,idleMaterials;}
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Install()
        {
            if(!Environment.GetCommandLineArgs().Contains("-hellscriptOutcomeSmoke"))return;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Outcome smoke validation").AddComponent<RuntimeOutcomeSmoke>();
        }
        static void Require(bool condition,string reason){if(!condition)throw new InvalidOperationException(reason);}
        static IEnumerator Until(Func<bool> ready)
        {float end=Time.realtimeSinceStartup+8;while(!ready()&&Time.realtimeSinceStartup<end)yield return null;Require(ready(),"Outcome fixture did not reach the expected state.");}
        static IEnumerator Capture(GameController game,string directory,string file)
        {game.Combat.State.paused=true;yield return new WaitForSecondsRealtime(.3f);ScreenCapture.CaptureScreenshot(Path.Combine(directory,file));yield return new WaitForSecondsRealtime(.2f);}
        static void VerifyOutcome(GameController game,EconomyStamp initial)
        {
            var run=game.Combat.State;var account=game.Store.Data;
            Require(run.health==0&&run.bossRewarded&&run.heroDeathRecorded,"Simultaneous deaths did not resolve as a boss win.");
            Require(run.damageEvents.Count==3&&run.damageEvents.Count(d=>d.incoming)==2&&run.damageEvents.Any(d=>d.definitionId=="M01"),"A projectile or ground damage event was lost.");
            Require(run.effectEvents.Count(e=>e.kind=="DEATH")==2,"A death was missing or repeated.");
            Require(account.gold==initial.gold+1950+initial.idleGold&&account.materials==initial.materials+15+initial.idleMaterials&&account.Hero.firstClears.Count(s=>s==1)==1,"Clear rewards were missing or repeated.");
            Require(run.drops.Count==3,"Boss loot was generated more than once.");
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();string directory="";for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptScreenshots")directory=args[i+1];
            Require(args.Contains("-hellscriptSavePath")&&!string.IsNullOrEmpty(directory),"Outcome smoke requires isolated save and output paths.");Directory.CreateDirectory(directory);Screen.SetResolution(540,960,FullScreenMode.Windowed);
            yield return new WaitForSecondsRealtime(1);var game=FindAnyObjectByType<GameController>();var account=game.Store.Data;
            if(!args.Contains("-hellscriptOutcomeResume")&&!args.Contains("-hellscriptOutcomeVerify"))
            {
                account.selectedHero=2;var hero=account.Hero;hero.level=30;hero.build=GameCatalog.Preset(HeroClass.Mage,0);hero.build.activeSkills.Clear();hero.build.activeSkills.Add(12);hero.build.rules.Clear();hero.build.rules.Add(new Rule(12));
                hero.build.passives=Array.Empty<int>();hero.build.potionThreshold=0;hero.build.movement=MovementMode.Stand;hero.build.autoRepeat=false;hero.build.bagPolicy=BagPolicy.Portal;
                var fixture=new CombatSimulation(account,game.catalog,1,1,seed:77881);var run=fixture.State;run.training=-1;run.position=RiftMap.Rooms[0];run.enemies.Clear();run.phase=RunPhase.Boss;run.bossId=900;
                run.enemies.Add(new EnemyState{id=900,boss=true,position=run.position+Vector2.up*5,health=100000,maxHealth=100000,speed=0,attack=0,cooldown=1000});account.suspendedRun=run;game.Begin(resume:true);game.SetSpeed(1);run=game.Combat.State;run.paused=true;
                yield return new WaitForSecondsRealtime(.5f);run.paused=false;yield return Until(()=>run.projectiles.Any(p=>p.skill==12));run.paused=true;run.decisionTime=100;
                var fireball=run.projectiles.Single(p=>p.skill==12);Require(run.actionEvents.Any(e=>e.kind=="ACTION_RELEASE"&&e.skill==12),"Fireball was not created by the real action scheduler.");
                fireball.position=run.enemies[0].position-Vector2.up*1.6f;fireball.remaining=2;run.enemies[0].health=1;run.health=10;hero.capacity=hero.inventory.Count;
                run.projectiles.Add(new CombatProjectile{id=run.nextId++,actionId=run.nextId++,hostile=true,createdAt=run.time-.05f,position=run.position+Vector2.up*.7f,direction=Vector2.down,speed=10,remaining=2,radius=.2f,damage=game.Combat.Stats.hp*20,casterId="900",definitionId="ENEMY_ARROW"});
                run.effects.Add(new GroundEffect{id=run.nextId++,rootCastId=run.nextId++,hostile=true,createdAt=run.time-.05f,position=run.position,radius=2,duration=.1f,damage=game.Combat.Stats.hp*20,casterId="900",definitionId="ENEMY_GROUND"});
                game.UI.ShowBattle();yield return Capture(game,directory,"01-opposing-attacks.png");game.Save();
                File.WriteAllText(Path.Combine(directory,"checkpoint.json"),JsonUtility.ToJson(run,true));File.WriteAllText(Path.Combine(directory,"economy-before.json"),JsonUtility.ToJson(new EconomyStamp{gold=account.gold,materials=account.materials},true));
                Debug.Log("OUTCOME_SMOKE_CHECKPOINT_READY");Application.Quit();yield break;
            }
            var economy=JsonUtility.FromJson<EconomyStamp>(File.ReadAllText(Path.Combine(directory,"economy-before.json")));
            economy.idleGold+=game.Store.LocalIdleGoldAwarded;economy.idleMaterials+=game.Store.LocalIdleMaterialsAwarded;File.WriteAllText(Path.Combine(directory,"economy-before.json"),JsonUtility.ToJson(economy,true));
            game.Begin(resume:true);var resumed=game.Combat.State;resumed.paused=true;
            if(args.Contains("-hellscriptOutcomeResume"))
            {
                var saved=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(directory,"checkpoint.json")));
                Require(resumed.id==saved.id&&resumed.time==saved.time&&resumed.rng==saved.rng&&resumed.health==saved.health&&resumed.resource==saved.resource&&resumed.projectiles.Count==saved.projectiles.Count
                    &&!resumed.projectiles.Where((p,i)=>JsonUtility.ToJson(p)!=JsonUtility.ToJson(saved.projectiles[i])).Any()&&resumed.effects.Count==saved.effects.Count
                    &&!resumed.effects.Where((p,i)=>JsonUtility.ToJson(p)!=JsonUtility.ToJson(saved.effects[i])).Any(),"Pending attacks changed during process restart.");
                yield return Capture(game,directory,"02-restored-attacks.png");game.SetSpeed(1);resumed.paused=false;yield return Until(()=>resumed.phase==RunPhase.Looting);resumed.paused=true;resumed.portal=false;
                VerifyOutcome(game,economy);Require(resumed.time>saved.time&&resumed.time-saved.time<.051f,"Both deaths must occur in the first resumed combat tick.");
                game.UI.ShowCombatEffects();yield return Capture(game,directory,"03-simultaneous-deaths.png");game.Save();File.WriteAllText(Path.Combine(directory,"settled.json"),JsonUtility.ToJson(resumed,true));
                Debug.Log("OUTCOME_SMOKE_SETTLED_READY");Application.Quit();yield break;
            }
            var settled=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(directory,"settled.json")));
            Require(resumed.id==settled.id&&resumed.phase==RunPhase.Looting&&resumed.time==settled.time&&resumed.rewardRng==settled.rewardRng,"Settled outcome changed during second restart.");VerifyOutcome(game,economy);
            game.UI.ShowCombatEffects();yield return Capture(game,directory,"04-restored-settlement.png");account.Hero.capacity=50;resumed.portal=false;game.UI.ShowBattle();resumed.paused=false;yield return Until(()=>resumed.phase==RunPhase.Cleared);VerifyOutcome(game,economy);
            Require(account.records.Count(r=>r.id==resumed.id)==1&&resumed.drops.All(d=>d.claimed),"Loot collection or run history repeated.");
            game.UI.ShowResult();yield return Capture(game,directory,"05-clear-result.png");File.WriteAllText(Path.Combine(directory,"completed.json"),JsonUtility.ToJson(resumed,true));game.Save();
            File.WriteAllText(Path.Combine(directory,"runtime-outcomes-smoke.txt"),$"PASS: actual fireball action, pending opposing attacks restored after process restart, the restart resumes one combat tick and records all three damage events and both deaths, boss clear wins with hero HP zero; second process restart restores settled rewards and collects three items with exactly one first clear and one run history record.\nControlled fixture: level 30 Mage, starter weapon, harmless fixed boss; actual fireball position adjusted near impact, boss HP 1 and hero HP 10; pre-existing hostile arrow and ground damage injected for a same-tick fatal collision; inventory capacity constrained until settlement restart. Normal isolated save path. No physical-input, Android or balance claim.\nrunId={resumed.id}\nsettlementTime={settled.time:F2}\nclearGold=1950\nclearMaterials=15\nseparateIdleGold={economy.idleGold}\nseparateIdleMaterials={economy.idleMaterials}\nRenderer={SystemInfo.graphicsDeviceType}\nScreen={Screen.width}x{Screen.height}\n");
            Debug.Log("HELLSCRIPT_OUTCOME_RUNTIME_SMOKE_OK");Application.Quit();
        }
    }
}
