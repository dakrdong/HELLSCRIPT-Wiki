using System;

namespace Hellscript
{
    public enum RiftRewardSource { Normal, Elite, Boss }

    public readonly struct RiftRarityProbabilities
    {
        public readonly double Common, Magic, Rare, Legendary;
        public double Total=>Common+Magic+Rare+Legendary;
        public double RareOrBetter=>Rare+Legendary;

        internal RiftRarityProbabilities(double common,double magic,double rare,double legendary)
        {Common=common;Magic=magic;Rare=rare;Legendary=legendary;}

        public double this[int rarity]
        {
            get
            {
                switch(rarity)
                {
                    case 0:return Common;
                    case 1:return Magic;
                    case 2:return Rare;
                    case 3:return Legendary;
                    default:throw new ArgumentOutOfRangeException(nameof(rarity));
                }
            }
        }

        public int Roll(double unit)
        {
            if(double.IsNaN(unit)||unit<0||unit>=1)throw new ArgumentOutOfRangeException(nameof(unit));
            // Preserve the existing legendary-first roll ordering and consume no additional random values.
            if(unit<Legendary)return 3;
            if(unit<Legendary+Rare)return 2;
            if(unit<Legendary+Rare+Magic)return 1;
            // Zero-probability grades stay impossible even if summation leaves a rounding residue.
            return Common>0?0:Magic>0?1:Rare>0?2:3;
        }
    }

    public static class RiftRarity
    {
        public static RiftRarityProbabilities Get(RiftRewardSource source,int stage)=>Get(source,stage,RiftRarityBalance.Current);

        public static RiftRarityProbabilities Get(RiftRewardSource source,int stage,RiftRarityParameters parameters)
        {
            if(parameters==null)throw new ArgumentNullException(nameof(parameters));
            var profile=parameters.Profile(source);
            // Cast before subtraction so even int.MinValue and int.MaxValue remain safe.
            double elapsed=Math.Max(0,(double)stage-1);
            double growth=elapsed/(elapsed+parameters.GrowthHalfSpan);
            double legendary=profile.Legendary+(profile.LegendaryCap-profile.Legendary)*growth;
            // Fund the legendary increase proportionally from the original non-legendary pool.
            double remaining=(1-legendary)/(1-profile.Legendary);
            return new RiftRarityProbabilities(profile.Common*remaining,profile.Magic*remaining,profile.Rare*remaining,legendary);
        }

        public static int Roll(RiftRewardSource source,int stage,ref uint rng)=>Get(source,stage).Roll(RandomStream.Unit(ref rng));
    }
}
