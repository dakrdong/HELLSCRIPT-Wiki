using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    [Serializable] public sealed class EdictCoreSkill
    {
        public string id;
        public List<EdictOption> options=new List<EdictOption>();
    }
    [Serializable] public sealed class HuntEdictV2Document
    {
        public int schema=HuntEdictV2.Schema,contentVersion=HuntEdictV2.ContentVersion,globalVersion=HuntEdictV2.GlobalVersion,
            optionVersion=HuntEdictV2.OptionVersion,policyVersion=HuntEdictV2.PolicyVersion;
        public string heroClass;
        public string[] slots={"","","",""};
        public List<EdictOption> global=new List<EdictOption>();
        // One shared attack order, independent of slot/display order. Unequipped entries stay here.
        public string[] skillOrder;
        public List<EdictCoreSkill> skills=new List<EdictCoreSkill>();
        public HuntEdictV2Document Copy()=>JsonUtility.FromJson<HuntEdictV2Document>(JsonUtility.ToJson(this));
    }
    public static class HuntEdictV2
    {
        public const int Schema=2,ContentVersion=1,GlobalVersion=1,OptionVersion=2,PolicyVersion=1;
        public static string[] SkillIds(string heroClass)=>HuntEdict.SkillIds(heroClass).Concat(new[]{"BASIC"}).ToArray();
        public static HuntEdictV2Document Create(HeroClass hero)
        {
            if((int)hero<0||(int)hero>2)throw new ArgumentException("알 수 없는 직업입니다.");
            string heroClass=HuntEdict.ClassId(hero);
            return new HuntEdictV2Document{heroClass=heroClass,global=EdictOptions.Defaults(EdictOptions.Global),skillOrder=SkillIds(heroClass),
                skills=SkillIds(heroClass).Select(id=>new EdictCoreSkill{id=id,options=HuntEdictV2Options.ForSkill(id,heroClass).Select(o=>new EdictOption(o.id,o.initial)).ToList()}).ToList()};
        }
        public static string Value(HuntEdictV2Document source,string skill,int option)
        {
            var definitions=HuntEdictV2Options.ForSkill(skill,source.heroClass);
            if(option<1||option>definitions.Count)throw new ArgumentException("해당 스킬의 핵심 옵션 번호를 확인하세요.");
            return source.skills.Single(s=>s.id==skill).options.Single(o=>o.id==definitions[option-1].id).value;
        }
        public static bool Automatic(HuntEdictV2Document source,string skill)=>Value(source,skill,1)=="ON";
        public static HuntEdictV2Document Canonical(HuntEdictV2Document source)
        {
            void Require(bool pass,string error){if(!pass)throw new ArgumentException(error);}
            Require(source!=null,"사냥 칙령 원본이 없습니다.");
            Require(source.schema==Schema&&source.contentVersion==ContentVersion&&source.globalVersion==GlobalVersion&&source.optionVersion==OptionVersion&&source.policyVersion==PolicyVersion,"지원하지 않는 사냥 칙령·옵션·고정 판단 버전입니다.");
            Require(HuntEdict.ClassIndex(source.heroClass)>=0,"알 수 없는 직업입니다.");
            var ids=SkillIds(source.heroClass);var active=HuntEdict.SkillIds(source.heroClass);
            Require(source.slots!=null&&source.slots.Length==4,"사용 스킬 칸은 빈칸을 포함해 네 칸입니다.");
            Require(source.slots.All(s=>s!=null&&(s==""||active.Contains(s)))&&source.slots.Where(s=>s!="").Distinct().Count()==source.slots.Count(s=>s!=""),"사용 스킬의 ID·직업·중복을 확인하세요.");
            Require(source.skillOrder!=null&&source.skillOrder.Length==ids.Length&&source.skillOrder.All(ids.Contains)&&source.skillOrder.Distinct().Count()==ids.Length,"공통 공격 순서에는 기본 공격과 직업 스킬을 한 번씩 넣어야 합니다.");
            Require(source.skills!=null&&source.skills.Count==ids.Length&&source.skills.All(s=>s!=null&&ids.Contains(s.id))&&source.skills.Select(s=>s.id).Distinct().Count()==ids.Length,"미장착 스킬을 포함해 모든 핵심 설정을 한 번씩 보관해야 합니다.");
            Require(source.global!=null&&source.global.Count==EdictOptions.Global.Length,"전역 설정 항목이 누락되거나 추가되었습니다.");
            var global=EdictOptions.Canonical(EdictOptions.Global,source.global,source.heroClass);var skills=new List<EdictCoreSkill>();
            foreach(string id in ids)
            {
                var saved=source.skills.Single(s=>s.id==id);var definitions=HuntEdictV2Options.ForSkill(id,source.heroClass);
                Require(saved.options!=null&&saved.options.Count==definitions.Count&&saved.options.All(o=>o!=null&&o.id!=null)&&saved.options.Select(o=>o.id).Distinct().Count()==definitions.Count,Loc.F("스킬 핵심 옵션이 누락·추가·중복되었습니다: {0}", id));
                Require(saved.options.All(o=>definitions.Any(d=>d.id==o.id)),Loc.F("해당 스킬에 없는 핵심 옵션입니다: {0}", id));
                skills.Add(new EdictCoreSkill{id=id,options=definitions.Select(d=>new EdictOption(d.id,d.CanonicalValue(saved.options.Single(o=>o.id==d.id).value))).ToList()});
            }
            string G(string id)=>global.Single(o=>o.id==id).value;
            if(G("survival.lowHp")=="ON")Require(decimal.Parse(G("survival.returnHpPercent"),CultureInfo.InvariantCulture)>decimal.Parse(G("survival.lowHpPercent"),CultureInfo.InvariantCulture),"전투 복귀 HP는 후퇴 시작 HP보다 높아야 합니다.");
            return new HuntEdictV2Document{heroClass=source.heroClass,slots=source.slots.ToArray(),global=global,skillOrder=source.skillOrder.ToArray(),skills=skills};
        }
        public static HuntEdictV2Document WithOption(HuntEdictV2Document source,string skill,int option,string value)
        {
            var next=Canonical(source);var definitions=HuntEdictV2Options.ForSkill(skill,next.heroClass);
            if(option<1||option>definitions.Count)throw new ArgumentException("해당 스킬의 핵심 옵션 번호를 확인하세요.");
            var definition=definitions[option-1];next.skills.Single(s=>s.id==skill).options[option-1].value=definition.CanonicalValue(value);return next;
        }
        public static HuntEdictV2Document WithSlot(HuntEdictV2Document source,int slot,string skillId,HeroSave hero,GameCatalog catalog)
        {
            var next=Canonical(source);ValidateReceiver(next,hero,catalog);
            if(slot<0||slot>=4||skillId==null||skillId!=""&&!HuntEdict.SkillIds(next.heroClass).Contains(skillId))throw new ArgumentException("현재 직업의 스킬과 사용 칸을 확인하세요.");
            if(skillId!=""&&catalog.skills.Single(s=>s.id==skillId).unlock>hero.level)throw new ArgumentException("아직 해금하지 않은 스킬입니다.");
            int previous=Array.IndexOf(next.slots,skillId);
            if(skillId!=""&&previous>=0&&previous!=slot){next.slots[previous]=next.slots[slot];next.slots[slot]=skillId;}
            else next.slots[slot]=skillId;
            return next;
        }
        internal static void ValidateReceiver(HuntEdictV2Document source,HeroSave hero,GameCatalog catalog)
        {
            if(hero==null||catalog==null||hero.level<1||hero.level>30||(int)hero.heroClass<0||(int)hero.heroClass>2)throw new ArgumentException("현재 캐릭터와 스킬 정보를 확인하세요.");
            if(source.heroClass!=HuntEdict.ClassId(hero.heroClass))throw new ArgumentException("다른 직업의 사냥 칙령입니다.");
            foreach(string id in HuntEdict.SkillIds(source.heroClass))
                if(catalog.skills.Count(s=>s!=null&&s.id==id)!=1||!catalog.skills.Any(s=>s!=null&&s.id==id&&s.heroClass==hero.heroClass&&s.unlock>=1&&s.unlock<=30))throw new ArgumentException(Loc.F("현재 스킬 카탈로그와 원본의 콘텐츠 기준이 다릅니다: {0}", id));
        }
    }
}
