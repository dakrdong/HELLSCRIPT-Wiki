using UnityEngine;

namespace Hellscript
{
    public sealed partial class GameController
    {
        public DisplaySettingsSession DisplaySettings { get; private set; }
        public string DisplayLoadNotice { get; private set; }
        public InterfaceScaleSession InterfaceScale { get; private set; }
        public string InterfaceScaleLoadNotice { get; private set; } = "";
        float displayRequestStarted;
        int displayRequestFrame;
        static DeviceScreenDirection ActualDirection => Screen.width > Screen.height ? DeviceScreenDirection.Landscape : DeviceScreenDirection.Portrait;
        void InitializeDisplaySettings(string directory)
        {
            var store = new DeviceDisplayStore(directory);
            var saved = Application.isMobilePlatform ? store.Read() : DeviceScreenDirection.Portrait;
            DisplayLoadNotice = store.Error;
            DisplaySettings = new DisplaySettingsSession(Application.isMobilePlatform, ActualDirection, saved, store.Write);
            if (DisplaySettings.Mobile) ApplyDisplayDirection(saved, false);
        }
        void InitializeInterfaceScale(string directory)
        {
            var store = new InterfaceScaleStore(directory);
            InterfaceScale = new InterfaceScaleSession(store.Read(), store.Write);
            InterfaceScaleLoadNotice = store.Error;
        }
        // Applying the same size again is the retry path; the screen already shows the choice either way.
        public void ApplyInterfaceScale(int percent)
        {
            if (InterfaceScale == null) return;
            InterfaceScale.Apply(percent);
            if (UI != null) UI.ApplyInterfaceScale();
        }
        public void ApplyDisplayDirection(DeviceScreenDirection direction, bool persist = true)
        {
            if (DisplaySettings == null || !DisplaySettings.Mobile) return;
            DisplaySettings.Request(direction, persist); displayRequestStarted = Time.realtimeSinceStartup; displayRequestFrame = Time.frameCount;
            Screen.orientation = direction == DeviceScreenDirection.Portrait ? ScreenOrientation.Portrait : ScreenOrientation.LandscapeLeft;
        }
        void UpdateDisplaySettings()
        {
            if (DisplaySettings == null) return;
            DisplaySettings.Observe(ActualDirection);
            long token = DisplaySettings.Pending; if (token == 0 || displayRequestFrame + 2 > Time.frameCount) return;
            bool confirmed = DisplaySettings.Actual == DisplaySettings.Requested && Screen.orientation == (DisplaySettings.Requested == DeviceScreenDirection.Portrait ? ScreenOrientation.Portrait : ScreenOrientation.LandscapeLeft);
            if (confirmed || Time.realtimeSinceStartup - displayRequestStarted >= 5) DisplaySettings.Complete(token, ActualDirection, confirmed);
        }
    }
}
