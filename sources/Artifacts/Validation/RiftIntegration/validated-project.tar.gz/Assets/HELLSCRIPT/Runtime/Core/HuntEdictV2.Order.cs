using System;
using System.Collections.Generic;
using System.Linq;

namespace Hellscript
{
    public sealed class EdictOrderedRule
    {
        public readonly Rule rule;
        public readonly int row;
        // Empty when the rule is evaluated; otherwise the reason it is skipped this cycle.
        public readonly string skipReason;
        internal EdictOrderedRule(Rule rule,int row,string skipReason){this.rule=rule;this.row=row;this.skipReason=skipReason;}
    }

    // Decides in which order the legacy rules are inspected when a v0.2 document drives the hero.
    // Pure: it never touches the rules, and with no document it returns them exactly as written.
    public static class EdictRuleOrder
    {
        public static List<EdictOrderedRule> Order(IReadOnlyList<Rule> rules,HuntEdictV2Document document)
        {
            var result=new List<EdictOrderedRule>();
            if(document==null){for(int i=0;i<rules.Count;i++)result.Add(new EdictOrderedRule(rules[i],i,""));return result;}
            var d=HuntEdictV2.Canonical(document);
            string G(string id)=>d.global.Single(o=>o.id==id).value;
            var categories=G("common.order").Split(',');
            int Rank(string category){int index=Array.IndexOf(categories,category);return index<0?categories.Length:index;}
            // Loot rules sit where the document puts loot: before attack when any rarity is collected
            // during combat, otherwise after it.
            bool priorityLoot=new[]{"NORMAL","MAGIC","RARE","LEGENDARY","SET"}.Any(r=>G("loot."+r)=="PRIORITY");
            int lootRank=Rank(priorityLoot?"PRIORITY_LOOT":"AFTER_COMBAT_LOOT"),attackRank=Rank("ATTACK"),exploreRank=Rank("EXPLORE");
            var order=d.skillOrder.ToList();
            string SkillId(Rule r)=>r.action==RuleAction.Basic?"BASIC":r.skill>=0&&r.skill<18?CombatTelemetry.SkillId(r.skill):"";
            int Category(Rule r)=>r.action==RuleAction.Loot?lootRank:r.action==RuleAction.Chest||r.action==RuleAction.Explore?exploreRank:attackRank;
            int Within(Rule r)
            {
                if(r.action!=RuleAction.Skill&&r.action!=RuleAction.Basic)return 0;
                int index=order.IndexOf(SkillId(r));return index<0?order.Count:index;
            }
            var indexed=Enumerable.Range(0,rules.Count).Select(i=>(rule:rules[i],row:i)).ToList();
            foreach(var item in indexed.OrderBy(x=>Category(x.rule)).ThenBy(x=>Within(x.rule)).ThenBy(x=>x.row))
            {
                string skip="";
                if(item.rule.action==RuleAction.Skill||item.rule.action==RuleAction.Basic)
                {
                    string id=SkillId(item.rule);
                    if(id!=""&&d.skills.Any(s=>s.id==id)&&!HuntEdictV2.Automatic(d,id))skip="사냥 칙령에서 자동 사용을 껐습니다.";
                }
                result.Add(new EdictOrderedRule(item.rule,item.row,skip));
            }
            return result;
        }
    }
}
