using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        public Func<string,string,Func<RunState,bool>,bool> CommitRunChange;
        RiftShrine ActiveShrine=>State.layout.shrines.Find(s=>s.id==State.exploration.shrineId);
        bool ShrineBusy=>ActiveShrine!=null&&ActiveShrine.phase==ShrinePhase.Invoking;
        public bool OutOfCombat=>Target==null&&!sensed.Any(e=>!e.dead)&&State.time-Mathf.Max(State.lastDamageTime,Mathf.Max(State.lastOutgoingDamageTime,State.lastAttackTime))>=3;
        public float MovementSpeed(bool recovering)
        {
            float bonus=moveBuff>0&&Hero.heroClass==HeroClass.Ranger&&Stats.passives[1]?.2f:0;
            if(OutOfCombat){if(State.guideShrineTime>0)bonus+=.15f;if(recovering&&Stats.specials.Contains("LC01"))bonus+=.15f;}
            return Stats.SpeedWithBonus(bonus);
        }
        public float BuffDamageReduction=>Mathf.Min(.5f,(leapDefense>0?.15f:0)+(State.resolveShrineTime>0?.1f:0));
        bool FieldSafe(Vector2 position)
        {
            return State.time-State.lastDamageTime>=1&&Target==null&&!InDanger&&!HeroActionBusy&&State.actionCd<=0&&State.activeSkill!=0
                &&!EnemyThreatAt(position,1.5f)&&!State.effects.Any(f=>f.hostile&&Vector2.Distance(f.position,position)<f.radius+3)
                &&!State.enemies.Any(e=>!e.dead&&Vector2.Distance(e.position,position)<3&&Map.LineClear(e.position,position));
        }
        bool FieldCommit(string request,string operation,Func<RunState,bool> change)
        {
            bool success;
            if(CommitRunChange!=null)success=CommitRunChange(request,operation,change);
            else
            {
                var receipt=account.transactions.Find(r=>r.requestId==request);
                if(receipt!=null)return receipt.operation==operation;
                var staged=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(State));GameStore.NormalizeRun(staged);
                success=change(staged);
                if(success){JsonUtility.FromJsonOverwrite(JsonUtility.ToJson(staged),State);GameStore.NormalizeRun(State);account.transactions.Add(new EconomyReceipt{requestId=request,operation=operation,committedUtc=DateTimeOffset.UtcNow.ToUnixTimeSeconds()});}
            }
            if(!success){State.navigationError="필드 진행 상태를 저장하지 못했습니다. 같은 균열을 보존하고 멈췄습니다.";DisableAutoRepeat();Log("FIELD_COMMIT_FAILED",operation);return false;}
            Map=new RiftNavigation(State.layout);sensed.Clear();State.decisionTime=0;return true;
        }
        void ChooseShrineGoal(ref Vector2 goal)
        {
            if(!Policy.useShrines||ActiveChest!=null||State.phase==RunPhase.Boss){CancelShrine("");return;}
            var active=ActiveShrine;
            if(active!=null&&active.phase==ShrinePhase.Approaching&&FieldSafe(active.openingPosition))
            {
                if(!OpeningPointFree(active.openingPosition))
                {var alternative=active.accessPoints.Where(OpeningPointFree).OrderBy(p=>Map.Length(State.position,p)).ToList();if(alternative.Count==0){CancelShrine("접근 위치가 막혔습니다");return;}active.openingPosition=alternative[0];Map.Repath();}
                goal=active.openingPosition;State.action="성소로 이동";return;
            }
            if(ShrineBusy)return;
            float best=float.PositiveInfinity;RiftShrine selected=null;Vector2 access=Vector2.zero;
            foreach(var shrine in State.layout.shrines)
            {
                if(!shrine.discovered||shrine.phase!=ShrinePhase.Available||shrine.retryAfter>State.time||shrine.definitionId=="SH01"&&!Policy.guideShrines||shrine.definitionId=="SH02"&&!Policy.resolveShrines||!FieldSafe(shrine.openingPosition))continue;
                foreach(var p in shrine.accessPoints)
                {if(!OpeningPointFree(p))continue;float length=Map.Length(State.position,p);if(length>Policy.shrineDetour||length>=best)continue;best=length;selected=shrine;access=p;}
            }
            if(selected==null)return;selected.openingPosition=access;selected.phase=ShrinePhase.Approaching;State.exploration.shrineId=selected.id;goal=access;State.action="성소로 이동";
        }
        bool OpeningPointFree(Vector2 p)=>Map.Walkable(p)&&!State.enemies.Any(e=>!e.dead&&Vector2.Distance(e.position,p)<(e.boss?1.65f:.85f));
        void AdvanceShrine(float dt)
        {
            var s=ActiveShrine;if(s==null||s.phase!=ShrinePhase.Invoking)return;
            if(FieldSafe(s.openingPosition)&&Vector2.Distance(State.position,s.position)<=1.5f)s.progress=Mathf.Min(.5f,s.progress+dt);
        }
        void TickShrine(float dt)
        {
            var s=ActiveShrine;if(s==null)return;
            if(!Policy.useShrines||!FieldSafe(s.openingPosition)||State.phase==RunPhase.Boss||s.definitionId=="SH01"&&!Policy.guideShrines||s.definitionId=="SH02"&&!Policy.resolveShrines)
            {CancelShrine("전투를 우선합니다");return;}
            if(s.phase==ShrinePhase.Approaching)
            {if(Vector2.Distance(State.position,s.openingPosition)>.25f)return;s.phase=ShrinePhase.Invoking;s.progress=0;State.activeSkill=-1;Log("SHRINE_START",s.definitionId);}
            if(s.phase!=ShrinePhase.Invoking)return;
            if(Vector2.Distance(State.position,s.position)>1.5f){CancelShrine("사용 거리 이탈");return;}
            State.action=Loc.F("성소 사용 {0:0.0} / 0.5초", s.progress);if(s.progress+.0001f<.5f)return;
            string id=s.id,definition=s.definitionId;Vector2 position=s.position;
            if(!FieldCommit(s.requestId,"shrine-use:"+State.id+":"+id,run=>
            {
                var shrine=run.layout.shrines.Single(x=>x.id==id);
                if(shrine.phase!=ShrinePhase.Invoking||shrine.progress+.0001f<.5f||Vector2.Distance(run.position,shrine.position)>1.5f)return false;
                shrine.phase=ShrinePhase.Used;shrine.progress=.5f;run.exploration.shrineId="";
                if(shrine.definitionId=="SH01")run.guideShrineTime=20;else run.resolveShrineTime=20;return true;
            }))return;
            State.action=definition=="SH01"?"길잡이의 축복 · 비전투 이동 +15%":"결의의 축복 · 피해 감소 +10%p";
            Log("SHRINE_USED",Loc.F("{0} / 20초", State.action));Visual?.Invoke(position,position,20,2);
        }
        void CancelShrine(string reason)
        {
            var s=ActiveShrine;if(s==null)return;
            if(s.phase==ShrinePhase.Approaching||s.phase==ShrinePhase.Invoking)
            {s.phase=ShrinePhase.Available;s.progress=0;s.retryAfter=State.time+2;if(reason!="")Log("SHRINE_INTERRUPTED",reason);}
            State.exploration.shrineId="";
        }
        bool CursedAllowed(RiftChest chest)
        {
            if(chest.definitionId!="CH03")return true;var e=State.layout.events.Find(x=>x.chestId==chest.id);if(e==null)return false;
            if(e.phase==RiftEventPhase.Succeeded)return true;
            return e.phase==RiftEventPhase.Dormant&&Policy.allowCursedChests&&State.phase==RunPhase.Exploring&&300-State.time>=Mathf.Max(90,Policy.cursedMinimumTime);
        }
        bool StartCursedEvent(RiftChest chest)
        {
            var evt=State.layout.events.Find(e=>e.chestId==chest.id);if(evt==null||evt.phase!=RiftEventPhase.Dormant||!CursedAllowed(chest))return false;
            var points=new List<Vector2>();
            foreach(var p in evt.spawnCandidates)
            {if(Vector2.Distance(p,State.position)<2||!OpeningPointFree(p)||points.Any(q=>Vector2.Distance(p,q)<1.5f))continue;points.Add(p);if(points.Count==4)break;}
            if(points.Count<4){chest.retryAfter=State.time+2;CancelChest("잔향 생성 공간 확인");return false;}
            string id=evt.id;int room=chest.room;
            if(!FieldCommit(evt.requestId,"event-start:"+State.id+":"+id,run=>
            {
                var e=run.layout.events.Single(x=>x.id==id);if(e.phase!=RiftEventPhase.Dormant||run.phase!=RunPhase.Exploring||300-run.time<Mathf.Max(90,run.build.cursedMinimumTime)||run.meter<70)return false;
                e.phase=RiftEventPhase.Active;e.remaining=12;e.startedAt=run.time;
                for(int n=0;n<4;n++)
                {SpawnEnemy(room,run.theme*6+(n==3?2:0),points[n],-1,false,true,run);var enemy=run.enemies[run.enemies.Count-1];enemy.eventId=id;e.enemyIds.Add(enemy.id);}
                var c=run.layout.chests.Single(x=>x.id==e.chestId);c.phase=ChestPhase.Locked;c.progress=0;run.exploration.chestId="";return true;
            }))return false;
            State.action="잔향 진압 · 12초 안에 4마리 처치";Log("CURSE_STARTED",State.action);return true;
        }
        void TickFieldEvents(float dt)
        {
            foreach(string id in State.layout.events.Where(e=>e.phase==RiftEventPhase.Active).Select(e=>e.id).ToArray())
            {
                var evt=State.layout.events.Single(e=>e.id==id);evt.remaining=Mathf.Max(0,evt.remaining-dt);
                bool success=evt.enemyIds.Count==4&&evt.enemyIds.All(enemyId=>State.enemies.Any(e=>e.id==enemyId&&e.dead));
                if(!success&&evt.remaining>0)continue;
                string result=success?"success":"failure";
                if(!FieldCommit(State.id+":"+id+":"+result,"event-"+result+":"+State.id+":"+id,run=>
                {
                    var e=run.layout.events.Single(x=>x.id==id);if(e.phase!=RiftEventPhase.Active)return false;
                    e.phase=success?RiftEventPhase.Succeeded:RiftEventPhase.Failed;
                    var c=run.layout.chests.Single(x=>x.id==e.chestId);c.phase=success?ChestPhase.Available:ChestPhase.Exhausted;c.abandoned=!success;
                    if(!success)foreach(var enemy in run.enemies.Where(x=>x.eventId==id))enemy.dead=true;
                    return true;
                }))return;
                Log(success?"CURSE_COMPLETED":"CURSE_FAILED",success?"잔향 진압 성공 · 저주 상자 개봉 가능":"잔향 진압 실패 · 해당 상자는 다시 시도할 수 없습니다");
            }
        }
        void CloseFieldContent()
        {
            foreach(var s in State.layout.shrines)if(s.phase!=ShrinePhase.Used){s.phase=ShrinePhase.Exhausted;s.progress=0;}
            foreach(var e in State.layout.events)if(e.phase==RiftEventPhase.Dormant||e.phase==RiftEventPhase.Active)e.phase=RiftEventPhase.Cancelled;
            foreach(var enemy in State.enemies.Where(e=>!string.IsNullOrEmpty(e.eventId)))enemy.dead=true;
            State.exploration.shrineId="";State.guideShrineTime=0;State.resolveShrineTime=0;
        }
    }
}
