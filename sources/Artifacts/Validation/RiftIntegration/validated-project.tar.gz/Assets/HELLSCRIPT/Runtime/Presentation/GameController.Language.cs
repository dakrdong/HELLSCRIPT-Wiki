using UnityEngine;

namespace Hellscript
{
    public sealed partial class GameController
    {
        public LanguageSession Language { get; private set; }
        public string LanguageLoadNotice { get; private set; } = "";
        // The tables live beside the generated art so a new language is one more text asset.
        public const string LanguageResourceFolder = "Localization/";
        void InitializeLanguage(string directory)
        {
            var store = new LanguageStore(directory);
            string saved = store.Read();
            LanguageLoadNotice = store.Error;
            Language = new LanguageSession(saved, store.Write, LoadLanguageTable);
        }
        static LocalizationTable.Result LoadLanguageTable(string code)
        {
            var asset = Resources.Load<TextAsset>(LanguageResourceFolder + code);
            return asset == null ? new LocalizationTable.Result() : LocalizationTable.Parse(asset.text);
        }
        // Choosing the same language again is the retry path; the screen already shows the choice.
        public void ApplyLanguage(string code)
        {
            if (Language == null) return;
            Language.Apply(code);
            UI?.ApplyLanguage();
        }
    }
}
