using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimeBattleLayoutSmoke : MonoBehaviour
    {
        GameController game;
        string directory;
        int capture;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if (!Debug.isDebugBuild || !Environment.GetCommandLineArgs().Contains("-hellscriptBattleLayoutSmoke")) return;
            Application.runInBackground = true; Application.logMessageReceived += (m,s,t) => { if (t == LogType.Exception) Application.Quit(1); };
            new GameObject("Battle layout validation").AddComponent<RuntimeBattleLayoutSmoke>();
        }
        static void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
        static string Json(object value) => JsonUtility.ToJson(value);
        static T Field<T>(object value, string name) => (T)value.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic).GetValue(value);
        void Click(string name) { var button = game.UI.GetComponentsInChildren<Button>().Single(b => b.name == name); Require(button.IsInteractable(), "Disabled: " + name); button.onClick.Invoke(); }
        IEnumerator Resize(int width, int height)
        {
            Screen.SetResolution(width, height, FullScreenMode.Windowed); float deadline = Time.realtimeSinceStartup + 6;
            while ((Screen.width != width || Screen.height != height) && Time.realtimeSinceStartup < deadline) yield return null;
            Require(Screen.width == width && Screen.height == height, $"Expected native window {width}x{height}; actual {Screen.width}x{Screen.height}."); yield return new WaitForSecondsRealtime(.2f);
        }
        void CheckBattle()
        {
            Canvas.ForceUpdateCanvases(); var viewport = game.UI.BattleViewport; var camera = Camera.main;
            Require(Vector2.Distance(camera.rect.min, viewport.min) < .001f && Vector2.Distance(camera.rect.max, viewport.max) < .001f, "Camera ignored HUD exclusion area.");
            var pixels = Rect.MinMaxRect(viewport.xMin * Screen.width, viewport.yMin * Screen.height, viewport.xMax * Screen.width, viewport.yMax * Screen.height);
            Require(pixels.width > 0 && pixels.height > 0, "Missing world viewport.");
            var hero = camera.WorldToScreenPoint(new Vector3(game.Combat.State.position.x, 1, game.Combat.State.position.y)); Require(pixels.Contains(hero), "Hero is behind the HUD.");
            foreach (var label in game.UI.GetComponentsInChildren<Text>()) Require(label.preferredHeight <= label.rectTransform.rect.height + 1, "Clipped battle text: " + label.text + $" preferred={label.preferredHeight} actual={label.rectTransform.rect.height}");
            foreach (string name in new[] { "Combat HUD", "Actions", "Footer", "Header", "Rift minimap" })
            {
                var rect = game.UI.transform.Find("HELLSCRIPT UI/Safe area/" + name) as RectTransform; if (rect == null || !rect.gameObject.activeInHierarchy) continue;
                var corners = new Vector3[4]; rect.GetWorldCorners(corners); var panel = Rect.MinMaxRect(corners[0].x, corners[0].y, corners[2].x, corners[2].y);
                Require(!pixels.Overlaps(panel), "World overlaps " + name);
                Require(corners.All(p => p.x >= UiSafeArea.Current.xMin - 1 && p.x <= UiSafeArea.Current.xMax + 1 && p.y >= UiSafeArea.Current.yMin - 1 && p.y <= UiSafeArea.Current.yMax + 1), "HUD is outside safe area: " + name);
            }
            foreach (string name in new[] { "일시정지", "행동 수정", "지도", "전투 상태", "귀환", "설정·안내" }) Require(game.UI.GetComponentsInChildren<Button>().Any(b => b.name == name && b.IsInteractable()), "Missing battle command: " + name);
            foreach (var room in Field<Dictionary<int,GameObject>>(game.World, "roomGeometry")) Require(room.Value.activeSelf == game.Combat.State.visited.Contains(room.Key), "Unexplored room exposed by the camera.");
            var actors = Field<Dictionary<int,GameObject>>(game.World, "actors"); Require(!actors.ContainsKey(901) || !actors[901].activeSelf, "Unobserved enemy exposed by wide view.");
            if (game.Combat.State.projectiles.Any(p=>p.id==810))
            {
                var projectiles = Field<Dictionary<int,GameObject>>(game.World,"projectileViews"); var ground = Field<Dictionary<int,GameObject>>(game.World,"hazards");
                Require(projectiles[810].activeSelf && ground[820].activeSelf, "Observed danger was hidden.");
                foreach(int id in new[]{811,812}) Require(!projectiles[id].activeSelf, "Unobserved projectile exposed.");
                foreach(int id in new[]{821,822}) Require(!ground.ContainsKey(id) || !ground[id].activeSelf, "Unobserved hostile ground exposed.");
                Require(!actors.ContainsKey(904) || !actors[904].activeSelf, "Enemy behind a wall exposed.");
                Require(!Field<Dictionary<string,GameObject>>(game.World,"enemyThreatViews").ContainsKey("link-903"), "Tether revealed an unseen partner.");
            }
            File.AppendAllText(Path.Combine(directory, "layout-checks.txt"), $"PASS {Screen.width}x{Screen.height} boss={game.Combat.State.phase==RunPhase.Boss} viewport={pixels} hero={hero} cameraHalfHeight={camera.orthographicSize}\n");
        }
        IEnumerator Capture(string name)
        {
            string before = Json(game.Combat.State), account = Json(game.Store.Data);
            game.World.Present(game.Combat.State, .2f); game.UI.RefreshHud(); yield return new WaitForSecondsRealtime(.2f); CheckBattle();
            Require(before == Json(game.Combat.State) && account == Json(game.Store.Data), "Rendering or reflow changed run, exploration or account.");
            ScreenCapture.CaptureScreenshot(Path.Combine(directory, $"{++capture:00}-{name}.png")); yield return new WaitForSecondsRealtime(.2f);
        }
        IEnumerator Start()
        {
            var args = Environment.GetCommandLineArgs(); Require(args.Contains("-hellscriptSavePath"), "Use an isolated save.");
            for (int i = 0; i < args.Length - 1; i++) if (args[i] == "-hellscriptScreenshots") directory = args[i + 1];
            Require(!string.IsNullOrEmpty(directory), "Use an evidence directory."); Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1); game = FindAnyObjectByType<GameController>(); Require(game.Store != null, "Missing store.");
            game.Store.Data.guide.hintsHidden = true; game.Store.Data.selectedHero = 0; var hero = game.Store.Data.Hero; hero.level = 30;
            hero.build = GameCatalog.Preset(HeroClass.Warrior, 0); hero.build.activeSkills = new List<int> { 0,1,2,4 }; hero.build.autoRepeat = false;
            game.Begin(seed: 335577); game.enabled = false; var run = game.Combat.State; run.paused = true; run.enemies.Clear();
            Vector2 nearby = Enumerable.Range(0,24).Select(i => run.position + new Vector2(Mathf.Cos(i*Mathf.PI/12),Mathf.Sin(i*Mathf.PI/12))*3).First(p => game.Combat.Map.Walkable(p) && game.Combat.Map.LineClear(run.position,p));
            run.enemies.Add(new EnemyState { id=900, position=nearby, health=10000, maxHealth=10000, attack=0, cooldown=1000 });
            run.enemies.Add(new EnemyState { id=901, position=run.layout.rooms.OrderByDescending(r=>(r.position-run.position).sqrMagnitude).First().position, health=10000, maxHealth=10000, attack=0, cooldown=1000 });
            var samples = Enumerable.Range(1,12).SelectMany(radius=>Enumerable.Range(0,48).Select(i=>run.position+new Vector2(Mathf.Cos(i*Mathf.PI/24),Mathf.Sin(i*Mathf.PI/24))*radius)).Where(p=>game.Combat.Map.Walkable(p)).ToArray();
            var blocked = samples.First(p=>!game.Combat.Map.LineClear(run.position,p));
            var linked = samples.First(p=>Vector2.Distance(p,blocked)<=5 && game.Combat.Map.LineClear(run.position,p));
            run.enemies.Add(new EnemyState { id=903,position=linked,health=10000,maxHealth=10000,attack=0,cooldown=1000,elite=2,elitePartner=904 });
            run.enemies.Add(new EnemyState { id=904,position=blocked,health=10000,maxHealth=10000,attack=0,cooldown=1000,elite=2,elitePartner=903 });
            var far = run.position + Vector2.right * 22;
            for(int i=0;i<3;i++)
            {
                var point = i==0?nearby:i==1?far:blocked;
                run.projectiles.Add(new CombatProjectile { id=810+i,actionId=810+i,casterId="E:900",definitionId="ENEMY_ARROW",hostile=true,position=point,origin=point,direction=Vector2.up,speed=8,remaining=10,radius=.2f,damage=1 });
                run.effects.Add(new GroundEffect { id=820+i,definitionId="ENEMY_GROUND",hostile=true,position=point,radius=2,delay=1,duration=5,damage=1 });
            }
            int cosmeticCount = Field<IList>(game.World,"effects").Count;
            game.World.Effect(far,far,30,20); game.World.Effect(blocked,blocked,30,20); game.World.Effect(nearby,blocked,6,1);
            Require(Field<IList>(game.World,"effects").Count==cosmeticCount, "Cosmetic hits or trails revealed an unobserved point.");
            run.action = "공격할 적과 안전한 이동 위치를 확인하고 다음 스킬의 사용 조건을 검사합니다.";
            var view = game.UI.transform.Find("HELLSCRIPT UI/Safe area/Combat viewport");
            var sizes = new[] { new Vector2Int(720,1280), new Vector2Int(1280,720), new Vector2Int(1920,1080), new Vector2Int(1920,1200), new Vector2Int(900,900), new Vector2Int(640,360), new Vector2Int(360,640), new Vector2Int(768,1024), new Vector2Int(958,640), new Vector2Int(960,640), new Vector2Int(1280,600), new Vector2Int(900,360), new Vector2Int(390,844), new Vector2Int(390,818), new Vector2Int(390,820), new Vector2Int(3440,1440) };
            foreach (var size in sizes)
            { yield return Resize(size.x,size.y); yield return Capture($"battle-{size.x}x{size.y}"); Require(game.UI.transform.Find("HELLSCRIPT UI/Safe area/Combat viewport") == view, "Resize recreated the battle page."); }
            run.projectiles[0].position=far;run.effects[0].position=far;game.World.Present(run,0);
            Require(!Field<Dictionary<int,GameObject>>(game.World,"projectileViews")[810].activeSelf && !Field<Dictionary<int,GameObject>>(game.World,"hazards")[820].activeSelf, "Previously visible danger remained exposed after leaving sight.");
            run.projectiles[0].position=nearby;run.effects[0].position=nearby;
            run.phase = RunPhase.Boss; run.bossId = 900; var boss = run.enemies[0]; boss.boss = true; boss.pattern = 0; boss.brain.state = "다음 공격을 준비합니다";
            run.enemyHazards.Add(new EnemyHazard { id=800,enemyId=900,definitionId="BOSS01_SLAM",shape=AttackShape.Circle,position=nearby,radius=3,delay=1,damage=20,duration=.2f });
            game.World.BuildDungeon(run);
            foreach (var size in new[] { new Vector2Int(1280,720), new Vector2Int(640,360), new Vector2Int(360,640), new Vector2Int(720,1280), new Vector2Int(960,640) })
            { yield return Resize(size.x,size.y); yield return Capture($"boss-{size.x}x{size.y}"); }
            yield return Resize(640,360); run.paused = false; yield return Capture("compact-action-summary"); run.paused = true;
            string before = Json(run); Click("전투 상태"); yield return new WaitForSecondsRealtime(.3f);
            var pane = game.UI.GetComponentsInChildren<ScrollRect>().Single();
            Require(pane.content.GetComponentsInChildren<Text>().Any(t=>t.text.Contains(run.action)), "Full action unavailable in compact view.");
            foreach(int id in run.build.activeSkills) Require(pane.content.GetComponentsInChildren<Text>().Any(t=>t.text.Contains(game.catalog.skills[id].name)), "Collapsed skill is inaccessible.");
            pane.verticalNormalizedPosition = 0; yield return new WaitForSecondsRealtime(.2f); ScreenCapture.CaptureScreenshot(Path.Combine(directory,$"{++capture:00}-compact-combat-overview.png")); yield return new WaitForSecondsRealtime(.2f);
            Click("닫기"); Require(Json(run) == before && run.paused, "Combat overview changed the paused run.");
            Click("행동 수정"); Require(game.UI.Page == "build", "Battle command did not reach editor."); Click("설정·안내"); yield return Resize(1280,720); Click("닫기"); game.UI.CancelBuild(); yield return Capture("returned-from-editor");
            game.ReturnTown(); game.Begin(2,seed: 998877); game.enabled = false; run = game.Combat.State; run.paused = false;
            var controlAccount = JsonUtility.FromJson<AccountSave>(Json(game.Store.Data));
            var control = new CombatSimulation(controlAccount, game.catalog, run.stage, run.training, JsonUtility.FromJson<RunState>(Json(run)));
            Require(Json(control.State) == Json(run), "Deterministic comparison did not start from the same state.");
            foreach (var size in new[] { new Vector2Int(720,1280), new Vector2Int(1280,720), new Vector2Int(640,360) })
            {
                yield return Resize(size.x,size.y);
                for(int i=0;i<40;i++) { game.Combat.Tick(CombatSimulation.Step); control.Tick(CombatSimulation.Step); game.World.Present(run,CombatSimulation.Step); game.UI.RefreshHud(); }
                Require(Json(run) == Json(control.State) && Json(game.Combat.Hero) == Json(control.Hero), "Layout or view changed deterministic damage, movement, cooldowns or outcomes.");
            }
            run.paused = true; yield return Capture("training-after-identical-ticks");
            File.WriteAllText(Path.Combine(directory,"runtime-battle-layout-smoke.txt"), "PASS: 16 native macOS sizes including 3440x1440 and fold boundaries, compact/portrait/wide HUD, 5 boss layouts and hazard preview, full text and commands, same battle objects, world viewport excludes persistent HUD, hero inside viewport, unseen room/enemy/projectile/ground/hit/trail/tether filtering and visibility restoration, full compact combat overview, editor/settings return, 120 identical training ticks against an unrendered copy. UI callbacks and Metal rendering; no physical input, mobile-device or performance claim.\n");
            Debug.Log("HELLSCRIPT_BATTLE_LAYOUT_RUNTIME_SMOKE_OK"); Application.Quit(0);
        }
    }
}
