using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public enum GuideStep { Controls, Build, Rift, Decision, Result, Equipment, Edit, Training, Retry }
    [Serializable] public sealed class AccountGuide {public bool controlsRead,hintsHidden;}
    [Serializable] public sealed class HeroGuide
    {
        public int completed;
        public bool firstSkillHintShown,equipmentExplanation;
        public string firstResultRun="",changedBuild="",changeSummary="",comparedItem="";
    }
    public static class FirstPlayGuide
    {
        public static readonly string[] Titles={"자동 전투 이해","현재 직업과 빌드","첫 균열 입장","행동 이유 확인","첫 결과 확인","장비 비교","행동 한 가지 수정","수정한 설정 훈련","다시 도전"};
        public static void Normalize(AccountSave account)
        {account.guide??=new AccountGuide();foreach(var hero in account.heroes)hero.guide??=new HeroGuide();}
        public static bool Done(AccountSave a,HeroSave h,GuideStep step)=>step==GuideStep.Controls?a.guide.controlsRead:(h.guide.completed&(1<<(int)step))!=0;
        public static int Count(AccountSave a,HeroSave h)=>Enumerable.Range(0,Titles.Length).Count(i=>Done(a,h,(GuideStep)i));
        public static bool Complete(AccountSave a,HeroSave h)=>Count(a,h)==Titles.Length;
        public static GuideStep Next(AccountSave a,HeroSave h)=>(GuideStep)Enumerable.Range(0,Titles.Length).FirstOrDefault(i=>!Done(a,h,(GuideStep)i));
        static bool Mark(HeroSave hero,GuideStep step)
        {int value=hero.guide.completed|(1<<(int)step);if(value==hero.guide.completed)return false;hero.guide.completed=value;return true;}
        static HeroSave Owner(AccountSave a,RunState run)=>run==null?null:a.heroes.Find(h=>h.id==run.heroId);
        public static bool ReadControls(AccountSave a){if(a.guide.controlsRead)return false;a.guide.controlsRead=true;return true;}
        public static bool HideHints(AccountSave a,bool hidden){if(a.guide.hintsHidden==hidden)return false;a.guide.hintsHidden=hidden;return true;}
        public static bool ReadBuild(HeroSave h)=>Mark(h,GuideStep.Build);
        public static bool Enter(AccountSave a,RunState run,bool resumed)
        {
            var h=Owner(a,run);if(h==null||run.training>=0)return false;bool changed=Mark(h,GuideStep.Rift);
            if(!resumed&&run.id!=h.guide.firstResultRun&&Done(a,h,GuideStep.Result)&&Done(a,h,GuideStep.Edit)&&Done(a,h,GuideStep.Training)&&Signature(run.build)==h.guide.changedBuild)
                changed|=Mark(h,GuideStep.Retry);
            return changed;
        }
        public static RuleDecision SelectedDecision(RunState run)=>run?.decisions.Where(d=>d.code=="SELECTED").OrderByDescending(d=>d.lastTime).FirstOrDefault();
        public static bool ReadDecision(AccountSave a,RunState run)
        {var h=Owner(a,run);return h!=null&&run.training<0&&SelectedDecision(run)!=null&&Mark(h,GuideStep.Decision);}
        public static bool ReadResult(AccountSave a,RunState run)
        {
            var h=Owner(a,run);if(h==null||run.time<=0||run.phase!=RunPhase.Cleared&&run.phase!=RunPhase.Failed)return false;
            if(run.training<0)
            {bool changed=Mark(h,GuideStep.Result);if(string.IsNullOrEmpty(h.guide.firstResultRun)){h.guide.firstResultRun=run.id;changed=true;}return changed;}
            bool finished=run.health<=0||run.time>=59.9f||run.enemies.Count>0&&run.enemies.All(e=>e.dead);
            return run.trainingUsesOwnedHero&&finished&&SelectedDecision(run)!=null&&Done(a,h,GuideStep.Edit)&&Signature(run.build)==h.guide.changedBuild&&Mark(h,GuideStep.Training);
        }
        public static Item ComparisonCandidate(HeroSave h)=>h.inventory.FirstOrDefault(i=>!i.equipped&&string.IsNullOrEmpty(Economy.EquipError(h,i)));
        public static bool ReadComparison(HeroSave h,Item item)
        {
            if(item==null||!h.inventory.Contains(item)||item.equipped||!string.IsNullOrEmpty(Economy.EquipError(h,item)))return false;
            bool changed=Mark(h,GuideStep.Equipment);if(changed){h.guide.comparedItem=item.id;h.guide.equipmentExplanation=false;}return changed;
        }
        public static bool ReadEquipmentExplanation(HeroSave h)
        {
            if(ComparisonCandidate(h)!=null)return false;bool changed=Mark(h,GuideStep.Equipment);if(changed)h.guide.equipmentExplanation=true;return changed;
        }
        static BuildEditing.BehaviorProfile Profile(BuildConfig build,bool loadout)=>BuildEditing.Profile(build,loadout);
        public static string Signature(BuildConfig b)=>BuildEditing.CombatSignature(b);
        public static string DescribeChange(BuildConfig before,BuildConfig after,GameCatalog catalog)
        {
            if(JsonUtility.ToJson(Profile(before,false))==JsonUtility.ToJson(Profile(after,false)))return "";
            var parts=new List<string>();string[] targets={"가까운 적","정예·보스 우선","지원형 우선","낮은 HP","밀집 중심"};
            if(before.target!=after.target)parts.Add(Loc.F("목표: {0} → {1}", targets[(int)before.target], targets[(int)after.target]));
            if(before.movement!=after.movement||before.distance!=after.distance)parts.Add(Loc.F("이동: {0} {1:0.#}m → {2} {3:0.#}m", BehaviorRules.Movements[(int)before.movement], before.distance, BehaviorRules.Movements[(int)after.movement], after.distance));
            if(before.clockwise!=after.clockwise)parts.Add(Loc.F("선회: {0} → {1}", (before.clockwise?"시계 방향":"반시계 방향"), (after.clockwise?"시계 방향":"반시계 방향")));
            if(before.potionThreshold!=after.potionThreshold)parts.Add(Loc.F("물약: HP {0:0}% 이하 → {1:0}% 이하", before.potionThreshold, after.potionThreshold));
            var a=Profile(before,false).rules;var b=Profile(after,false).rules;
            string Name(Rule r)=>r.action==RuleAction.Skill?catalog.skills[r.skill].name:r.action==RuleAction.Basic?"기본 공격":r.action==RuleAction.Loot?"장비 회수":r.action==RuleAction.Chest?"상자 개봉":"탐색";
            for(int i=0;i<Math.Max(a.Count,b.Count);i++)
            {
                if(i>=a.Count){parts.Add(Loc.F("{0}번 {1} 규칙 추가", i+1, Name(b[i])));break;}
                if(i>=b.Count){parts.Add(Loc.F("{0}번 {1} 규칙 삭제", i+1, Name(a[i])));break;}
                if(JsonUtility.ToJson(a[i])==JsonUtility.ToJson(b[i]))continue;
                parts.Add(Loc.F("{0}번 {1} → {2}\n이전: {3} · {4}\n변경: {5} · {6}", i+1, Name(a[i]), Name(b[i]), (a[i].enabled?"켜짐":"꺼짐"), BehaviorRules.Summary(a[i]), (b[i].enabled?"켜짐":"꺼짐"), BehaviorRules.Summary(b[i])));
                if(a[i].target!=b[i].target||a[i].targetRadius!=b[i].targetRadius)parts.Add(Loc.F("규칙 목표: {0} {1:0.#}m → {2} {3:0.#}m", BehaviorRules.Targets[(int)a[i].target], a[i].targetRadius, BehaviorRules.Targets[(int)b[i].target], b[i].targetRadius));
                if(a[i].overrideMovement!=b[i].overrideMovement||a[i].movement!=b[i].movement||a[i].distance!=b[i].distance)parts.Add(Loc.F("규칙 이동: {0} → {1}", (a[i].overrideMovement?Loc.F("{0} {1:0.#}m",BehaviorRules.Movements[(int)a[i].movement],a[i].distance):"전체 설정"), (b[i].overrideMovement?Loc.F("{0} {1:0.#}m",BehaviorRules.Movements[(int)b[i].movement],b[i].distance):"전체 설정")));
                if(a[i].positionPurpose!=b[i].positionPurpose)parts.Add(Loc.F("이동 목적: {0} → {1}", BehaviorRules.Purposes[(int)a[i].positionPurpose], BehaviorRules.Purposes[(int)b[i].positionPurpose]));
                if(a[i].areaAim!=b[i].areaAim){string[] area={"목표 위치","무리 중심","자신 아래","관측한 이동 경로"};parts.Add(Loc.F("설치 위치: {0} → {1}", area[(int)a[i].areaAim], area[(int)b[i].areaAim]));}
                if(a[i].blizzardMode!=b[i].blizzardMode)parts.Add(Loc.F("눈보라: {0} → {1}", (a[i].blizzardMode==BlizzardMode.Follow?"목표 추적":"위치 고정"), (b[i].blizzardMode==BlizzardMode.Follow?"목표 추적":"위치 고정")));
                if(a[i].escape!=b[i].escape)parts.Add(Loc.F("이동 용도: {0} → {1}", (a[i].escape?"생존용":"공격용"), (b[i].escape?"생존용":"공격용")));break;
            }
            return string.Join("\n",parts);
        }
        public static bool Applied(AccountSave a,HeroSave h,BuildConfig before,BuildConfig after,GameCatalog catalog)
        {
            if(Complete(a,h))return false;string change=DescribeChange(before,after,catalog);if(change=="")return false;
            h.guide.changeSummary=change;h.guide.changedBuild=Signature(after);Mark(h,GuideStep.Edit);
            h.guide.completed&=~((1<<(int)GuideStep.Training)|(1<<(int)GuideStep.Retry));return true;
        }
    }
}
