using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public enum CombatFinish { None, Duration, HeroDeath, TargetsDefeated, Abandoned, Other }
    public enum BlockReason { Cooldown, Resource, CrowdControl, ActionLock, Other }

    [Serializable]
    public sealed class BlockedSkillAttempt
    {
        public int skill;
        public string skillId;
        public string skillName;
        public BlockReason reason;
        public string detail;
        public float time;
    }

    [Serializable]
    public sealed class TickDamageSource
    {
        public string sourceId;
        public string sourceName;
        public float damage;
        public float hpLoss;
        public bool isBoss;
        public bool isHazard;
    }

    [Serializable]
    public sealed class CombatTickSnapshot
    {
        public int tick;
        public float time;
        public float hp;
        public float maxHp;
        public float resource;
        public float incomingDamage;
        public float hpLoss;
        public float absorbed;
        public List<TickDamageSource> damageSources = new List<TickDamageSource>();
        public List<BlockedSkillAttempt> blockedAttempts = new List<BlockedSkillAttempt>();
    }

    [Serializable]
    public sealed class DefeatFatalSourceSummary
    {
        public string sourceId;
        public string sourceName;
        public float totalDamage;
        public float totalHpLoss;
        public int hitCount;
        public float percentage;
        public bool isBoss;
    }

    [Serializable]
    public sealed class DefeatBlockedSummary
    {
        public int skill;
        public string skillId;
        public string skillName;
        public BlockReason reason;
        public string reasonName;
        public int count;
        public string latestDetail;
    }

    [Serializable]
    public sealed class DefeatAnalysis
    {
        public float preDeathWindowSeconds;
        public int snapshotCount;
        public float burstDamage5s;
        public float hpLost5s;
        public float startingHp5s;
        public float finalHp;
        public List<DefeatFatalSourceSummary> fatalSources = new List<DefeatFatalSourceSummary>();
        public List<DefeatBlockedSummary> blockedSummary = new List<DefeatBlockedSummary>();
        public List<CombatTickSnapshot> timeline = new List<CombatTickSnapshot>();
    }

    [Serializable] public sealed class SkillStatistics
    {
        public string definitionId;
        public int starts,releases,completions,interruptions,resourceChecks,hits;
        public double damage,hpDamage;
    }
    [Serializable] public sealed class EvasionObservation
    {
        public int enemyId,attackId,movementId;
        public float startedAt;
    }
    [Serializable] public sealed class CombatStatistics
    {
        public const int RingBufferCapacity = 300;
        public int version,ticks,incomingHits,movementStarts,movementCompletions,resourceChecks;
        public int evasionAttempts,evasionSuccesses,evasionHits,evasionExcluded;
        public bool fullRun,buildChanged;
        public float observedFrom;
        public CombatFinish finish;
        public double damage,hpDamage,incomingDamage,hpLost,absorbed,walkingDistance;
        public List<SkillStatistics> skills=new List<SkillStatistics>();
        public List<EvasionObservation> pendingEvasions=new List<EvasionObservation>();
        // Pre-death telemetry is a within-session read. Serializing 300 snapshots would enlarge every
        // checkpoint and change the account JSON that existing tests compare, so it is never written.
        [NonSerialized] public List<CombatTickSnapshot> ringBuffer=new List<CombatTickSnapshot>();

        public static string ReasonName(BlockReason reason)=>reason switch
        {
            BlockReason.Cooldown=>"재사용 대기중",
            BlockReason.Resource=>"자원 부족",
            BlockReason.CrowdControl=>"군중 제어/침묵",
            BlockReason.ActionLock=>"행동 잠김",
            _=>"기타 방해"
        };

        public void RecordSnapshot(CombatTickSnapshot snapshot)
        {
            ringBuffer??=new List<CombatTickSnapshot>();
            ringBuffer.Add(snapshot);
            if(ringBuffer.Count>RingBufferCapacity)ringBuffer.RemoveAt(0);
        }

        public DefeatAnalysis BuildDefeatAnalysis(GameCatalog catalog=null,float windowSeconds=5f)
        {
            ringBuffer??=new List<CombatTickSnapshot>();
            var analysis=new DefeatAnalysis();
            if(ringBuffer.Count==0)return analysis;

            float lastTime=ringBuffer[ringBuffer.Count-1].time;
            float cutoff=lastTime-windowSeconds;
            var window=ringBuffer.Where(s=>s.time>=cutoff-.001f).ToList();
            if(window.Count==0)window=ringBuffer.ToList();

            analysis.snapshotCount=window.Count;
            analysis.preDeathWindowSeconds=window.Count>1?(window[window.Count-1].time-window[0].time):0f;
            analysis.startingHp5s=window[0].hp;
            analysis.finalHp=window[window.Count-1].hp;
            analysis.timeline=window;

            var sourceMap=new Dictionary<string,DefeatFatalSourceSummary>(StringComparer.Ordinal);
            var blockedMap=new Dictionary<string,DefeatBlockedSummary>(StringComparer.Ordinal);

            foreach(var snap in window)
            {
                analysis.burstDamage5s+=snap.incomingDamage;
                analysis.hpLost5s+=snap.hpLoss;

                if(snap.damageSources!=null)
                {
                    foreach(var src in snap.damageSources)
                    {
                        string key=string.IsNullOrEmpty(src.sourceId)?"UNKNOWN":src.sourceId;
                        if(!sourceMap.TryGetValue(key,out var sum))
                        {
                            sum=new DefeatFatalSourceSummary
                            {
                                sourceId=key,
                                sourceName=src.sourceName??key,
                                totalDamage=0,
                                totalHpLoss=0,
                                hitCount=0,
                                isBoss=src.isBoss
                            };
                            sourceMap[key]=sum;
                        }
                        sum.totalDamage+=src.damage;
                        sum.totalHpLoss+=src.hpLoss;
                        sum.hitCount++;
                        if(src.isBoss)sum.isBoss=true;
                    }
                }

                if(snap.blockedAttempts!=null)
                {
                    foreach(var blk in snap.blockedAttempts)
                    {
                        string key=$"{blk.skill}:{blk.reason}";
                        if(!blockedMap.TryGetValue(key,out var bSum))
                        {
                            string rName=ReasonName(blk.reason);
                            bSum=new DefeatBlockedSummary
                            {
                                skill=blk.skill,
                                skillId=blk.skillId,
                                skillName=blk.skillName??blk.skillId,
                                reason=blk.reason,
                                reasonName=rName,
                                count=0,
                                latestDetail=blk.detail
                            };
                            blockedMap[key]=bSum;
                        }
                        bSum.count++;
                        bSum.latestDetail=blk.detail;
                    }
                }
            }

            float totalLoss=analysis.hpLost5s>0?analysis.hpLost5s:analysis.burstDamage5s;
            foreach(var s in sourceMap.Values.OrderByDescending(s=>s.totalDamage))
            {
                s.percentage=totalLoss>0?Mathf.Clamp01(s.totalDamage/totalLoss)*100f:0f;
                analysis.fatalSources.Add(s);
            }

            analysis.blockedSummary=blockedMap.Values.OrderByDescending(b=>b.count).ToList();
            return analysis;
        }

        public SkillStatistics For(string id)
        {
            id=string.IsNullOrEmpty(id)?"UNKNOWN":id;
            var entry=skills.Find(s=>s.definitionId==id);if(entry!=null)return entry;
            entry=new SkillStatistics{definitionId=id};skills.Add(entry);return entry;
        }
    }
    public static class CombatTelemetry
    {
        public const int Version=1;
        public static bool MovementSkill(int skill)=>skill==1||skill==9||skill==15;
        public static string SkillId(int skill)=>skill<0?"BASIC":new[]{"W","A","M"}[skill/6]+(skill%6+1).ToString("00");
        public static void Normalize(RunState run)
        {
            if(run.statistics!=null&&run.statistics.version>Version)throw new NotSupportedException("더 새로운 전투 집계 버전이 필요합니다. 저장 파일은 보존했습니다.");
            if(run.statistics==null||run.statistics.version==0)
                run.statistics=new CombatStatistics{version=Version,observedFrom=run.time,fullRun=run.time<=.00001f};
            run.statistics.skills??=new List<SkillStatistics>();
            run.statistics.pendingEvasions??=new List<EvasionObservation>();
            run.statistics.ringBuffer??=new List<CombatTickSnapshot>();
        }
        public static void Action(CombatStatistics stats,int skill,string kind)
        {
            var row=stats.For(SkillId(skill));
            if(kind=="ACTION_START")row.starts++;
            if(kind=="ACTION_RELEASE")row.releases++;
            if(kind=="ACTION_END")row.completions++;
            if(kind=="ACTION_INTERRUPTED")row.interruptions++;
            if(kind=="ACTION_TRAVEL"||skill==15&&kind=="ACTION_RELEASE")stats.movementStarts++;
            if(MovementSkill(skill)&&kind=="ACTION_RELEASE")stats.movementCompletions++;
        }
        public static void Damage(CombatStatistics stats,DamageEvent e)
        {
            if(e.incoming)
            {stats.incomingHits++;stats.incomingDamage+=e.finalDamage;stats.hpLost+=e.hpLoss;stats.absorbed+=e.absorbed;return;}
            var row=stats.For(e.definitionId);row.hits++;row.damage+=e.finalDamage;row.hpDamage+=e.hpLoss;
            stats.damage+=e.finalDamage;stats.hpDamage+=e.hpLoss;
        }
        public static void ResourceBlocked(CombatStatistics stats,int skill)
        {stats.resourceChecks++;stats.For(SkillId(skill)).resourceChecks++;}
        public static void Finish(CombatStatistics stats,CombatFinish reason)
        {
            stats.finish=reason;stats.evasionExcluded+=stats.pendingEvasions.Count;stats.pendingEvasions.Clear();
        }
    }
}
