using System;
using System.Collections;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimeGrowthSmoke : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Install()
        {
            if(!Environment.GetCommandLineArgs().Contains("-hellscriptGrowthSmoke"))return;
            Application.runInBackground=true;Application.logMessageReceived+=(m,s,t)=>{if(t==LogType.Exception)Application.Quit(1);};
            new GameObject("Growth validation").AddComponent<RuntimeGrowthSmoke>();
        }
        static void Require(bool condition,string reason){if(!condition)throw new InvalidOperationException(reason);}
        static BuildConfig Draft(GameController game)=>(BuildConfig)typeof(GameUI).GetField("editing",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(game.UI);
        static void Click(GameController game,string prefix)=>game.UI.GetComponentsInChildren<Button>().Single(b=>b.name.StartsWith(prefix,StringComparison.Ordinal)).onClick.Invoke();
        static IEnumerator Until(Func<bool> ready,float seconds=25)
        {
            float deadline=Time.realtimeSinceStartup+seconds;while(!ready()&&Time.realtimeSinceStartup<deadline)yield return null;
            if(ready())yield break;
            var args=Environment.GetCommandLineArgs();var game=FindAnyObjectByType<GameController>();
            for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptScreenshots"&&game?.Combat!=null)
                File.WriteAllText(Path.Combine(args[i+1],"timeout-run.json"),JsonUtility.ToJson(game.Combat.State,true));
            Require(false,"Growth runtime condition timed out; see timeout-run.json.");
        }
        static IEnumerator Capture(GameController game,string dir,string file)
        {
            yield return new WaitForSecondsRealtime(.25f);Canvas.ForceUpdateCanvases();
            foreach(var b in game.UI.GetComponentsInChildren<Button>().Where(b=>b.transform.parent.name=="Footer"))
            {var corners=new Vector3[4];((RectTransform)b.transform).GetWorldCorners(corners);Require(corners.All(c=>c.x>=-1&&c.y>=-1&&c.x<=Screen.width+1&&c.y<=Screen.height+1),"Growth footer clipped.");}
            foreach(var notice in game.UI.GetComponentsInChildren<Text>().Where(t=>t.transform.parent.name=="Notice"))
            {
                Require(notice.preferredHeight<=notice.rectTransform.rect.height+1,"Growth notice text clipped.");
                var bottom=new Vector3[4];((RectTransform)notice.transform.parent).GetWorldCorners(bottom);
                foreach(var skill in game.UI.GetComponentsInChildren<Text>().Where(t=>t.name.StartsWith("Skill ",StringComparison.Ordinal)))
                {var corners=new Vector3[4];skill.rectTransform.GetWorldCorners(corners);Require(bottom[0].y>=corners[1].y,"Growth notice overlaps a skill label.");}
            }
            ScreenCapture.CaptureScreenshot(Path.Combine(dir,file));yield return new WaitForSecondsRealtime(.25f);
        }
        static void ScrollTo(GameController game,string phrase)
        {
            Canvas.ForceUpdateCanvases();var label=game.UI.GetComponentsInChildren<Text>().Single(t=>t.text.Contains(phrase));
            var row=(RectTransform)label.transform.parent;var scroll=row.GetComponentInParent<ScrollRect>();
            scroll.content.anchoredPosition=new Vector2(0,Mathf.Clamp(-(row.localPosition.y+row.rect.yMax),0,Mathf.Max(0,scroll.content.rect.height-scroll.viewport.rect.height)));scroll.StopMovement();
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();string dir="";for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptScreenshots")dir=args[i+1];
            Require(args.Contains("-hellscriptSavePath")&&!string.IsNullOrEmpty(dir),"Growth smoke requires isolated save and evidence paths.");Directory.CreateDirectory(dir);Screen.SetResolution(540,960,FullScreenMode.Windowed);
            yield return new WaitForSecondsRealtime(1);var game=FindAnyObjectByType<GameController>();
            if(args.Contains("-hellscriptGrowthResume"))
            {
                var expectedHero=JsonUtility.FromJson<HeroSave>(File.ReadAllText(Path.Combine(dir,"checkpoint-hero.json")));var expected=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(dir,"checkpoint-run.json")));
                Require(JsonUtility.ToJson(expectedHero)==JsonUtility.ToJson(game.Store.Data.Hero),"Hero progress or explicitly applied recommendation changed on restart.");
                game.Begin(resume:true);var restored=game.Combat.State;restored.paused=true;
                Require(restored.id==expected.id&&restored.time==expected.time&&restored.rng==expected.rng&&restored.health==expected.health&&restored.resource==expected.resource,"Growth rift checkpoint changed.");
                Require(restored.pendingExperience==0&&restored.growthEvents.Count==1&&JsonUtility.ToJson(restored.growthEvents[0])==JsonUtility.ToJson(expected.growthEvents[0]),"Growth was repeated or its HP/unlock record changed.");
                Require(game.Combat.Stats.hp==new HeroStats(game.Store.Data.Hero).hp,"Restored combat stats do not match the new level.");
                game.UI.ShowGrowth();ScrollTo(game,"HP ");yield return Capture(game,dir,"06-restored-growth-record.png");game.ReturnTown();
                int xp=game.Store.Data.Hero.xp;game.Begin(1);game.SetSpeed(1);
                yield return Until(()=>game.Combat.State.actionEvents.Any(e=>e.kind=="ACTION_START"&&e.skill==13));
                yield return Until(()=>game.Combat.State.damageEvents.Any(d=>d.definitionId=="M01"&&d.hpLoss>0));game.Combat.State.paused=true;
                Require(game.Store.Data.Hero.xp==xp,"Post-unlock training changed real XP.");File.WriteAllText(Path.Combine(dir,"unlocked-training.json"),JsonUtility.ToJson(game.Combat.State,true));
                yield return Capture(game,dir,"07-unlocked-blizzard-and-fireball.png");game.ReturnTown();
                File.WriteAllText(Path.Combine(dir,"runtime-growth-smoke.txt"),"PASS: real recommendation preview/cancel/draft/apply, level-one fireball in owned group training, genuine generated-rift kill from an isolated Lv.2 XP174 setup, ratio-preserving Lv.3 with disabled rules preserved, explicit in-rift recommendation application, real process restart with unchanged XP/HP/growth record, Lv.3 blizzard and fireball in owned training.\nRenderer="+SystemInfo.graphicsDeviceType+"\nScreen="+Screen.width+"x"+Screen.height+"\nFixture is not a fresh-account progression/balance claim. UI callbacks, not physical-input or Android proof.\n");
                Debug.Log("HELLSCRIPT_GROWTH_RUNTIME_SMOKE_OK");Application.Quit(0);yield break;
            }
            game.SelectHero(2);Require(game.Store.Data.Hero.level==1,"Growth smoke needs a fresh isolated account.");
            string original=JsonUtility.ToJson(game.Store.Data.Hero.build);game.UI.ShowBuild();Draft(game).distance=5.5f;
            Click(game,"서리 장판");yield return Capture(game,dir,"01-starter-recommendation-preview.png");Click(game,"돌아가기");
            Require(Draft(game).distance==5.5f&&JsonUtility.ToJson(game.Store.Data.Hero.build)==original,"Preview cancel changed the draft or live build.");
            Click(game,"서리 장판");Click(game,"편집안에 불러오기");Require(JsonUtility.ToJson(game.Store.Data.Hero.build)==original,"Loading a preview applied it prematurely.");Click(game,"설정 적용");
            game.Begin(1);game.SetSpeed(1);yield return Until(()=>game.Combat.State.damageEvents.Any(d=>d.definitionId=="M01"&&d.hpLoss>0));game.Combat.State.paused=true;
            Require(game.Combat.EffectiveLevel==1&&!game.Combat.State.actionEvents.Any(e=>e.kind=="ACTION_START"&&e.skill==13),"Unlearned blizzard executed.");
            yield return Capture(game,dir,"02-starter-fireball-training.png");game.ReturnTown();
            var hero=game.Store.Data.Hero;hero.level=2;hero.xp=174;hero.build=BehaviorPresets.ForLevel(HeroClass.Mage,0,2,game.catalog);game.Save();
            game.Begin(seed:91367);var run=game.Combat.State;run.health=game.Combat.Stats.hp*.65f;game.SetSpeed(1);
            yield return Until(()=>run.growthEvents.Count>0||!game.Active,40);run.paused=true;
            Require(hero.level==3&&run.growthEvents.Count==1,"A generated-rift kill did not unlock level three.");var change=run.growthEvents[0];
            Require(Mathf.Abs(change.healthBefore/change.oldMaxHp-change.healthAfter/change.newMaxHp)<.00001f&&change.healthAfter<change.newMaxHp,"Level up healed or changed the HP ratio.");
            Require(!run.build.rules.Single(r=>r.skill==13).enabled&&change.unlockedSkills.Contains(13),"Unlock silently enabled the saved rule.");
            game.UI.RefreshHud();yield return Capture(game,dir,"03-live-level-and-xp.png");game.UI.ShowGrowth();yield return Capture(game,dir,"04-unlocked-skill-status.png");ScrollTo(game,"HP ");yield return Capture(game,dir,"05-health-ratio-growth-record.png");
            Click(game,"서리 장판 · 현재 레벨 추천");Click(game,"편집안에 불러오기");float hp=run.health,resource=run.resource;string cds=string.Join(",",run.cooldowns);var skills=run.build.activeSkills.ToArray();Click(game,"설정 적용");
            Require(run.build.rules.Single(r=>r.skill==13).enabled&&skills.SequenceEqual(run.build.activeSkills)&&run.health==hp&&run.resource==resource&&string.Join(",",run.cooldowns)==cds,"Explicit recommendation reset resources or bypassed the rift loadout lock.");
            game.Save();Require(string.IsNullOrEmpty(game.Store.Error),"Growth checkpoint save failed.");File.WriteAllText(Path.Combine(dir,"checkpoint-hero.json"),JsonUtility.ToJson(hero,true));File.WriteAllText(Path.Combine(dir,"checkpoint-run.json"),JsonUtility.ToJson(run,true));
            Debug.Log("HELLSCRIPT_GROWTH_CHECKPOINT_READY");Application.Quit(0);
        }
    }
}
