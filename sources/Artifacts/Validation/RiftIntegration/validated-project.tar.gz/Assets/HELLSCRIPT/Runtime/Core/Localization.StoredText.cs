using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace Hellscript
{
    public static partial class Loc
    {
        sealed class StoredTemplate
        {
            public string source,translation;
            public Regex pattern;
            public int[] arguments;
            public int literalLength;
        }
        static readonly Regex StoredHole=new Regex(@"(?<!\{)\{([0-9]+)(?:,-?[0-9]+)?(?::[^{}]*)?\}(?!\})",RegexOptions.CultureInvariant);
        static readonly Regex LogPrefix=new Regex(@"\A[0-9]+(?:[.,][0-9]+)?s \[[A-Z][A-Z0-9_]*\] ",RegexOptions.CultureInvariant);
        static List<StoredTemplate> storedTemplates;
        static readonly Dictionary<string,string> storedTranslations=new Dictionary<string,string>(StringComparer.Ordinal);
        static void ResetStoredTranslations(){storedTemplates=null;storedTranslations.Clear();}

        // Saved logs predate structured localization. Translate their message at read time without
        // changing the timestamp, event identifier, stored precision, or original record bytes.
        public static string LogLine(string line)
        {
            if(table==null||string.IsNullOrEmpty(line))return line;
            var prefix=LogPrefix.Match(line);
            string message=prefix.Success?line.Substring(prefix.Length):line;
            return (prefix.Success?prefix.Value:"")+StoredText(message);
        }
        public static string StoredText(string text)
        {
            if(table==null||string.IsNullOrEmpty(text)||!WrittenInSource(text))return text;
            if(storedTranslations.TryGetValue(text,out string known))return known;
            string result=TranslateStored(text,0);
            // A long session must not retain every generated combat line indefinitely.
            if(storedTranslations.Count>=2048)storedTranslations.Clear();
            storedTranslations[text]=result;return result;
        }
        static string TranslateStored(string text,int depth)
        {
            if(table.TryGetValue(text,out string exact))return exact;
            if(!WrittenInSource(text))return text;
            if(depth>=8||text.Length>8192)return T(text);
            if(storedTemplates==null)BuildStoredTemplates();
            foreach(var template in storedTemplates)
            {
                Match match;
                try{match=template.pattern.Match(text);}catch(RegexMatchTimeoutException){continue;}
                if(!match.Success)continue;
                int maximum=0;foreach(int argument in template.arguments)maximum=Math.Max(maximum,argument);
                var values=new object[maximum+1];
                foreach(int argument in template.arguments)
                    values[argument]=TranslateStored(match.Groups["p"+argument].Value,depth+1);
                // Captures are strings, so numeric format specifiers never round an already
                // rendered value again. The translated template may still reorder arguments.
                try{return string.Format(CultureInfo.InvariantCulture,template.translation,values);}
                catch(FormatException){return T(text);}
            }
            // Generic joins contain no Korean literal and have no table entry of their own.
            foreach(string separator in new[]{" · "," / "," → ",", ","\n"})
            {
                if(!text.Contains(separator))continue;
                string[] parts=text.Split(new[]{separator},StringSplitOptions.None);
                for(int i=0;i<parts.Length;i++)parts[i]=TranslateStored(parts[i],depth+1);
                return string.Join(separator,parts);
            }
            return T(text);
        }
        static void BuildStoredTemplates()
        {
            storedTemplates=new List<StoredTemplate>();
            foreach(var pair in table)
            {
                var holes=StoredHole.Matches(pair.Key);if(holes.Count==0)continue;
                var expression=new StringBuilder(@"\A");var arguments=new List<int>();int end=0,literals=0;bool valid=true;
                foreach(Match hole in holes)
                {
                    if(!int.TryParse(hole.Groups[1].Value,NumberStyles.None,CultureInfo.InvariantCulture,out int index)||index>31){valid=false;break;}
                    string literal=pair.Key.Substring(end,hole.Index-end).Replace("{{","{").Replace("}}","}");
                    expression.Append(Regex.Escape(literal));literals+=literal.Length;
                    if(arguments.Contains(index))expression.Append(@"\k<p"+index+">");
                    else{arguments.Add(index);expression.Append("(?<p"+index+">.*?)");}
                    end=hole.Index+hole.Length;
                }
                if(!valid)continue;
                string tail=pair.Key.Substring(end).Replace("{{","{").Replace("}}","}");
                expression.Append(Regex.Escape(tail)).Append(@"\z");literals+=tail.Length;
                if(literals==0)continue;
                storedTemplates.Add(new StoredTemplate{source=pair.Key,translation=pair.Value,arguments=arguments.ToArray(),literalLength=literals,
                    pattern=new Regex(expression.ToString(),RegexOptions.CultureInvariant|RegexOptions.Singleline,TimeSpan.FromMilliseconds(20))});
            }
            storedTemplates.Sort((a,b)=>{int specificity=b.literalLength.CompareTo(a.literalLength);return specificity!=0?specificity:StringComparer.Ordinal.Compare(a.source,b.source);});
        }
    }
}
