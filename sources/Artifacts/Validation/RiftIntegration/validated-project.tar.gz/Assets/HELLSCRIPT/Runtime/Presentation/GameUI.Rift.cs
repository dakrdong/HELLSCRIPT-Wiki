using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed partial class GameUI
    {
        RiftMinimap riftMinimap;
        Text chestCountText,fieldStatusText;
        bool riftMapWasPaused;
        void AddRiftMinimap(RunState run)
        {
            if(run.layout.legacy)return;
            var holder=Box("Rift minimap",root,new Color(.025f,.035f,.055f,.91f));
            holder.anchorMin=holder.anchorMax=new Vector2(1,1);holder.pivot=new Vector2(1,1);holder.anchoredPosition=new Vector2(-18,-275);holder.sizeDelta=new Vector2(212,281);
            var viewport=Box("Map viewport",holder,Color.clear);Place(viewport,8,8,196,196);viewport.gameObject.AddComponent<RectMask2D>();
            var graphic=new GameObject("Explored geometry",typeof(RectTransform),typeof(CanvasRenderer),typeof(RiftMinimap));graphic.transform.SetParent(viewport,false);Stretch((RectTransform)graphic.transform);
            riftMinimap=graphic.GetComponent<RiftMinimap>();riftMinimap.run=run;riftMinimap.raycastTarget=false;
            chestCountText=Label(holder,"",15,gold,TextAnchor.MiddleCenter);Place(chestCountText.rectTransform,4,205,204,28);
            fieldStatusText=Label(holder,"",15,pale,TextAnchor.MiddleCenter);Place(fieldStatusText.rectTransform,4,234,204,42);
            var button=holder.gameObject.AddComponent<Button>();button.targetGraphic=holder.GetComponent<Image>();button.onClick.AddListener(ShowRiftMap);
        }
        public void ShowRiftMap()
        {
            if(game.Combat==null)return;var run=game.Combat.State;if(Page!="rift-map")riftMapWasPaused=run.paused;run.paused=true;
            pageRepaint=()=>ShowRiftMap();Base("rift-map","균열 지도","발견한 지역 · 전투 일시정지");
            var panel=Row(content,630);panel.gameObject.AddComponent<RectMask2D>();
            var obj=new GameObject("Expanded rift map",typeof(RectTransform),typeof(CanvasRenderer),typeof(RiftMinimap));obj.transform.SetParent(panel,false);Stretch((RectTransform)obj.transform);
            var map=obj.GetComponent<RiftMinimap>();map.run=run;map.expanded=true;map.raycastTarget=false;
            Note(content,"▲ 영웅   × 보스   ◇ 정예   + 성소\n□ 상자 · 잠금 표시: 봉인 · 빨간 빗금: 저주\n체크 표시는 개봉 완료를 뜻합니다.",20,108,gold);
            if(run.layout.objective==RiftObjectiveKind.Seals)
                Note(content,"육각형은 발견한 봉인석입니다. 보라색은 경비 중, 금색은 파괴 가능, 초록색 체크는 파괴 완료를 뜻합니다.",20,80,gold);
            if(run.layout.objective==RiftObjectiveKind.EssenceCarriers)
                Note(content,"이중 마름모는 정수 운반자의 마지막 관측 위치입니다. 초록색은 처치 완료를 뜻합니다.",20,100,gold);
            if(run.layout.objective==RiftObjectiveKind.Offerings)
                Note(content,"삼각형은 제물, 받침대는 제단입니다. 경비를 처치한 뒤 제물을 회수하고 3개를 제단에 바칩니다.",20,110,gold);
            if(run.layout.objective!=RiftObjectiveKind.None)Note(content,ObjectiveProgress(run.layout),22,70,gold);
            if(run.layout.gates.Count>0)
            {
                Note(content,run.layout.gateOpen?"보스 관문 · 열림":"보스 관문 · 닫힘",22,60,gold);
                Note(content,"빗장은 발견한 관문입니다. 보라색은 닫힘, 초록색은 열림을 뜻합니다.",20,100,pale);
            }
            Note(content,Loc.F("발견한 방 {0} / {1}\n개봉한 상자 {2} / {3}", run.visited.Count, run.layout.rooms.Count, run.layout.chests.Count(c=>c.phase==ChestPhase.Opened), run.layout.chests.Count),22,88,pale);
            foreach(var shrine in run.layout.shrines.Where(s=>s.discovered))Note(content,Loc.F("{0}\n{1}", (shrine.definitionId=="SH01"?"길잡이의 성소 · 비전투 이동 +15%":"결의의 성소 · 피해 감소 +10%p"), (shrine.phase==ShrinePhase.Used?"사용 완료":shrine.phase==ShrinePhase.Exhausted?"사용 종료":"사용 시 20초 지속")),21,86,pale);
            foreach(var evt in run.layout.events.Where(e=>run.layout.chests.Any(c=>c.id==e.chestId&&c.discovered)))Note(content,Loc.F("저주 상자 · {0}", (evt.phase==RiftEventPhase.Active?Loc.F("잔향 진압 {0:0.0}초 남음", evt.remaining):evt.phase==RiftEventPhase.Succeeded?"진압 성공":evt.phase==RiftEventPhase.Failed?"진압 실패":evt.phase==RiftEventPhase.Cancelled?"이벤트 종료":"참여 설정과 남은 시간 조건에 따라 시작")),20,88,pale);
            if(!string.IsNullOrEmpty(run.navigationError))
            {Note(content,run.navigationError,21,112,gold);BigButton(content,"같은 균열의 상태 다시 확인",()=>{bool ok=game.Combat.RetryRiftFault();game.Save();ShowToast(ok?"저장된 상태에서 다시 진행할 수 있습니다.":run.navigationError);});}
            FooterButton(0,1,"균열로 돌아가기",()=>{run.paused=riftMapWasPaused;ShowBattle();});
        }
    }
}
