using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimePassiveSmoke : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Install()
        {
            if(!Environment.GetCommandLineArgs().Contains("-hellscriptPassiveSmoke"))return;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Passive smoke validation").AddComponent<RuntimePassiveSmoke>();
        }
        static void Require(bool pass,string reason){if(!pass)throw new InvalidOperationException(reason);}
        static IEnumerator Until(Func<bool> ready)
        {float end=Time.realtimeSinceStartup+12;while(!ready()&&Time.realtimeSinceStartup<end)yield return null;Require(ready(),"Passive runtime state was not reached.");}
        static IEnumerator Capture(GameController game,string directory,string name)
        {game.Combat.State.paused=true;game.UI.RefreshHud();yield return new WaitForSecondsRealtime(.3f);ScreenCapture.CaptureScreenshot(Path.Combine(directory,name));yield return new WaitForSecondsRealtime(.2f);}
        static RunState Arena(GameController game,int hero)
        {
            if(game.Running)game.ReturnTown();var account=game.Store.Data;account.selectedHero=hero;var h=account.Hero;h.level=30;h.inventory.Clear();uint rng=71823;
            for(int slot=0;slot<8;slot++){var item=ItemGenerator.Create(h.heroClass,slot,2,30,ref rng);h.inventory.Add(item);Require(Economy.Equip(h,item),"Passive fixture equipment was illegal.");}
            h.build=GameCatalog.Preset(h.heroClass,0);h.build.passives=hero==0?new[]{0,1,2}:hero==1?new[]{0,1,2}:new[]{0,3,5};h.build.rules.Clear();
            h.build.activeSkills=(hero==0?new[]{0,1,4,5}:hero==1?new[]{6,7,9,10}:new[]{12,15,16,17}).ToList();h.build.rules.Add(new Rule(hero==0?1:hero==1?9:17,ConditionKind.Always,0,hero==1));
            if(hero==2)h.build.rules.Add(new Rule(12));h.build.movement=MovementMode.Stand;h.build.autoRepeat=false;h.build.potionThreshold=0;
            Require(BehaviorRules.Validate(h.build,h.heroClass).Count==0,"Passive fixture build was invalid.");
            var fixture=new CombatSimulation(account,game.catalog,1,1,seed:76109);var run=fixture.State;run.training=-1;run.position=RiftMap.Rooms[0];run.enemies.Clear();
            run.enemies.Add(new EnemyState{id=900,position=run.position+Vector2.up*(hero==0?6:2),health=100000,maxHealth=100000,cooldown=1000,speed=0,attack=0});
            account.suspendedRun=run;game.Begin(resume:true);game.SetSpeed(1);game.Combat.State.paused=true;return game.Combat.State;
        }
        static IEnumerator Description(GameController game,string directory,string name)
        {
            game.UI.ShowBuild();yield return null;Canvas.ForceUpdateCanvases();var scroll=FindAnyObjectByType<ScrollRect>();
            var heading=scroll.content.GetComponentsInChildren<Text>().First(t=>t.text=="패시브 · 6개 중 3개");var row=heading.transform.parent as RectTransform;
            scroll.content.anchoredPosition=new Vector2(0,-row.anchoredPosition.y);
            Require(scroll.content.GetComponentsInChildren<Text>().Any(t=>t.text==GameCatalog.PassiveDescriptions[(int)game.Combat.Hero.heroClass*6]),"Passive description was missing from the editor.");
            yield return Capture(game,directory,name);game.UI.CancelBuild();
        }
        static void Save(GameController game,string directory,string name)
        {game.Save();Require(string.IsNullOrEmpty(game.Store.Error),"Passive checkpoint failed.");File.WriteAllText(Path.Combine(directory,name),JsonUtility.ToJson(game.Combat.State,true));}
        static RunState Resume(GameController game,string directory,string name)
        {
            var saved=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(directory,name)));GameStore.NormalizeRun(saved);game.Begin(resume:true);var run=game.Combat.State;run.paused=true;
            Require(run.id==saved.id&&run.time==saved.time&&run.rng==saved.rng&&run.health==saved.health&&run.resource==saved.resource
                &&JsonUtility.ToJson(run.itemEffects)==JsonUtility.ToJson(saved.itemEffects)&&JsonUtility.ToJson(run.heroAction)==JsonUtility.ToJson(saved.heroAction)
                &&run.damageEvents.Count==saved.damageEvents.Count,"Passive state changed across process restart.");return run;
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();string directory="";int stage=0;
            for(int n=0;n<args.Length-1;n++){if(args[n]=="-hellscriptScreenshots")directory=args[n+1];if(args[n]=="-hellscriptPassiveResume")stage=int.Parse(args[n+1]);}
            Require(args.Contains("-hellscriptSavePath")&&!string.IsNullOrEmpty(directory),"Passive smoke requires isolated save and screenshot directories.");Directory.CreateDirectory(directory);Screen.SetResolution(540,960,FullScreenMode.Windowed);
            yield return new WaitForSecondsRealtime(1);var game=FindAnyObjectByType<GameController>();RunState run;
            string[] ids={"WP03","AP02","MP06"};string[] names={"warrior","ranger","mage"};
            if(stage>0)
            {
                int previous=stage-1;run=Resume(game,directory,names[previous]+"-checkpoint.json");game.UI.ShowCombatEffects();yield return Capture(game,directory,$"{stage*3:00}-restored-{names[previous]}.png");
                game.UI.ShowBattle();game.SetSpeed(1);run.paused=false;
                yield return Until(()=>run.effectEvents.Any(e=>e.definitionId==ids[previous]&&e.kind=="EXPIRED"));run.paused=true;
                Require((previous==0?run.itemEffects.leapDefense:previous==1?run.itemEffects.moveBuff:run.itemEffects.elementBuff)==0,"Passive remained active after expiry.");
                Require(run.effectEvents.Count(e=>e.definitionId==ids[previous]&&e.kind=="BUFF")==1,"A saved passive was generated twice.");Save(game,directory,names[previous]+"-completed.json");
                if(stage==3)
                {
                    game.UI.ShowCombatEffects();yield return Capture(game,directory,"10-mage-expired.png");
                    File.WriteAllText(Path.Combine(directory,"runtime-passives-smoke.txt"),"PASS: actual automatic W02/A04/M06/M01 actions grant WP03/AP02/MP06; real process restart for each pending buff; saved state equality; 1.5x/2x/1x expiry with no repeated activation; three class passive descriptions and active buff UI.\nFixture: isolated level 30 heroes, eight legally equipped rare pieces each, stationary harmless high-HP targets, frozen rule selection after activation; UI calls, not physical input. Not six-build balance or Android proof.\nRenderer="+SystemInfo.graphicsDeviceType+"\nScreen="+Screen.width+"x"+Screen.height+"\n");
                    Debug.Log("HELLSCRIPT_PASSIVE_RUNTIME_SMOKE_OK");Application.Quit();yield break;
                }
            }
            run=Arena(game,stage);yield return new WaitForSecondsRealtime(.5f);yield return Description(game,directory,$"{stage*3+1:00}-{names[stage]}-descriptions.png");
            run.paused=false;yield return Until(()=>run.effectEvents.Any(e=>e.definitionId==ids[stage]&&e.kind=="BUFF"));run.paused=true;
            // Stop new decisions while keeping the real action, costs, projectiles and buff untouched.
            run.build.rules.Clear();run.decisionTime=1000;game.UI.ShowCombatEffects();yield return Capture(game,directory,$"{stage*3+2:00}-{names[stage]}-checkpoint.png");
            if(stage==2)Require(run.itemEffects.elementHitTicks.Count(t=>t>=0)>=2&&run.damageEvents.Any(d=>d.definitionId=="M01")&&run.damageEvents.Any(d=>d.definitionId=="M06"),"Mage did not earn two real elemental hits.");
            Save(game,directory,names[stage]+"-checkpoint.json");Debug.Log("PASSIVE_"+names[stage].ToUpperInvariant()+"_CHECKPOINT_READY");Application.Quit();
        }
    }
}
