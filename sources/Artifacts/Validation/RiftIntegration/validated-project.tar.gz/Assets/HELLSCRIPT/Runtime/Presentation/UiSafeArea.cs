using UnityEngine;

namespace Hellscript
{
    // One source for the usable display area so screens, modals and checks agree on it.
    // A development build can stand in for a notch and a home bar, which is the only way
    // to exercise the inset paths without a physical device.
    public static class UiSafeArea
    {
        static bool simulating;
        static Vector4 insets;
        public static bool Simulating => simulating;
        // left, bottom, right and top insets in pixels; a request larger than the display is trimmed.
        public static Rect Inset(float width, float height, Vector4 requested)
        {
            float limitX = Mathf.Max(0, width) * .4f, limitY = Mathf.Max(0, height) * .4f;
            float left = Mathf.Clamp(requested.x, 0, limitX), bottom = Mathf.Clamp(requested.y, 0, limitY);
            float right = Mathf.Clamp(requested.z, 0, limitX), top = Mathf.Clamp(requested.w, 0, limitY);
            return new Rect(left, bottom, Mathf.Max(1, width - left - right), Mathf.Max(1, height - bottom - top));
        }
        public static Rect Current => simulating ? Inset(Screen.width, Screen.height, insets) : Screen.safeArea;
        public static void Simulate(float left, float bottom, float right, float top)
        {
            if (!Debug.isDebugBuild) return;
            insets = new Vector4(Mathf.Max(0, left), Mathf.Max(0, bottom), Mathf.Max(0, right), Mathf.Max(0, top));
            simulating = true;
        }
        public static void StopSimulating() { simulating = false; }
    }
}
