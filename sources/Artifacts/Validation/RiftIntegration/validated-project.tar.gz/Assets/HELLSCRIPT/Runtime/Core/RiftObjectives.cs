using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    [Serializable] public sealed class RiftEssenceCarrier
    {
        public string id;
        public int spawn,room,enemyId=-1;
        public Vector2 position;
        public bool discovered,completed;
    }
    [Serializable] public sealed class RiftOffering
    {
        public string id;
        public int room,guardGroup;
        public Vector2 position;
        public bool discovered,available,collected;
    }
    public enum OfferingAltarPhase { Available, Approaching, Offering, Offered }
    [Serializable] public sealed class RiftOfferingAltar
    {
        public const float Duration=1;
        public string id;
        public int room;
        public Vector2 position,access;
        public List<Vector2> accessPoints=new List<Vector2>();
        public bool discovered;
        public OfferingAltarPhase phase;
        public float progress,retryAfter;
    }
    [Serializable] public sealed class RiftObjectiveRecord
    {
        // Zero means absent in an older save, including Unity's default restored nested object.
        public int version;
        public RiftObjectiveKind kind;
        public int completed,total;
        public bool gateOpen,byMeter,delivered,timeKnown;
        public float seconds;
        public RiftObjectiveRecord Copy()=>(RiftObjectiveRecord)MemberwiseClone();
    }
    public static class RiftObjectives
    {
        public const int ChainPoints=3,ChainPathMeter=100;
        public static RiftObjectiveKind Select(uint seed,int stage)
        {
            if(stage<RiftGenerator.ObjectiveFirstStage)return RiftObjectiveKind.None;
            // Chosen once from the run seed: retrying a layout cannot reroll its objective kind.
            uint value=RiftGenerator.Derive(seed,"objectives-v4");value^=value>>16;value*=0x7feb352du;value^=value>>15;value*=0x846ca68bu;value^=value>>16;
            return (RiftObjectiveKind)(1+value%3);
        }
        public static bool PointRoom(RiftRoom room)=>room.role==RiftRoomRole.Passage||room.role==RiftRoomRole.Crossroad;
        public static int Meter(RiftLayout map,int room)=>map.spawns.Where(s=>s.room==room).Sum(s=>s.elite<0?1:5);
        public static int Completed(RiftLayout map)=>map.objective==RiftObjectiveKind.Seals?map.seals.Count(s=>s.phase==SealPhase.Broken):map.objective==RiftObjectiveKind.EssenceCarriers?map.carriers.Count(c=>c.completed):map.offerings.Count(o=>o.collected);
        public static int Total(RiftLayout map)=>map.objective==RiftObjectiveKind.Seals?map.seals.Count:map.objective==RiftObjectiveKind.EssenceCarriers?map.carriers.Count:map.offerings.Count;
        public static RiftObjectiveRecord Capture(RunState run)
        {
            var map=run.layout;if(map.objectiveRecord?.version==1)return map.objectiveRecord.Copy();
            return new RiftObjectiveRecord{version=1,kind=map.objective,completed=Completed(map),total=Total(map),
                gateOpen=map.gateOpen,byMeter=map.gateOpenedByMeter,delivered=map.altar?.phase==OfferingAltarPhase.Offered,
                timeKnown=map.version>=4,seconds=run.time};
        }
        public static void Open(RunState run,bool byMeter)
        {
            if(run.layout.gateOpen)return;
            run.layout.gateOpen=true;run.layout.gateOpenedByMeter=byMeter;
            run.layout.objectiveRecord=Capture(run);
        }
        static List<RiftRoom> Rooms(RiftLayout map,bool elite)
        {
            var rooms=map.rooms.Where(PointRoom).Where(r=>!elite||map.spawns.Any(s=>s.room==r.index&&s.elite>=0)).ToArray();
            var distances=RiftGenerator.GraphDistances(map,0);int ante=map.rooms.Single(r=>r.role==RiftRoomRole.Antechamber).index;
            List<RiftRoom> best=null;int score=int.MaxValue;
            for(int i=0;i<rooms.Length;i++)for(int j=i+1;j<rooms.Length;j++)for(int k=j+1;k<rooms.Length;k++)
            {
                var set=new List<RiftRoom>{rooms[i],rooms[j],rooms[k]};
                if(set.Sum(r=>Meter(map,r.index))+Meter(map,ante)<ChainPathMeter)continue;
                int candidate=set.Sum(r=>distances[r.index])*100+set.Sum(r=>r.index);
                if(candidate<score){score=candidate;best=set;}
            }
            if(best==null)throw new InvalidOperationException("Three accessible fighting rooms are required for this objective.");
            return best;
        }
        static IEnumerable<Vector2> GridSpots(RiftRoom room)
        {
            var bounds=room.Bounds;
            for(float y=bounds.yMin+2.5f;y<=bounds.yMax-2.5f;y+=1.5f)
                for(float x=bounds.xMin+2.5f;x<=bounds.xMax-2.5f;x+=1.5f)yield return new Vector2(x,y);
        }
        static IEnumerable<Vector2> Spots(RiftLayout map,RiftRoom room,RiftNavigation nav)
            =>room.chestAnchors.Concat(room.groupAnchors).Concat(GridSpots(room)).Where(p=>nav.Reachable(p)&&
                !room.doors.Any(d=>Vector2.Distance(d.position,p)<3)&&
                !map.chests.Any(c=>Vector2.Distance(c.position,p)<3)&&!map.shrines.Any(s=>Vector2.Distance(s.position,p)<3));
        public static void Place(RiftLayout map,RiftNavigation nav)
        {
            if(map.objective==RiftObjectiveKind.EssenceCarriers)
            {
                foreach(var room in Rooms(map,true))
                {
                    var spawn=map.spawns.First(s=>s.room==room.index&&s.elite>=0);
                    map.carriers.Add(new RiftEssenceCarrier{id="carrier:"+map.carriers.Count,room=room.index,spawn=spawn.index,position=spawn.position});
                }
            }
            if(map.objective!=RiftObjectiveKind.Offerings)return;
            foreach(var room in Rooms(map,false))
            {
                var spots=Spots(map,room,nav).ToArray();if(spots.Length==0)throw new InvalidOperationException("No accessible offering point.");
                Vector2 point=spots[0];var guard=map.groups.Where(g=>g.room==room.index).OrderBy(g=>(g.position-point).sqrMagnitude).First();
                map.offerings.Add(new RiftOffering{id="offering:"+map.offerings.Count,room=room.index,guardGroup=guard.index,position=point});
            }
            var ante=map.rooms.Single(r=>r.role==RiftRoomRole.Antechamber);
            foreach(var point in Spots(map,ante,nav))
            {
                var body=new RiftObstacle{id="body:offering-altar",kind="OfferingAltar",position=point,halfSize=Vector2.one*.6f,height=1.2f,blocksSight=false,blocksProjectile=false};
                if(map.spawns.Any(s=>body.Contains(s.position,.4f))||map.obstacles.Any(o=>o.Contains(point,.9f))||
                    map.events.Any(e=>e.spawnCandidates.Any(p=>body.Contains(p,.4f))))continue;
                map.obstacles.Add(body);var after=new RiftNavigation(map);
                var access=new[]{Vector2.up,Vector2.down,Vector2.left,Vector2.right}.Select(d=>point+d*1.35f).Where(after.Reachable).ToList();
                if(access.Count<2||map.spawns.Any(s=>!after.Reachable(s.position))||map.chests.Any(c=>c.accessPoints.Any(p=>!after.Reachable(p)))||map.shrines.Any(s=>s.accessPoints.Any(p=>!after.Reachable(p)))||
                    map.events.Any(e=>e.spawnCandidates.Any(p=>!after.Reachable(p))))
                {map.obstacles.Remove(body);continue;}
                map.altar=new RiftOfferingAltar{id="offering-altar",room=ante.index,position=point,access=access[0],accessPoints=access};return;
            }
            throw new InvalidOperationException("No safe offering altar in the antechamber.");
        }
        public static void Validate(RiftLayout map)
        {
            if(map.version<4)return;
            if(map.objective==RiftObjectiveKind.EssenceCarriers)
            {
                if(map.carriers.Count!=ChainPoints||map.carriers.Select(c=>c.room).Distinct().Count()!=ChainPoints||map.carriers.Any(c=>!PointRoom(map.rooms[c.room])||map.spawns[c.spawn].elite<0||map.spawns[c.spawn].room!=c.room))
                    throw new InvalidOperationException("Invalid essence carrier assignment.");
            }
            else if(map.carriers.Count>0)throw new InvalidOperationException("Carriers belong only to the carrier objective.");
            if(map.objective==RiftObjectiveKind.Offerings)
            {
                if(map.offerings.Count!=ChainPoints||map.offerings.Select(o=>o.room).Distinct().Count()!=ChainPoints||map.offerings.Any(o=>!PointRoom(map.rooms[o.room])||map.groups[o.guardGroup].room!=o.room)||
                    map.altar==null||map.rooms[map.altar.room].role!=RiftRoomRole.Antechamber||map.altar.accessPoints.Count<2)
                    throw new InvalidOperationException("Invalid offering assignment.");
            }
            else if(map.offerings.Count>0)throw new InvalidOperationException("Offerings belong only to the offering objective.");
            if(map.objective==RiftObjectiveKind.EssenceCarriers||map.objective==RiftObjectiveKind.Offerings)
            {
                var rooms=map.objective==RiftObjectiveKind.EssenceCarriers?map.carriers.Select(c=>c.room):map.offerings.Select(o=>o.room);
                int ante=map.rooms.Single(r=>r.role==RiftRoomRole.Antechamber).index;
                if(rooms.Concat(new[]{ante}).Distinct().Sum(r=>Meter(map,r))<ChainPathMeter)throw new InvalidOperationException("Insufficient objective-path encounters.");
            }
        }
    }
}
