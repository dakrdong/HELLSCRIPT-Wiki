using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    // Isolated development fixture, enabled only through an explicit command-line flag.
    public sealed class RuntimeRiftSmoke : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Install()
        {if(Environment.GetCommandLineArgs().Contains("-hellscriptRiftSmoke"))new GameObject("Rift smoke validation").AddComponent<RuntimeRiftSmoke>();}
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();string dir="";int profile=-1;float speed=1;
            for(int n=0;n<args.Length-1;n++)
            {
                if(args[n]=="-hellscriptScreenshots")dir=args[n+1];
                if(args[n]=="-hellscriptRiftProfile")profile=int.Parse(args[n+1]);
                if(args[n]=="-hellscriptRiftSpeed")speed=float.Parse(args[n+1],System.Globalization.CultureInfo.InvariantCulture);
            }
            if(profile< -1||profile>5||speed!=1&&speed!=1.5f&&speed!=2)throw new InvalidOperationException("Invalid rift smoke profile or speed.");
            if(string.IsNullOrEmpty(dir)||!args.Contains("-hellscriptSavePath"))throw new InvalidOperationException("Rift smoke requires isolated save and output directories.");
            Directory.CreateDirectory(dir);yield return new WaitForSecondsRealtime(1);
            var game=FindAnyObjectByType<GameController>();bool resume=args.Contains("-hellscriptRiftResume");
            if(!resume)
            {
                var account=game.Store.Data;if(profile>=0)account.selectedHero=profile/2;var hero=account.Hero;
                hero.level=30;hero.capacity=100;hero.build=GameCatalog.Preset(hero.heroClass,profile>=0?profile%2:0);
                uint rng=profile>=0?(uint)(41073+profile/2):300122;
                if(profile<0){hero.build.chestsAfterBoss=true;hero.build.chestDetour=30;foreach(var old in hero.inventory)old.equipped=false;}
                else hero.inventory.Clear();
                for(int slot=0;slot<8;slot++)
                {
                    var item=ItemGenerator.Create(hero.heroClass,slot,2,30,ref rng);hero.inventory.Add(item);
                    if(!Economy.Equip(hero,item))throw new InvalidOperationException("Rift smoke could not equip its legal fixture.");
                }
                game.Save();game.Begin(seed:91367);game.SetSpeed(speed);yield return new WaitForSecondsRealtime(5);
                game.Combat.State.paused=true;game.Save();ScreenCapture.CaptureScreenshot(Path.Combine(dir,"01-generated-rift.png"));
                File.WriteAllText(Path.Combine(dir,"checkpoint.json"),JsonUtility.ToJson(game.Combat.State,true));
                yield return new WaitForSecondsRealtime(.3f);Debug.Log("RIFT_SMOKE_CHECKPOINT_READY");Application.Quit();yield break;
            }
            var checkpoint=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(dir,"checkpoint.json")));
            game.Begin(resume:true);var run=game.Combat.State;
            if(run.id!=checkpoint.id||run.layout.fingerprint!=checkpoint.layout.fingerprint||run.health!=checkpoint.health||run.time!=checkpoint.time||run.rng!=checkpoint.rng)throw new InvalidOperationException("Runtime checkpoint changed on reload.");
            run.paused=true;game.UI.ShowRiftMap();yield return new WaitForSecondsRealtime(.3f);ScreenCapture.CaptureScreenshot(Path.Combine(dir,"02-restored-map.png"));
            yield return new WaitForSecondsRealtime(.2f);game.UI.ShowBattle();run.paused=false;
            float deadline=Time.realtimeSinceStartup+300/game.Store.Data.speed+30,nextLog=0;bool opening=false,opened=false;
            while(game.Active&&Time.realtimeSinceStartup<deadline)
            {
                if(!string.IsNullOrEmpty(run.navigationError))throw new InvalidOperationException(run.navigationError);
                if(Time.realtimeSinceStartup>=nextLog){nextLog=Time.realtimeSinceStartup+10;Debug.Log($"RIFT_SMOKE_PROGRESS t={run.time:F1} kills={run.kills} rooms={run.visited.Count} chest={run.layout.chests.Count(c=>c.phase==ChestPhase.Opened)}");}
                if(!opening&&run.layout.chests.Any(c=>c.phase==ChestPhase.Opening)){opening=true;ScreenCapture.CaptureScreenshot(Path.Combine(dir,"03-chest-opening.png"));}
                if(!opened&&run.layout.chests.Any(c=>c.phase==ChestPhase.Opened)){opened=true;ScreenCapture.CaptureScreenshot(Path.Combine(dir,"04-chest-opened.png"));}
                yield return new WaitForSecondsRealtime(.1f);
            }
            if(run.phase!=RunPhase.Cleared)throw new InvalidOperationException("Rift smoke fixture did not clear: "+run.phase+" "+run.action);
            if(!opened)throw new InvalidOperationException("Rift smoke did not open a discovered chest.");
            yield return new WaitForSecondsRealtime(.5f);ScreenCapture.CaptureScreenshot(Path.Combine(dir,"05-rift-result.png"));
            File.WriteAllText(Path.Combine(dir,"final-run.json"),JsonUtility.ToJson(run,true));
            File.WriteAllText(Path.Combine(dir,"runtime-rift-smoke.txt"),$"PASS: generated rift, actual process restart, manifest/HP/time/RNG restoration, automatic exploration/combat, chest opening, boss clear, result.\nFixture: level 30 {game.Store.Data.Hero.heroClass}, 8 rare item-level 30 pieces, stage 1, seed 91367. {(profile>=0?"Unmodified recommended build and comparison gear seed.":"Chest range 30 m and post-boss chest policy enabled.")} This is a flow test, not a balance claim.\nbuild={run.build.name}\nrunId={run.id}\nmap={run.layout.fingerprint}\nspeed={game.Store.Data.speed}\ncombatSeconds={run.time:F2}\nchestsOpened={run.layout.chests.Count(c=>c.phase==ChestPhase.Opened)}\nScreen={Screen.width}x{Screen.height}\n");
            game.Save();yield return new WaitForSecondsRealtime(.3f);Debug.Log("HELLSCRIPT_RIFT_RUNTIME_SMOKE_OK");Application.Quit();
        }
    }
}
