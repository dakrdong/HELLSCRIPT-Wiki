using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        void ResolveCombatDeaths()
        {
            // Damage still resolves against the current living targets. Rewards and terminal transitions wait for the whole tick.
            var deaths=State.enemies.Where(e=>e.dead&&e.pendingDeath).OrderBy(e=>e.id).ToArray();
            foreach(var enemy in deaths)
            {
                enemy.pendingDeath=false;RegisterEnemyDeath(enemy);
                ClearSetPoison(enemy,"REMOVED");ClearFrostMark(enemy,"REMOVED");enemy.exposure=enemy.frostCooldown=0;
                EffectEvent(enemy.boss?"BOSS":"ENEMY","DEATH",target:enemy.id);
                Log("ENEMY_DEATH",Loc.F("{0} #{1} 사망", (enemy.boss?"보스":"적"), enemy.id));
                RewardEnemyDeath(enemy);
            }
            // A kill in the same tick cannot revive a hero already killed by a projectile or ground effect.
            ApplyKillHealing(deaths.Length);
            if(State.health<=0&&!State.heroDeathRecorded)
            {State.heroDeathRecorded=true;EffectEvent("HERO","DEATH");Log("HERO_DEATH","영웅 사망");}
            ResolveCarriers();
        }
        bool SettleCombatOutcome()
        {
            if(!string.IsNullOrEmpty(State.navigationError))return true;
            RefreshEnemyAuras();
            // The boss wins ties against hero death and the rift timer, after every due damage subsystem has run.
            if(State.training<0&&State.enemies.Any(e=>e.boss&&e.dead))
            {BossClear();CommitExperience();return true;}
            CommitExperience();
            if(State.health<=0){Finish(false,"영웅 사망",CombatFinish.HeroDeath);return true;}
            if(OwnedTraining&&Mathf.RoundToInt(State.time/Step)>=1200){Finish(true,"60초 훈련 완료",CombatFinish.Duration);return true;}
            if(State.time>=300){Finish(false,"제한시간 초과");return true;}
            if((ObjectiveActive?State.layout.gateOpen:State.meter>=100)&&State.phase==RunPhase.Exploring&&State.training<0)
            {State.phase=RunPhase.Boss;TrySpawnBoss(0);}
            return !string.IsNullOrEmpty(State.navigationError);
        }
    }
}
