using System;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        // The v0.2 document only drives combat when the hero opts in. Existing saves and the legacy
        // rule editor keep their behaviour untouched until someone turns this on.
        HuntEdictV2Document edictSource;
        BuildConfig edictPolicy;
        EdictLootPolicy edictLoot;
        string edictInactiveReason="",edictBlockLogged="";

        // What the simulation reads for its global policies. With the edict off this is the live
        // BuildConfig itself, so every existing read keeps its exact behaviour.
        public BuildConfig Policy=>edictPolicy??State.build;
        // Navigation failures switch repeat off; the overlay must agree or the controller would restart anyway.
        void DisableAutoRepeat(){State.build.autoRepeat=false;if(edictPolicy!=null)edictPolicy.autoRepeat=false;}

        public bool EdictActive=>edictSource!=null;
        // The editor calls this after saving so an in-progress run reads the new document instead of
        // the copy it prepared at start.
        public void RefreshEdict()=>PrepareEdict();
        public string EdictInactiveReason=>edictInactiveReason;
        public EdictResponsePlan LastEdictPlan {get;private set;}
        public EdictAimPlan LastEdictAim {get;private set;}
        public int EdictAimedCasts {get;private set;}
        // W03 분쇄 일격, A01 관통 사격, A02 다중 사격, M03 연쇄 번개: the skills whose aiming stage exists.
        static readonly int[] AimSkills={2,6,7,14};

        // Called once at construction and again whenever the live build changes, because the document
        // is only allowed to act while its slots match the loadout actually fighting.
        void PrepareEdict()
        {
            edictSource=null;edictPolicy=null;edictLoot=null;edictTarget=null;LastEdictPlan=null;edictBlockLogged="";
            if(Hero?.edict==null||HuntEdictV2Storage.IsAbsent(Hero.edict)){edictInactiveReason="이 캐릭터에 저장된 사냥 칙령 원본이 없습니다.";return;}
            if(!Hero.useEdict){edictInactiveReason="사냥 칙령 v0.2 자동 판단이 꺼져 있습니다.";return;}
            try
            {
                var document=HuntEdictV2.Canonical(Hero.edict);
                HuntEdictV2.ValidateReceiver(document,Hero,catalog);
                edictSource=document;edictPolicy=EdictPolicyBridge.Apply(State.build,document,Hero.heroClass);edictLoot=new EdictLootPolicy(document);edictTarget=EdictTargetPolicy.Compile(document);edictInactiveReason="";
            }
            catch(ArgumentException e){edictInactiveReason=Loc.F("사냥 칙령 원본을 사용할 수 없습니다: {0}", e.Message);}
        }

        // Returns true when the edict took the main action this decision cycle, so the ordinary rule
        // pass is skipped and does not immediately override the survival response it just started.
        // Applies the document's aiming stage to a ready skill candidate. "Not available" means the
        // skill's chosen purpose is not met right now, so the candidate is passed over and reads EDICT_AIM.
        bool EdictAimGate(RuleCandidate c)
        {
            if(edictSource==null||c.rule.action!=RuleAction.Skill||Array.IndexOf(AimSkills,c.rule.skill)<0)return true;
            EdictAimPlan plan;
            try{plan=PlanEdictAim(edictSource,CombatTelemetry.SkillId(c.rule.skill),c.target);}
            catch(Exception e)
            {
                edictSource=null;edictPolicy=null;edictLoot=null;edictTarget=null;edictInactiveReason=Loc.F("사냥 칙령 조준 판단을 중단했습니다: {0}", e.Message);
                Log("EDICT_STOPPED",edictInactiveReason);return true;
            }
            LastEdictAim=plan;
            if(!plan.supported)return true;
            if(!plan.available){c.ready=false;c.code="EDICT_AIM";c.detail=plan.reason;return false;}
            var target=State.enemies.Find(e=>e.id==plan.targetId&&!e.dead);
            if(target!=null)c.target=target;
            if(plan.forecast!=null)c.aim=plan.forecast.aim;
            EdictAimedCasts++;
            return true;
        }

        bool TickEdictSurvival()
        {
            if(edictSource==null)return false;
            EdictResponseExecution execution;
            try{execution=ExecuteEdictSurvival(edictSource);}
            catch(Exception e)
            {
                // A bad document must never end a run. Stand down for the rest of it and say why.
                edictSource=null;edictPolicy=null;edictLoot=null;edictTarget=null;edictInactiveReason=Loc.F("사냥 칙령 판단을 중단했습니다: {0}", e.Message);
                Log("EDICT_STOPPED",edictInactiveReason);
                return false;
            }
            LastEdictPlan=execution.plan;
            if(execution.plan.assessment.emergency&&execution.plan.ControlsMainAction&&State.edictTarget!=null)
            {State.edictTarget.enemyId=-1;State.edictTarget.searching=false;State.edictTarget.pursuitSeconds=0;}
            string blocked=execution.plan.blockedReason;
            if(blocked!=edictBlockLogged)
            {
                // Logged only on change; the decision cycle runs five times a second.
                if(blocked!="")Log("EDICT_BLOCKED",blocked);
                else if(edictBlockLogged!="")Log("EDICT_RESUMED","사냥 칙령 판단을 다시 사용합니다.");
                edictBlockLogged=blocked;
            }
            return blocked==""&&execution.plan.ControlsMainAction;
        }
    }
}
