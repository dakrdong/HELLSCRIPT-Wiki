using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        EnemyState NextChainTarget(Vector2 previous,int previousId,IDictionary<int,int> visits,IEnumerable<EnemyState> observed)
            =>observed.Where(e=>e!=null&&!e.dead&&e.id!=previousId&&(!visits.TryGetValue(e.id,out int count)||Stats.specials.Contains("LM04")&&count<2)&&
                Vector2.Distance(previous,e.position)<=4&&Map.LineClear(previous,e.position))
                .OrderBy(e=>visits.ContainsKey(e.id)?1:0).ThenBy(e=>(e.position-previous).sqrMagnitude).ThenBy(e=>e.id).FirstOrDefault();

        static Vector2 RotateShot(Vector2 direction,float degrees)
        {float a=degrees*Mathf.Deg2Rad;return new Vector2(direction.x*Mathf.Cos(a)-direction.y*Mathf.Sin(a),direction.x*Mathf.Sin(a)+direction.y*Mathf.Cos(a));}
        static float MultiShotHalfAngle(bool focused)=>focused?10:30;
        static bool Finite(Vector2 p)=>!float.IsNaN(p.x)&&!float.IsNaN(p.y)&&!float.IsInfinity(p.x)&&!float.IsInfinity(p.y);
        EnemyState[] ForecastSeen(IEnumerable<EnemyState> subset=null)
        {
            // IDs supplied by a caller cannot grant perception or inject detached/future positions.
            HashSet<int> ids=subset==null?null:new HashSet<int>(subset.Where(e=>e!=null).Select(e=>e.id));
            return State.enemies.Where(e=>Perceived(e)&&(ids==null||ids.Contains(e.id))).OrderBy(e=>e.id).ToArray();
        }
        IEnumerable<(EnemyState enemy,float entry)> ForecastLine(Vector2 origin,Vector2 end,float radius,EnemyState[] seen)
            =>seen.Select(e=>(enemy:e,entry:Entry(origin,end,e.position,radius+(e.boss?1.2f:.4f))))
                .Where(h=>!float.IsInfinity(h.entry)).OrderBy(h=>h.entry).ThenBy(h=>h.enemy.id);

        public AttackForecast ForecastAttack(Rule rule,EnemyState target,Vector2? aim=null,Vector2? origin=null,EnemyState[] observed=null)
        {
            if(rule==null)throw new ArgumentException("예측할 공격이 없습니다.");
            Vector2 start=origin??State.position;if(!Finite(start)||aim.HasValue&&!Finite(aim.Value))throw new ArgumentException("예측 위치가 유효하지 않습니다.");
            var seen=ForecastSeen(observed);target=target==null?null:seen.FirstOrDefault(e=>e.id==target.id);
            int index=rule.action==RuleAction.Basic?-1:rule.skill;
            bool skill=rule.action==RuleAction.Skill&&index>=0&&index<catalog.skills.Count;
            Vector2 point=aim??(skill&&GroundSkill(index)?GroundAim(rule,target,seen,start):target?.position??start);
            AttackForecast Result(Vector2 impact,IEnumerable<int> hits)=>new AttackForecast(start,point,impact,hits);
            AttackForecast Empty()=>Result(point,Array.Empty<int>());
            if(!skill&&rule.action!=RuleAction.Basic||target==null&&!(skill&&GroundSkill(index)&&rule.areaAim==AreaAim.Self))return Empty();
            Vector2 direction=(point-start).normalized;
            if(rule.action==RuleAction.Basic)
            {
                if(Hero.heroClass==HeroClass.Warrior)
                    return Result(target.position,Vector2.Distance(start,target.position)<=2&&Map.LineClear(start,target.position)?new[]{target.id}:Array.Empty<int>());
                Vector2 end=ClipProjectile(start,start+direction*10,.2f,out _);var first=ForecastLine(start,end,.2f,seen).FirstOrDefault();
                return Result(first.enemy==null?end:Vector2.Lerp(start,end,first.entry),first.enemy==null?Array.Empty<int>():new[]{first.enemy.id});
            }
            var definition=catalog.skills[index];
            if(definition.kind==SkillKind.Pierce)
            {
                Vector2 end=ClipProjectile(start,start+direction*10,.3f,out _);
                return Result(end,ForecastLine(start,end,.3f,seen).Take(Stats.passives[2]?7:5).Select(h=>h.enemy.id));
            }
            if(definition.kind==SkillKind.Multi)
            {
                var hits=new List<int>();bool focused=Stats.specials.Contains("LA02");float angle=MultiShotHalfAngle(focused);
                foreach(float degrees in new[]{-angle,0,angle})
                {
                    Vector2 end=ClipProjectile(start,start+RotateShot(direction,degrees)*8,.2f,out _);var first=ForecastLine(start,end,.2f,seen).FirstOrDefault();
                    // The arrow is consumed by the first collision even if this cast already hit
                    // that victim. It does not pass through to the next enemy after reaching the cap.
                    if(first.enemy!=null&&(focused||!hits.Contains(first.enemy.id)))hits.Add(first.enemy.id);
                }
                return Result(point,hits);
            }
            if(definition.kind==SkillKind.Chain)
            {
                // Keep shape prediction separate from first-cast range. Legacy SC06 uses
                // this result before its RANGE/approach decision; v2 filters first targets.
                if(!Map.LineClear(start,target.position))return Empty();
                int limit=(Stats.passives[2]?5:4)+(ItemEffects.chainCharge>0&&ItemEffects.chainCharges>0&&Stats.SetPieces("SMB")>=4?2:0);
                var visits=new Dictionary<int,int>();var hits=new List<int>();var current=target;
                for(int i=0;i<limit&&current!=null;i++)
                {
                    hits.Add(current.id);visits[current.id]=visits.TryGetValue(current.id,out int count)?count+1:1;
                    current=NextChainTarget(current.position,current.id,visits,seen);
                }
                return Result(point,hits);
            }
            if(definition.kind==SkillKind.Shield||definition.kind==SkillKind.Shout||definition.kind==SkillKind.Shadow||definition.kind==SkillKind.Teleport||definition.kind==SkillKind.Retreat)return Empty();
            if(definition.kind==SkillKind.Mark)return Result(point,new[]{target.id});
            Vector2 center=definition.kind==SkillKind.Whirlwind||definition.kind==SkillKind.Crush||definition.kind==SkillKind.Slam||definition.kind==SkillKind.Nova?start:point;
            if(definition.kind==SkillKind.Leap)center=aim??MovementDestination(rule,definition,target,start,seen);
            if(definition.kind==SkillKind.Fireball)
            {
                // The live fireball ends at its chosen aim distance, including a nearby wall.
                Vector2 end=ClipProjectile(start,Vector2.MoveTowards(start,point,10),.25f,out _);
                var first=ForecastLine(start,end,.25f,seen).FirstOrDefault();center=first.enemy==null?end:Vector2.Lerp(start,end,first.entry);
            }
            float radius=definition.kind==SkillKind.Whirlwind||definition.kind==SkillKind.Leap||definition.kind==SkillKind.Fireball?2.5f:GroundSkill(index)?GroundRadius(index):definition.radius;
            return Result(center,seen.Where(e=>Vector2.Distance(center,e.position)<=radius&&Map.LineClear(center,e.position)&&
                (definition.kind!=SkillKind.Crush||Vector2.Angle(direction,e.position-start)<=50)).Select(e=>e.id));
        }

        // Only observed motion is used. The fixed intercept includes wind-up and flight, never
        // enemy intent/navigation targets; terrain clips the predicted movement of the target.
        public Vector2 ObservedProjectileAim(int skill,EnemyState target)
        {
            var enemy=target==null?null:ForecastSeen().FirstOrDefault(e=>e.id==target.id);
            if(enemy==null)throw new ArgumentException("현재 감지한 대상이 없습니다.");
            if(skill!=12&&!(skill==-1&&Hero.heroClass==HeroClass.Mage))throw new ArgumentException("관측 이동 조준을 지원하지 않는 공격입니다.");
            var observation=State.exploration.enemies.Find(e=>e.id==enemy.id);
            if(observation==null||!observation.motionSampled||State.time-observation.seenAt<-.00001f||State.time-observation.seenAt>.4f||!Finite(observation.velocity)||Immobilized(enemy))return enemy.position;
            float prepare=CombatActions.Timing(skill,Hero.heroClass,Stats.attackSpeed).prepare;
            Vector2 velocity=observation.velocity,relative=enemy.position-State.position+velocity*prepare;
            const float speed=14,range=10;float a=velocity.sqrMagnitude-speed*speed,b=2*Vector2.Dot(relative,velocity),c=relative.sqrMagnitude,t;
            if(Mathf.Abs(a)<.00001f)t=Mathf.Abs(b)<.00001f?(c<.00001f?0:float.PositiveInfinity):-c/b;
            else
            {
                float disc=b*b-4*a*c;if(disc<0)return enemy.position;
                float root=Mathf.Sqrt(disc),t1=(-b-root)/(2*a),t2=(-b+root)/(2*a);
                t=Mathf.Min(t1>=0?t1:float.PositiveInfinity,t2>=0?t2:float.PositiveInfinity);
            }
            if(float.IsInfinity(t)||float.IsNaN(t)||t<0||t>range/speed)return enemy.position;
            Vector2 offset=velocity*(prepare+t);
            return Map.MoveDirect(enemy.position,enemy.position+offset,offset.magnitude,.1f);
        }
    }
}
