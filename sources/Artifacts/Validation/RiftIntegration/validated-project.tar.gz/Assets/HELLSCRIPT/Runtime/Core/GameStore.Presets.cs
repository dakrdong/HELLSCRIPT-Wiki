using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Hellscript
{
    public static class PresetNames
    {
        public const int MaxLength=24;
        public static string Validate(string name)
        {
            if(name==null||name.Length>512)throw new ArgumentException("프리셋 이름은 표시 문자 1~24자로 입력하세요.");
            name=name.Trim().Normalize(NormalizationForm.FormC);
            if(name.Length==0||name.Any(char.IsControl))throw new ArgumentException("프리셋 이름에 글자를 입력하고 줄바꿈·제어 문자는 빼 주세요.");
            // Mono StringInfo handles combining marks. Merge emoji joiners, modifiers and flag pairs too.
            var elements=StringInfo.GetTextElementEnumerator(name);int count=0,regional=0;bool joinNext=false,previousEmoji=false;
            while(elements.MoveNext())
            {
                string part=elements.GetTextElement();int scalar=char.ConvertToUtf32(part,0);
                if(scalar==0x200d){joinNext=previousEmoji;continue;}
                bool modifier=scalar>=0x1f3fb&&scalar<=0x1f3ff||scalar>=0xfe00&&scalar<=0xfe0f||scalar>=0xe0100&&scalar<=0xe01ef;
                bool flag=scalar>=0x1f1e6&&scalar<=0x1f1ff;
                bool emoji=!flag&&(scalar>=0x1f000&&scalar<=0x1faff||scalar>=0x2300&&scalar<=0x27ff);
                if(count==0||!modifier&&!(joinNext&&emoji)&&(!flag||regional%2==0))count++;
                if(!modifier)previousEmoji=emoji;
                joinNext=previousEmoji&&part.EndsWith("\u200d",StringComparison.Ordinal);regional=flag?regional+(part.Length>=4?2:1):0;
            }
            if(count<1||count>MaxLength)throw new ArgumentException("프리셋 이름은 표시 문자 1~24자로 입력하세요.");
            return name;
        }
    }
    public sealed partial class GameStore
    {
        // Presets remain local BuildConfig snapshots until the lossless Hunt Edict adapter is connected.
        // A successful disk replacement is the only point at which the live preset collection changes.
        public bool SaveBuildPreset(string heroId,int slot,BuildConfig source,string name)
        {
            try
            {
                if(slot<0||slot>=HuntEdict.PresetSlots)throw new ArgumentException("프리셋 슬롯은 1~5입니다.");
                var owner=Data.heroes.SingleOrDefault(h=>h.id==heroId);
                if(owner==null||owner!=Data.Hero)throw new ArgumentException("설정을 편집한 캐릭터를 먼저 선택하세요.");
                if(!BuildEditing.HasPreset(source))throw new ArgumentException("보관할 설정이 없습니다.");
                string issue=BehaviorRules.InputValueIssue(source);if(issue!="")throw new ArgumentException(issue);
                var copy=source.Copy();copy.name=PresetNames.Validate(name);
                var issues=BehaviorRules.Validate(copy,owner.heroClass);if(issues.Count>0)throw new ArgumentException(issues[0]);
                var staged=JsonUtility.FromJson<AccountSave>(JsonUtility.ToJson(Data));
                var hero=staged.heroes.Single(h=>h.id==heroId);NormalizePresetSlots(hero);hero.presets[slot]=copy;
                staged.lastSeenUtc=DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                if(!Write(staged))return false;
                owner.presets=hero.presets;Data.lastSeenUtc=staged.lastSeenUtc;Error="";return true;
            }
            catch(Exception e){Error=Loc.F("프리셋을 저장하지 못했습니다: {0}", e.Message);return false;}
        }
        public bool RenameBuildPresets(string heroId,IReadOnlyDictionary<int,string> names)
        {
            try
            {
                var owner=Data.heroes.SingleOrDefault(h=>h.id==heroId);
                if(owner==null||owner!=Data.Hero||names==null||names.Count==0||names.Count>HuntEdict.PresetSlots)throw new ArgumentException("이름을 바꿀 캐릭터와 슬롯을 확인하세요.");
                var validated=new Dictionary<int,string>();
                foreach(var pair in names)
                {
                    if(pair.Key<0||pair.Key>=HuntEdict.PresetSlots||pair.Key>=owner.presets.Count||!BuildEditing.HasPreset(owner.presets[pair.Key]))throw new ArgumentException("비어 있는 슬롯의 이름은 바꿀 수 없습니다.");
                    validated.Add(pair.Key,PresetNames.Validate(pair.Value));
                }
                var staged=JsonUtility.FromJson<AccountSave>(JsonUtility.ToJson(Data));var hero=staged.heroes.Single(h=>h.id==heroId);
                foreach(var pair in validated)hero.presets[pair.Key].name=pair.Value;
                staged.lastSeenUtc=DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                if(!Write(staged))return false;
                owner.presets=hero.presets;Data.lastSeenUtc=staged.lastSeenUtc;Error="";return true;
            }
            catch(Exception e){Error=Loc.F("이름을 저장하지 못했습니다: {0}", e.Message);return false;}
        }
    }
}
