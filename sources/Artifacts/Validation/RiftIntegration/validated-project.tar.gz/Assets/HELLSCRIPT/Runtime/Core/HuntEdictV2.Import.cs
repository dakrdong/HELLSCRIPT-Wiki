using System.Collections.Generic;
using System.Linq;

namespace Hellscript
{
    public sealed class EdictV2ImportPreview
    {
        readonly HuntEdictV2Document original;
        public readonly string OriginalCode;
        public HuntEdictV2Document Original=>original.Copy();
        public readonly HuntEdictV2Document Draft;
        public readonly IReadOnlyList<EdictMissingSkill> MissingSkills;
        public bool Partial=>MissingSkills.Count>0;
        internal EdictV2ImportPreview(string code,HuntEdictV2Document original,HuntEdictV2Document draft,List<EdictMissingSkill> missing)
        {OriginalCode=code;this.original=original.Copy();Draft=draft;MissingSkills=missing.AsReadOnly();}
    }
    public static class HuntEdictV2Import
    {
        public static EdictV2ImportPreview Prepare(string code,HeroSave hero,GameCatalog catalog)
        {
            var original=HuntEdictV2Codec.Decode(code);HuntEdictV2.ValidateReceiver(original,hero,catalog);
            var draft=original.Copy();var missing=new List<EdictMissingSkill>();
            for(int n=0;n<4;n++)
            {
                if(draft.slots[n]=="")continue;var skill=catalog.skills.Single(s=>s.id==draft.slots[n]);
                if(hero.level>=skill.unlock)continue;missing.Add(new EdictMissingSkill(n,skill));draft.slots[n]="";
            }
            return new EdictV2ImportPreview(code.Trim(),original,draft,missing);
        }
    }
}
