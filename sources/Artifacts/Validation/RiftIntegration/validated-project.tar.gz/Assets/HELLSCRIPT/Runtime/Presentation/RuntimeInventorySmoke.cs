using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimeInventorySmoke : MonoBehaviour
    {
        GameController game;string directory,saveDirectory,candidateId,lockedId;int capture;uint rng=889933;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if(!Debug.isDebugBuild||!Environment.GetCommandLineArgs().Contains("-hellscriptInventorySmoke"))return;
            Application.runInBackground=true;Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Inventory validation").AddComponent<RuntimeInventorySmoke>();
        }
        static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
        static string Json(object value)=>JsonUtility.ToJson(value);
        static string Account(AccountSave value){var copy=JsonUtility.FromJson<AccountSave>(Json(value));copy.lastSeenUtc=0;return Json(copy);}
        static T Field<T>(object owner,string name)=>(T)owner.GetType().GetField(name,BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic).GetValue(owner);
        ScrollRect Pane(string name)=>Field<ScrollRect>(game.UI,name);
        object Session=>Field<object>(game.UI,"inventorySession");
        void Click(string name)
        {var button=game.UI.GetComponentsInChildren<Button>().Single(b=>b.name==name);Require(button.IsInteractable(),"Disabled command: "+name);button.onClick.Invoke();}
        Item Add(int slot,int rarity=2,string unique=null)
        {var item=ItemGenerator.Create(HeroClass.Warrior,slot,rarity,30,ref rng,uniqueId:unique);Require(Economy.AddItem(game.Store.Data.Hero,item,BagPolicy.Ignore,game.Store.Data),"Fixture bag full.");return item;}
        void CheckLayout()
        {
            Canvas.ForceUpdateCanvases();var list=Pane("inventoryList");Require(list!=null,"Missing inventory page.");
            var panels=new List<Rect>();
            foreach(var pane in new[]{list,Pane("inventoryDetail"),Pane("inventoryComparison"),Pane("inventoryTool")})
            {
                if(!pane.gameObject.activeInHierarchy)continue;var corners=new Vector3[4];pane.viewport.GetWorldCorners(corners);
                Require(corners.All(p=>p.x>=UiSafeArea.Current.xMin-1&&p.x<=UiSafeArea.Current.xMax+1&&p.y>=UiSafeArea.Current.yMin-1&&p.y<=UiSafeArea.Current.yMax+1),"Inventory pane outside safe area.");
                var rect=Rect.MinMaxRect(corners[0].x,corners[0].y,corners[2].x,corners[2].y);Require(!panels.Any(p=>p.Overlaps(rect)),"Inventory panes overlap.");panels.Add(rect);
                var display=game.UI.transform.Find("HELLSCRIPT UI/Display");var safeRoot=game.UI.transform.Find("HELLSCRIPT UI/Safe area");
                Require(display.Cast<Transform>().Any(t=>t.name=="Backdrop"&&t.gameObject.activeSelf)&&display.GetSiblingIndex()<safeRoot.GetSiblingIndex(),"Opaque backdrop covers inventory content.");
                foreach(var button in pane.content.GetComponentsInChildren<Button>().Where(b=>b.IsInteractable()))
                {
                    var buttonRect=(RectTransform)button.transform;var center=RectTransformUtility.WorldToScreenPoint(null,buttonRect.TransformPoint(buttonRect.rect.center));
                    if(!rect.Contains(center))continue;CheckRaycast(button,center);break;
                }
            }
            foreach(var text in game.UI.GetComponentsInChildren<Text>())Require(text.preferredHeight<=text.rectTransform.rect.height+1,"Clipped inventory text: "+text.text+" preferred="+text.preferredHeight+" actual="+text.rectTransform.rect.height);
            var footer=game.UI.transform.Find("HELLSCRIPT UI/Safe area/Footer");
            foreach(var button in footer.GetComponentsInChildren<Button>())
            {
                var corners=new Vector3[4];((RectTransform)button.transform).GetWorldCorners(corners);
                Require(corners.All(p=>p.x>=UiSafeArea.Current.xMin-1&&p.x<=UiSafeArea.Current.xMax+1&&p.y>=UiSafeArea.Current.yMin-1&&p.y<=UiSafeArea.Current.yMax+1),"Fixed command outside safe area.");
                Require(!panels.Any(p=>p.Overlaps(Rect.MinMaxRect(corners[0].x,corners[0].y,corners[2].x,corners[2].y))),"Fixed command overlaps reading content.");
                if(button.IsInteractable())CheckRaycast(button,(corners[0]+corners[2])*.5f);
            }
            File.AppendAllText(Path.Combine(directory,"layout-checks.txt"),$"PASS {Screen.width}x{Screen.height} page={game.UI.Page} tool={Field<string>(game.UI,"inventoryToolKind")} visiblePanes={panels.Count}\n");
        }
        void CheckRaycast(Button button,Vector2 point)
        {
            var hits=new List<RaycastResult>();EventSystem.current.RaycastAll(new PointerEventData(EventSystem.current){position=point},hits);
            Require(hits.Count>0&&(hits[0].gameObject.transform==button.transform||hits[0].gameObject.transform.IsChildOf(button.transform)),"Input is covered before reaching "+button.name);
        }
        IEnumerator Resize(int width,int height)
        {
            Screen.SetResolution(width,height,FullScreenMode.Windowed);float deadline=Time.realtimeSinceStartup+6;
            while((Screen.width!=width||Screen.height!=height)&&Time.realtimeSinceStartup<deadline)yield return null;
            Require(Screen.width==width&&Screen.height==height,"Native window size mismatch.");yield return new WaitForSecondsRealtime(.2f);
        }
        IEnumerator Capture(string name)
        {yield return new WaitForSecondsRealtime(.2f);CheckLayout();ScreenCapture.CaptureScreenshot(Path.Combine(directory,$"{++capture:00}-{name}.png"));yield return new WaitForSecondsRealtime(.2f);}
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();for(int i=0;i<args.Length-1;i++){if(args[i]=="-hellscriptSavePath")saveDirectory=args[i+1];if(args[i]=="-hellscriptScreenshots")directory=args[i+1];}
            Require(!string.IsNullOrEmpty(saveDirectory)&&!string.IsNullOrEmpty(directory),"Use isolated save and evidence paths.");Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1);game=FindAnyObjectByType<GameController>();Require(game.Store!=null,"Missing account.");game.enabled=false;
            if(args.Contains("-hellscriptInventoryResume"))
            {
                Require(Account(game.Store.Data)==File.ReadAllText(Path.Combine(directory,"expected-account.json")),"Restart changed acquisition metadata, items or rewards.");
                string id=File.ReadAllText(Path.Combine(directory,"retained-item-id.txt"));game.UI.ShowItemDetail(id);yield return Resize(1920,1080);yield return Capture("restart-comparison");
                Require(game.Store.Data.Hero.inventory.Any(i=>i.id==id&&i.locked&&i.acquiredOrder>0),"Restart lost retained protection/acquisition.");
                File.WriteAllText(Path.Combine(directory,"runtime-inventory-resume.txt"),"PASS: separate native process restored all item IDs, acquisition sequence/read flags, protection, transaction receipts and currency, then opened responsive comparison.\n");
                Debug.Log("HELLSCRIPT_INVENTORY_RESUME_OK");Application.Quit(0);yield break;
            }
            var account=game.Store.Data;var hero=account.Hero;hero.level=30;hero.build=GameCatalog.Preset(HeroClass.Warrior,0);account.guide.hintsHidden=true;account.gold=100000;account.materials=1000;
            foreach(string id in new[]{"SW1","SW2","SW3","SW4"}){var def=ItemCatalog.Unique(id);var item=Add(def.slot,3,id);Require(Economy.Equip(hero,item),"Fixture equip failed.");}
            candidateId=Add(3).id;lockedId=Add(1).id;hero.inventory.Single(i=>i.id==lockedId).locked=true;
            var referenced=Add(2);account.heroes[1].presets[0]=account.heroes[1].build.Copy();account.heroes[1].presets[0].equipmentIds.Add(referenced.id);
            for(int i=0;i<27;i++)Add(i%8,i%3);Add(0,3,"LW01");game.Save();game.UI.ShowItemDetail(candidateId);yield return null;
            Click("강화 +1 · 재료 20 / 6,000 골드");yield return null;
            var edited=hero.inventory.Single(i=>i.id==candidateId);Require(edited.enhancement==1&&edited.investedMaterials==20&&account.materials==980&&account.gold==94000,"Enhancement UI disagrees with the quoted cost.");
            edited.rerollSlotId=null;Click("한 줄 재설정");yield return null;
            var reroll=Pane("inventoryTool").content.GetComponentsInChildren<Button>().First(b=>b.IsInteractable());
            long cost=Economy.RerollGold(edited);int goldBefore=account.gold;
            Require(game.Store.Transact("inventory-smoke-change-quote","fixture:quote",staged=>{staged.Hero.inventory.Single(i=>i.id==candidateId).rerolls=1;return true;}),"Could not replace the quoted item fixture.");
            Require(!ReferenceEquals(edited,hero.inventory.Single(i=>i.id==candidateId))&&Economy.RerollGold(hero.inventory.Single(i=>i.id==candidateId))==cost*2,"Fixture did not replace the item or increase its quote.");
            reroll.onClick.Invoke();yield return null;
            Require(Pane("inventoryTool").content.GetComponentsInChildren<Text>().Any(t=>t.text.Contains($"비용 {cost:N0} 골드")),"Pending confirmation lost its displayed quote.");
            string changed=Account(account);Click("확인");yield return null;
            Require(Account(account)==changed&&account.gold==goldBefore&&hero.inventory.Single(i=>i.id==candidateId).rerolls==1,"Confirmation accepted an item replaced after rendering its quote.");
            Require(game.Store.Transact("inventory-smoke-restore-quote","fixture:quote",staged=>{staged.Hero.inventory.Single(i=>i.id==candidateId).rerolls=0;return true;}),"Could not restore the quoted item fixture.");
            Click("확인");yield return null;edited=hero.inventory.Single(i=>i.id==candidateId);
            Require(edited.rerolls==1&&!string.IsNullOrEmpty(edited.rerollSlotId)&&edited.enhancement==1&&account.gold==goldBefore-cost,"Reroll retry lost enhancement or used the wrong cost.");
            yield return new WaitForSecondsRealtime(5.2f);
            var list=Pane("inventoryList");var detail=Pane("inventoryDetail");string snapshot=Account(account);
            foreach(var size in new[]{new Vector2Int(720,1280),new Vector2Int(1280,720),new Vector2Int(1920,1080),new Vector2Int(1920,1200),new Vector2Int(3440,1440),new Vector2Int(900,900),new Vector2Int(640,360),new Vector2Int(360,640),new Vector2Int(390,844),new Vector2Int(818,390),new Vector2Int(820,390),new Vector2Int(844,390),new Vector2Int(958,640),new Vector2Int(960,640),new Vector2Int(1438,720),new Vector2Int(1440,720)})
            {
                yield return Resize(size.x,size.y);yield return Capture($"comparison-{size.x}x{size.y}");
                Require(Pane("inventoryList")==list&&Pane("inventoryDetail")==detail&&Field<string>(Session,"selectedId")==candidateId,"Resize recreated panes or lost selection.");Require(Account(account)==snapshot,"Resize changed inventory/account.");
            }
            yield return Resize(1920,1080);var comparison=Pane("inventoryComparison");comparison.verticalNormalizedPosition=.55f;((DialogScrollRect)comparison).readingStarted();Canvas.ForceUpdateCanvases();
            var anchor=DialogReadingAnchor.Capture(comparison);var row=Field<RectTransform>(anchor,"row");yield return Resize(1438,720);
            Require(Field<RectTransform>(DialogReadingAnchor.Capture(detail),"row")==row,"Merging comparison lost the paragraph being read.");yield return Capture("merged-reading-anchor");yield return Resize(1440,720);
            Require(Field<RectTransform>(DialogReadingAnchor.Capture(comparison),"row")==row,"Splitting comparison lost the paragraph being read.");
            yield return Resize(360,640);Click("목록");list.verticalNormalizedPosition=.45f;yield return Capture("narrow-list");
            Click("필터");yield return null;Click("부위 · 모두");yield return null;Click("손");yield return null;Click("등급 · 모든 등급");yield return null;Click("희귀");yield return null;
            Click("정렬 · 장착·부위순");yield return null;Click("최근 획득순");yield return null;yield return Capture("filters");Click("목록 보기");yield return null;
            var query=Field<InventoryQuery>(Session,"query");Require(query.slot==3&&query.grade==InventoryGrade.Rare&&query.order==InventoryOrder.Newest,"Filter choices were not applied.");
            Require(list.content.GetComponentsInChildren<Button>().All(b=>query.Matches(hero.inventory.Single(i=>b.name=="Inventory item "+i.id))),"List ignored filters.");
            Click("Inventory item "+candidateId);yield return null;Click("설정·안내");var session=Session;string selection=Field<string>(session,"selectedId");
            yield return Resize(1280,720);Click("닫기");yield return null;Require(Session==session&&Field<string>(Session,"selectedId")==selection&&ReferenceEquals(query,Field<InventoryQuery>(Session,"query")),"Settings lost inventory selection or query.");
            Click("필터");yield return null;Click("조건 초기화");yield return null;Click("목록 보기");yield return null;Click("정리");yield return null;
            var plan=Field<InventoryBulkPlan>(game.UI,"inventoryBulk");Require(plan.Count>20&&plan.entries.Any(e=>e.id==lockedId&&e.excludedReason!="")&&plan.entries.Any(e=>e.id==referenced.id&&e.excludedReason!=""),"Bulk protection preview is incomplete.");
            int materialsBeforeBulk=account.materials;string before=Account(account);foreach(var size in new[]{new Vector2Int(1920,1080),new Vector2Int(640,360),new Vector2Int(360,640)})
            {yield return Resize(size.x,size.y);yield return Capture($"bulk-{size.x}x{size.y}");Require(ReferenceEquals(plan,Field<InventoryBulkPlan>(game.UI,"inventoryBulk"))&&before==Account(account),"Resize changed pending disposal.");}
            var tool=Pane("inventoryTool");tool.verticalNormalizedPosition=0;yield return Capture("bulk-exclusions-last-row");
            var last=tool.content.Cast<Transform>().Last(t=>t.gameObject.activeSelf) as RectTransform;var bounds=RectTransformUtility.CalculateRelativeRectTransformBounds(tool.viewport,last);
            Require(bounds.min.y>=tool.viewport.rect.yMin-1&&bounds.min.y<=tool.viewport.rect.yMax,"Last exclusion cannot be reached.");
            string disk=File.ReadAllText(Path.Combine(saveDirectory,"hellscript-local-v1.json"));string temp=Path.Combine(saveDirectory,"hellscript-local-v1.json.tmp");Directory.CreateDirectory(temp);
            var confirm=game.UI.GetComponentsInChildren<Button>().Single(b=>b.name=="분해 확정");Click("분해 확정");yield return null;
            Require(before==Account(account)&&disk==File.ReadAllText(Path.Combine(saveDirectory,"hellscript-local-v1.json"))&&ReferenceEquals(plan,Field<InventoryBulkPlan>(game.UI,"inventoryBulk")),"Failed save consumed items or replaced pending preview.");yield return Capture("bulk-write-failure");
            Directory.Delete(temp);Click("분해 확정");yield return null;int materials=account.materials;string committed=Account(account);confirm.onClick.Invoke();Require(committed==Account(account),"Double confirmation duplicated disposal.");
            Require(materials==materialsBeforeBulk+plan.Materials&&account.Hero.inventory.All(i=>plan.entries.All(e=>e.id!=i.id||e.excludedReason!="")),"Bulk rewards or retained items differ from preview.");
            game.UI.ShowItemDetail(lockedId);yield return null;long acquired=hero.inventory.Single(i=>i.id==lockedId).acquiredOrder;
            Require(game.UI.GetComponentsInChildren<Button>().Where(b=>b.name.StartsWith("판매 ·",StringComparison.Ordinal)||b.name.StartsWith("분해 ·",StringComparison.Ordinal)).All(b=>!b.IsInteractable()),"Protected single-item disposal is enabled.");
            Click("공유 창고로 이동");yield return null;Click("창고");yield return null;Click("Inventory item "+lockedId);yield return Resize(1920,1080);yield return Capture("warehouse-comparison");
            Require(account.warehouse.Single(i=>i.id==lockedId).acquiredOrder==acquired&&account.warehouse.Single(i=>i.id==lockedId).locked,"Storage transfer reset acquisition/protection.");
            Click("현재 캐릭터의 가방으로 이동");yield return null;Click("가방");yield return null;game.UI.ShowItemDetail(lockedId);yield return null;
            game.Begin(seed:889977);var run=game.Combat.State;run.portal=true;game.UI.ShowBag(true);yield return null;game.UI.ShowItemDetail(lockedId,true);yield return Resize(640,360);yield return Capture("portal-management");
            Require(game.UI.Page=="bag"&&!game.UI.GetComponentsInChildren<Button>().Any(b=>b.name.StartsWith("강화 +",StringComparison.Ordinal)||b.name=="한 줄 재설정"),"Portal exposed town-only services.");
            Require(!game.UI.GetComponentsInChildren<Button>().Single(b=>b.name=="장착").IsInteractable(),"Portal can equip gear.");
            string pausedRun=Json(run);yield return Resize(1920,1080);Click("잠금 해제");yield return null;Require(Json(run)==pausedRun,"Inventory command or resize changed portal checkpoint.");
            Click("균열 복귀");yield return null;Require(!run.portal&&run.time==game.Combat.State.time,"Portal return reset the run.");game.ReturnTown();
            var kept=account.Hero.inventory.Single(i=>i.id==lockedId);kept.locked=true;game.Save();
            File.WriteAllText(Path.Combine(directory,"expected-account.json"),Account(account));File.WriteAllText(Path.Combine(directory,"retained-item-id.txt"),lockedId);
            File.WriteAllText(Path.Combine(directory,"runtime-inventory-smoke.txt"),"PASS: 16 actual macOS sizes, same list/detail objects and selected item, 3/2/1-pane folds including short landscape, comparison paragraph continuity, filter/sort, settings retention, enhancement/reroll quoted costs and stale confirmation retry, protected single-disposal controls, bulk targets/exclusions/rewards, pending-plan preservation, forced save failure/retry/double click, storage acquisition/protection, portal service restrictions and checkpoint preservation. Draw order and real UI raycast reachability checked. Native UI callbacks and Metal; no physical mobile or keyboard claim.\n");
            Debug.Log("HELLSCRIPT_INVENTORY_RUNTIME_SMOKE_OK");Application.Quit(0);
        }
    }
}
