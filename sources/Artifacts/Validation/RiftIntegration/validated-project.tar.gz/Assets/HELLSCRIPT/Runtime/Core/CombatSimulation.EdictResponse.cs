using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        string EdictResponseBlock(HuntEdictV2Document d)
        {
            if(State.paused||State.portal||State.health<=0||State.phase==RunPhase.Looting||State.phase==RunPhase.Cleared||State.phase==RunPhase.Failed||!string.IsNullOrEmpty(State.navigationError))return "전투가 진행 가능한 상태가 아닙니다.";
            var slots=d.slots.Where(s=>s!="").Select(s=>catalog.skills.FindIndex(k=>k.id==s));
            return new HashSet<int>(slots).SetEquals(State.build.activeSkills)?"":"원본의 스킬 배치가 현재 전투에 적용되지 않았습니다.";
        }
        bool EdictCanInterrupt(EdictSurvivalAssessment assessment)
        {
            if(!HeroActionBusy)return true;var a=State.heroAction;
            if(a.phase==HeroActionPhase.Travelling||a.phase==HeroActionPhase.Recovering||a.exitChannelForBuild||a.exitChannelForSurvival)return false;
            if(a.policy?.rule?.id?.StartsWith("HED2:SURVIVAL:",StringComparison.Ordinal)==true)return false;
            return assessment.emergency||assessment.dodgeInterrupt=="CANCEL_ALLOWED";
        }
        public EdictResponsePlan PlanEdictSurvival(HuntEdictV2Document source)
        {
            var d=HuntEdictV2.Canonical(source);HuntEdictV2.ValidateReceiver(d,Hero,catalog);
            var values=d.global.ToDictionary(o=>o.id,o=>o.value,StringComparer.Ordinal);
            var assessment=AssessEdictSurvival(d,State.edictResponse?.memory,null,values);
            var attempts=new List<EdictResponseCandidate>();string blocked=EdictResponseBlock(d);
            EdictResponsePlan Result(EdictResponseCandidate choice=null)=>new EdictResponsePlan(blocked,assessment,attempts,choice);
            if(blocked!=""||!assessment.emergency&&!assessment.DodgeRequested)return Result();
            var seen=ForecastSeen();var target=seen.FirstOrDefault(e=>e.id==State.targetId)??seen.OrderBy(e=>(e.position-State.position).sqrMagnitude).ThenBy(e=>e.id).FirstOrDefault();
            var risks=new Dictionary<Vector2,EdictSurvivalAssessment>{{State.position,assessment}};
            EdictSurvivalAssessment Risk(Vector2 p)
            {if(!risks.TryGetValue(p,out var a)){a=AssessEdictSurvival(d,null,p,values);risks[p]=a;}return a;}
            bool Add(EdictResponseCandidate c){attempts.Add(c);return c.ready;}
            EdictResponseCandidate Skill(EdictSurvivalIntent intent)=>EdictSurvivalSkill(d,values,assessment,intent,seen,target,Risk);
            EdictResponseCandidate Walk()=>EdictSurvivalWalk(assessment,seen,target,Risk);
            EdictResponseCandidate Fallback()
            {
                var f=assessment.escapeFallback;
                return f.role=="WALK"?Walk():f.role=="KEEP_FIGHTING"?new EdictResponseCandidate("KEEP_FIGHTING","",-1,-1,State.position,0,"KEEP_FIGHTING","사용자가 정한 전투 유지 방침을 따릅니다.",true):Skill(f);
            }
            if(assessment.emergency)
            {
                foreach(var intent in assessment.emergencyOrder)
                {
                    var c=intent.role=="WALK"?Walk():Skill(intent);if(Add(c))return Result(c);
                    if(intent.role=="ESCAPE")
                    {var f=Fallback();if(Add(f))return Result(f);}
                }
                return Result();
            }
            var escape=assessment.emergencyOrder.Single(i=>i.role=="ESCAPE");
            EdictResponseCandidate DodgeSkill()=>assessment.preserveEscapeForEmergency?
                new EdictResponseCandidate("ESCAPE",escape.skillId,-1,-1,State.position,0,"RESERVED","회피기를 긴급 생존용으로 보존합니다."):Skill(escape);
            if(assessment.dodgeMethod=="SKILL_FIRST")
            {var c=DodgeSkill();if(Add(c))return Result(c);c=Walk();if(Add(c))return Result(c);}
            else
            {
                var walk=Walk();Add(walk);
                if(walk.ready&&(assessment.dodgeMethod=="WALK_FIRST"||walk.timely))return Result(walk);
                var c=DodgeSkill();if(Add(c))return Result(c);if(walk.ready)return Result(walk);
            }
            var fallback=Fallback();return Add(fallback)?Result(fallback):Result();
        }
        EdictResponseCandidate EdictSurvivalSkill(HuntEdictV2Document d,Dictionary<string,string> values,EdictSurvivalAssessment assessment,EdictSurvivalIntent intent,EnemyState[] seen,EnemyState target,Func<Vector2,EdictSurvivalAssessment> risk)
        {
            int index=catalog.skills.FindIndex(s=>s.id==intent.skillId);Vector2 point=State.position;float cost=index>=0?Cost(catalog.skills[index]):0;
            var rule=new Rule(index){id="HED2:SURVIVAL:"+intent.skillId,action=RuleAction.Skill,always=true,enabled=true,overrideMovement=true,movement=MovementMode.Stand,escape=true};
            EdictResponseCandidate C(string code,string detail,bool ready=false,float arrival=0)=>new EdictResponseCandidate(intent.role,intent.skillId,index,target?.id??-1,point,cost,code,detail,ready,true,arrival,rule);
            if(!intent.referenceAvailable||index<0||!State.build.activeSkills.Contains(index))return C("REFERENCE",intent.reason);
            if(!EdictCanInterrupt(assessment))return C("ACTION_LOCK","현재 행동이 끝나거나 중단 가능한 구간이 되어야 합니다.");
            if(State.cooldowns[index]>0)return C("COOLDOWN","지정한 스킬의 재사용 대기시간이 남아 있습니다.");
            if(State.resource<cost)return C("RESOURCE","지정한 스킬을 사용할 자원이 부족합니다.");
            var skill=catalog.skills[index];var timing=CombatActions.Timing(index,Hero.heroClass,Stats.attackSpeed);
            bool move=skill.kind==SkillKind.Leap||skill.kind==SkillKind.Retreat||skill.kind==SkillKind.Teleport;
            if(move)
            {
                if(!assessment.emergency&&assessment.preserveEscapeForEmergency&&intent.skillId==values["survival.escapeSkill"])return C("RESERVED","다른 생존기 참조로도 긴급용 회피기 보존을 우회하지 않습니다.");
                if(index==1&&!assessment.emergency&&HuntEdictV2.Value(d,"W02",2)=="ESCAPE")return C("PURPOSE","생존 이탈 전용 도약은 전역 긴급 대응에서만 사용합니다.");
                if(index==9&&target==null)return C("NO_TARGET","후퇴 도약의 기준이 될 감지 대상이 없습니다.");
                if(index==9&&!assessment.emergency)
                {
                    string purpose=HuntEdictV2.Value(d,"A04",2);
                    if(purpose=="OFF")return C("PURPOSE","후퇴 도약의 일반 사용을 끈 상태이므로 긴급 대응에서만 사용합니다.");
                    if(purpose=="TRAP_LINK"&&(!Stats.specials.Contains("LA03")||!d.slots.Contains("A03")||State.traps.Count>=2||!seen.Any(e=>Vector2.Distance(State.position,e.position)<=GroundRadius(8))))return C("LINK","출발점 덫 연계의 장착·공간·인원 조건을 충족하지 않습니다.");
                    if(purpose=="PIERCE_LINK"&&(Stats.SetPieces("SAB")<4||!d.slots.Contains("A01")||ItemEffects.pierceCharge>0))return C("LINK","관통 연계의 장착·충전 조건을 충족하지 않습니다.");
                }
                var choice=EdictEscapePoint(d,values,index,skill.range,seen,target,risk,!assessment.emergency);
                if(!choice.HasValue)return C("LANDING","전역 위험 기준을 만족하는 유효 착지점이 없습니다.");point=choice.Value;
                return C("READY","착지·시야·전역 위험 기준을 확인한 생존 이동입니다.",true,timing.prepare+timing.travel);
            }
            if(skill.kind==SkillKind.Shield)
            {
                if(State.shields.Any(s=>s.definitionId==skill.id&&s.amount>0&&s.remaining>0))return C("EFFECT_ACTIVE","자신의 보호막이 남아 있어 다시 사용하지 않습니다.");
                if(Stats.shieldMultiplier<=0||Stats.hp-State.shields.Sum(s=>Mathf.Max(0,s.amount))<=.00001f)return C("SHIELD_CAP","추가로 생성할 수 있는 보호막이 없습니다.");
                if(!assessment.emergency)
                {
                    string moment=HuntEdictV2.Value(d,skill.id,2);
                    if(moment=="EMERGENCY"||moment=="ELITE_ENGAGE")return C("PURPOSE","이 보호막의 사용 시점은 현재 일반 회피 요청에 해당하지 않습니다.");
                    if(HuntEdictV2.Value(d,skill.id,3)=="AFTER"&&State.shields.Any(s=>s.amount>0&&s.remaining>0))return C("WAIT_DEFENSE","다른 보호막의 소진·만료를 기다립니다.");
                    if(index==4&&HuntEdictV2.Value(d,"W05",4)=="AFTER"&&leapDefense>0)return C("WAIT_DEFENSE","도약 방어 효과가 끝나기를 기다립니다.");
                    if(index==16)
                    {
                        string group=HuntEdictV2.Value(d,"M05",4);
                        if(group=="ELITE"&&!seen.Any(e=>e.elite>=0||e.boss)||group=="BOSS"&&!seen.Any(e=>e.boss))return C("ENCOUNTER","원소 보호막의 일반 사용을 허용한 교전이 아닙니다.");
                    }
                }
                return C("READY","지정한 생존 방침에 따라 보호막 생성을 시작합니다.",true,timing.prepare);
            }
            if(skill.kind==SkillKind.Slam||skill.kind==SkillKind.Nova)
            {
                bool Control(EnemyState e)=>e.boss?e.bossControl.staggered<=0&&e.bossControl.immunity<=0&&e.bossControl.meter+15>=100-.0001f:
                    Mathf.Max(CombatEffects.Remaining(e,StatusKind.Stun),CombatEffects.Remaining(e,StatusKind.Freeze))<=timing.prepare+.00001f;
                var affected=seen.Where(e=>Vector2.Distance(State.position,e.position)<=3&&Map.LineClear(State.position,e.position)&&Control(e)).ToArray();
                if(affected.Length==0)return C("NO_CONTROL","이번 사용으로 새로 제어할 수 있는 감지 대상이 없습니다.");target=affected.OrderBy(e=>(e.position-State.position).sqrMagnitude).ThenBy(e=>e.id).First();
                return C("READY","범위 안에서 새 제어 또는 보스 제압 완성이 가능한 대상을 확인했습니다.",true,timing.prepare);
            }
            if(skill.kind==SkillKind.Trap)
            {
                string aim=HuntEdictV2.Value(d,"A03",2),purpose=HuntEdictV2.Value(d,"A03",3);rule.areaAim=aim=="SELF"?AreaAim.Self:aim=="PATH"?AreaAim.ObservedPath:aim=="DENSE"?AreaAim.Dense:AreaAim.Target;
                if(purpose=="AMBUSH")return C("PURPOSE","교전 전 매복은 긴급 제어용 직접 설치 조건이 아닙니다.");
                point=GroundAim(rule,target,seen);if(!Map.CanLand(point,.1f)||!Map.LineClear(State.position,point)||Vector2.Distance(State.position,point)>skill.range+.0001f)return C("LANDING","덫을 설치할 수 있는 범위와 위치가 아닙니다.");
                var victims=seen.Where(e=>Vector2.Distance(e.position,point)<=GroundRadius(index)&&Map.LineClear(point,e.position)).ToArray();
                if(victims.Length<(purpose=="ONE"?1:2)&&!(purpose=="ELITE_OR_GROUP"&&victims.Any(e=>e.boss||e.elite>=0)))return C("TARGET_COUNT","설치 위치의 감지 인원이 설정 기준보다 적습니다.");
                if(State.traps.Count>=2&&HuntEdictV2.Value(d,"A03",4)=="KEEP")return C("TRAP_CAP","기존 덫 두 개를 유지합니다.");
                if(HuntEdictV2.Value(d,"A03",5)=="NEW_TARGET"&&!victims.Any(e=>!OwnArea(e,true)))return C("AREA_OVERLAP","기존 활성 덫 밖에서 새로 덮을 적이 없습니다.");
                if(!victims.Any(e=>!e.boss&&CombatEffects.Remaining(e,StatusKind.Root)<=timing.prepare+.5f||e.boss&&e.bossControl.staggered<=0&&e.bossControl.immunity<=0&&e.bossControl.meter+15*(Stats.passives[3]?1.25f:1)>=100-.0001f))return C("NO_CONTROL","덫 발동으로 새로 속박하거나 제압할 대상이 없습니다.");
                return C("READY","설치 후 무장·진입 조건을 거쳐 발동할 덫입니다.",true,timing.prepare+.5f);
            }
            return C("ROLE","지정한 스킬은 이 생존 역할을 수행하지 않습니다.");
        }
        // Re-evaluate immediately before mutation. Never execute an old preview/plan supplied by a caller.
        // The future HED2 decision scheduler must call this with the successfully saved source only.
        public EdictResponseExecution ExecuteEdictSurvival(HuntEdictV2Document source)
        {
            var d=HuntEdictV2.Canonical(source);HuntEdictV2.ValidateReceiver(d,Hero,catalog);var before=PlanEdictSurvival(d);
            if(before.blockedReason!="")return new EdictResponseExecution(before,false,false,false);
            bool potion=before.assessment.potionRequested&&TryUsePotion(float.Parse(d.global.Single(o=>o.id=="survival.potionHpPercent").value,CultureInfo.InvariantCulture));
            var plan=potion?PlanEdictSurvival(d):before;
            State.edictResponse??=new EdictResponseState();State.edictResponse.memory=plan.assessment.NextState;
            bool finish=!plan.assessment.emergency&&plan.assessment.DodgeRequested&&plan.assessment.dodgeInterrupt=="FINISH"&&State.heroAction.phase==HeroActionPhase.Channeling;
            if(finish)State.heroAction.exitChannelForSurvival=true;
            var c=plan.selected;
            if(c==null){if(!plan.assessment.emergency&&!plan.assessment.DodgeRequested)StopEdictWalk();return new EdictResponseExecution(plan,potion,false,finish);}
            if(c.role=="KEEP_FIGHTING"){StopEdictWalk();return new EdictResponseExecution(plan,potion,false,finish);}
            string reason=plan.assessment.emergency?"전역 긴급 생존":"전역 일반 회피";
            if(c.role=="WALK")
            {
                if(HeroActionBusy)InterruptHeroAction(Loc.F("{0} · 보행 전환", reason));CancelChest(reason);CancelShrine(reason);State.portalCast=0;
                var walk=State.edictResponse;walk.walking=true;walk.destination=c.destination;walk.expiresAt=State.time+Mathf.Max(1,c.arrival+1);walk.reason=reason;
                State.action=Loc.F("{0} · 보행 후퇴", reason);State.destination=c.destination;Map.Repath();Log("EDICT_SURVIVAL_WALK",c.detail);
            }
            else
            {
                var target=State.enemies.Find(e=>e.id==c.targetId&&!e.dead);StartHeroAction(c.skill,target,c.destination,c.cost,-1,true,c.rule);
                Log("EDICT_SURVIVAL_SKILL",Loc.F("{0} · {1}",reason,catalog.skills[c.skill].name));
            }
            return new EdictResponseExecution(plan,potion,true,finish);
        }
        void StopEdictWalk(){if(State.edictResponse!=null)State.edictResponse.walking=false;}
        bool MoveEdictResponse(float dt)
        {
            var walk=State.edictResponse;if(walk==null||!walk.walking)return false;
            if(walk.memory==null||walk.memory.heroId!=State.heroId||walk.memory.runId!=State.id||State.time>walk.expiresAt||Vector2.Distance(State.position,walk.destination)<.05f){StopEdictWalk();return false;}
            if(HeroActionBusy)return false;
            float speed=MovementSpeed(false)*(State.enemySlowTime>0?.65f:1);var old=State.position;
            var p=Map.Move(old,walk.destination,speed*dt,0,State.time);State.position=p;State.destination=walk.destination;State.moveDistance+=Vector2.Distance(old,p);State.action=Loc.F("{0} · 보행 후퇴", walk.reason);
            if(Map.HeroPathFailed){StopEdictWalk();Log("EDICT_WALK_BLOCKED","후퇴 경로를 진행할 수 없어 다시 판단합니다.");}
            return true;
        }
    }
}
