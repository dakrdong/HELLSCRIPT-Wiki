using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed class RuntimeBossSmoke : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Install()
        {
            if(!Environment.GetCommandLineArgs().Contains("-hellscriptBossSmoke"))return;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};new GameObject("Boss pattern smoke").AddComponent<RuntimeBossSmoke>();
        }
        static void Require(bool pass,string why){if(!pass)throw new InvalidOperationException(why);}
        static IEnumerator Until(Func<bool> ready,float timeout=15)
        {float end=Time.realtimeSinceStartup+timeout;while(!ready()&&Time.realtimeSinceStartup<end)yield return null;Require(ready(),"Boss runtime state was not reached.");}
        static IEnumerator Capture(GameController game,string directory,string name)
        {game.Combat.State.paused=true;game.UI.RefreshHud();yield return new WaitForSecondsRealtime(.35f);ScreenCapture.CaptureScreenshot(Path.Combine(directory,name));yield return new WaitForSecondsRealtime(.2f);}
        static RunState Arena(GameController game,int pattern,int slot,float distance,bool enraged=false)
        {
            if(game.Running)game.ReturnTown();var account=game.Store.Data;account.selectedHero=0;var hero=account.Hero;hero.level=30;hero.inventory.Clear();uint rng=92723;
            for(int n=0;n<8;n++){var item=ItemGenerator.Create(HeroClass.Warrior,n,2,30,ref rng);item.equipped=true;hero.inventory.Add(item);}
            hero.build=GameCatalog.Preset(HeroClass.Warrior,0);hero.build.rules.Clear();hero.build.activeSkills=new[]{2,4}.ToList();hero.build.passives=Array.Empty<int>();hero.build.movement=MovementMode.Stand;hero.build.autoRepeat=false;hero.build.potionThreshold=0;
            var fixture=new CombatSimulation(account,game.catalog,1,1,seed:8917);var run=fixture.State;run.training=-1;run.phase=RunPhase.Boss;run.position=RiftMap.Rooms[0];run.enemies.Clear();run.bossId=900;
            var boss=new EnemyState{id=900,boss=true,pattern=pattern,position=run.position+Vector2.up*distance,health=enraged?50000:100000,maxHealth=100000,attack=5,speed=0,cooldown=1000};
            boss.brain.boss.initialized=true;Array.Fill(boss.brain.boss.cooldowns,1000);boss.brain.boss.cooldowns[slot]=0;run.enemies.Add(boss);
            account.suspendedRun=run;game.Begin(resume:true);game.SetSpeed(1);game.Combat.State.paused=true;return game.Combat.State;
        }
        static void Save(GameController game,string directory,string name)
        {game.Save();Require(string.IsNullOrEmpty(game.Store.Error),"Boss checkpoint failed.");File.WriteAllText(Path.Combine(directory,name),JsonUtility.ToJson(game.Combat.State,true));}
        static RunState Resume(GameController game,string directory,string name)
        {
            var saved=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(directory,name)));GameStore.NormalizeRun(saved);game.Begin(resume:true);var run=game.Combat.State;run.paused=true;
            Require(run.id==saved.id&&run.time==saved.time&&run.rng==saved.rng&&run.health==saved.health&&run.resource==saved.resource
                &&JsonUtility.ToJson(run.heroAction)==JsonUtility.ToJson(saved.heroAction)&&run.enemies.Count==saved.enemies.Count&&!run.enemies.Where((e,i)=>JsonUtility.ToJson(e)!=JsonUtility.ToJson(saved.enemies[i])).Any()
                &&run.enemyHazards.Count==saved.enemyHazards.Count&&!run.enemyHazards.Where((h,i)=>JsonUtility.ToJson(h)!=JsonUtility.ToJson(saved.enemyHazards[i])).Any(),"Boss pattern changed across the real process restart.");return run;
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();string directory="";int stage=0;
            for(int n=0;n<args.Length-1;n++){if(args[n]=="-hellscriptScreenshots")directory=args[n+1];if(args[n]=="-hellscriptBossResume")stage=int.Parse(args[n+1]);}
            Require(args.Contains("-hellscriptSavePath")&&!string.IsNullOrEmpty(directory),"Boss smoke requires isolated save and output paths.");Directory.CreateDirectory(directory);Screen.SetResolution(540,960,FullScreenMode.Windowed);
            yield return new WaitForSecondsRealtime(1);var game=FindAnyObjectByType<GameController>();RunState run;EnemyState boss;
            if(stage==0)
            {
                run=Arena(game,0,1,3,true);boss=run.enemies[0];yield return new WaitForSecondsRealtime(.5f);run.paused=false;yield return Until(()=>boss.brain.action.phase==EnemyActionPhase.Preparing);run.paused=true;
                yield return Capture(game,directory,"01-slam-warning.png");run.paused=false;yield return Until(()=>boss.brain.action.phase==EnemyActionPhase.Preparing&&boss.brain.action.remainingCharges==1);run.paused=true;
                game.UI.ShowEnemyCombat();yield return Capture(game,directory,"02-slam-followup-checkpoint.png");Save(game,directory,"slam-checkpoint.json");Debug.Log("BOSS_SLAM_CHECKPOINT_READY");Application.Quit();yield break;
            }
            if(stage==1)
            {
                run=Resume(game,directory,"slam-checkpoint.json");boss=run.enemies[0];game.UI.ShowBattle();yield return Capture(game,directory,"03-restored-slam-warning.png");game.SetSpeed(1);run.paused=false;
                yield return Until(()=>boss.brain.action.phase==EnemyActionPhase.Idle);run.paused=true;Require(run.damageEvents.Count(d=>d.incoming&&d.definitionId=="BOSS01_SLAM")==2,"Restored slam did not hit exactly twice.");Save(game,directory,"slam-completed.json");
                run=Arena(game,0,2,6);yield return new WaitForSecondsRealtime(.5f);run.paused=false;yield return Until(()=>run.enemies[0].brain.action.phase==EnemyActionPhase.Preparing);run.paused=true;yield return Capture(game,directory,"04-hook-warning.png");
                run.paused=false;yield return Until(()=>run.projectiles.Any(p=>p.definitionId=="BOSS01_HOOK"&&Vector2.Distance(p.origin,p.position)>=2));run.paused=true;yield return Capture(game,directory,"05-hook-flight.png");run.paused=false;yield return Until(()=>run.effectEvents.Any(e=>e.kind=="PULLED"));run.paused=true;
                Require(Mathf.Abs(run.effectEvents.Single(e=>e.kind=="PULLED").value-2)<.001f,"Native hook did not pull two metres.");game.UI.ShowCombatEffects();yield return Capture(game,directory,"06-hook-hit.png");Save(game,directory,"hook-completed.json");
                run=Arena(game,1,1,6);boss=run.enemies[0];boss.brain.boss.cooldowns[2]=0;yield return new WaitForSecondsRealtime(.5f);run.paused=false;
                yield return Until(()=>run.enemies.Count(e=>e.add&&e.summonerId==boss.id)==4&&run.enemyHazards.Any(h=>h.definitionId=="BOSS02_BEAM"));run.paused=true;yield return Capture(game,directory,"07-choir-summons-beam.png");
                run.paused=false;yield return Until(()=>run.damageEvents.Count(d=>d.incoming&&d.definitionId=="BOSS02_BEAM")>=2);run.paused=true;Require(run.enemyHazards.Any(h=>h.definitionId=="BOSS02_BEAM"),"Beam expired before checkpoint.");
                game.UI.ShowEnemyCombat();yield return Capture(game,directory,"08-beam-checkpoint-status.png");Save(game,directory,"beam-checkpoint.json");Debug.Log("BOSS_BEAM_CHECKPOINT_READY");Application.Quit();yield break;
            }
            if(stage==2)
            {
                run=Resume(game,directory,"beam-checkpoint.json");game.UI.ShowBattle();yield return Capture(game,directory,"09-restored-beam.png");game.SetSpeed(1);run.paused=false;
                yield return Until(()=>!run.enemyHazards.Any(h=>h.definitionId=="BOSS02_BEAM"));run.paused=true;Require(run.damageEvents.Count(d=>d.incoming&&d.definitionId=="BOSS02_BEAM")==8,"Beam did not retain exactly eight damage pulses.");Save(game,directory,"beam-completed.json");
                run=Arena(game,2,1,6,true);boss=run.enemies[0];yield return new WaitForSecondsRealtime(.5f);run.paused=false;yield return Until(()=>boss.brain.action.phase==EnemyActionPhase.Preparing);run.paused=true;yield return Capture(game,directory,"10-predator-charge-warning.png");
                run.paused=false;yield return Until(()=>boss.brain.action.phase==EnemyActionPhase.Preparing&&boss.brain.action.remainingCharges==1);run.paused=true;Require(boss.windup>0&&boss.windup<=.8f,"Second charge lost its fresh warning.");yield return Capture(game,directory,"11-predator-second-warning.png");
                run.paused=false;yield return Until(()=>boss.brain.action.phase==EnemyActionPhase.Idle);run.paused=true;Require(run.damageEvents.Count(d=>d.incoming&&d.definitionId=="BOSS03_CHARGE")==2,"Predator charge did not hit once per pass.");Save(game,directory,"charge-completed.json");
                run=Arena(game,2,2,4);boss=run.enemies[0];yield return new WaitForSecondsRealtime(.5f);run.paused=false;yield return Until(()=>boss.brain.action.kind==(int)BossAttack.Blasts&&boss.brain.action.phase==EnemyActionPhase.Preparing);run.paused=true;
                Require(boss.brain.boss.refuges.Count==2&&boss.brain.action.points.Count==3,"Three blast circles/two refuges were not planned.");yield return Capture(game,directory,"12-blasts-safe-refuges.png");
                run.paused=false;yield return Until(()=>run.enemyHazards.Count(h=>h.definitionId=="BOSS03_BLAST")==2);run.paused=true;
                yield return Capture(game,directory,"13-blasts-checkpoint.png");Save(game,directory,"blasts-checkpoint.json");Debug.Log("BOSS_BLASTS_CHECKPOINT_READY");Application.Quit();yield break;
            }
            run=Resume(game,directory,"blasts-checkpoint.json");game.UI.ShowBattle();yield return Capture(game,directory,"14-restored-blasts.png");game.SetSpeed(1);run.paused=false;
            yield return Until(()=>!run.enemyHazards.Any(h=>h.definitionId=="BOSS03_BLAST")&&run.enemies[0].brain.action.phase==EnemyActionPhase.Idle);run.paused=true;
            Require(run.damageEvents.Count(d=>d.incoming&&d.definitionId=="BOSS03_BLAST")==1,"Fixed central blast was replayed or shifted onto the stationary hero.");Require(run.enemies[0].brain.boss.refuges.Count==0,"Expired refuge presentation was retained.");
            game.UI.ShowCombatEffects();yield return Capture(game,directory,"15-blasts-completed.png");Save(game,directory,"blasts-completed.json");
            File.WriteAllText(Path.Combine(directory,"runtime-bosses-smoke.txt"),"PASS: real process restart between empowered slam hits, during eight-pulse beam and after the first of three fixed blasts. Nondestructive saved-state equality checks. Real two-metre hook pull, owned four-add summon and second predator charge warning. Resumes at the 1x the current speed policy allows.\nFixtures: isolated save, level 30 warrior with eight legal rare pieces, stationary high-HP bosses with attack 5 and selected cooldowns enabled. Half HP initialized for empowered patterns. No physical input, Android, balance or performance claim.\nRenderer="+SystemInfo.graphicsDeviceType+"\nScreen="+Screen.width+"x"+Screen.height+"\n");
            Debug.Log("HELLSCRIPT_BOSS_RUNTIME_SMOKE_OK");Application.Quit();
        }
    }
}
