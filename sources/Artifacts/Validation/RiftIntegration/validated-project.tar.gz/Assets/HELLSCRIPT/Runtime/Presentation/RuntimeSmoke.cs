using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Explicit command-line-only smoke run. Never runs for a normal player launch.
    public sealed class RuntimeSmoke : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Install()
        {
            if(!Environment.GetCommandLineArgs().Contains("-hellscriptSmoke"))return;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Smoke Validation").AddComponent<RuntimeSmoke>();
        }
        IEnumerator Start()
        {
            var game=FindAnyObjectByType<GameController>();if(game==null)yield break;
            string[] args=Environment.GetCommandLineArgs();string dir=Application.persistentDataPath;
            for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptScreenshots")dir=args[i+1];Directory.CreateDirectory(dir);
            yield return new WaitForSecondsRealtime(2);
            ScreenCapture.CaptureScreenshot(Path.Combine(dir,"01-sanctuary.png"));
            yield return new WaitForSecondsRealtime(1);
            var build=FindObjectsByType<Button>().FirstOrDefault(b=>b.name=="자동 행동 설계");
            if(build==null)throw new InvalidOperationException("Town build button missing");build.onClick.Invoke();
            yield return new WaitForSecondsRealtime(.6f);ScreenCapture.CaptureScreenshot(Path.Combine(dir,"02-rules.png"));
            yield return new WaitForSecondsRealtime(.5f);
            game.CommitBuild(GameCatalog.Preset(HeroClass.Warrior,0));game.Begin(1);game.SetSpeed(1);
            yield return new WaitForSecondsRealtime(4);
            ScreenCapture.CaptureScreenshot(Path.Combine(dir,"03-combat.png"));
            float time=game.Combat.State.time;game.TogglePause();yield return new WaitForSecondsRealtime(.4f);
            if(Mathf.Abs(time-game.Combat.State.time)>.051f)throw new InvalidOperationException("Pause did not freeze time");
            game.SetSpeed(1);game.TogglePause();
            yield return new WaitForSecondsRealtime(2);
            game.EditBuild();yield return new WaitForSecondsRealtime(.2f);game.CommitBuild(game.Combat.State.build);
            game.ReturnTown();
            if(!args.Contains("-hellscriptSavePath"))throw new InvalidOperationException("The equipment smoke requires an explicit isolated save directory.");
            var account=game.Store.Data;account.gold=1000000;account.materials=10000;uint rng=99125;
            foreach(var old in account.Hero.inventory)if(old.slot>0)old.equipped=false;
            for(int slot=1;slot<=4;slot++){var piece=ItemGenerator.Create(HeroClass.Warrior,slot,3,1,ref rng,uniqueId:"SW"+slot);piece.equipped=true;account.Hero.inventory.Add(piece);}
            var comparison=ItemGenerator.Create(HeroClass.Warrior,4,3,1,ref rng,uniqueId:"SWB4");account.Hero.inventory.Add(comparison);
            var rare=ItemGenerator.Create(HeroClass.Warrior,0,2,1,ref rng);account.Hero.inventory.Add(rare);game.Save();
            game.UI.ShowBag();yield return new WaitForSecondsRealtime(.5f);ScreenCapture.CaptureScreenshot(Path.Combine(dir,"04-equipment.png"));yield return new WaitForSecondsRealtime(.2f);
            game.UI.ShowItemDetail(comparison.id);yield return new WaitForSecondsRealtime(.5f);ScreenCapture.CaptureScreenshot(Path.Combine(dir,"05-item-detail.png"));yield return new WaitForSecondsRealtime(.2f);
            ScrollTo("교체 후 전체 능력치");yield return new WaitForSecondsRealtime(.2f);ScreenCapture.CaptureScreenshot(Path.Combine(dir,"08-comparison.png"));yield return new WaitForSecondsRealtime(.2f);
            ScrollTo("회오리 감시자  ");yield return new WaitForSecondsRealtime(.2f);ScreenCapture.CaptureScreenshot(Path.Combine(dir,"09-set-comparison.png"));yield return new WaitForSecondsRealtime(.2f);
            var reroll=FindObjectsByType<Button>().First(b=>b.name.StartsWith("한 줄 재설정"));reroll.onClick.Invoke();
            yield return new WaitForSecondsRealtime(.3f);ScreenCapture.CaptureScreenshot(Path.Combine(dir,"06-reroll.png"));yield return new WaitForSecondsRealtime(.2f);
            var choice=FindObjectsByType<Button>().First(b=>b.interactable&&b.name.StartsWith("접미"));choice.onClick.Invoke();
            yield return new WaitForSecondsRealtime(.2f);
            var confirm=FindObjectsByType<Button>().First(b=>b.name=="확인");confirm.onClick.Invoke();
            yield return new WaitForSecondsRealtime(.3f);
            var updated=account.Hero.inventory.Find(i=>i.id==comparison.id);if(updated.rerolls!=1||string.IsNullOrEmpty(updated.rerollSlotId))throw new InvalidOperationException("Reroll selection did not commit.");
            ScreenCapture.CaptureScreenshot(Path.Combine(dir,"07-reroll-applied.png"));
            yield return new WaitForSecondsRealtime(.5f);game.ReturnTown();
            File.WriteAllText(Path.Combine(dir,"runtime-smoke.txt"),"PASS: scene boot, generated equipment art, UI button callback, rule page, training combat, 1.5x/2x speed, pause, condition edit, return, equipment comparison, suffix selection, confirmed reroll, local transaction save.\nScreen="+Screen.width+"x"+Screen.height+"\n");
            Debug.Log("HELLSCRIPT_RUNTIME_SMOKE_OK");
            if(args.Contains("-hellscriptSmokeQuit"))Application.Quit();
        }
        static void ScrollTo(string labelPrefix)
        {
            Canvas.ForceUpdateCanvases();var text=FindObjectsByType<Text>().First(t=>t.text.StartsWith(labelPrefix));
            var row=(RectTransform)text.transform.parent;var scroll=row.GetComponentInParent<ScrollRect>();
            float offset=-(row.localPosition.y+row.rect.yMax),maximum=Mathf.Max(0,scroll.content.rect.height-scroll.viewport.rect.height);
            scroll.content.anchoredPosition=new Vector2(0,Mathf.Clamp(offset,0,maximum));scroll.StopMovement();
        }
    }
}
