using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        // Fixed policy v1 look-ahead. The player's overlap window remains a separate option.
        public const float EdictSurvivalLookAhead=1.5f;
        public EdictSurvivalAssessment AssessEdictSurvival(HuntEdictV2Document source,EdictSurvivalState previous=null,Vector2? position=null)
        {
            var d=HuntEdictV2.Canonical(source);HuntEdictV2.ValidateReceiver(d,Hero,catalog);
            return AssessEdictSurvival(d,previous,position,d.global.ToDictionary(o=>o.id,o=>o.value,StringComparer.Ordinal));
        }
        EdictSurvivalAssessment AssessEdictSurvival(HuntEdictV2Document d,EdictSurvivalState previous,Vector2? position,Dictionary<string,string> values)
        {
            string G(string key)=>values[key];bool On(string key)=>G(key)=="ON";float N(string key)=>float.Parse(G(key),CultureInfo.InvariantCulture);
            float overlapWindow=N("dodge.window"),horizon=Mathf.Max(EdictSurvivalLookAhead+1,overlapWindow);
            var forecast=ForecastIncoming(horizon,position);var reasons=new List<EdictDodgeReason>();var limitations=new List<string>();
            var soon=forecast.sources.Where(s=>s.begins<=EdictSurvivalLookAhead+.00001f).ToArray();
            foreach(var hazard in soon)
            {
                string shape=hazard.category==IncomingCategory.Ground?"ground":hazard.category==IncomingCategory.Area?"area":hazard.category==IncomingCategory.Direct?"direct":"";
                if(shape=="")continue;string policy=G("dodge."+shape+".policy");float percent;
                if(hazard.category==IncomingCategory.Ground)
                    percent=100*forecast.hits.Where(h=>h.sourceKey==hazard.key&&h.after>=hazard.begins-.00001f&&h.after<=hazard.begins+1+.00001f).Sum(h=>h.hpLoss)/Stats.hp;
                else percent=100*forecast.hits.Where(h=>h.sourceKey==hazard.key&&h.after<=EdictSurvivalLookAhead+.00001f).Select(h=>h.hpLoss).DefaultIfEmpty(0).Max()/Stats.hp;
                if(policy=="ALWAYS")reasons.Add(new EdictDodgeReason(hazard.key,"ALWAYS","감지한 해당 공격에 항상 회피를 시도합니다.",percent));
                else if(policy=="DAMAGE"&&percent+.0001f>=N("dodge."+shape+".hpPercent"))
                    reasons.Add(new EdictDodgeReason(hazard.key,"DAMAGE",hazard.category==IncomingCategory.Ground?"1초 동안 예상되는 HP 손실이 회피 기준 이상입니다.":"한 번의 예상 HP 손실이 회피 기준 이상입니다.",percent));
                IncomingControl selected=IncomingControl.None;
                foreach(string value in G("dodge.control").Split(','))
                    if(value=="STUN")selected|=IncomingControl.Stun;else if(value=="FREEZE")selected|=IncomingControl.Freeze;else if(value=="ROOT")selected|=IncomingControl.Root;else if(value=="PULL")selected|=IncomingControl.Pull;
                if((hazard.control&selected)!=0)reasons.Add(new EdictDodgeReason(hazard.key,"CONTROL","선택한 행동 방해 효과의 예고를 감지했습니다."));
            }
            float total=forecast.HpLossThrough(overlapWindow);
            if(On("dodge.overlap")&&total/Stats.hp*100+.0001f>=N("dodge.totalHpPercent"))
                reasons.Add(new EdictDodgeReason("OVERLAP","OVERLAP","보호막을 한 번씩만 사용한 합산 HP 손실이 기준 이상입니다.",total/Stats.hp*100));
            bool alive=State.health>0,low=alive&&On("survival.lowHp")&&State.health/Stats.hp*100<=N("survival.lowHpPercent")+.0001f;
            bool lethal=alive&&On("survival.lethal")&&forecast.HpLossThrough(EdictSurvivalLookAhead)+.00001f>=State.health;
            bool ownedMemory=previous!=null&&previous.heroId==State.heroId&&previous.runId==State.id&&previous.active;
            bool held=alive&&ownedMemory&&(On("survival.lowHp")||On("survival.lethal"))&&State.health/Stats.hp*100<N("survival.returnHpPercent")-.0001f;
            bool emergency=low||lethal||held;
            bool potion=alive&&On("survival.potion")&&State.potionCd<=0&&State.health<Stats.hp&&State.health/Stats.hp*100<=N("survival.potionHpPercent")+.0001f;
            EdictSurvivalIntent Intent(string role,string skill)
            {
                if(role=="WALK"||role=="KEEP_FIGHTING")return new EdictSurvivalIntent(role,"",true,role=="WALK"?"유효한 보행 후퇴 경로를 검사합니다.":"전투를 유지하는 방침입니다.");
                if(skill=="")return new EdictSurvivalIntent(role,"",false,"지정한 스킬이 없습니다.");
                int index=catalog.skills.FindIndex(s=>s.id==skill);bool valid=index>=0&&d.slots.Contains(skill)&&catalog.skills[index].unlock<=EffectiveLevel&&HuntEdictV2.Automatic(d,skill);
                string reason=valid?"장착·해금·자동 사용을 확인했습니다. 실제 시전 자격은 실행 단계에서 검사합니다.":"미장착·미해금이거나 자동 사용이 꺼진 참조입니다.";
                if(valid&&skill=="W02"&&HuntEdictV2.Value(d,skill,2)=="ATTACK"){valid=false;reason="도약의 역할이 공격 진입 전용입니다.";}
                return new EdictSurvivalIntent(role,skill,valid,reason,index>=0?State.cooldowns[index]:0,index>=0?Cost(catalog.skills[index]):0);
            }
            var defense=Intent("DEFENSE",G("survival.defenseSkill"));
            var escape=Intent("ESCAPE",G("survival.escapeSkill"));
            var walk=Intent("WALK","");
            var order=G("survival.order").Split(',').Select(role=>role=="DEFENSE"?defense:role=="ESCAPE"?escape:walk).ToArray();
            string fallback=G("survival.fallback");var alternate=fallback=="OTHER_SKILL"?Intent("OTHER_SKILL",G("survival.fallbackSkill")):Intent(fallback,"");
            if(On("survival.dot"))limitations.Add("현재 영웅에게 부착되는 지속 피해의 실행 자료는 아직 없습니다. 바닥 장판을 부착 피해로 대신 계산하지 않습니다.");
            limitations.Add("이 자료만으로 행동을 시작하지 않습니다. 실행 시에는 목적지·잠금·비용과 실패 분기를 다시 검사합니다.");
            return new EdictSurvivalAssessment(State.heroId,State.id,emergency,low,lethal,held&&!low&&!lethal,potion,
                On("survival.reserveSkill")&&escape.referenceAvailable,On("survival.reserveResource")&&escape.referenceAvailable?escape.cost:0,G("dodge.method"),G("dodge.interrupt"),forecast,reasons,order,alternate,limitations);
        }
    }
}
