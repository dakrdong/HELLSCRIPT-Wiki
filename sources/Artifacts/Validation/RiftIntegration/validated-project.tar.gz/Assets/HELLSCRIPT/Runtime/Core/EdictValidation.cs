using System;
using System.Collections.Generic;
using System.Linq;

namespace Hellscript
{
    public static class EdictConditions
    {
        public static readonly string[] ExtensionIds={"SKILL_READY","SKILL_HIT_RECENT","BUFF_CHARGES","OWN_TRAP_POISON"};
        public static readonly string[] BuffIds={"SHIELD","W06","A06","W02_DEFENSE","A04_SPEED","MP06","SW_CHARGE","SWB_CHARGE","SAB_CHARGE","SMB_CHARGE","LC02_DISCOUNT","GUIDE_SHRINE","RESOLVE_SHRINE","AP05_READY"};
        public static string[] Choices(string id)
        {
            switch(id)
            {
                case "SC04":return BuffIds;
                case "SC07":return new[]{"ELITE_OR_BOSS","ELITE","BOSS"};
                case "SC11":return new[]{"MELEE","CHARGER","RANGED","AREA","SUPPORT","EXPLOSIVE"};
                case "SC12":return new[]{"NORMAL","ELITE","BOSS"};
                case "SC13":return new[]{"POISON","SLOW","STUN","FREEZE","MARK","SET_EXPOSURE","OWN_BLIZZARD","OWN_TRAP"};
                case "SC20":return new[]{"UNSPAWNED","FIGHTING","DEFEATED"};
                case "BUFF_CHARGES":return new[]{"A06","SW_CHARGE","SWB_CHARGE","SAB_CHARGE","SMB_CHARGE","LC02_DISCOUNT","AP05_READY"};
                default:return Array.Empty<string>();
            }
        }
        public static bool ReferencesSkill(string id)=>id=="SC15"||id=="SC22"||id=="SKILL_READY"||id=="SKILL_HIT_RECENT";
        public static EdictCondition FromRuntime(RuleCondition c)
        {
            string[] choices=Choices(c.id);
            if(c.choice<0||choices.Length==0&&c.choice!=0||choices.Length>0&&c.choice>=choices.Length)throw new ArgumentException("조건 선택값이 유효하지 않습니다.");
            return new EdictCondition{id=c.id,comparison=c.comparison.ToString(),value=c.value,upper=c.upper,radius=c.radius,window=c.window,predicted=c.predicted,
                choiceId=choices.Length==0?"":choices[c.choice],skillId=ReferencesSkill(c.id)?SkillId(c.skill):""};
        }
        static string SkillId(int index)
        {if(index<0||index>=18)throw new ArgumentException("참조 스킬 ID가 없습니다.");return new[]{"W","A","M"}[index/6]+(index%6+1).ToString("00");}
        public static RuleCondition ToRuntime(EdictCondition c)
        {
            if(BehaviorRules.Definition(c.id)==null)throw new NotSupportedException(Loc.F("실행 연결이 필요한 확장 조건입니다: {0}", c.id));
            var choices=Choices(c.id);int index=-1;
            if(ReferencesSkill(c.id))
            {
                for(int n=0;n<18;n++)if(SkillId(n)==c.skillId){index=n;break;}
                if(index<0)throw new ArgumentException("참조 스킬 ID가 유효하지 않습니다.");
            }
            return new RuleCondition{id=c.id,comparison=(Comparison)Enum.Parse(typeof(Comparison),c.comparison),choice=choices.Length==0?0:Array.IndexOf(choices,c.choiceId),skill=index,value=c.value,upper=c.upper,radius=c.radius,window=c.window,predicted=c.predicted};
        }
        public static void Validate(EdictCondition c,string heroClass,bool skillRule)
        {
            EdictValidation.Require(c!=null,"조건이 없습니다.");
            EdictValidation.Require(BehaviorRules.Definition(c.id)!=null||ExtensionIds.Contains(c.id),"알 수 없는 조건 ID입니다.");
            EdictValidation.EnumName<Comparison>(c.comparison,"조건 비교");
            EdictValidation.Finite(c.value,0,300,"조건 값");EdictValidation.Finite(c.upper,0,300,"조건 상한");EdictValidation.Finite(c.radius,0,100,"조건 반경");EdictValidation.Finite(c.window,0,20,"조건 시간");
            var choices=Choices(c.id);EdictValidation.Require(c.choiceId!=null&&(choices.Length==0?c.choiceId=="":choices.Contains(c.choiceId)),"조건의 콘텐츠 선택 ID가 잘못됐습니다.");
            EdictValidation.Require(c.skillId!=null&&(ReferencesSkill(c.id)?HuntEdict.SkillIds(heroClass).Contains(c.skillId):c.skillId==""),"참조 스킬은 같은 직업의 알려진 ID여야 합니다.");
            EdictValidation.Require(!c.predicted||c.id=="SC06"&&skillRule,"예상 명중은 스킬의 감지 조건에만 사용합니다.");
            if(BehaviorRules.Definition(c.id)!=null)
            {string error=BehaviorRules.ValidateCondition(ToRuntime(c));EdictValidation.Require(error=="",error);return;}
            if(c.id=="SKILL_READY"||c.id=="OWN_TRAP_POISON")EdictValidation.Require(c.comparison=="Present"||c.comparison=="Absent","있음 또는 없음으로 검사하세요.");
            else if(c.id=="SKILL_HIT_RECENT")
            {EdictValidation.Require(c.comparison=="Present"||c.comparison=="Absent","최근 적중의 유무를 선택하세요.");EdictValidation.Step(c.value,.5f,10,.5f,"최근 적중 시간");}
            else {EdictValidation.Require(c.comparison=="AtMost"||c.comparison=="AtLeast","남은 충전 수의 비교를 선택하세요.");EdictValidation.Step(c.value,0,20,1,"남은 충전 수");}
        }
    }
    public static class EdictValidation
    {
        internal static void Require(bool valid,string error){if(!valid)throw new ArgumentException(error);}
        internal static void Finite(float value,float min,float max,string label)=>Require(!float.IsNaN(value)&&!float.IsInfinity(value)&&value>=min&&value<=max,Loc.F("{0}: 범위를 확인하세요.", label));
        internal static void Step(float value,float min,float max,float step,string label)
        {Finite(value,min,max,label);Require(Math.Abs((value-min)/step-Math.Round((value-min)/step))<.001,Loc.F("{0}: 입력 단위를 확인하세요.", label));}
        internal static void EnumName<T>(string value,string label)=>Require(value!=null&&Enum.GetNames(typeof(T)).Contains(value),Loc.F("{0}: 알 수 없는 선택입니다.", label));
        public static HuntEdictDocument Canonical(HuntEdictDocument source)
        {
            Require(source!=null,"사냥 칙령이 없습니다.");
            Require(source.schema==HuntEdict.Version&&source.contentVersion==HuntEdict.ContentVersion,"현재 지원하는 사냥 칙령·콘텐츠 버전이 아닙니다.");
            Require(HuntEdict.ClassIndex(source.heroClass)>=0,"알 수 없는 직업입니다.");
            Require(source.slots!=null&&source.slots.Length==HuntEdict.ActiveSlots,"사용 스킬 칸은 빈칸을 포함해 네 칸이어야 합니다.");
            string[] skills=HuntEdict.SkillIds(source.heroClass),ids=HuntEdict.ActionIds(source.heroClass);
            Require(source.slots.All(s=>s!=null&&(s==""||skills.Contains(s)))&&source.slots.Where(s=>s!="").Distinct().Count()==source.slots.Count(s=>s!=""),"사용 스킬 칸의 ID·직업·중복을 확인하세요.");
            Require(source.actions!=null&&source.actions.Count==ids.Length&&source.actions.All(a=>a!=null&&ids.Contains(a.id))&&source.actions.Select(a=>a.id).Distinct().Count()==ids.Length,"모든 스킬과 기본 행동의 사용 상태를 한 번씩 보관해야 합니다.");
            Require(source.rules!=null&&source.rules.Count<=HuntEdict.MaxRules&&source.rules.All(r=>r!=null),"보관 규칙 수를 확인하세요.");
            Require(source.rules.Select(r=>r.Key).Distinct().Count()==source.rules.Count,"스킬별 규칙 번호가 중복되었습니다.");
            // Validate before copying so a caller cannot pass an unbounded object graph through JsonUtility.
            var global=EdictOptions.Canonical(EdictOptions.Global,source.global,source.heroClass);
            foreach(var r in source.rules)
            {
                Require(ids.Contains(r.actionId)&&r.slot>=1&&r.slot<=HuntEdict.RuleLimit(r.actionId),"규칙의 스킬 ID 또는 번호를 확인하세요.");
                if(r.target!="HighHealth")EnumName<RuleTarget>(r.target,"규칙 대상");
                EnumName<PositionPurpose>(r.positionPurpose,"이동 목적");EnumName<AreaAim>(r.areaAim,"설치 조준");EnumName<BlizzardMode>(r.blizzardMode,"눈보라 이동");EnumName<MovementMode>(r.movement,"이동 방식");
                Finite(r.distance,.5f,10,"규칙 거리");Require(BehaviorRules.Radii.Contains(r.targetRadius),"규칙의 목표 반경을 확인하세요.");
                Require(r.areaAim=="Target"||r.actionId=="A03"||r.actionId=="M02","설치 조준은 맹독 덫과 눈보라에만 사용합니다.");
                Require(r.groups!=null&&(r.always?r.groups.Count==0:r.groups.Count>=1&&r.groups.Count<=2),"항상 검사 또는 OR 묶음 1~2개를 선택하세요.");
                foreach(var group in r.groups)
                {Require(group!=null&&group.conditions!=null&&group.conditions.Count>=1&&group.conditions.Count<=3,"AND 조건은 1~3개입니다.");foreach(var c in group.conditions)EdictConditions.Validate(c,source.heroClass,skills.Contains(r.actionId));}
                EdictOptions.Canonical(EdictOptions.ForAction(r.actionId,source.heroClass),r.options,source.heroClass);
            }
            Require(source.rules.Count(r=>r.enabled&&source.actions.Single(a=>a.id==r.actionId).automatic&&(!skills.Contains(r.actionId)||source.slots.Contains(r.actionId)))<=24,"현재 구성의 활성 규칙은 최대 24개입니다.");
            string Value(string id)=>global.Single(o=>o.id==id).value;
            if(Value("survival.lowHp")=="ON")Require(decimal.Parse(Value("survival.returnHpPercent"),System.Globalization.CultureInfo.InvariantCulture)>decimal.Parse(Value("survival.lowHpPercent"),System.Globalization.CultureInfo.InvariantCulture),"전투 복귀 HP는 후퇴 시작 HP보다 높아야 합니다.");
            var result=source.Copy();result.global=global;result.actions=ids.Select(id=>result.actions.Single(a=>a.id==id)).ToList();
            foreach(var r in result.rules)
            {
                r.options=EdictOptions.Canonical(EdictOptions.ForAction(r.actionId,result.heroClass),r.options,result.heroClass);
                foreach(var c in r.groups.SelectMany(g=>g.conditions)){if(c.value==0)c.value=0;if(c.upper==0)c.upper=0;if(c.radius==0)c.radius=0;if(c.window==0)c.window=0;}
            }
            return result;
        }
    }
}
