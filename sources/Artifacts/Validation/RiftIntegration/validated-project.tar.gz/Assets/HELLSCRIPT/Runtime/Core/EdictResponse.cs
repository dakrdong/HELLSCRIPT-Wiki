using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    [Serializable]public sealed class EdictResponseState
    {
        public int version=1;
        public EdictSurvivalState memory;
        public bool walking;
        public Vector2 destination;
        public float expiresAt;
        public string reason;
        public static void Normalize(RunState run)
        {
            var s=run.edictResponse;if(s==null)return;
            if(s.version>1)throw new NotSupportedException("더 새로운 생존 행동 상태 버전이 필요합니다.");
            if(s.memory==null||s.memory.heroId!=run.heroId||s.memory.runId!=run.id){run.edictResponse=null;return;}
            if(s.walking&&(float.IsNaN(s.destination.x)||float.IsInfinity(s.destination.x)||float.IsNaN(s.destination.y)||float.IsInfinity(s.destination.y)||float.IsNaN(s.expiresAt)||float.IsInfinity(s.expiresAt)))
                throw new ArgumentException("생존 보행의 저장 위치 또는 시간이 유효하지 않습니다.");
            s.version=1;
        }
    }
    public sealed class EdictResponseCandidate
    {
        public readonly string role,skillId,code,detail;
        public readonly bool ready,timely;
        public readonly int skill,targetId;
        public readonly Vector2 destination;
        public readonly float cost,arrival;
        internal readonly Rule rule;
        internal EdictResponseCandidate(string role,string id,int skill,int target,Vector2 destination,float cost,string code,string detail,bool ready=false,bool timely=false,float arrival=0,Rule rule=null)
        {this.role=role;skillId=id;this.skill=skill;targetId=target;this.destination=destination;this.cost=cost;this.code=code;this.detail=detail;this.ready=ready;this.timely=timely;this.arrival=arrival;this.rule=rule?.Copy();}
    }
    public sealed class EdictResponsePlan
    {
        public readonly string blockedReason;
        public readonly EdictSurvivalAssessment assessment;
        public readonly IReadOnlyList<EdictResponseCandidate> attempts;
        public readonly EdictResponseCandidate selected;
        public bool ControlsMainAction=>selected!=null&&selected.role!="KEEP_FIGHTING";
        internal EdictResponsePlan(string blocked,EdictSurvivalAssessment assessment,IEnumerable<EdictResponseCandidate> attempts,EdictResponseCandidate selected)
        {blockedReason=blocked;this.assessment=assessment;this.attempts=Array.AsReadOnly(attempts.ToArray());this.selected=selected;}
    }
    public sealed class EdictResponseExecution
    {
        public readonly EdictResponsePlan plan;
        public readonly bool potionUsed,mainActionStarted,channelFinishRequested;
        internal EdictResponseExecution(EdictResponsePlan plan,bool potion,bool started,bool finish)
        {this.plan=plan;potionUsed=potion;mainActionStarted=started;channelFinishRequested=finish;}
    }
}
