using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimeFirstPlaySmoke : MonoBehaviour
    {
        string evidence;
        GameController game;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]static void Install()
        {
            if(!Environment.GetCommandLineArgs().Contains("-hellscriptFirstPlaySmoke"))return;
            Application.runInBackground=true;Application.logMessageReceived+=(m,s,t)=>{if(t==LogType.Exception)Application.Quit(1);};
            new GameObject("First play validation").AddComponent<RuntimeFirstPlaySmoke>();
        }
        static void Require(bool condition,string reason){if(!condition)throw new InvalidOperationException(reason);}
        void Click(string prefix)=>game.UI.GetComponentsInChildren<Button>().Single(b=>b.name.StartsWith(prefix,StringComparison.Ordinal)).onClick.Invoke();
        IEnumerator Until(Func<bool> ready,float timeout=30)
        {
            float deadline=Time.realtimeSinceStartup+timeout;while(!ready()&&Time.realtimeSinceStartup<deadline)yield return null;
            if(ready())yield break;
            File.WriteAllText(Path.Combine(evidence,"timeout-account.json"),JsonUtility.ToJson(game.Store.Data,true));
            if(game.Combat!=null)File.WriteAllText(Path.Combine(evidence,"timeout-run.json"),JsonUtility.ToJson(game.Combat.State,true));
            Require(false,"First play runtime condition timed out.");
        }
        // Opening an item clears its unread marker on purpose, so the gear comparison ignores that flag
        // and the marker is checked on its own.
        static string Gear(AccountSave account)=>string.Join("|",account.Hero.inventory.Select(i=>
        {var copy=JsonUtility.FromJson<Item>(JsonUtility.ToJson(i));copy.reviewed=false;return JsonUtility.ToJson(copy);}));
        static string FirstDifference(string before,string after)
        {
            string[] a=before.Split('|'),b=after.Split('|');
            for(int i=0;i<Mathf.Max(a.Length,b.Length);i++)
            {
                string x=i<a.Length?a[i]:"(missing)",y=i<b.Length?b[i]:"(missing)";
                if(x!=y)return $"entry {i} of {a.Length}->{b.Length}\nbefore={x}\nafter={y}";
            }
            return $"entry count {a.Length} -> {b.Length}";
        }
        void Step(int step)
        {
            game.UI.ShowOnboarding();var field=typeof(GameUI).GetField("guideStep",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Instance);
            for(int i=0;i<9&&(int)field.GetValue(game.UI)!=step;i++)Click("단계  ·");Require((int)field.GetValue(game.UI)==step,"Guide step navigation failed.");
        }
        IEnumerator Capture(string filename)
        {
            yield return new WaitForSecondsRealtime(.25f);Canvas.ForceUpdateCanvases();
            foreach(var b in game.UI.GetComponentsInChildren<Button>().Where(b=>b.transform.parent.name=="Footer"))
            {var corners=new Vector3[4];((RectTransform)b.transform).GetWorldCorners(corners);Require(corners.All(c=>c.x>=-1&&c.y>=-1&&c.x<=Screen.width+1&&c.y<=Screen.height+1),"First play footer clipped.");}
            foreach(var t in game.UI.GetComponentsInChildren<Text>().Where(t=>t.transform.parent.name=="Notice"))Require(t.preferredHeight<=t.rectTransform.rect.height+1,"First play hint clipped.");
            ScreenCapture.CaptureScreenshot(Path.Combine(evidence,filename));yield return new WaitForSecondsRealtime(.25f);
        }
        void Distance(float value)
        {
            var slider=game.UI.GetComponentsInChildren<Slider>().Single(s=>s.transform.parent.GetComponentsInChildren<Text>().Any(t=>t.text.StartsWith("목표 거리",StringComparison.Ordinal)));
            slider.value=value;
        }
        void ScrollTo(string prefix)
        {
            Canvas.ForceUpdateCanvases();var label=game.UI.GetComponentsInChildren<Text>().Single(t=>t.text.StartsWith(prefix,StringComparison.Ordinal));
            var row=(RectTransform)label.transform.parent;var scroll=row.GetComponentInParent<ScrollRect>();
            scroll.content.anchoredPosition=new Vector2(0,Mathf.Clamp(-(row.localPosition.y+row.rect.yMax),0,Mathf.Max(0,scroll.content.rect.height-scroll.viewport.rect.height)));scroll.StopMovement();
        }
        static string Progress(AccountSave a)=>JsonUtility.ToJson(a.guide)+"|"+string.Join("|",a.heroes.Select(h=>JsonUtility.ToJson(h.guide)));
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptScreenshots")evidence=args[i+1];
            Require(args.Contains("-hellscriptSavePath")&&!string.IsNullOrEmpty(evidence),"First play validation requires isolated paths.");Directory.CreateDirectory(evidence);Screen.SetResolution(540,960,FullScreenMode.Windowed);
            yield return new WaitForSecondsRealtime(1);game=FindAnyObjectByType<GameController>();
            if(args.Contains("-hellscriptFirstPlayResume"))
            {
                var expected=JsonUtility.FromJson<AccountSave>(File.ReadAllText(Path.Combine(evidence,"checkpoint-account.json")));var actual=game.Store.Data;
                Require(Progress(expected)==Progress(actual)&&JsonUtility.ToJson(expected.Hero)==JsonUtility.ToJson(actual.Hero),"Guide or hero changed after actual restart.");
                game.Begin(resume:true);var run=game.Combat.State;run.paused=true;var old=expected.suspendedRun;
                Require(run.id==old.id&&run.time==old.time&&run.rng==old.rng&&run.health==old.health&&run.resource==old.resource,"First play retry checkpoint changed.");
                Require(FirstPlayGuide.Complete(actual,actual.Hero)&&Progress(expected)==Progress(actual),"Resume replayed or lost guide progress.");
                game.UI.ShowOnboarding();yield return Capture("10-restored-guide-and-retry.png");
                File.WriteAllText(Path.Combine(evidence,"runtime-first-play-smoke.txt"),"PASS: fresh account, shared controls and independent hero guidance, hide/reopen with no rewards, no-candidate explanation, real generated Lv.1 rift with no injected HP/XP/gear, first-skill hint and selected-rule link, pause restoration, real result, repeat timer paused while reading guide, explicit repeat stop, owned-item comparison, slider preview/cancel/apply, matching 60-second owned training, new rift and real process restart.\nRenderer="+SystemInfo.graphicsDeviceType+"\nScreen="+Screen.width+"x"+Screen.height+"\nUI callbacks; no physical-input, human-comprehension, Android, or balance-completion claim.\n");
                Debug.Log("HELLSCRIPT_FIRST_PLAY_RUNTIME_SMOKE_OK");Application.Quit(0);yield break;
            }
            var account=game.Store.Data;Require(account.heroes.All(h=>h.level==1&&h.inventory.Count==1)&&account.gold==0,"First play smoke requires a fresh account.");
            game.UI.ShowOnboarding();yield return Capture("01-first-play-introduction.png");Click("안내 숨기기");Require(account.guide.hintsHidden&&FirstPlayGuide.Count(account,account.Hero)==0,"Hide falsely completed guidance.");
            game.UI.ShowOnboarding();Click("안내 다시 표시");game.UI.ShowOnboarding();Click("자동 전투 안내 확인");
            Step(5);string items=JsonUtility.ToJson(account.Hero.inventory[0]);yield return Capture("02-no-candidate-explanation.png");Click("장비 비교 설명 확인");Require(account.Hero.guide.equipmentExplanation&&account.Hero.inventory.Count==1&&JsonUtility.ToJson(account.Hero.inventory[0])==items&&account.gold==0,"Explanation awarded or changed gear.");Click("닫기");
            game.SelectHero(2);Require(FirstPlayGuide.Count(account,account.Hero)==1,"Other hero inherited private guide progress.");Step(1);yield return Capture("03-current-mage-builds.png");Click("현재 스킬과 성장 확인");Require(FirstPlayGuide.Done(account,account.Hero,GuideStep.Build),"Growth read was not recorded.");Click("성소로");
            float started=Time.realtimeSinceStartup;game.Begin(seed:91367);game.SetSpeed(1);var first=game.Combat.State;
            yield return Until(()=>account.Hero.guide.firstSkillHintShown,30);first.paused=true;game.UI.RefreshHud();yield return Capture("04-first-skill-hint.png");first.paused=false;
            game.UI.ShowRuleDecisions();Require(first.paused&&FirstPlayGuide.Done(account,account.Hero,GuideStep.Decision),"Actual decision read failed.");Click("선택된 행동의 규칙 보기");Click("취소");Require(!first.paused,"Decision-to-editor cancel did not restore prior pause.");
            game.UI.ShowBuild();Click("자동 반복 꺼짐");Click("설정 적용");Require(first.build.autoRepeat&&!FirstPlayGuide.Done(account,account.Hero,GuideStep.Edit),"Repeat toggle falsely counted as a combat edit.");
            yield return Until(()=>!game.Active&&game.UI.Page=="result",480);Require(FirstPlayGuide.Done(account,account.Hero,GuideStep.Result),"Genuine rift result was not read.");
            File.WriteAllText(Path.Combine(evidence,"first-rift-result.json"),JsonUtility.ToJson(first,true));Debug.Log($"HELLSCRIPT_FIRST_RIFT_RESULT phase={first.phase} time={first.time} kills={first.kills} level={account.Hero.level}");
            game.UI.ShowOnboarding();yield return new WaitForSecondsRealtime(6);Require(game.Combat.State==first&&!game.Active&&first.build.autoRepeat,"Repeat advanced while reading guidance.");Click("닫기");Click("자동 반복 중지");Require(!first.build.autoRepeat&&!account.Hero.build.autoRepeat,"Repeat stop did not save the actual setting.");yield return Capture("05-real-first-rift-result.png");
            Step(5);var candidate=FirstPlayGuide.ComparisonCandidate(account.Hero);Require(candidate!=null,"Seeded natural first rift produced no eligible comparison candidate; inspect actual loot.");string inventory=Gear(account);Click("소유 장비 상세와 비교");Require(!account.Hero.guide.equipmentExplanation&&FirstPlayGuide.Done(account,account.Hero,GuideStep.Equipment),"Owned comparison was not recorded.");yield return Capture("06-owned-item-comparison.png");
            ScrollTo("교체 후 전체 능력치");yield return Capture("06b-owned-item-stat-comparison.png");ScrollTo("자원 회복 / 초");yield return Capture("06c-owned-item-set-comparison.png");
            string afterComparison=Gear(account);
            Require(inventory==afterComparison,"Comparison changed owned gear: "+FirstDifference(inventory,afterComparison));
            Require(account.Hero.inventory.Single(i=>i.id==candidate.id).reviewed,"Opening the comparison left the item marked unread.");
            game.UI.ShowBuild();string before=JsonUtility.ToJson(account.Hero.build);Distance(5.5f);Require(game.UI.GetComponentsInChildren<Text>().Any(t=>t.text.Contains("7m → 거리 유지 5.5m")),"Live slider change preview missing.");yield return Capture("07-edit-before-apply.png");Click("취소");Require(JsonUtility.ToJson(account.Hero.build)==before&&!FirstPlayGuide.Done(account,account.Hero,GuideStep.Edit),"Cancel applied or counted a draft.");
            game.UI.ShowBuild();Distance(5.5f);Click("설정 적용");Require(account.Hero.build.distance==5.5f&&FirstPlayGuide.Done(account,account.Hero,GuideStep.Edit),"Explicit slider apply was not recorded.");
            Step(7);Click("고정 훈련장으로");Click("02  다수 적");yield return Until(()=>!game.Active&&game.UI.Page=="result",90);
            Require(FirstPlayGuide.Done(account,account.Hero,GuideStep.Training),"Matching owned training result was not recorded.");File.WriteAllText(Path.Combine(evidence,"matching-training.json"),JsonUtility.ToJson(game.Combat.State,true));yield return Capture("08-matching-training-result.png");
            Step(8);yield return Capture("09-retry-policy-summary.png");Click("현재 설정으로 새 균열");game.Combat.State.paused=true;Require(FirstPlayGuide.Complete(account,account.Hero),"Real retry did not complete nine guide steps.");game.Save();Require(string.IsNullOrEmpty(game.Store.Error),"Guide checkpoint save failed.");
            File.WriteAllText(Path.Combine(evidence,"checkpoint-account.json"),JsonUtility.ToJson(account,true));File.WriteAllText(Path.Combine(evidence,"first-play-duration.txt"),$"Automated callback flow elapsed {Time.realtimeSinceStartup-started:0.0}s; not a human first-15-minute observation.\n");
            Debug.Log("HELLSCRIPT_FIRST_PLAY_CHECKPOINT_READY");Application.Quit(0);
        }
    }
}
