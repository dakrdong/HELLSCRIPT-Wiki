using System;
using System.Collections;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Opt-in native development-player evidence; always requires an isolated account path.
    // What only a real player can show is that choosing a language redraws the page that is already
    // on screen, and that a separate process starts in the language the device stored.
    public sealed class RuntimeLanguageSmoke : MonoBehaviour
    {
        GameController game;
        string directory, saveDirectory;
        int captureIndex;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if (!Debug.isDebugBuild || !Environment.GetCommandLineArgs().Contains("-hellscriptLanguageSmoke")) return;
            Application.runInBackground = true;
            Application.logMessageReceived += (message, stack, type) => { if (type == LogType.Exception) Application.Quit(1); };
            new GameObject("Language validation").AddComponent<RuntimeLanguageSmoke>();
        }
        static void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
        static string Json(object value) => JsonUtility.ToJson(value);
        static string Account(AccountSave source) { var copy = JsonUtility.FromJson<AccountSave>(Json(source)); copy.lastSeenUtc = 0; return Json(copy); }
        RectTransform Modal => (RectTransform)game.UI.transform.Find("Screen and help modal");
        void Click(string name, Transform parent = null)
        { var button = (parent ?? game.UI.transform).GetComponentsInChildren<Button>().Single(b => b.name == name); Require(button.IsInteractable(), "Disabled: " + name); button.onClick.Invoke(); }
        void ClickFirst(string name)
        { var button = game.UI.GetComponentsInChildren<Button>().First(b => b.name == name); Require(button.IsInteractable(), "Disabled: " + name); button.onClick.Invoke(); }
        Button Row(int index) => game.UI.GetComponentsInChildren<Button>().FirstOrDefault(b => b.name.StartsWith(index.ToString("00") + "  ", StringComparison.Ordinal));
        string[] Lines() => game.UI.GetComponentsInChildren<Text>().Select(t => t.text).ToArray();
        // Each language is named in its own language and is never translated, so the language row is
        // the one place where source text on screen is correct.
        static bool Translatable(string text) => !LanguageOptions.All.Any(o => o.NativeName == text);
        static string[] Untranslated() => Loc.Missing.Where(Translatable).ToArray();
        // Reading every screen before reporting turns one run into the whole remaining list rather
        // than the first screen that still has Korean on it.
        readonly List<string> leftovers = new List<string>();
        void Sweep(string screen)
        {
            foreach (string line in Lines().Where(HasKorean).Where(Translatable)) leftovers.Add(screen + " still Korean: " + line);
            foreach (string key in Untranslated()) leftovers.Add(screen + " has no entry: " + key);
        }
        static bool HasKorean(string text) => text.Any(c => c >= 0xAC00 && c <= 0xD7A3);
        // The object name keeps the source text, so a button is found the same way in every language.
        void RequireNamesStayKorean()
        { Require(game.UI.GetComponentsInChildren<Button>().Any(b => b.name == "설정·안내"), "The settings button lost its source name."); }
        IEnumerator Capture(string label)
        {
            yield return new WaitForSecondsRealtime(.2f);
            // An English sentence is often longer than its Korean original, so every capture is also
            // a check that no label outgrew the box it was authored into.
            Canvas.ForceUpdateCanvases();
            foreach (var text in game.UI.GetComponentsInChildren<Text>())
                Require(text.preferredHeight <= text.rectTransform.rect.height + 1,
                    $"Text clipped on {label}: needs {text.preferredHeight:0} in a box of {text.rectTransform.rect.height:0} at width {text.rectTransform.rect.width:0}: {text.text}");
            ScreenCapture.CaptureScreenshot(Path.Combine(directory, $"{++captureIndex:00}-{label}.png"));
            yield return new WaitForSecondsRealtime(.2f);
        }
        IEnumerator Start()
        {
            var args = Environment.GetCommandLineArgs();
            for (int i = 0; i < args.Length - 1; i++) { if (args[i] == "-hellscriptSavePath") saveDirectory = args[i + 1]; if (args[i] == "-hellscriptScreenshots") directory = args[i + 1]; }
            Require(!string.IsNullOrEmpty(saveDirectory) && !string.IsNullOrEmpty(directory), "Use isolated save and evidence paths."); Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1); game = FindAnyObjectByType<GameController>(); Require(game.Store != null, "Account failed to load.");
            string preference = Path.Combine(saveDirectory, "hellscript-language-v1.json");

            if (args.Contains("-hellscriptLanguageResume"))
            {
                Require(Account(game.Store.Data) == File.ReadAllText(Path.Combine(directory, "expected-account.json")), "A restart changed persisted gameplay.");
                Require(game.Language.Language == "en" && game.Language.Saved == "en", "A restart lost the saved language.");
                Require(string.IsNullOrEmpty(game.LanguageLoadNotice), "The saved language was reported as unreadable: " + game.LanguageLoadNotice);
                Require(game.Language.Entries > 2000, "A restart did not load the English table: " + game.Language.Entries);
                Require(Lines().Contains("Design the behavior, rule the rift"), "A restart drew the town in the wrong language.");
                Require(!Lines().Any(HasKorean), "A restart left Korean on the town screen.");
                RequireNamesStayKorean();
                ScreenCapture.CaptureScreenshot(Path.Combine(directory, "00-restart-town-in-english.png")); yield return new WaitForSecondsRealtime(.4f);
                File.WriteAllText(Path.Combine(directory, "runtime-language-resume.txt"), "PASS: a separate native process restored the account and the saved English language, drew the town with no Korean left on it, and kept every control findable by its source name.\n");
                Debug.Log("HELLSCRIPT_LANGUAGE_RESUME_OK"); Application.Quit(0); yield break;
            }

            Require(!File.Exists(preference), "A default language wrote a preference file.");
            Require(game.Language.Language == "ko" && Loc.IsSource, "The default language is not the source language.");
            string accountBefore = Account(game.Store.Data);
            var display = Path.Combine(saveDirectory, "hellscript-display-v1.json");
            var scale = Path.Combine(saveDirectory, "hellscript-interface-scale-v1.json");
            string displayBefore = File.Exists(display) ? File.ReadAllText(display) : "", scaleBefore = File.Exists(scale) ? File.ReadAllText(scale) : "";

            string[] korean = Lines();
            Require(korean.Contains("행동을 설계하고, 균열을 지배하라"), "The town was not drawn in Korean to begin with.");
            yield return Capture("town-korean");

            Click("설정·안내"); yield return Capture("settings-korean");
            Require(Modal.GetComponentsInChildren<Button>().Any(b => b.name == "한국어") && Modal.GetComponentsInChildren<Button>().Any(b => b.name == "English"),
                "The settings screen is missing a language choice.");
            foreach (var option in LanguageOptions.All)
                Require(Modal.GetComponentsInChildren<Text>().Any(t => t.text == option.NativeName), "A language is not labelled in its own language: " + option.Code);

            Click("English", Modal); yield return new WaitForSecondsRealtime(.4f);
            Require(Account(game.Store.Data) == accountBefore, "Choosing a language changed the account.");
            Require(game.Language.Language == "en" && game.Language.Saved == "en" && !game.Language.CanRetrySave, "English was applied without being saved.");
            Require(game.Language.Entries > 2000, "The English table did not load: " + game.Language.Entries);
            Sweep("settings");
            yield return Capture("settings-english");
            Require(game.UI.CommonPanelOpen, "Choosing a language closed the settings window.");
            Require(Modal.GetComponentsInChildren<Text>().Any(t => t.text == "Language"), "The settings window was not redrawn in English.");
            var languageRow = (RectTransform)Modal.GetComponentsInChildren<Button>().Single(b => b.name == "English").transform.parent;
            var pane = languageRow.GetComponentInParent<ScrollRect>();
            var bounds = RectTransformUtility.CalculateRelativeRectTransformBounds(pane.viewport, languageRow);
            Require(bounds.min.y >= pane.viewport.rect.yMin - 1 && bounds.max.y <= pane.viewport.rect.yMax + 1, "The language choices left the view after being pressed.");
            RequireNamesStayKorean();

            Click("닫기", Modal); yield return new WaitForSecondsRealtime(.3f);
            string[] english = Lines();
            Require(english.Contains("Design the behavior, rule the rift"), "The page behind the settings window stayed in Korean.");
            Sweep("town");
            Require(english.Length == korean.Length, $"The redraw changed how many labels the town has: {korean.Length} -> {english.Length}.");
            yield return Capture("town-english");

            // Every screen the town can reach has to survive the same reading, including the ones
            // that compose their lines from catalogue names.
            game.UI.ShowBuild(); yield return Capture("build-english");
            Sweep("behavior");

            // The rule editor packs widgets into fixed bands, so it is the screen most likely to clip
            // a longer English label. Rows are expanded until one shows its condition groups, which is
            // also the way to reach the two pickers.
            bool conditions = false;
            for (int row = 1; row <= 8 && !conditions; row++)
            {
                var header = Row(row); if (header == null) break;
                header.onClick.Invoke(); yield return null;
                if (row == 1) { yield return Capture("rule-editor-english"); Sweep("rule editor"); }
                conditions = game.UI.GetComponentsInChildren<Button>().Any(b => b.name == "+ AND 조건 추가");
            }
            Require(conditions, "No rule row exposed its condition groups.");
            yield return Capture("rule-conditions-english"); Sweep("rule conditions");
            ClickFirst("+ AND 조건 추가"); yield return Capture("condition-picker-english"); Sweep("condition picker");
            Click("취소"); yield return null;
            ClickFirst("+ 행동 규칙 추가"); yield return Capture("rule-picker-english"); Sweep("rule picker");
            Click("편집으로 돌아가기"); yield return null;

            game.UI.CancelBuild(); game.UI.ShowGrowth(); yield return Capture("growth-english");
            Sweep("growth");
            game.UI.ShowTown(); game.UI.ShowBag(); yield return Capture("bag-english");
            Sweep("gear");
            game.UI.ShowTown(); game.UI.ShowRiftKeeper(); yield return Capture("keeper-english");
            Sweep("rift keeper");

            // The hunt edict editor is the other screen with fixed bands, and each of its three tabs
            // draws a different set of option labels.
            game.UI.ShowTown(); game.UI.ShowEdictEditor();
            Require(game.UI.Page == "edict", "The hunt edict editor did not open.");
            yield return Capture("edict-global-english"); Sweep("edict global");
            Click("사용 스킬·순서"); yield return Capture("edict-slots-english"); Sweep("edict slots");
            Click("스킬 설정"); yield return Capture("edict-skills-english"); Sweep("edict skills");
            game.UI.ShowTown();

            // A rift in English: the combat HUD and the decision log compose their lines while it runs.
            game.Begin(1, seed: 445533); yield return new WaitForSecondsRealtime(1.2f);
            game.TogglePause(); yield return Capture("battle-english");
            Sweep("battle");
            game.UI.ShowRuleDecisions(); yield return Capture("decisions-english");
            Sweep("decision log");
            game.UI.ShowBattle(); game.ReturnTown(); yield return new WaitForSecondsRealtime(.3f);

            // Back to Korean, then to English again, so the last state on disk is the one a restart reads.
            // The rift above wrote to the account, as it should, so the isolation check restarts here.
            accountBefore = Account(game.Store.Data);
            Click("설정·안내"); Click("한국어", Modal); yield return new WaitForSecondsRealtime(.4f);
            Require(Modal.GetComponentsInChildren<Text>().Any(t => t.text == "언어"), "The settings window did not return to Korean.");
            Click("닫기", Modal); yield return new WaitForSecondsRealtime(.3f);
            Require(Lines().Contains("행동을 설계하고, 균열을 지배하라"), "Returning to Korean did not redraw the town.");
            yield return Capture("town-korean-again");
            Click("설정·안내"); Click("English", Modal); yield return new WaitForSecondsRealtime(.3f); Click("닫기", Modal);
            yield return new WaitForSecondsRealtime(.3f);

            Require(leftovers.Count == 0, leftovers.Count + " lines are not translated:\n" + string.Join("\n", leftovers.Distinct().Take(25)));
            Require(File.Exists(preference) && File.ReadAllText(preference).Contains("\"en\""), "The language was not stored in its own device file.");
            Require(Account(game.Store.Data) == accountBefore, "Choosing a language changed the account.");
            Require((File.Exists(display) ? File.ReadAllText(display) : "") == displayBefore, "Choosing a language touched the screen direction file.");
            Require((File.Exists(scale) ? File.ReadAllText(scale) : "") == scaleBefore, "Choosing a language touched the reading size file.");
            File.WriteAllText(Path.Combine(directory, "expected-account.json"), Account(game.Store.Data));
            File.WriteAllText(Path.Combine(directory, "runtime-language-smoke.txt"),
                "PASS: the default is the source language and writes no file; the settings window lists each language under its own name; choosing English redraws the open window and the page behind it with no Korean left on the town, behavior, rule editor, rule conditions, condition picker, rule picker, growth, gear, rift keeper, hunt edict editor on all three tabs, battle and decision log screens, no line missing an entry and no label taller than its box on any of them; the pressed choice stays in view; control names stay in the source language; returning to Korean redraws again; the choice is stored in its own device file and leaves the account, the screen direction and the reading size untouched. UI callbacks and Metal rendering; no physical touch or keyboard.\n");
            Debug.Log("HELLSCRIPT_LANGUAGE_RUNTIME_SMOKE_OK"); Application.Quit(0);
        }
    }
}
