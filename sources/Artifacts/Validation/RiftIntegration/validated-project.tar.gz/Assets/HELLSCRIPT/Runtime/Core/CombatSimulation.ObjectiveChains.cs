using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        bool OfferingBusy=>State.layout.altar?.phase==OfferingAltarPhase.Offering;
        void ResolveCarriers()
        {
            if(!ObjectiveActive||State.layout.gateOpen||State.layout.objective!=RiftObjectiveKind.EssenceCarriers)return;
            // A field commit replaces nested state. Resolve IDs afresh after every transaction.
            var ids=State.layout.carriers.Where(c=>!c.completed&&State.enemies.Any(e=>e.id==c.enemyId&&e.dead&&!e.pendingDeath)).Select(c=>c.id).ToArray();
            foreach(string id in ids)
            {
                bool closed=!State.layout.gateOpen;
                if(!FieldCommit(State.id+":"+id+":complete","carrier-complete:"+State.id+":"+id,run=>
                {
                    var point=run.layout.carriers.Single(c=>c.id==id);
                    if(!run.enemies.Any(e=>e.id==point.enemyId&&e.dead&&!e.pendingDeath))return false;
                    point.completed=true;
                    if(run.layout.carriers.All(c=>c.completed))RiftObjectives.Open(run,false);
                    return true;
                }))return;
                State.action=Loc.F("정수 운반자 {0} / {1}",RiftObjectives.Completed(State.layout),RiftObjectives.Total(State.layout));
                Log("CARRIER_COMPLETE",State.action);
                if(closed&&State.layout.gateOpen)AnnounceGate();
            }
        }
        void UpdateOfferingAvailability()
        {
            if(State.layout.objective!=RiftObjectiveKind.Offerings||State.layout.gateOpen)return;
            foreach(var point in State.layout.offerings)
                if(!point.available&&!State.enemies.Any(e=>!e.dead&&e.group==point.guardGroup))point.available=true;
        }
        bool ChooseObjectiveGoal(ref Vector2 goal)
        {
            if(!ObjectiveActive||State.layout.gateOpen)return false;
            if(State.layout.objective==RiftObjectiveKind.Seals)return ChooseSealGoal(ref goal);
            if(State.layout.objective==RiftObjectiveKind.EssenceCarriers)
            {
                var point=State.layout.carriers.Where(c=>!c.completed&&(c.discovered||State.visited.Contains(c.room))&&Vector2.Distance(State.position,c.position)>2&&
                    !State.exploration.enemies.Any(o=>o.id==c.enemyId&&o.investigated)).OrderBy(c=>Map.Length(State.position,c.position)).FirstOrDefault();
                if(point==null||float.IsInfinity(Map.Length(State.position,point.position)))return false;
                goal=point.position;State.action="정수 운반자의 마지막 관측 위치로 이동";return true;
            }
            var pickup=State.layout.offerings.Where(o=>o.discovered&&o.available&&!o.collected).OrderBy(o=>Map.Length(State.position,o.position)).FirstOrDefault();
            if(pickup!=null)
            {goal=pickup.position;State.action="제물 회수 지점으로 이동";return true;}
            var altar=State.layout.altar;
            if(altar==null||!altar.discovered||!State.layout.offerings.All(o=>o.collected)||altar.phase==OfferingAltarPhase.Offered||altar.retryAfter>State.time)return false;
            if(OfferingBusy)return true;
            var access=altar.accessPoints.Where(OpeningPointFree).OrderBy(p=>Map.Length(State.position,p)).ToList();
            if(access.Count==0||float.IsInfinity(Map.Length(State.position,access[0])))return false;
            altar.access=access[0];altar.phase=OfferingAltarPhase.Approaching;goal=altar.access;State.action="제물을 바칠 제단으로 이동";return true;
        }
        void AdvanceOffering(float dt)
        {
            var altar=State.layout.altar;
            if(!State.layout.gateOpen&&OfferingBusy&&FieldSafe(altar.access)&&Vector2.Distance(State.position,altar.position)<=1.8f)
                altar.progress=Mathf.Min(RiftOfferingAltar.Duration,altar.progress+dt);
        }
        void TickOfferings()
        {
            if(!ObjectiveActive||State.layout.gateOpen||State.layout.objective!=RiftObjectiveKind.Offerings)return;
            UpdateOfferingAvailability();
            var ids=State.layout.offerings.Where(o=>o.discovered&&o.available&&!o.collected&&Vector2.Distance(State.position,o.position)<=.75f).Select(o=>o.id).ToArray();
            foreach(string id in ids)
            {
                var point=State.layout.offerings.Single(o=>o.id==id);if(!FieldSafe(point.position))continue;
                Vector2 position=point.position;
                if(!FieldCommit(State.id+":"+id+":pickup","offering-pickup:"+State.id+":"+id,run=>
                {
                    var item=run.layout.offerings.Single(o=>o.id==id);
                    if(!item.available||!item.discovered||Vector2.Distance(run.position,item.position)>.75f||run.enemies.Any(e=>!e.dead&&e.group==item.guardGroup))return false;
                    item.collected=true;return true;
                }))return;
                State.action=Loc.F("제물 회수 {0} / {1}",RiftObjectives.Completed(State.layout),RiftObjectives.Total(State.layout));
                Log("OFFERING_COLLECTED",State.action);Visual?.Invoke(position,position,20,1);
            }
            var altar=State.layout.altar;
            if(altar==null||altar.phase==OfferingAltarPhase.Available||altar.phase==OfferingAltarPhase.Offered)return;
            if(!FieldSafe(altar.access)){CancelOffering("전투를 우선합니다");return;}
            if(altar.phase==OfferingAltarPhase.Approaching)
            {
                if(Vector2.Distance(State.position,altar.access)>.25f)return;
                if(!State.layout.offerings.All(o=>o.collected)){CancelOffering("");return;}
                altar.phase=OfferingAltarPhase.Offering;State.activeSkill=-1;Log("OFFERING_START","제물을 바치기 시작합니다");
            }
            if(Vector2.Distance(State.position,altar.position)>1.8f){CancelOffering("제단에서 멀어졌습니다");return;}
            State.action=Loc.F("제물 바치기 {0:0.0} / {1:0.0}초",altar.progress,RiftOfferingAltar.Duration);
            if(altar.progress+.0001f<RiftOfferingAltar.Duration)return;
            string altarId=altar.id;Vector2 altarPosition=altar.position;
            if(!FieldCommit(State.id+":"+altarId+":deliver","offering-deliver:"+State.id+":"+altarId,run=>
            {
                var a=run.layout.altar;
                if(a.phase!=OfferingAltarPhase.Offering||a.progress+.0001f<RiftOfferingAltar.Duration||Vector2.Distance(run.position,a.position)>1.8f||!run.layout.offerings.All(o=>o.collected))return false;
                a.phase=OfferingAltarPhase.Offered;a.progress=RiftOfferingAltar.Duration;RiftObjectives.Open(run,false);return true;
            }))return;
            Log("OFFERING_DELIVERED","제물 전달 완료");Visual?.Invoke(altarPosition,altarPosition,20,2);AnnounceGate();
        }
        void CancelOffering(string reason)
        {
            var altar=State.layout.altar;
            if(altar==null||altar.phase==OfferingAltarPhase.Available||altar.phase==OfferingAltarPhase.Offered)return;
            altar.phase=OfferingAltarPhase.Available;altar.retryAfter=State.time+2;
            if(!string.IsNullOrEmpty(reason))Log("OFFERING_INTERRUPTED",reason);
        }
    }
}
