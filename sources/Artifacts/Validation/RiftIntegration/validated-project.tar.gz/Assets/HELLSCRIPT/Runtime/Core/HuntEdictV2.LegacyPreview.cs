using System;
using System.Collections.Generic;
using System.Linq;

namespace Hellscript
{
    public sealed class EdictSimplificationChange
    {
        public readonly string source,target,detail;
        public readonly bool copiedValue;
        internal EdictSimplificationChange(string source,string target,string detail,bool copied=false)
        {this.source=source;this.target=target;this.detail=detail;copiedValue=copied;}
    }
    public sealed class EdictV2LegacyPreview
    {
        readonly HuntEdictV2Document proposal;
        public readonly string OriginalCode;
        public readonly IReadOnlyList<EdictSimplificationChange> Changes;
        public readonly IReadOnlyList<EdictMissingSkill> MissingSkills;
        public HuntEdictDocument Original=>HuntEdictCodec.Decode(OriginalCode);
        public HuntEdictV2Document Proposal=>proposal.Copy();
        // UI calls this only for the explicit "간소화하여 불러오기" action. No store or combat writes.
        public HuntEdictV2Document AcceptAsDraft()=>proposal.Copy();
        internal EdictV2LegacyPreview(string code,HuntEdictV2Document proposal,List<EdictSimplificationChange> changes,IReadOnlyList<EdictMissingSkill> missing)
        {OriginalCode=code;this.proposal=proposal.Copy();Changes=changes.AsReadOnly();MissingSkills=missing;}
    }
    public static class HuntEdictV2LegacyPreview
    {
        public static EdictV2LegacyPreview Prepare(string code,HeroSave hero,GameCatalog catalog)
        {
            var old=HuntEdictCodec.Decode(code);var proposal=HuntEdictV2.Create((HeroClass)HuntEdict.ClassIndex(old.heroClass));
            HuntEdictV2.ValidateReceiver(proposal,hero,catalog);
            var changes=new List<EdictSimplificationChange>();var mapped=new HashSet<string>();
            proposal.global=EdictOptions.Canonical(EdictOptions.Global,old.global,old.heroClass);proposal.slots=old.slots.ToArray();
            changes.Add(new EdictSimplificationChange("전역·사용 스킬 칸","전역·사용 스킬 칸","전역 값과 빈칸을 포함한 배치를 복사합니다. 새 선택의 실행 방식까지 같다는 뜻은 아닙니다.",true));
            var ids=HuntEdictV2.SkillIds(old.heroClass);
            proposal.skillOrder=old.rules.Where(r=>ids.Contains(r.actionId)).Select(r=>r.actionId).Distinct().Concat(ids).Distinct().ToArray();
            changes.Add(new EdictSimplificationChange("전체 규칙 순서","공통 공격 순서","각 공격이 처음 등장한 순서를 사용합니다. 같은 스킬의 여러 규칙은 하나로 합치며 다른 행동 분류와의 순서는 전역 설정을 사용합니다."));
            void Set(string skill,int option,string value,string source,string detail,bool copied)
            {
                var definition=HuntEdictV2Options.ForSkill(skill,old.heroClass)[option-1];
                proposal.skills.Single(s=>s.id==skill).options[option-1].value=definition.CanonicalValue(value);mapped.Add(definition.id);
                changes.Add(new EdictSimplificationChange(source,definition.id,detail,copied));
            }
            foreach(string skill in ids)
            {
                var rules=old.rules.Where(r=>r.actionId==skill).ToArray();bool enabled=old.actions.Single(a=>a.id==skill).automatic&&rules.Any(r=>r.enabled);
                Set(skill,1,enabled?"ON":"OFF",Loc.F("{0} 자동 사용·규칙 상태", skill),enabled?"기존에 사용 중인 규칙이 있어 자동 사용을 켭니다. 개별 조건은 아래 변경 내역을 확인하세요.":"기존 자동 사용이 꺼져 있거나 켜진 규칙이 없어 자동 사용을 끕니다.",false);
                if(rules.Length==1&&(skill=="A03"||skill=="M02"))
                {
                    var rule=rules[0];string aim=rule.areaAim=="Dense"?"DENSE":rule.areaAim=="Self"?"SELF":rule.areaAim=="ObservedPath"?"PATH":"TARGET";
                    Set(skill,skill=="A03"?2:3,aim,rule.Key+" areaAim","설치 위치 선택값을 복사합니다. 새 설치 상황과 중복 영역 판단은 별도로 제안합니다.",true);
                    if(skill=="M02")Set(skill,5,rule.blizzardMode=="Follow"?"FOLLOW":"FIXED",rule.Key+" blizzardMode","새로 생성할 눈보라의 추적·고정 선택값을 복사합니다.",true);
                    string preserve=rule.options.Single(o=>o.id=="area.preserve").value;
                    if(preserve=="REPLACE"||preserve=="WAIT_AT_CAP")Set(skill,4,preserve=="REPLACE"?"REPLACE":"KEEP",rule.Key+" area.preserve","두 영역이 남았을 때의 보존·교체 선택값을 복사합니다.",true);
                }
                foreach(var definition in HuntEdictV2Options.ForSkill(skill,old.heroClass).Where(d=>!mapped.Contains(d.id)))
                    changes.Add(new EdictSimplificationChange(Loc.F("{0} 기존 설정", skill),definition.id,Loc.F("정확한 대응을 확인하지 않은 항목입니다. 새 기본값 ‘{0}’을 제안합니다.", definition.Describe(definition.initial))));
            }
            foreach(var rule in old.rules)
                changes.Add(new EdictSimplificationChange(rule.Key,"기존 규칙 제외","기존 규칙의 조건식·대상·이동·세부 옵션은 새 실행 원본에 넣지 않습니다. 위에서 명시한 선택값 복사만 사용하며 HED1 원본 전체를 보존합니다."));
            foreach(string utility in new[]{"LOOT","CHEST","EXPLORE"})
                changes.Add(new EdictSimplificationChange(Loc.F("{0} 자동 사용", utility),"전역 해당 분류","별도의 행동 토글·규칙 대신 복사한 전역 방침을 사용합니다. 기존 사용 상태와 새 회수·상호작용 방침의 차이를 확인하세요."));
            var preview=HuntEdictV2Import.Prepare(HuntEdictV2Codec.Encode(proposal),hero,catalog);
            return new EdictV2LegacyPreview(code.Trim(),preview.Draft,changes,preview.MissingSkills);
        }
    }
}
