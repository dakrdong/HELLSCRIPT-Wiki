using UnityEngine;

namespace Hellscript
{
    public sealed partial class GameUI
    {
        public static string ObjectiveName(RiftObjectiveKind kind)=>Loc.T(kind==RiftObjectiveKind.Seals?"봉인 해제":kind==RiftObjectiveKind.EssenceCarriers?"정수 운반자 처치":"제물 운반");
        public static string ObjectiveProgress(RiftLayout map)
        {
            string pattern=map.objective==RiftObjectiveKind.Seals?"봉인 {0} / {1}":map.objective==RiftObjectiveKind.EssenceCarriers?"정수 운반자 {0} / {1}":"제물 회수 {0} / {1}";
            string progress=Loc.F(pattern,RiftObjectives.Completed(map),RiftObjectives.Total(map));
            if(map.objective==RiftObjectiveKind.Offerings)progress+=" · "+Loc.T(map.altar?.phase==OfferingAltarPhase.Offered?"전달 완료":RiftObjectives.Completed(map)==RiftObjectives.Total(map)?"제단에 전달":"회수 중");
            return progress;
        }
        public static string ObjectiveSummary(RiftObjectiveRecord record)
        {
            if(record?.version!=1||record.kind==RiftObjectiveKind.None)return "";
            string method=Loc.T(!record.gateOpen?"열리지 않음":record.byMeter?"처치 게이지":"목표 완료");
            string time=record.timeKnown?Loc.F(record.gateOpen?"관문이 열린 시점 · 전투 {0:0.0}초":"종료 시점 · 전투 {0:0.0}초",record.seconds):Loc.T("이전 저장 · 시점 기록 없음");
            string delivery=record.kind==RiftObjectiveKind.Offerings?" · "+Loc.T(record.delivered?"전달 완료":"미전달"):"";
            return Loc.F("균열 목표 · {0}\n진행 {1} / {2}{3}\n관문 개방 · {4}\n{5}",ObjectiveName(record.kind),record.completed,record.total,delivery,method,time);
        }
        void ObjectiveResult(RiftObjectiveRecord record)
        {string text=ObjectiveSummary(record);if(text!="")Note(content,text,21,190,gold);}
    }
}
