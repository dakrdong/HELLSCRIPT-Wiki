using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public enum TownStation { Blacksmith, Reroller, Merchant, RiftKeeper, Warehouse }

    public sealed class TownStationDefinition
    {
        public readonly TownStation id;
        public readonly string name,service;
        public readonly Vector2 position;
        internal TownStationDefinition(TownStation id,string name,string service,Vector2 position)
        {this.id=id;this.name=name;this.service=service;this.position=position;}
    }

    // The plaza is one open rectangle: no walls, so walking never fails and never gates a service.
    public static class TownLayout
    {
        public const float Speed=5.5f,ArriveRadius=1.4f,HalfWidth=20,HalfHeight=12;
        public static readonly Vector2 Spawn=new Vector2(0,-7);
        public static readonly TownStationDefinition[] Stations=
        {
            new TownStationDefinition(TownStation.Blacksmith,"대장장이","강화 · 일반 제작 · 분해",new Vector2(-14,6)),
            new TownStationDefinition(TownStation.Reroller,"재설정 담당","접사 재설정 · 보석은 검증 전",new Vector2(-5,9)),
            new TownStationDefinition(TownStation.Merchant,"수수께끼 상인","미확인 장비 구매 · 제작",new Vector2(5,9)),
            new TownStationDefinition(TownStation.RiftKeeper,"균열 관리자","단계 선택 · 소탕 · 훈련",new Vector2(14,6)),
            new TownStationDefinition(TownStation.Warehouse,"공유 창고","계정 보관함",new Vector2(0,-1)),
        };
        public static TownStationDefinition Station(TownStation id)=>Stations.Single(s=>s.id==id);
        public static Vector2 Clamp(Vector2 p)=>new Vector2(Mathf.Clamp(p.x,-HalfWidth,HalfWidth),Mathf.Clamp(p.y,-HalfHeight,HalfHeight));
    }

    // Chooses the station a tap meant from already-projected screen positions. Pure, so the rule
    // "nearest within the radius, first wins a tie" is tested without a camera.
    public static class TownPick
    {
        public static bool Nearest(IReadOnlyList<(TownStation id,Vector2 screen)> projected,Vector2 point,float radius,out TownStation station)
        {
            station=default;float best=float.PositiveInfinity;bool found=false;
            foreach(var item in projected)
            {
                float d=Vector2.Distance(item.screen,point);
                if(d<=radius&&d<best){best=d;station=item.id;found=true;}
            }
            return found;
        }
    }

    // Session-only walking state for the sanctuary plaza. Pure: no rendering, no save, no randomness.
    public sealed class TownWalk
    {
        public Vector2 Position {get;private set;}=TownLayout.Spawn;
        public Vector2 Facing {get;private set;}=Vector2.up;
        public TownStation? Destination {get;private set;}
        public float Elapsed {get;private set;}
        TownStation? arrival;

        public bool Walking=>Destination.HasValue;
        public float Remaining=>Destination.HasValue?Vector2.Distance(Position,TownLayout.Station(Destination.Value).position):0;

        // A new destination replaces the old request. Standing at the station already counts as
        // arriving at once: walking is never a waiting time for a service.
        public void Request(TownStation station)
        {
            arrival=null;Destination=station;
            if(Vector2.Distance(Position,TownLayout.Station(station).position)<=TownLayout.ArriveRadius){Destination=null;arrival=station;}
        }
        public void Cancel(){Destination=null;arrival=null;}

        // Returns true when the hero moved this tick.
        public bool Tick(float dt)
        {
            if(dt<=0)return false;Elapsed+=dt;
            if(!Destination.HasValue)return false;
            var target=TownLayout.Station(Destination.Value).position;var delta=target-Position;
            float step=TownLayout.Speed*dt;
            if(delta.magnitude<=step||delta.magnitude<=TownLayout.ArriveRadius)
            {
                if(delta.sqrMagnitude>.0001f)Facing=delta.normalized;
                Position=TownLayout.Clamp(delta.magnitude<=step?target:Position+delta.normalized*step);
                var reached=Destination.Value;Destination=null;arrival=reached;return true;
            }
            Facing=delta.normalized;Position=TownLayout.Clamp(Position+Facing*step);return true;
        }

        // The arrival is handed over once; the caller opens the service.
        public bool TakeArrival(out TownStation station)
        {
            if(arrival.HasValue){station=arrival.Value;arrival=null;return true;}
            station=default;return false;
        }
    }
}
