using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimeTargetSmoke:MonoBehaviour
    {
        GameController game;string directory;int capture;
        static void Require(bool value,string message){if(!value)throw new InvalidOperationException(message);}
        static string Json(object value)=>JsonUtility.ToJson(value);
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if(!Debug.isDebugBuild||!Environment.GetCommandLineArgs().Contains("-hellscriptTargetSmoke"))return;
            Application.runInBackground=true;Application.logMessageReceived+=(m,s,t)=>{if(t==LogType.Exception)Application.Quit(1);};
            new GameObject("Target validation").AddComponent<RuntimeTargetSmoke>();
        }
        void Click(string name)=>game.UI.GetComponentsInChildren<Button>().Single(b=>b.name==name).onClick.Invoke();
        IEnumerator Capture(string name,int width,int height,bool showOrder=false)
        {
            Screen.SetResolution(width,height,FullScreenMode.Windowed);float end=Time.realtimeSinceStartup+6;
            while((Screen.width!=width||Screen.height!=height)&&Time.realtimeSinceStartup<end)yield return null;
            Require(Screen.width==width&&Screen.height==height,"Native size failed.");yield return new WaitForSecondsRealtime(.25f);
            if(showOrder)
            {
                DialogReadingAnchor.Show(game.UI.GetComponentsInChildren<Button>().First(b=>b.name=="▼ 아래로").transform.parent as RectTransform);
                yield return new WaitForSecondsRealtime(.2f);
            }
            string before=game.Combat==null?null:Json(game.Combat.State);
            if(game.Combat!=null){game.World.Present(game.Combat.State,.2f);game.UI.RefreshHud();}
            Canvas.ForceUpdateCanvases();
            foreach(var t in game.UI.GetComponentsInChildren<Text>())Require(t.preferredHeight<=t.rectTransform.rect.height+1,"Clipped text: "+t.text);
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,$"{++capture:00}-{name}.png"));yield return new WaitForSecondsRealtime(.2f);
            Require(before==null||before==Json(game.Combat.State),"Drawing changed pursuit or combat state.");
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();Require(args.Contains("-hellscriptSavePath"),"Use an isolated account.");
            for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptScreenshots")directory=args[i+1];
            Require(!string.IsNullOrEmpty(directory),"Use a dedicated evidence path.");Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1);game=FindAnyObjectByType<GameController>();game.enabled=false;
            if(args.Contains("-hellscriptTargetResume"))
            {
                Require(Json(game.Store.Data.suspendedRun)==File.ReadAllText(Path.Combine(directory,"expected-run.json")),"Disk pursuit checkpoint changed during loading.");
                game.Begin(resume:true);var run=game.Combat.State;Require(run.edictTarget.pursuitSeconds>0&&run.edictTarget.pursuitSeconds<1,"Partial pursuit was not restored.");
                int id=run.edictTarget.enemyId;var target=run.enemies.Single(e=>e.id==id);var direction=(target.position-run.position).normalized;
                var account=JsonUtility.FromJson<AccountSave>(Json(game.Store.Data));var control=new CombatSimulation(account,game.catalog,run.stage,restore:JsonUtility.FromJson<RunState>(Json(run)));
                for(int i=0;i<25;i++)
                {
                    target.position=run.position+direction*2.8f;control.State.enemies.Single(e=>e.id==id).position=target.position;
                    run.decisionTime=control.State.decisionTime=0;game.Combat.Tick(CombatSimulation.Step);control.Tick(CombatSimulation.Step);
                    Require(Json(run)==Json(control.State),"Resumed pursuit differs from an unrendered control.");
                }
                Require(run.targetId<0&&run.edictTarget.excluded.Contains(id)&&run.logs.Any(l=>l.Contains("EDICT_PURSUIT_END")),"The restored time limit did not stop repeated pursuit.");
                yield return Capture("resumed-pursuit-stopped",1280,720);
                target.position=run.position+direction*1.5f;run.decisionTime=0;game.Combat.Tick(CombatSimulation.Step);
                Require(run.targetId==id,"An enemy that approaches into reach cannot be attacked.");
                yield return Capture("resumed-close-target",720,1280);
                File.WriteAllText(Path.Combine(directory,"resume.txt"),"PASS: separate process restored exact pursuit state, remaining time expired once, rejected repeated chase, control matched, close enemy became attackable.\n");
                Debug.Log("HELLSCRIPT_TARGET_RESUME_OK");Application.Quit(0);yield break;
            }
            var hero=game.Store.Data.Hero;hero.level=30;hero.build=BehaviorPresets.ForLevel(hero.heroClass,0,30,game.catalog);
            hero.build.rules=new List<Rule>{BehaviorRules.Utility(RuleAction.Basic)};game.Store.Data.guide.hintsHidden=true;
            var document=HuntEdictV2Editing.WithGlobal(HuntEdictV2Storage.CreateForHero(hero),"target.chaseTime","1");
            Require(game.Store.SaveHeroEdict(hero.id,document,game.catalog,true),"Initial policy save failed.");
            game.UI.ShowEdictEditor();Click(EdictOptionLabels.Group("target"));
            for(int i=0;i<2;i++)game.UI.GetComponentsInChildren<Button>().Single(b=>b.name.StartsWith("기본 대상  ·",StringComparison.Ordinal)).onClick.Invoke();
            Click("저장 및 적용");Require(hero.edict.global.Single(o=>o.id=="target.default").value=="HIGH_HP","Editor did not save the exact high-HP choice.");
            yield return Capture("target-editor-korean",1280,720);game.ApplyLanguage("en");yield return Capture("target-editor-english",720,1280);
            yield return Capture("target-editor-english-compact",640,360);
            game.ApplyInterfaceScale(140);Require(Mathf.Abs(game.UI.InterfaceFactor-1.4f)<.001f,"Reading size did not apply.");
            yield return Capture("target-editor-english-140-portrait",720,1280);yield return Capture("target-editor-english-140-compact",640,360);
            yield return Capture("target-order-english-140-compact",640,360,true);
            game.ApplyInterfaceScale(100);game.ApplyLanguage("ko");
            game.Begin(seed:43117);var state=game.Combat.State;state.enemies.Clear();
            Vector2 origin=state.position;var directionOpen=Enumerable.Range(0,16).Select(i=>new Vector2(Mathf.Cos(i*Mathf.PI/8),Mathf.Sin(i*Mathf.PI/8)))
                .First(v=>game.Combat.Map.Walkable(origin+v*5)&&game.Combat.Map.LineClear(origin,origin+v*5));
            EnemyState Add(float distance,float hp)
            {
                var enemy=new EnemyState{id=state.nextId++,position=origin+directionOpen*distance,health=hp,maxHealth=10000,speed=0,attack=0,cooldown=1000};state.enemies.Add(enemy);return enemy;
            }
            var low=Add(1,2000);var high=Add(2.8f,9000);game.Combat.Tick(CombatSimulation.Step);
            Require(state.targetId==high.id,"The saved editor choice did not drive actual targeting.");low.dead=true;
            for(int i=0;i<5;i++){high.position=state.position+directionOpen*2.8f;state.decisionTime=0;game.Combat.Tick(CombatSimulation.Step);}
            Require(state.edictTarget.pursuitSeconds>0&&state.edictTarget.pursuitSeconds<1,"No partial pursuit to persist.");
            game.World.BuildDungeon(state);yield return Capture("partial-pursuit-wide",1920,1080);yield return Capture("partial-pursuit-portrait",720,1280);
            game.Save();Require(string.IsNullOrEmpty(game.Store.Error),"Checkpoint save failed.");File.WriteAllText(Path.Combine(directory,"expected-run.json"),Json(state));
            File.WriteAllText(Path.Combine(directory,"main.txt"),"PASS: actual editor saved HIGH_HP, Korean/English target settings, selected high-HP target over nearer low-HP target, persisted partial chase; rendering left state unchanged.\n");
            Debug.Log("HELLSCRIPT_TARGET_RUNTIME_OK");Application.Quit(0);
        }
    }
}
