using System;
using System.Collections.Generic;
using System.Linq;

namespace Hellscript
{
    public sealed class EdictMissingSkill
    {
        public readonly int slot,requiredLevel;
        public readonly string skillId,reason;
        public EdictMissingSkill(int slot,SkillDefinition skill)
        {this.slot=slot;skillId=skill.id;requiredLevel=skill.unlock;reason=Loc.F("원본: {0} · Lv.{1} 해금 필요", skill.name, skill.unlock);}
    }
    public sealed class EdictImportPreview
    {
        readonly HuntEdictDocument original;
        public readonly string OriginalCode;
        public HuntEdictDocument Original=>original.Copy();
        public readonly HuntEdictDocument Draft;
        public readonly IReadOnlyList<EdictMissingSkill> MissingSkills;
        public bool Partial=>MissingSkills.Count>0;
        internal EdictImportPreview(string code,HuntEdictDocument original,HuntEdictDocument draft,List<EdictMissingSkill> missing)
        {OriginalCode=code;this.original=original.Copy();Draft=draft;MissingSkills=missing.AsReadOnly();}
    }
    public static class HuntEdictImport
    {
        public static EdictImportPreview Prepare(string code,HeroSave hero,GameCatalog catalog)
        {
            if(hero==null||catalog==null||hero.level<1||hero.level>30)throw new ArgumentException("현재 캐릭터와 스킬 정보를 확인해 주세요.");
            var original=HuntEdictCodec.Decode(code);
            if(original.heroClass!=HuntEdict.ClassId(hero.heroClass))throw new ArgumentException("다른 직업의 사냥 칙령입니다.");
            var expected=HuntEdict.SkillIds(original.heroClass);
            foreach(string id in expected)
                if(catalog.skills.Count(s=>s.id==id&&s.heroClass==hero.heroClass)!=1)throw new InvalidOperationException(Loc.F("스킬 카탈로그와 코드의 콘텐츠 기준이 다릅니다: {0}", id));
            var draft=original.Copy();var missing=new List<EdictMissingSkill>();
            for(int n=0;n<HuntEdict.ActiveSlots;n++)
            {
                if(draft.slots[n]=="")continue;
                var skill=catalog.skills.Single(s=>s.id==draft.slots[n]&&s.heroClass==hero.heroClass);
                if(hero.level>=skill.unlock)continue;
                missing.Add(new EdictMissingSkill(n,skill));draft.slots[n]="";
            }
            return new EdictImportPreview(code.Trim(),original,draft,missing);
        }
    }
}
