using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // An explicitly requested isolated development run; ordinary launches never create this fixture.
    public sealed class RuntimeLegendarySmoke : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Install()
        {
            if(!Environment.GetCommandLineArgs().Contains("-hellscriptLegendarySmoke"))return;
            Application.runInBackground=true;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Legendary smoke validation").AddComponent<RuntimeLegendarySmoke>();
        }
        static void Require(bool valid,string reason){if(!valid)throw new InvalidOperationException(reason);}
        static IEnumerator Until(Func<bool> ready)
        {float deadline=Time.realtimeSinceStartup+12;while(!ready()&&Time.realtimeSinceStartup<deadline)yield return null;Require(ready(),"Legendary runtime condition was not reached.");}
        static IEnumerator Capture(GameController game,string dir,string name)
        {game.Combat.State.paused=true;game.UI.RefreshHud();yield return new WaitForSecondsRealtime(.3f);ScreenCapture.CaptureScreenshot(Path.Combine(dir,name));yield return new WaitForSecondsRealtime(.2f);}
        static void Save(GameController game,string dir,string name)
        {game.Save();Require(string.IsNullOrEmpty(game.Store.Error),"Legendary checkpoint failed.");File.WriteAllText(Path.Combine(dir,name),JsonUtility.ToJson(game.Combat.State,true));}
        static RunState Arena(GameController game)
        {
            var account=game.Store.Data;account.selectedHero=0;var hero=account.Hero;hero.level=30;hero.inventory.Clear();uint rng=71711;
            var gear=new[]{"LW01","SW1","SW2","LW03","LW02","LC03","LW04","LC01"};
            for(int slot=0;slot<8;slot++)
            {var item=ItemGenerator.Create(hero.heroClass,slot,3,30,ref rng,uniqueId:gear[slot]);hero.inventory.Add(item);Require(Economy.Equip(hero,item),"Illegal legendary fixture equipment.");}
            hero.build=GameCatalog.Preset(HeroClass.Warrior,0);hero.build.passives=Array.Empty<int>();hero.build.rules.Clear();hero.build.activeSkills=new[]{0,1,2,4}.ToList();
            hero.build.rules.Add(BehaviorRules.Make(0));hero.build.movement=MovementMode.Stand;hero.build.potionThreshold=0;hero.build.autoRepeat=false;
            Require(BehaviorRules.Validate(hero.build,hero.heroClass).Count==0,"Invalid legendary fixture build.");
            var fixture=new CombatSimulation(account,game.catalog,1,1,seed:71711);var run=fixture.State;run.training=-1;run.position=RiftMap.Rooms[0];run.enemies.Clear();
            foreach(var pair in new[]{(id:902,distance:2.2f),(id:900,distance:3.5f)})
                run.enemies.Add(new EnemyState{id=pair.id,position=run.position+Vector2.up*pair.distance,health=100000,maxHealth=100000,cooldown=1000});
            account.suspendedRun=run;game.Begin(resume:true);game.SetSpeed(1);game.Combat.State.paused=true;return game.Combat.State;
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();string dir="";
            for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptScreenshots")dir=args[i+1];
            Require(args.Contains("-hellscriptSavePath")&&!string.IsNullOrEmpty(dir),"Legendary smoke requires isolated save and image directories.");Directory.CreateDirectory(dir);Screen.SetResolution(540,960,FullScreenMode.Windowed);
            yield return new WaitForSecondsRealtime(1);var game=FindAnyObjectByType<GameController>();RunState run;
            if(!args.Contains("-hellscriptLegendaryResume"))
            {
                run=Arena(game);var weapon=game.Store.Data.Hero.inventory.Single(i=>i.special=="LW01");game.UI.ShowItemDetail(weapon.id);yield return null;Canvas.ForceUpdateCanvases();
                var description=game.UI.GetComponentsInChildren<Text>().Single(t=>t.text==ItemCatalog.Unique("LW01").description);
                Require(description.preferredHeight<=description.rectTransform.rect.height+.5f,"Legendary description was clipped.");
                var row=(RectTransform)description.transform.parent;var scroll=row.GetComponentInParent<ScrollRect>();float max=Mathf.Max(0,scroll.content.rect.height-scroll.viewport.rect.height);
                scroll.content.anchoredPosition=new Vector2(0,Mathf.Clamp(-(row.localPosition.y+row.rect.yMax),0,max));scroll.StopMovement();
                yield return Capture(game,dir,"01-weapon-description.png");game.UI.ShowBattle();run.paused=false;
                yield return Until(()=>run.effectEvents.Any(e=>e.definitionId=="LW01"&&e.kind=="PULLED"));run.paused=true;
                var pulls=run.effectEvents.Where(e=>e.definitionId=="LW01").ToArray();Require(pulls.Length==2,"The first paid pulse must move both legal targets once.");
                Require(Vector2.Distance(run.position,run.enemies[0].position)>=.8499f,"Pull overlapped the hero.");
                Require(!run.damageEvents.Any(d=>d.definitionId=="LW01"),"Pull incorrectly generated damage.");
                yield return Capture(game,dir,"02-first-pull-world.png");game.UI.ShowCombatEffects();yield return Capture(game,dir,"03-first-pull-record.png");
                Save(game,dir,"checkpoint.json");Debug.Log("LEGENDARY_CHECKPOINT_READY");Application.Quit();yield break;
            }
            var saved=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(dir,"checkpoint.json")));GameStore.NormalizeRun(saved);game.Begin(resume:true);run=game.Combat.State;run.paused=true;
            Require(run.id==saved.id&&run.rng==saved.rng&&run.time==saved.time&&run.health==saved.health&&run.resource==saved.resource
                &&JsonUtility.ToJson(run.heroAction)==JsonUtility.ToJson(saved.heroAction)&&JsonUtility.ToJson(run.itemEffects)==JsonUtility.ToJson(saved.itemEffects)
                &&run.enemies.Select(e=>JsonUtility.ToJson(e)).SequenceEqual(saved.enemies.Select(e=>JsonUtility.ToJson(e))),"Legendary state changed on restart.");
            game.UI.ShowCombatEffects();yield return Capture(game,dir,"04-restored-pull-record.png");float first=run.itemEffects.lastPull;int damageCount=run.damageEvents.Count;
            game.UI.ShowBattle();game.SetSpeed(1);run.paused=false;yield return Until(()=>run.itemEffects.lastPull>first);run.paused=true;
            Require(Mathf.RoundToInt(run.itemEffects.lastPull/CombatSimulation.Step)-Mathf.RoundToInt(first/CombatSimulation.Step)==20,"Pull did not preserve its 20-tick interval.");
            Require(run.effectEvents.Count(e=>e.definitionId=="LW01")==3,"Saved pulls were repeated or a blocked body moved again.");
            Require(Vector2.Distance(run.enemies[0].position,run.enemies[1].position)>=.7999f,"Pull overlapped another enemy.");
            Require(run.damageEvents.Count>damageCount&&!run.damageEvents.Any(d=>d.definitionId=="LW01"),"Paid channel damage and pull records were mixed.");
            yield return Capture(game,dir,"05-second-pull-world.png");game.UI.ShowCombatEffects();yield return Capture(game,dir,"06-second-pull-record.png");Save(game,dir,"completed.json");
            File.WriteAllText(Path.Combine(dir,"runtime-legendary-smoke.txt"),$"PASS: legal eight-slot LW01/SW2/LW02/LW03/LC03/LW04/LC01 fixture, actual automatic paid W01, hero/body limits, real process restart with full action/effect/enemy equality, 20-tick pull spacing, no invented damage, weapon description layout and effect record.\nFixture: level 30, stationary harmless high-HP enemies, legacy training geometry; isolated development save, not balance or Android/physical-input proof.\nrunId={run.id}\nfirstPull={first:R}\nsecondPull={run.itemEffects.lastPull:R}\nRenderer={SystemInfo.graphicsDeviceType}\nScreen={Screen.width}x{Screen.height}\n");
            Debug.Log("HELLSCRIPT_LEGENDARY_RUNTIME_SMOKE_OK");Application.Quit();
        }
    }
}
