using System;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class DialogScrollRect : ScrollRect
    {
        public Action readingStarted;
        public override void OnBeginDrag(PointerEventData data){base.OnBeginDrag(data);readingStarted?.Invoke();}
        public override void OnScroll(PointerEventData data){base.OnScroll(data);readingStarted?.Invoke();}
    }
}
