using System.Collections.Generic;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class WorldView
    {
        sealed class SealView
        {
            public GameObject root,stone,lockBars,fragments,light;
            public LineRenderer progress;
        }
        readonly Dictionary<string,SealView> sealViews=new Dictionary<string,SealView>();
        void BuildObjectives(RunState run)
        {
            foreach(var seal in run.layout.seals)
            {
                var root=new GameObject("Objective "+seal.id);root.transform.SetParent(world.transform,false);root.transform.position=Position(seal.position);
                Shape("Seal plinth",PrimitiveType.Cylinder,root.transform,Vector3.up*.12f,new Vector3(1.65f,.12f,1.65f),darkStone);
                var stone=Shape("Seal monolith",PrimitiveType.Cube,root.transform,Vector3.up*1.05f,new Vector3(.75f,1.85f,.65f),trim);
                stone.transform.localRotation=Quaternion.Euler(0,35,0);
                var light=Shape("Seal rune",PrimitiveType.Sphere,root.transform,Vector3.up*1.9f,new Vector3(.38f,.48f,.38f),purple);
                var locks=new GameObject("Guard locks");locks.transform.SetParent(root.transform,false);
                foreach(int sign in new[]{-1,1})
                {
                    var bar=Shape("Guard binding",PrimitiveType.Cube,locks.transform,new Vector3(0,.95f,-.47f),new Vector3(1.3f,.1f,.1f),purple);
                    bar.transform.localRotation=Quaternion.Euler(0,0,sign*45);
                }
                var fragments=new GameObject("Broken seal");fragments.transform.SetParent(root.transform,false);
                for(int i=0;i<3;i++)
                {
                    float angle=i*Mathf.PI*2/3;
                    var piece=Shape("Seal fragment",PrimitiveType.Cube,fragments.transform,new Vector3(Mathf.Cos(angle)*.6f,.3f,Mathf.Sin(angle)*.6f),new Vector3(.4f,.4f,.65f),darkStone);
                    piece.transform.localRotation=Quaternion.Euler(15+i*20,i*120,25);
                }
                Ring(root.transform,Vector3.up*.05f,.95f,trim,.07f);
                var progress=Ring(root.transform,Vector3.up*.07f,1.1f,ember,.13f).GetComponent<LineRenderer>();progress.name="Breaking progress";
                sealViews.Add(seal.id,new SealView{root=root,stone=stone,lockBars=locks,fragments=fragments,light=light,progress=progress});
                root.SetActive(false);
            }
        }
        void PresentObjectives(RunState run)
        {
            foreach(var seal in run.layout.seals)
            {
                if(!sealViews.TryGetValue(seal.id,out var view))continue;
                bool known=seal.discovered&&run.visited.Contains(seal.room);
                view.root.SetActive(known&&Vector2.Distance(run.position,seal.position)<25);
                bool broken=seal.phase==SealPhase.Broken,locked=seal.phase==SealPhase.Locked;
                view.stone.SetActive(!broken);view.light.SetActive(!broken);view.lockBars.SetActive(locked);view.fragments.SetActive(broken);
                view.light.GetComponent<Renderer>().sharedMaterial=locked?purple:ember;
                float progress=broken?1:Mathf.Clamp01(seal.progress/RiftSeal.Duration);
                view.progress.gameObject.SetActive(progress>0);view.progress.sharedMaterial=broken?green:ember;
                // Use persisted simulation progress, so resizing, pausing and rebuilding the view do not restart it.
                view.progress.positionCount=49;
                for(int i=0;i<49;i++)
                {float a=i/48f*Mathf.PI*2*progress;view.progress.SetPosition(i,new Vector3(Mathf.Cos(a)*1.1f,0,Mathf.Sin(a)*1.1f));}
                view.stone.transform.localPosition=Vector3.up*1.05f+(seal.phase==SealPhase.Breaking?Vector3.right*(Mathf.Sin(run.time*32)*.025f):Vector3.zero);
            }
        }
    }
}
