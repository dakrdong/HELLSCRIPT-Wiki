using System;
using System.Linq;

namespace Hellscript
{
    // Where a hero keeps its hunt edict v0.2 document, and how a save written before the document
    // existed is brought forward. Storage only; nothing here decides combat behaviour.
    public static class HuntEdictV2Storage
    {
        // JsonUtility materializes an absent serializable class as a default instance rather than null,
        // so absence is decided by content instead of by the reference.
        public static bool IsAbsent(HuntEdictV2Document source)=>source==null||string.IsNullOrEmpty(source.heroClass);

        public static HuntEdictV2Document CreateForHero(HeroSave hero)
        {
            if(hero==null)throw new ArgumentException("현재 캐릭터를 확인하세요.");
            return HuntEdictV2.Canonical(WithBuildSlots(HuntEdictV2.Create(hero.heroClass),hero.build));
        }

        // Seed the four slots from the loadout the hero already fights with, so a migrated save does not
        // start out of step with its own equipped skills.
        static HuntEdictV2Document WithBuildSlots(HuntEdictV2Document document,BuildConfig build)
        {
            if(build?.activeSkills==null)return document;
            var ids=HuntEdict.SkillIds(document.heroClass);var slots=new[]{"","","",""};int filled=0;
            foreach(int index in build.activeSkills)
            {
                if(filled>=slots.Length)break;
                if(index<0||index>=18)continue;
                string id=CombatTelemetry.SkillId(index);
                if(!ids.Contains(id)||slots.Contains(id))continue;
                slots[filled++]=id;
            }
            document.slots=slots;return document;
        }

        static bool Newer(HuntEdictV2Document d)=>d.schema>HuntEdictV2.Schema||d.contentVersion>HuntEdictV2.ContentVersion
            ||d.globalVersion>HuntEdictV2.GlobalVersion||d.optionVersion>HuntEdictV2.OptionVersion||d.policyVersion>HuntEdictV2.PolicyVersion;

        public static void Normalize(HeroSave hero)
        {
            if(hero==null)return;
            // A document belonging to another class cannot be applied to this hero, so it is replaced
            // rather than repaired. An absent one is created from the class defaults.
            if(IsAbsent(hero.edict)||hero.edict.heroClass!=HuntEdict.ClassId(hero.heroClass)){hero.edict=CreateForHero(hero);return;}
            if(Newer(hero.edict))throw new NotSupportedException("더 새로운 사냥 칙령 버전이 필요합니다. 저장 파일은 보존했습니다.");
            // Resetting a readable-looking document would silently change how the hero fights, so an
            // unreadable one stops the load with the file left untouched.
            try{hero.edict=HuntEdictV2.Canonical(hero.edict);}
            catch(ArgumentException e){throw new NotSupportedException(Loc.F("저장된 사냥 칙령을 읽을 수 없습니다. 저장 파일은 보존했습니다.\n{0}", e.Message));}
        }
    }
}
