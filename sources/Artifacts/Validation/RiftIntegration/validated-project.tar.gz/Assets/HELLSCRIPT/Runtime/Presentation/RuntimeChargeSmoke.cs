using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimeChargeSmoke : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Install()
        {
            if(!Environment.GetCommandLineArgs().Contains("-hellscriptChargeSmoke"))return;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Charge smoke validation").AddComponent<RuntimeChargeSmoke>();
        }
        static void Require(bool pass,string reason){if(!pass)throw new InvalidOperationException(reason);}
        static Button Find(string name)=>FindObjectsByType<Button>().First(b=>b.name==name);
        static RunState Arena(GameController game,HeroClass heroClass,string set,int[] skills,int[] passives=null,string legendary=null)
        {
            if(game.Running)game.ReturnTown();var account=game.Store.Data;account.selectedHero=(int)heroClass;var hero=account.Hero;hero.level=30;hero.inventory.RemoveAll(i=>i.slot>0);
            uint rng=1909;if(set!=null)for(int i=1;i<=4;i++){var d=ItemCatalog.Unique(set+i);var item=ItemGenerator.Create(heroClass,d.slot,3,30,ref rng,uniqueId:d.id);item.equipped=true;hero.inventory.Add(item);}
            if(legendary!=null){var d=ItemCatalog.Unique(legendary);var item=ItemGenerator.Create(heroClass,d.slot,3,30,ref rng,uniqueId:legendary);item.equipped=true;hero.inventory.Add(item);}
            hero.build=GameCatalog.Preset(heroClass,0);hero.build.rules.Clear();hero.build.rules.Add(new Rule(skills[0],escape:skills[0]==9));hero.build.activeSkills=skills.ToList();
            hero.build.passives=passives??Array.Empty<int>();hero.build.movement=MovementMode.Stand;hero.build.distance=2;hero.build.autoRepeat=false;hero.build.potionThreshold=0;
            var fixture=new CombatSimulation(account,game.catalog,1,1,seed:52107);var run=fixture.State;run.training=-1;run.position=RiftMap.Rooms[0];run.enemies.Clear();
            run.enemies.Add(new EnemyState{id=900,kind=0,position=run.position+Vector2.up*(skills[0]==1?6:2),health=100000,maxHealth=100000,cooldown=1000,speed=0,attack=0});
            account.suspendedRun=run;game.Begin(resume:true);game.SetSpeed(1);game.Combat.State.paused=true;return game.Combat.State;
        }
        static void SkillRule(GameController game,int skill)
        {
            var build=game.Combat.State.build.Copy();build.rules.Clear();build.rules.Add(new Rule(skill,escape:skill==9));build.movement=MovementMode.Stand;
            Require(game.Combat.ApplyBuild(build),"Fixture build rejected.");game.Combat.State.decisionTime=0;game.UI.ShowBattle();
        }
        static IEnumerator Until(Func<bool> ready,float timeout=8)
        {float end=Time.realtimeSinceStartup+timeout;while(!ready()&&Time.realtimeSinceStartup<end)yield return null;Require(ready(),"Charge fixture did not reach the expected state.");}
        static IEnumerator Capture(GameController game,string directory,string file)
        {game.Combat.State.paused=true;game.UI.RefreshHud();yield return new WaitForSecondsRealtime(.3f);ScreenCapture.CaptureScreenshot(Path.Combine(directory,file));yield return new WaitForSecondsRealtime(.2f);}
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();string directory="";for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptScreenshots")directory=args[i+1];
            Require(args.Contains("-hellscriptSavePath")&&!string.IsNullOrEmpty(directory),"Charge smoke requires isolated save and output paths.");Directory.CreateDirectory(directory);Screen.SetResolution(540,960,FullScreenMode.Windowed);
            yield return new WaitForSecondsRealtime(1);var game=FindAnyObjectByType<GameController>();RunState run;
            if(!args.Contains("-hellscriptChargeResume"))
            {
                run=Arena(game,HeroClass.Warrior,"SW",new[]{0,1});run.build.movement=MovementMode.Orbit;yield return new WaitForSecondsRealtime(.5f);run.paused=false;
                yield return Until(()=>run.itemEffects.whirlwindCharge>0);run.paused=true;Require(run.moveDistance>=4&&run.heroAction.cost>0,"Unpaid or stationary whirlwind generated a charge.");
                game.UI.ShowCombatEffects();yield return Capture(game,directory,"01-earned-whirlwind.png");SkillRule(game,1);
                run.position=RiftMap.Rooms[0];run.enemies[0].position=run.position+Vector2.up*6;game.Combat.Map.Repath();run.itemEffects.whirlwindCharge=1f;
                yield return new WaitForSecondsRealtime(.5f);run.paused=false;yield return Until(()=>run.heroAction.phase==HeroActionPhase.Travelling&&run.heroAction.elapsed>=.2f);run.paused=true;run.decisionTime=100;
                File.WriteAllText(Path.Combine(directory,"reserved-leap.json"),JsonUtility.ToJson(run,true));
                Require(run.heroAction.whirlwindReserved&&run.itemEffects.whirlwindCharge==0&&!run.damageEvents.Any(d=>d.definitionId=="SW4"),
                    $"Travel did not hold exactly one unspent landing reservation: skill={run.heroAction.skill} phase={run.heroAction.phase} elapsed={run.heroAction.elapsed:0.000} prepare={run.heroAction.prepare:0.000} reserved={run.heroAction.whirlwindReserved} charge={run.itemEffects.whirlwindCharge:0.000} setPieces={game.Combat.Stats.SetPieces("SW")} sw4Damage={run.damageEvents.Count(d=>d.definitionId=="SW4")} events={string.Join(",",run.effectEvents.Where(e=>e.definitionId=="SW4").Select(e=>e.kind))}");
                game.UI.ShowCombatEffects();yield return Capture(game,directory,"02-reserved-leap.png");game.Save();File.WriteAllText(Path.Combine(directory,"checkpoint.json"),JsonUtility.ToJson(run,true));
                Debug.Log("CHARGE_SMOKE_CHECKPOINT_READY");Application.Quit();yield break;
            }
            var saved=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(directory,"checkpoint.json")));GameStore.NormalizeRun(saved);game.Begin(resume:true);var resumed=game.Combat.State;resumed.paused=true;
            Require(resumed.id==saved.id&&resumed.time==saved.time&&resumed.rng==saved.rng&&JsonUtility.ToJson(resumed.heroAction)==JsonUtility.ToJson(saved.heroAction),"Reserved action changed on process restart.");
            game.UI.ShowCombatEffects();yield return Capture(game,directory,"03-restored-reservation.png");Find("전투로 돌아가기").onClick.Invoke();Require(resumed.paused,"Detail view did not preserve pause.");
            game.SetSpeed(1);resumed.paused=false;yield return Until(()=>resumed.damageEvents.Any(d=>d.definitionId=="SW4"));resumed.paused=true;
            Require(resumed.damageEvents.Count(d=>d.definitionId=="SW4")==1&&!resumed.heroAction.whirlwindReserved,"Leap reservation did not resolve exactly once.");
            yield return Capture(game,directory,"04-reserved-leap-landed.png");File.WriteAllText(Path.Combine(directory,"restored-leap-completed.json"),JsonUtility.ToJson(resumed,true));

            run=Arena(game,HeroClass.Warrior,"SWB",new[]{1,2});yield return new WaitForSecondsRealtime(.5f);run.paused=false;yield return Until(()=>run.itemEffects.crushCharge>0);run.paused=true;
            SkillRule(game,2);run.itemEffects.crushCharge=.1f;run.paused=false;yield return Until(()=>run.heroAction.phase==HeroActionPhase.Preparing&&run.heroAction.crushBonus);run.paused=true;run.decisionTime=100;
            game.UI.ShowCombatEffects();yield return Capture(game,directory,"05-reserved-crush.png");game.UI.ShowBattle();run.paused=false;yield return Until(()=>run.damageEvents.Any(d=>d.definitionId=="SWB4"));run.paused=true;
            Require(run.itemEffects.crushCharge==0&&run.damageEvents.Count(d=>d.definitionId=="SWB4")==1,"Crush charge expired or repeated.");File.WriteAllText(Path.Combine(directory,"crush-completed.json"),JsonUtility.ToJson(run,true));

            run=Arena(game,HeroClass.Ranger,"SAB",new[]{9,6});yield return new WaitForSecondsRealtime(.5f);run.paused=false;yield return Until(()=>run.itemEffects.pierceCharge>0);run.paused=true;
            SkillRule(game,6);run.itemEffects.pierceCharge=.1f;run.position=RiftMap.Rooms[0];run.enemies[0].position=run.position+Vector2.up*6;game.Combat.Map.Repath();
            run.paused=false;yield return Until(()=>run.projectiles.Any(p=>p.extra&&p.delay>0));run.paused=true;run.decisionTime=100;yield return Capture(game,directory,"06-delayed-pierce-echo.png");
            Require(run.itemEffects.pierceCharge==0&&run.projectiles.Count(p=>p.extra)==1,"Pierce did not create exactly one reserved echo.");run.paused=false;yield return Until(()=>run.damageEvents.Any(d=>d.definitionId=="SAB4"));run.paused=true;File.WriteAllText(Path.Combine(directory,"pierce-completed.json"),JsonUtility.ToJson(run,true));

            run=Arena(game,HeroClass.Mage,"SMB",new[]{17,14},new[]{2});for(int i=1;i<7;i++)run.enemies.Add(new EnemyState{id=900+i,kind=0,position=run.position+new Vector2(Mathf.Cos(i*Mathf.PI*2/7),Mathf.Sin(i*Mathf.PI*2/7))*2,health=100000,maxHealth=100000,cooldown=1000,speed=0});
            yield return new WaitForSecondsRealtime(.5f);run.paused=false;yield return Until(()=>run.itemEffects.chainCharges==2);run.paused=true;SkillRule(game,14);run.paused=false;
            yield return Until(()=>run.damageEvents.Count(d=>d.definitionId=="M03")==7);run.paused=true;run.decisionTime=100;Require(run.itemEffects.chainCharges==1,"One chain consumed more than one overcharge.");
            game.UI.ShowCombatEffects();yield return Capture(game,directory,"07-chain-charge-remaining.png");File.WriteAllText(Path.Combine(directory,"chain-completed.json"),JsonUtility.ToJson(run,true));

            run=Arena(game,HeroClass.Ranger,null,new[]{6},new[]{4},"LC02");var build=run.build.Copy();build.rules.Clear();build.rules.Add(BehaviorRules.Utility(RuleAction.Basic));Require(game.Combat.ApplyBuild(build),"Basic build rejected.");
            yield return new WaitForSecondsRealtime(.5f);run.paused=false;yield return Until(()=>run.itemEffects.lc02Charge>0);run.paused=true;
            build=run.build.Copy();build.rules.Clear();build.rules.Add(BehaviorRules.Utility(RuleAction.Explore));Require(game.Combat.ApplyBuild(build),"Walking build rejected.");run.decisionTime=0;
            run.paused=false;yield return Until(()=>run.itemEffects.ap05Ready);run.paused=true;Require(run.itemEffects.lc02Charge>0,"Discipline expired before one second of walking.");
            game.UI.ShowCombatEffects();yield return Capture(game,directory,"08-cost-bonuses-ready.png");SkillRule(game,6);run.resource=100;run.paused=false;yield return Until(()=>run.heroAction.skill==6&&run.heroAction.phase==HeroActionPhase.Preparing);run.paused=true;
            Require(Mathf.Abs(run.heroAction.cost-game.catalog.skills[6].cost*.5f)<.001f&&!run.itemEffects.reducedNext&&!run.itemEffects.ap05Ready,"Cost bonuses were not capped or consumed together.");
            Require(run.effectEvents.Count(e=>e.definitionId=="LC02"&&e.kind=="CONSUMED")==1&&run.effectEvents.Count(e=>e.definitionId=="AP05"&&e.kind=="CONSUMED")==1,"Cost bonus was consumed repeatedly.");
            game.UI.ShowCombatEffects();yield return Capture(game,directory,"09-cost-bonuses-consumed.png");File.WriteAllText(Path.Combine(directory,"cost-completed.json"),JsonUtility.ToJson(run,true));game.Save();
            File.WriteAllText(Path.Combine(directory,"runtime-charges-smoke.txt"),$"PASS: real paid whirlwind walking earns SW4; travel reservation survives actual process restart and expires only through one landing; SWB/SAB valid casts retain short-lived charges through preparation; one SAB echo; SMB with MP03 hits seven distinct targets and consumes one of two charges; real LC02 basic hits and one-second AP05 walking prepare discounts, then one paid cast consumes both at the 50% cap. Native effect UI inspected.\nControlled fixtures: level 30, starter weapons, actual legal four-piece sets or LC02 necklace; harmless stationary high-HP targets; SW/SWB/SAB charge times deliberately shortened after earning, fixed positions between actions; normal run save path. No physical-input, Android or balance claim.\ncheckpointRun={saved.id}\ncheckpointTime={saved.time:F2}\nRenderer={SystemInfo.graphicsDeviceType}\nScreen={Screen.width}x{Screen.height}\n");
            Debug.Log("HELLSCRIPT_CHARGE_RUNTIME_SMOKE_OK");Application.Quit();
        }
    }
}
