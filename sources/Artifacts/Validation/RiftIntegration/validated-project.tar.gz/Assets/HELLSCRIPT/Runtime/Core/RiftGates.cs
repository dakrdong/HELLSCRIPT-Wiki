using System;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    [Serializable] public sealed class RiftGate
    {
        public int door,corridor;
        public Vector2 outward;
        public RiftObstacle barrier;
        public bool discovered;
        public Vector2 Outside=>barrier.position+outward*1.1f;
    }

    public static class RiftGates
    {
        // Gate geometry belongs to the saved map, not the renderer. Older in-progress maps keep
        // their original entrances; creating barriers during load could strand a saved character.
        public static void Place(RiftLayout map)
        {
            if(map.objective==RiftObjectiveKind.None)return;
            var arena=map.rooms[map.bossRoom];
            foreach(var door in arena.doors.Where(d=>d.corridor>=0))
            {
                float span=Mathf.Max(door.width,map.corridors[door.corridor].width)*.5f+.4f;
                map.gates.Add(new RiftGate{door=door.index,corridor=door.corridor,outward=door.direction,
                    barrier=new RiftObstacle{id="gate:"+door.index,kind="Gate",position=door.position,height=3,
                        halfSize=door.direction.x!=0?new Vector2(.4f,span):new Vector2(span,.4f)}});
            }
        }

        public static void Validate(RiftLayout map)
        {
            if(map.version<3||map.legacy)return;
            if(map.objective==RiftObjectiveKind.None)
            {if(map.gates.Count!=0)throw new InvalidOperationException("Unexpected gates without an objective.");return;}
            var arena=map.rooms[map.bossRoom];var doors=arena.doors.Where(d=>d.corridor>=0).ToArray();
            if(map.gates.Count!=doors.Length||map.gates.Select(g=>g.door).Distinct().Count()!=doors.Length)
                throw new InvalidOperationException("Every boss entrance must have its own gate.");
            foreach(var door in doors)
            {
                var gate=map.gates.Single(g=>g.door==door.index);
                if(gate.corridor!=door.corridor||gate.barrier.position!=door.position||gate.outward!=door.direction)
                    throw new InvalidOperationException("Gate does not match its saved entrance.");
            }
            // Validate both phases without changing the live gate flag. Non-boss rooms, objectives
            // and the meter alternative must remain accessible while every arena entrance is shut.
            var closed=new RiftNavigation(map);
            if(!map.gateOpen)
            {
                if(map.bossPoints.Any(closed.Reachable))throw new InvalidOperationException("A route bypasses a closed boss gate.");
                foreach(var room in map.rooms.Where(r=>r.index!=map.bossRoom))
                    if(room.groupAnchors.Any(p=>!closed.Reachable(p)))throw new InvalidOperationException("A closed gate strands a non-boss room.");
                if(map.seals.Any(s=>s.accessPoints.Any(p=>!closed.Reachable(p)))||
                    map.carriers.Any(c=>!closed.Reachable(c.position))||map.offerings.Any(o=>!closed.Reachable(o.position))||
                    map.objective==RiftObjectiveKind.Offerings&&map.altar.accessPoints.Any(p=>!closed.Reachable(p))||
                    map.events.Any(e=>e.spawnCandidates.Any(p=>!closed.Reachable(p)))||
                    map.chests.Where(c=>c.room!=map.bossRoom).Any(c=>c.accessPoints.Any(p=>!closed.Reachable(p)))||
                    map.shrines.Any(s=>s.accessPoints.Any(p=>!closed.Reachable(p))))
                    throw new InvalidOperationException("A closed gate strands field content.");
                int meter=map.spawns.Where(s=>closed.Reachable(s.position)).Sum(s=>s.elite<0?1:5);
                if(meter<CombatSimulation.GateMeter)throw new InvalidOperationException("The closed side cannot fill the gate meter.");
            }
            var opened=new RiftNavigation(map,gatesOpen:true);
            if(map.spawns.Any(s=>!opened.Reachable(s.position))||map.bossPoints.Any(p=>!opened.Reachable(p)))
                throw new InvalidOperationException("Opening the gates does not restore all encounters.");
            foreach(var door in doors)
                if(!opened.TravelClear(door.position+door.direction*3,door.position-door.direction*3,1.2f))
                    throw new InvalidOperationException("An opened gate is too narrow for passage.");
        }
    }
}
