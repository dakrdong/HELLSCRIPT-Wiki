using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public enum IncomingCategory { Ground,Area,Direct,Attached }
    [Flags]public enum IncomingControl { None=0,Stun=1,Freeze=2,Root=4,Pull=8 }
    public sealed class ObservedIncomingSource
    {
        public readonly string key,definition;
        public readonly IncomingCategory category;
        public readonly IncomingControl control;
        public readonly float begins;
        internal ObservedIncomingSource(string key,string definition,IncomingCategory category,IncomingControl control,float begins)
        {this.key=key;this.definition=definition;this.category=category;this.control=control;this.begins=begins;}
    }
    public sealed class ObservedIncomingHit
    {
        public readonly string sourceKey,definition;
        public readonly IncomingCategory category;
        public readonly IncomingControl control;
        public readonly int element;
        public readonly float after,rawDamage,finalDamage,absorbed,hpLoss;
        internal ObservedIncomingHit(string key,string definition,IncomingCategory category,IncomingControl control,int element,float after,float raw,float final,float absorbed)
        {sourceKey=key;this.definition=definition;this.category=category;this.control=control;this.element=element;this.after=after;rawDamage=raw;finalDamage=final;this.absorbed=absorbed;hpLoss=Mathf.Max(0,final-absorbed);}
    }
    public sealed class IncomingForecast
    {
        public readonly Vector2 position;
        public readonly float seconds;
        public readonly IReadOnlyList<ObservedIncomingSource> sources;
        public readonly IReadOnlyList<ObservedIncomingHit> hits;
        public float HpLoss=>hits.Sum(h=>h.hpLoss);
        public float Absorbed=>hits.Sum(h=>h.absorbed);
        internal IncomingForecast(Vector2 position,float seconds,IEnumerable<ObservedIncomingSource> sources,IEnumerable<ObservedIncomingHit> hits)
        {this.position=position;this.seconds=seconds;this.sources=Array.AsReadOnly(sources.ToArray());this.hits=Array.AsReadOnly(hits.ToArray());}
        public float HpLossThrough(float seconds)=>hits.Where(h=>h.after<=seconds+.00001f).Sum(h=>h.hpLoss);
    }
}
