using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Hellscript
{
    public enum EdictLootMode { Ignore, Passing, AfterCombat, Priority }

    // Compile the document once. Independent rarity choices cannot be represented by one threshold.
    public sealed class EdictLootPolicy
    {
        static readonly string[] Grades={"NORMAL","MAGIC","RARE","LEGENDARY"};
        static readonly string[] Slots={"WEAPON","HEAD","CHEST","HANDS","FEET","WAIST","AMULET","RING"};
        readonly Dictionary<string,string> values;
        readonly HashSet<string> slots,effects;
        readonly int minimumLevel;
        public readonly float maximumPath;
        public readonly bool collectAtEnd,waitForDanger;
        public EdictLootPolicy(HuntEdictV2Document document)
        {
            values=HuntEdictV2.Canonical(document).global.ToDictionary(o=>o.id,o=>o.value,StringComparer.Ordinal);
            slots=new HashSet<string>(values["loot.slots"].Split(','),StringComparer.Ordinal);
            effects=new HashSet<string>(values["loot.exceptEffects"].Split(','),StringComparer.Ordinal);
            minimumLevel=int.Parse(values["loot.itemLevel"],CultureInfo.InvariantCulture);
            maximumPath=float.Parse(values["loot.distance"],CultureInfo.InvariantCulture);
            collectAtEnd=values["loot.finish"]=="COLLECT";waitForDanger=values["loot.danger"]=="WAIT";
        }
        public EdictLootMode Mode(Item item,HeroClass hero)
        {
            if(item==null||item.rarity<0||item.rarity>=Grades.Length||item.slot<0||item.slot>=Slots.Length)return EdictLootMode.Ignore;
            var unique=ItemCatalog.Unique(item.special);bool set=!string.IsNullOrEmpty(unique?.setId);
            string mode=values["loot."+(set?"SET":Grades[item.rarity])];
            if(mode=="IGNORE")return EdictLootMode.Ignore;
            bool exception=set?values["loot.exceptSet"]=="ON":item.rarity==3&&values["loot.exceptLegendary"]=="ON";
            exception|=!string.IsNullOrEmpty(item.special)&&effects.Contains(item.special);
            if(!exception)
            {
                int owner=unique!=null&&unique.heroClass>=0?unique.heroClass:ItemCatalog.Base(item).heroClass;
                if(values["loot.class"]=="OWN"&&owner>=0&&owner!=(int)hero||!slots.Contains(Slots[item.slot])||item.level<minimumLevel)return EdictLootMode.Ignore;
            }
            return mode=="PASSING"?EdictLootMode.Passing:mode=="PRIORITY"?EdictLootMode.Priority:EdictLootMode.AfterCombat;
        }
    }
}
