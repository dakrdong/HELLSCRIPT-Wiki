using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimeComparisonSmoke : MonoBehaviour
    {
        GameController game;
        string directory;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]static void Install()
        {
            if(!Environment.GetCommandLineArgs().Contains("-hellscriptComparisonSmoke"))return;
            Application.runInBackground=true;Application.logMessageReceived+=(m,s,t)=>{if(t==LogType.Exception)Application.Quit(1);};
            new GameObject("Training comparison validation").AddComponent<RuntimeComparisonSmoke>();
        }
        static void Require(bool condition,string reason){if(!condition)throw new InvalidOperationException(reason);}
        void Click(string prefix)=>game.UI.GetComponentsInChildren<Button>().Single(b=>b.name.StartsWith(prefix,StringComparison.Ordinal)).onClick.Invoke();
        void RequireButtonVisible(string prefix)
        {
            Canvas.ForceUpdateCanvases();var button=game.UI.GetComponentsInChildren<Button>().Single(b=>b.name.StartsWith(prefix,StringComparison.Ordinal));
            var corners=new Vector3[4];((RectTransform)button.transform).GetWorldCorners(corners);var scroll=button.GetComponentInParent<ScrollRect>();
            Require(corners.All(c=>c.x>=-1&&c.y>=-1&&c.x<=Screen.width+1&&c.y<=Screen.height+1),"Comparison button is outside the screen: "+prefix);
            if(scroll!=null)
            {
                var viewport=new Vector3[4];scroll.viewport.GetWorldCorners(viewport);
                float minX=viewport.Min(c=>c.x),maxX=viewport.Max(c=>c.x),minY=viewport.Min(c=>c.y),maxY=viewport.Max(c=>c.y);
                bool exact=corners.All(c=>RectTransformUtility.RectangleContainsScreenPoint(scroll.viewport,c));
                File.AppendAllText(Path.Combine(directory,"button-bounds.txt"),$"{prefix}: button x={corners.Min(c=>c.x):R}..{corners.Max(c=>c.x):R} y={corners.Min(c=>c.y):R}..{corners.Max(c=>c.y):R}; viewport x={minX:R}..{maxX:R} y={minY:R}..{maxY:R}; exactContains={exact}\n");
                // This UI uses an axis-aligned ScreenSpaceOverlay canvas; allow one screen pixel for scaled edge rounding.
                Require(corners.All(c=>c.x>=minX-1&&c.x<=maxX+1&&c.y>=minY-1&&c.y<=maxY+1),"Comparison button is outside its scroll viewport: "+prefix);
            }
        }
        static string Snapshot(AccountSave account)
        {var copy=JsonUtility.FromJson<AccountSave>(JsonUtility.ToJson(account));copy.lastSeenUtc=0;copy.speed=1;return JsonUtility.ToJson(copy);}
        static string Progress(AccountSave account)
        {
            var copy=JsonUtility.FromJson<AccountSave>(JsonUtility.ToJson(account));copy.lastSeenUtc=0;copy.speed=1;
            foreach(var hero in copy.heroes){hero.trainingComparison=null;hero.build=null;hero.presets.Clear();hero.guide=null;}return JsonUtility.ToJson(copy);
        }
        IEnumerator Until(Func<bool> ready,float seconds=40)
        {
            float deadline=Time.realtimeSinceStartup+seconds;while(!ready()&&Time.realtimeSinceStartup<deadline)yield return null;
            if(!ready()&&game.Combat!=null)File.WriteAllText(Path.Combine(directory,"timeout-run.json"),JsonUtility.ToJson(game.Combat.State,true));
            Require(ready(),"Comparison UI condition timed out.");
        }
        IEnumerator Capture(string name)
        {
            yield return new WaitForSecondsRealtime(.25f);Canvas.ForceUpdateCanvases();
            foreach(var b in game.UI.GetComponentsInChildren<Button>().Where(b=>b.transform.parent.name=="Footer"))
            {var corners=new Vector3[4];((RectTransform)b.transform).GetWorldCorners(corners);Require(corners.All(c=>c.x>=-1&&c.y>=-1&&c.x<=Screen.width+1&&c.y<=Screen.height+1),"Comparison footer is clipped.");}
            foreach(var t in game.UI.GetComponentsInChildren<Text>().Where(t=>t.transform.parent.name=="Text row"))
                Require(t.preferredHeight<=t.rectTransform.rect.height+1,"Comparison note is clipped: "+t.text);
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,name));yield return new WaitForSecondsRealtime(.25f);
        }
        void Distance(float value)
        {
            var slider=game.UI.GetComponentsInChildren<Slider>().Single(s=>s.transform.parent.GetComponentsInChildren<Text>().Any(t=>t.text.StartsWith("목표 거리",StringComparison.Ordinal)));slider.value=value;
        }
        void ScrollTo(string prefix)
        {
            Canvas.ForceUpdateCanvases();var label=game.UI.GetComponentsInChildren<Text>().Single(t=>t.text.StartsWith(prefix,StringComparison.Ordinal));
            var row=(RectTransform)label.transform.parent;var scroll=row.GetComponentInParent<ScrollRect>();
            scroll.content.anchoredPosition=new Vector2(0,Mathf.Clamp(-(row.localPosition.y+row.rect.yMax),0,Mathf.Max(0,scroll.content.rect.height-scroll.viewport.rect.height)));scroll.StopMovement();
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptScreenshots")directory=args[i+1];
            Require(args.Contains("-hellscriptSavePath")&&!string.IsNullOrEmpty(directory),"Comparison validation requires isolated save/evidence paths.");
            Directory.CreateDirectory(directory);Screen.SetResolution(540,960,FullScreenMode.Windowed);yield return new WaitForSecondsRealtime(1);game=FindAnyObjectByType<GameController>();
            if(args.Contains("-hellscriptComparisonResume"))
            {
                var expected=JsonUtility.FromJson<AccountSave>(File.ReadAllText(Path.Combine(directory,"expected-account.json")));Require(Snapshot(expected)==Snapshot(game.Store.Data),"Saved report, preset, applied build, or progress changed after actual restart.");
                Require(game.Comparison==null&&game.Store.Data.suspendedRun==null,"A training comparison resumed as a real rift.");
                var saved=game.Store.Data.Hero.trainingComparison;Require(saved.Complete&&game.Store.Data.Hero.presets[1].distance==5.5f&&game.Store.Data.Hero.build.distance==5.5f,"Explicit comparison choices were not restored.");
                game.UI.ShowComparisonPicker();Click("최근 저장한 비교");yield return Capture("11-restored-comparison.png");Click("변경한 조건 보기");yield return Capture("12-restored-change-list.png");
                File.WriteAllText(Path.Combine(directory,"runtime-comparison-smoke.txt"),"PASS: fresh Lv.1 owned mage, real 60-second A and B at 1x with the same baseline, mid-run build mutation blocked at controller, readonly comparison conditions and pause restoration, B slider preview/cancel/start, visible A/B battle titles and fixed B-edit footer, result-action jump with save/A/B buttons fully inside viewport, full statistics and changed conditions, explicit report save and slot 2 save, real-build preview/cancel/apply, actual process restart preserving report/preset/build/progress, no suspended training rift.\nRenderer="+SystemInfo.graphicsDeviceType+"\nScreen="+Screen.width+"x"+Screen.height+"\nUI callbacks; no physical touch, Android, human comprehension, or balance-completion claim.\n");
                Debug.Log("HELLSCRIPT_COMPARISON_RUNTIME_SMOKE_OK");Application.Quit(0);yield break;
            }
            game.SelectHero(2);var account=game.Store.Data;Require(account.Hero.level==1&&account.gold==0&&account.Hero.trainingComparison==null,"Use a fresh isolated comparison account.");
            string original=Snapshot(account),progress=Progress(account),originalBuild=JsonUtility.ToJson(account.Hero.build);
            game.UI.ShowTraining();Click("같은 조건으로 A/B 비교");yield return Capture("01-comparison-picker.png");Click("A/B 02");var first=game.Combat.State;first.paused=true;
            Require(game.UI.GetComponentsInChildren<Text>().Any(t=>t.text=="TRAINING / A · Lv.1"),"A battle title is missing.");yield return Capture("01b-a-battle.png");
            var illegal=first.build.Copy();illegal.distance=9;game.CommitBuild(illegal);Require(first.build.distance==7&&!first.statistics.buildChanged,"Controller accepted an in-run comparison edit.");
            Click("비교 조건");Require(first.paused&&game.UI.Page=="comparison-conditions","Comparison conditions are not readonly.");yield return Capture("02-fixed-comparison-conditions.png");Click("훈련으로 돌아가기");Require(first.paused,"Readonly conditions changed prior pause.");
            game.SetSpeed(1);first.paused=false;yield return Until(()=>!game.Active&&game.UI.Page=="comparison-result",90);Require(game.Comparison.HasA&&!game.Comparison.HasB,"A result missing.");Require(Snapshot(account)==original,"A changed the real account.");
            yield return Capture("03-completed-a.png");RequireButtonVisible("B 설정 만들기");Click("B 설정 만들기");Distance(5.5f);Require(game.UI.GetComponentsInChildren<Text>().Any(t=>t.text.Contains("7m → 거리 유지 5.5m")),"B live change preview missing.");yield return Capture("04-b-edit-preview.png");Click("취소");Require(Snapshot(account)==original&&game.Comparison.HasA&&!game.Comparison.HasB,"Cancel mutated the baseline or account.");
            Click("B 설정 만들기");Distance(5.5f);Click("B 훈련 시작");var second=game.Combat.State;
            Require(game.Comparison.IsB&&second.time==0&&second.health==game.Combat.Stats.hp&&second.resource==100&&second.statistics.damage==0,"B inherited A terminal state.");
            Require(second.build.distance==5.5f&&second.cooldowns.All(c=>c==0),"B setting or fresh cooldowns missing.");
            Require(game.UI.GetComponentsInChildren<Text>().Any(t=>t.text=="TRAINING / B · Lv.1"),"B battle title is missing.");second.paused=true;yield return Capture("04b-b-battle.png");second.paused=false;yield return Until(()=>!game.Active&&game.UI.Page=="comparison-result",90);
            var record=game.Comparison.Record();Require(record!=null&&record.Complete&&record.changes.Any(c=>c.Contains("5.5m")),"Completed A/B report missing.");Require(Snapshot(account)==original,"B changed the real account.");
            File.WriteAllText(Path.Combine(directory,"completed-comparison.json"),JsonUtility.ToJson(record,true));yield return Capture("05-completed-a-and-b.png");ScrollTo("스킬·효과별 전체 기록");yield return Capture("06-skill-statistics.png");
            RequireButtonVisible("저장·활용으로");Click("저장·활용으로");yield return Capture("06b-result-actions.png");
            foreach(string button in new[]{"이 비교 결과 저장","A 설정 활용","B 설정 활용"})RequireButtonVisible(button);
            ScrollTo("변경한 조건 보기");RequireButtonVisible("변경한 조건 보기");Click("변경한 조건 보기");yield return Capture("07-changed-conditions.png");Click("비교 결과로");Click("저장·활용으로");RequireButtonVisible("이 비교 결과 저장");Click("이 비교 결과 저장");Require(account.Hero.trainingComparison?.id==record.id,"Explicit comparison save failed.");
            Click("저장·활용으로");RequireButtonVisible("B 설정 활용");Click("B 설정 활용");yield return Capture("08-explicit-setting-choice.png");Click("슬롯 2에 선택한 설정 저장");Click("프리셋 저장");Require(account.Hero.presets[1].distance==5.5f&&JsonUtility.ToJson(account.Hero.build)==originalBuild,"Preset save changed current build or missed B.");
            Click("실제 행동 편집안으로 불러오기");Require(game.Comparison==null&&JsonUtility.ToJson(account.Hero.build)==originalBuild,"Preview applied settings early.");yield return Capture("09-real-build-preview.png");Click("취소");Require(JsonUtility.ToJson(account.Hero.build)==originalBuild,"Cancel changed actual build.");
            game.UI.ShowComparisonPicker();Click("최근 저장한 비교");Click("저장·활용으로");RequireButtonVisible("B 설정 활용");Click("B 설정 활용");Click("실제 행동 편집안으로 불러오기");Click("설정 적용");Require(account.Hero.build.distance==5.5f,"Explicit real build apply failed.");Require(Progress(account)==progress,"Comparison changed progression, equipment, currency, or rift records.");
            game.UI.ShowComparisonPicker();Click("최근 저장한 비교");yield return Capture("10-saved-comparison.png");game.Save();Require(string.IsNullOrEmpty(game.Store.Error),"Final comparison save failed.");
            File.WriteAllText(Path.Combine(directory,"expected-account.json"),JsonUtility.ToJson(account,true));Debug.Log("HELLSCRIPT_COMPARISON_CHECKPOINT_READY");Application.Quit(0);
        }
    }
}
