using System.Collections.Generic;
using System.Linq;

namespace Hellscript
{
    public sealed class EdictDifference
    {
        public readonly string group,label,current,incoming;
        internal EdictDifference(string group,string label,string current,string incoming)
        {this.group=group;this.label=label;this.current=current;this.incoming=incoming;}
        public override string ToString()=>Loc.F("{0} · {1}: {2} → {3}",group,label,current,incoming);
    }

    // What a received document would change about the hero's current one. Read-only: the caller
    // decides whether to apply anything, and both documents are canonicalized before comparing so
    // formatting differences never show up as changes.
    public static class HuntEdictV2Diff
    {
        public static IReadOnlyList<EdictDifference> Describe(HuntEdictV2Document current,HuntEdictV2Document incoming)
        {
            var result=new List<EdictDifference>();
            if(current==null||incoming==null)return result.AsReadOnly();
            var a=HuntEdictV2.Canonical(current);var b=HuntEdictV2.Canonical(incoming);
            if(a.heroClass!=b.heroClass)
            {
                result.Add(new EdictDifference("직업","사냥 칙령의 직업",a.heroClass,b.heroClass));
                return result.AsReadOnly();
            }
            for(int n=0;n<4;n++)
                if(a.slots[n]!=b.slots[n])
                    result.Add(new EdictDifference("사용 스킬",Loc.F("{0}번 칸", n+1),Slot(a.slots[n]),Slot(b.slots[n])));
            if(!a.skillOrder.SequenceEqual(b.skillOrder))
                result.Add(new EdictDifference("공격 순서","공통 공격 순서",string.Join(" → ",a.skillOrder),string.Join(" → ",b.skillOrder)));
            var labels=EdictOptions.Global.ToDictionary(o=>o.id,o=>o.label);
            foreach(var option in a.global)
            {
                string next=b.global.Single(o=>o.id==option.id).value;
                if(next!=option.value)result.Add(new EdictDifference("전역 설정",labels.TryGetValue(option.id,out var l)?l:option.id,option.value,next));
            }
            foreach(var skill in a.skills)
            {
                var other=b.skills.Single(s=>s.id==skill.id);
                var definitions=HuntEdictV2Options.ForSkill(skill.id,a.heroClass);
                foreach(var option in skill.options)
                {
                    string next=other.options.Single(o=>o.id==option.id).value;
                    if(next==option.value)continue;
                    var definition=definitions.SingleOrDefault(d=>d.id==option.id);
                    result.Add(new EdictDifference(skill.id,definition?.label??option.id,option.value,next));
                }
            }
            return result.AsReadOnly();
        }
        static string Slot(string id)=>id==""?"비어 있음":id;
    }
}
