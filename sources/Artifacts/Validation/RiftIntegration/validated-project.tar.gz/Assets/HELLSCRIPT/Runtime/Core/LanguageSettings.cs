using System;
using System.IO;
using System.Text;
using UnityEngine;

namespace Hellscript
{
    // Reading preference, kept in its own file for the same reason as the screen direction and the
    // reading size: a damaged preference must never disturb progress or the other two settings.
    public sealed class LanguageStore
    {
        [Serializable] sealed class Record { public int version; public string language; }
        public string Path { get; }
        public string Error { get; private set; } = "";
        public LanguageStore(string directory) { Path = System.IO.Path.Combine(directory, "hellscript-language-v1.json"); }
        public string Read()
        {
            Error = "";
            try
            {
                if (!File.Exists(Path)) return LanguageOptions.Default;
                if (new FileInfo(Path).Length > 1024) throw new InvalidDataException();
                var record = JsonUtility.FromJson<Record>(File.ReadAllText(Path));
                if (record == null || record.version != 1 || !LanguageOptions.IsSupported(record.language)) throw new InvalidDataException();
                return record.language;
            }
            catch (Exception) { Error = "언어 설정을 읽지 못했습니다. 기본 언어로 시작하며 기존 파일은 그대로 보존했습니다."; return LanguageOptions.Default; }
        }
        public bool Write(string language)
        {
            if (!LanguageOptions.IsSupported(language)) throw new ArgumentOutOfRangeException(nameof(language));
            Error = "";
            try
            {
                Directory.CreateDirectory(System.IO.Path.GetDirectoryName(Path));
                var record = new Record { version = 1, language = language };
                // Flush before the atomic replacement so a failed write leaves the previous preference intact.
                using (var stream = new FileStream(Path + ".tmp", FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    byte[] bytes = Encoding.UTF8.GetBytes(JsonUtility.ToJson(record));
                    stream.Write(bytes, 0, bytes.Length); stream.Flush(true);
                }
                if (File.Exists(Path)) File.Replace(Path + ".tmp", Path, null); else File.Move(Path + ".tmp", Path);
                return true;
            }
            catch (Exception) { Error = "선택한 언어는 화면에 적용했지만 기기에 저장하지 못했습니다. 저장을 다시 시도해 주세요."; return false; }
        }
    }

    // The chosen language always reaches the screen immediately; only the device file can fail.
    // A language whose table is missing is still applied, and the lines without a translation stay
    // in Korean rather than leaving the screen empty.
    public sealed class LanguageSession
    {
        readonly Func<string, bool> save;
        readonly Func<string, LocalizationTable.Result> load;
        public string Language { get; private set; }
        public string Saved { get; private set; }
        public bool CanRetrySave { get; private set; }
        public string Message { get; private set; } = "";
        public int Entries { get; private set; }
        public LanguageSession(string saved, Func<string, bool> save, Func<string, LocalizationTable.Result> load)
        {
            this.save = save ?? throw new ArgumentNullException(nameof(save));
            this.load = load ?? throw new ArgumentNullException(nameof(load));
            Language = Saved = LanguageOptions.Nearest(saved);
            ApplyTable(Language);
        }
        void ApplyTable(string code)
        {
            var option = LanguageOptions.Find(code);
            LocalizationTable.Result loaded = null;
            if (option != null && option.NeedsTable) { try { loaded = load(code); } catch (Exception) { loaded = null; } }
            Entries = loaded?.Entries.Count ?? 0;
            Loc.Use(code, loaded?.Entries);
        }
        public bool Apply(string code)
        {
            string chosen = LanguageOptions.Nearest(code);
            Language = chosen; ApplyTable(chosen);
            string name = LanguageOptions.Find(chosen).NativeName;
            bool missingTable = LanguageOptions.Find(chosen).NeedsTable && Entries == 0;
            bool success; try { success = save(chosen); } catch (Exception) { success = false; }
            CanRetrySave = !success;
            if (success) { Saved = chosen; Message = Loc.F("언어를 {0}로 적용하고 이 기기에 저장했습니다.", name); }
            else Message = Loc.F("언어 {0}를 지금 화면에 적용했지만 기기에 저장하지 못했습니다. 다시 시도하지 않으면 다음 실행에는 저장해 둔 {1}를 사용합니다.", name, LanguageOptions.Find(Saved).NativeName);
            if (missingTable) Message += Loc.T("\n번역 파일을 찾지 못해 번역이 없는 줄은 한국어로 표시합니다.");
            return success;
        }
        public bool RetrySave() => CanRetrySave && Apply(Language);
    }
}
