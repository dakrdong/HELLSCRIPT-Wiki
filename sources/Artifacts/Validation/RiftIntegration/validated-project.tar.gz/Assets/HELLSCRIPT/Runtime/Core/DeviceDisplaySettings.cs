using System;
using System.IO;
using System.Text;
using UnityEngine;

namespace Hellscript
{
    public enum DeviceScreenDirection { Portrait, Landscape }

    // Deliberately separate from AccountSave, BuildConfig and share codes.
    public sealed class DeviceDisplayStore
    {
        [Serializable] sealed class Record { public int version; public string direction; }
        public string Path { get; }
        public string Error { get; private set; } = "";
        public DeviceDisplayStore(string directory) { Path = System.IO.Path.Combine(directory, "hellscript-display-v1.json"); }
        public DeviceScreenDirection Read()
        {
            Error = "";
            try
            {
                if (!File.Exists(Path)) return DeviceScreenDirection.Portrait;
                if (new FileInfo(Path).Length > 1024) throw new InvalidDataException();
                var record = JsonUtility.FromJson<Record>(File.ReadAllText(Path));
                if (record == null || record.version != 1 || (record.direction != "portrait" && record.direction != "landscape")) throw new InvalidDataException();
                return record.direction == "landscape" ? DeviceScreenDirection.Landscape : DeviceScreenDirection.Portrait;
            }
            catch (Exception) { Error = "화면 설정을 읽지 못했습니다. 기본 세로 방향으로 시작합니다. 기존 파일은 유지됩니다."; return DeviceScreenDirection.Portrait; }
        }
        public bool Write(DeviceScreenDirection direction)
        {
            if (!Enum.IsDefined(typeof(DeviceScreenDirection), direction)) throw new ArgumentOutOfRangeException(nameof(direction));
            Error = "";
            try
            {
                Directory.CreateDirectory(System.IO.Path.GetDirectoryName(Path));
                var record = new Record { version = 1, direction = direction == DeviceScreenDirection.Portrait ? "portrait" : "landscape" };
                // Flush before the atomic replacement; failed writes leave the previous preference intact.
                using (var stream = new FileStream(Path + ".tmp", FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    byte[] bytes = Encoding.UTF8.GetBytes(JsonUtility.ToJson(record));
                    stream.Write(bytes, 0, bytes.Length); stream.Flush(true);
                }
                if (File.Exists(Path)) File.Replace(Path + ".tmp", Path, null); else File.Move(Path + ".tmp", Path);
                return true;
            }
            catch (Exception) { Error = "현재 방향은 적용됐지만 기기에 저장하지 못했습니다. 저장을 다시 시도해 주세요."; return false; }
        }
    }

    // Completion tokens keep an older platform acknowledgement from committing a newer selection.
    public sealed class DisplaySettingsSession
    {
        readonly Func<DeviceScreenDirection, bool> save;
        long generation;
        bool persistRequest;
        public bool Mobile { get; }
        public DeviceScreenDirection Actual { get; private set; }
        public DeviceScreenDirection Saved { get; private set; }
        public DeviceScreenDirection Requested { get; private set; }
        public long Pending { get; private set; }
        public bool CanRetrySave { get; private set; }
        public string Message { get; private set; } = "";
        public DisplaySettingsSession(bool mobile, DeviceScreenDirection actual, DeviceScreenDirection saved, Func<DeviceScreenDirection, bool> save)
        { Mobile = mobile; Actual = actual; Saved = saved; Requested = actual; this.save = save ?? throw new ArgumentNullException(nameof(save)); }
        public void Observe(DeviceScreenDirection actual)
        { if (Actual != actual) CanRetrySave = false; Actual = actual; }
        public long Request(DeviceScreenDirection direction, bool persist = true)
        {
            if (!Enum.IsDefined(typeof(DeviceScreenDirection), direction)) throw new ArgumentOutOfRangeException(nameof(direction));
            if (!Mobile) return 0;
            Requested = direction; persistRequest = persist; Pending = ++generation;
            CanRetrySave = false; Message = "화면 방향을 적용하고 있습니다."; return Pending;
        }
        public bool Complete(long token, DeviceScreenDirection actual, bool platformConfirmed)
        {
            if (token == 0 || token != Pending) return false;
            Observe(actual); Pending = 0;
            if (!platformConfirmed || actual != Requested)
            { Message = "요청한 방향을 적용하지 못했습니다. 현재 표시 방향을 유지합니다. 다시 적용할 수 있습니다."; return false; }
            if (!persistRequest) { Message = "저장된 화면 방향으로 시작했습니다."; return true; }
            return PersistActual();
        }
        bool PersistActual()
        {
            bool success; try { success = save(Actual); } catch (Exception) { success = false; }
            CanRetrySave = !success;
            if (success) { Saved = Actual; Message = "화면 방향을 적용하고 이 기기에 저장했습니다."; }
            else Message = "현재 방향은 적용됐지만 기기에 저장하지 못했습니다. 저장을 다시 시도해 주세요. 다음 실행에는 이전 저장값을 사용합니다.";
            return success;
        }
        public bool RetrySave() => Mobile && Pending == 0 && CanRetrySave && PersistActual();
    }
}
