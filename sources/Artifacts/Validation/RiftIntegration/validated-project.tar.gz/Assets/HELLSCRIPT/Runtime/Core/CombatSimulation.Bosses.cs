using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        void TickBossTimers(EnemyState e,float dt)
        {
            var b=e.brain.boss;
            if(!b.initialized){b.initialized=true;for(int n=0;n<3;n++)b.cooldowns[n]=e.cooldown;}
            for(int n=0;n<3;n++)b.cooldowns[n]=Mathf.Max(0,b.cooldowns[n]-dt);
            b.planRetry=Mathf.Max(0,b.planRetry-dt);e.cooldown=b.cooldowns.Min();
        }
        void InterruptBossAction(EnemyState e,string reason)
        {
            var a=e.brain.action;
            if(a.phase==EnemyActionPhase.Idle)
            {
                // A scalar preparation in an old snapshot has not acquired an explicit action yet.
                if(e.windup>0){e.windup=0;e.cooldown=Mathf.Max(e.cooldown,6);if(e.brain.boss.initialized)for(int n=0;n<3;n++)e.brain.boss.cooldowns[n]=Mathf.Max(e.brain.boss.cooldowns[n],6);}
                return;
            }
            if(!a.released)e.brain.boss.refuges.Clear();
            InterruptEnemyAction(e,reason);
        }
        bool SummonPositionFree(EnemyState boss,Vector2 point)
            =>Map.CanLand(point,.4f)&&Map.Reachable(point)&&Map.LineClear(boss.position,point)&&State.enemies.All(e=>e.dead||Vector2.Distance(e.position,point)>=(e.boss?1.2f:.4f)+.4f+.1f)&&Vector2.Distance(State.position,point)>=.95f;
        List<Vector2> SummonPoints(EnemyState boss)
        {
            int count=Mathf.Min(4,8-State.enemies.Count(e=>!e.dead&&BossCombat.OwnAdd(e,boss)));var result=new List<Vector2>();if(count<=0)return result;
            foreach(float radius in new[]{3f,4.5f,6f})for(int n=0;n<12;n++)
            {var point=boss.position+EnemyCombat.Rotate(boss.brain.facing,n*30)*radius;if(!SummonPositionFree(boss,point)||result.Any(p=>Vector2.Distance(p,point)<.9f))continue;result.Add(point);if(result.Count==count)return result;}
            return result;
        }
        bool BeginBossAction(EnemyState e,BossAttack kind,int slot)
        {
            var def=BossCombat.Attack(kind);var b=e.brain.boss;List<Vector2> points=null;List<BossRefuge> refuges=null;
            if(kind==BossAttack.Summon)
            {points=SummonPoints(e);if(points.Count==0){b.planRetry=1;return false;}}
            if(kind==BossAttack.Blasts&&!BossCombat.TryBlastPlan(State,Map,e,MovementSpeed(false)*(State.enemySlowTime>0?.65f:1),out points,out refuges))
            {b.planRetry=1;EnemyEvent(e,"PLAN_DEFERRED",BossCombat.Definition((int)kind));return false;}
            var a=new EnemyActionState{id=State.nextId++,kind=(int)kind,phase=EnemyActionPhase.Preparing,origin=e.position,aim=State.position,remaining=def.preparation,preparation=def.preparation,empowered=b.enraged,
                remainingCharges=kind==BossAttack.Slam||kind==BossAttack.Charge?(b.enraged?2:1):0,points=points??new List<Vector2>()};
            a.direction=(a.aim-a.origin).normalized;if(a.direction==Vector2.zero)a.direction=e.brain.facing;
            if(kind==BossAttack.Charge)a.aim=Map.MoveDirect(a.origin,a.origin+a.direction*8,8,1.2f);
            if(kind==BossAttack.Hook||kind==BossAttack.Beam)a.aim=Map.ProjectileEnd(a.origin,a.origin+a.direction*def.range,kind==BossAttack.Hook?.5f:.75f,out _);
            b.cooldowns[slot]=def.cooldown;e.cooldown=b.cooldowns.Min();e.brain.action=a;e.brain.facing=a.direction;e.aim=a.aim;e.windup=a.remaining;
            if(refuges!=null)b.refuges=refuges;
            EnemyMode(e,Loc.F("{0} 준비", BossCombat.Name(a.kind)));EnemyEvent(e,"PREPARE",BossCombat.Definition(a.kind),a.id,a.remaining,a.aim);return true;
        }
        void ReleaseBossAction(EnemyState e)
        {
            var a=e.brain.action;var kind=(BossAttack)a.kind;float attack=EnemyAttackValue(e);string definition=BossCombat.Definition(a.kind);
            EnemyEvent(e,"RELEASE",definition,a.id);a.released=true;e.windup=0;
            if(kind==BossAttack.Charge)
            {a.phase=EnemyActionPhase.Charging;a.damage=attack*1.5f;a.moved=0;a.hitHero=false;EnemyMode(e,"돌진");return;}
            if(kind==BossAttack.Hook)
                State.projectiles.Add(new CombatProjectile{id=State.nextId++,actionId=a.id,hostile=true,casterId=e.id.ToString(),definitionId=definition,origin=a.origin,position=a.origin,direction=a.direction,remaining=10,speed=12,radius=.5f,damage=attack,pullDistance=2,createdAt=State.time});
            else if(kind==BossAttack.Beam)
            {
                State.enemyHazards.Add(new EnemyHazard{id=State.nextId++,actionId=a.id,enemyId=e.id,definitionId=definition,shape=AttackShape.Line,position=a.origin,end=a.aim,direction=a.direction,
                    radius=.75f,createdAt=State.time,duration=2,interval=.25f,tick=.25f,damage=attack*.375f,element=5});
                a.phase=EnemyActionPhase.Recovering;a.remaining=2;EnemyMode(e,"집중 광선 유지");return;
            }
            else if(kind==BossAttack.Summon)
            {
                int spawned=0;
                foreach(var point in a.points)
                {
                    if(State.enemies.Count(x=>!x.dead&&BossCombat.OwnAdd(x,e))>=8)break;if(!SummonPositionFree(e,point))continue;
                    SpawnEnemy(Map.ClosestRoom(point),0,point,-1,false,true);State.enemies[State.enemies.Count-1].summonerId=e.id;spawned++;
                }
                EnemyEvent(e,"SUMMONED",definition,a.id,spawned);
            }
            else if(kind==BossAttack.Blasts)
            {
                for(int i=0;i<a.points.Count;i++)CreateEnemyHazard(e,definition,a.points[i],i*.35f,0,attack*1.5f,5,action:a.id);
                // The first impact is due at release; later independent impacts keep their own saved delays.
                var first=State.enemyHazards.Last(h=>h.actionId==a.id&&h.delay<=0);ApplyEnemyHazard(first);State.enemyHazards.Remove(first);
                a.phase=EnemyActionPhase.Recovering;a.remaining=.7f;EnemyMode(e,"연속 폭발 진행");return;
            }
            else if(kind==BossAttack.Legacy)
            {
                if(e.pattern==1)AddGround(a.aim,2.5f,0,2,attack*1.5f,true,4,caster:e.id.ToString(),definition:definition);
                else{if(Vector2.Distance(State.position,a.aim)<3&&Map.LineClear(e.position,State.position))Hurt(attack*2,0,e.id.ToString(),definition,a.id,a.id);if(e.pattern==2)e.position=Map.MoveDirect(e.position,a.aim,8,1.2f);}
                for(int n=0;n<3;n++)e.brain.boss.cooldowns[n]=6;
            }
            else
            {
                var shape=new EnemyThreat("",definition,AttackShape.Sector,a.origin,a.aim,a.direction,kind==BossAttack.Slam?4:3);
                if(EnemyCombat.Contains(shape,State.position)&&Map.LineClear(a.origin,State.position))Hurt(attack*(kind==BossAttack.Slam?2:1),0,e.id.ToString(),definition,a.id,a.id);
                if(kind==BossAttack.Slam&&--a.remainingCharges>0)
                {a.released=false;a.phase=EnemyActionPhase.Preparing;a.remaining=a.preparation=.7f;e.windup=.7f;EnemyMode(e,"내려찍기 추가타 준비");EnemyEvent(e,"FOLLOWUP_PREPARE",definition,a.id,.7f,a.aim);return;}
            }
            FinishEnemyAction(e);
        }
        void TickBossAction(EnemyState e,float dt)
        {
            var a=e.brain.action;
            if(a.phase==EnemyActionPhase.Preparing)
            {a.remaining=Mathf.Max(0,a.remaining-dt);e.windup=a.remaining;if(a.remaining<=.00001f)ReleaseBossAction(e);return;}
            if(a.phase==EnemyActionPhase.Recovering)
            {a.remaining=Mathf.Max(0,a.remaining-dt);if(a.remaining<=.00001f)FinishEnemyAction(e);return;}
            if(a.phase!=EnemyActionPhase.Charging)return;
            Vector2 from=e.position,to=Map.MoveDirect(from,a.aim,Mathf.Min(10*dt,Mathf.Max(0,8-a.moved)),1.2f);float moved=Vector2.Distance(from,to);a.moved+=moved;e.position=to;
            if(!a.hitHero&&!float.IsInfinity(Entry(from,to,State.position,.95f))&&Map.LineClear(from,State.position))
            {a.hitHero=true;Hurt(a.damage,0,e.id.ToString(),BossCombat.Definition(a.kind),a.id,a.id);}
            if(moved>.00001f&&Vector2.Distance(to,a.aim)>.01f&&a.moved<8-.0001f)return;
            if(--a.remainingCharges>0)
            {
                a.origin=e.position;a.direction=(e.lastSeenPosition-e.position).normalized;if(a.direction==Vector2.zero)a.direction=e.brain.facing;
                a.aim=Map.MoveDirect(a.origin,a.origin+a.direction*8,8,1.2f);a.phase=EnemyActionPhase.Preparing;a.preparation=a.remaining=.8f;a.released=false;e.aim=a.aim;e.windup=.8f;e.brain.facing=a.direction;
                EnemyMode(e,"두 번째 돌진 준비");EnemyEvent(e,"FOLLOWUP_PREPARE",BossCombat.Definition(a.kind),a.id,.8f,a.aim);
            }
            else FinishEnemyAction(e);
        }
        void TickBoss(EnemyState e,float dt)
        {
            float distance=Vector2.Distance(e.position,State.position);bool visible=distance<=14&&Map.LineClear(e.position,State.position);var b=e.brain.boss;
            if(!b.enraged&&e.health<=e.maxHealth*.5f)b.enragePending=true;
            if(visible){e.lastSeenTime=State.time;e.lastSeenPosition=State.position;}
            if(e.brain.action.phase==EnemyActionPhase.Idle&&e.windup>0)
            {
                var direction=(e.aim-e.position).normalized;e.brain.action=new EnemyActionState{id=State.nextId++,kind=(int)BossAttack.Legacy,phase=EnemyActionPhase.Preparing,origin=e.position,aim=e.aim,direction=direction,remaining=e.windup,preparation=e.windup};
            }
            if(e.brain.action.phase!=EnemyActionPhase.Idle){TickBossAction(e,dt);return;}
            if(!b.enraged&&b.enragePending){b.enraged=true;b.enragePending=false;EnemyEvent(e,"ENRAGED","BOSS0"+(e.pattern+1));}
            if(!visible&&State.time-e.lastSeenTime>4){EnemyMode(e,"목표 상실");return;}
            BossAttack first=e.pattern==0?BossAttack.Slam:e.pattern==1?BossAttack.Summon:BossAttack.Charge;
            BossAttack second=e.pattern==0?BossAttack.Hook:e.pattern==1?BossAttack.Beam:BossAttack.Blasts;
            foreach(var candidate in new[]{(kind:first,slot:1),(kind:second,slot:2),(kind:BossAttack.Basic,slot:0)})
            {
                var def=BossCombat.Attack(candidate.kind);
                if(!visible||b.cooldowns[candidate.slot]>.00001f||distance>def.range||(candidate.kind==BossAttack.Summon||candidate.kind==BossAttack.Blasts)&&b.planRetry>0)continue;
                if((candidate.kind==BossAttack.Hook||candidate.kind==BossAttack.Beam)&&!Map.ProjectileClear(e.position,State.position,candidate.kind==BossAttack.Hook?.5f:.75f))continue;
                if(BeginBossAction(e,candidate.kind,candidate.slot))return;
            }
            bool blockedShot=e.pattern==1&&visible&&!Map.ProjectileClear(e.position,State.position,.75f);
            if(distance>(e.pattern==1?8:2.5f)||!visible||blockedShot)
            {
                Vector2 before=e.position;e.position=Map.Move(e.position,e.lastSeenPosition,e.speed*(e.pattern==1?.35f:1)*dt,e.id+1,State.time,1.2f);
                if(before!=e.position)e.brain.facing=(e.position-before).normalized;EnemyMode(e,"추적");
            }
            else EnemyMode(e,"재사용 대기");
        }
        void PullHero(CombatProjectile projectile)
        {
            if(State.health<=0||!Map.CanLand(State.position))return;
            Vector2 from=State.position;float distance=Mathf.Min(projectile.pullDistance,Mathf.Max(0,Vector2.Distance(from,projectile.origin)-1.65f));
            Vector2 to=Map.MoveDirect(from,projectile.origin,distance);
            foreach(var enemy in State.enemies.Where(e=>!e.dead))
            {float t=Entry(from,to,enemy.position,(enemy.boss?1.2f:.4f)+.45f);if(!float.IsInfinity(t))to=Vector2.Lerp(from,to,Mathf.Max(0,t-.001f));}
            if(Vector2.Distance(from,to)<.001f||!Map.CanLand(to))return;
            InterruptHeroAction("갈고리에 끌림");State.position=State.destination=to;Map.Repath();State.decisionTime=0;
            EffectEvent("BOSS01_HOOK","PULLED",root:projectile.actionId,instance:projectile.id,value:Vector2.Distance(from,to));
        }
        void ClearFinishedBossRefuges()
        {
            foreach(var e in State.enemies.Where(e=>e.boss&&e.brain.boss.refuges.Count>0))
            {
                var a=e.brain.action;bool preparing=a.kind==(int)BossAttack.Blasts&&a.phase==EnemyActionPhase.Preparing;
                if(!preparing&&!State.enemyHazards.Any(h=>h.enemyId==e.id&&h.definitionId=="BOSS03_BLAST"))e.brain.boss.refuges.Clear();
            }
        }
    }
}
