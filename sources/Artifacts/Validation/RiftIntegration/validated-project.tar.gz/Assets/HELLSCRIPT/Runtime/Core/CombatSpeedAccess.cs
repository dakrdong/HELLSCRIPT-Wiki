namespace Hellscript
{
    // Current release access only. Simulation ticks remain independent of this policy.
    // Subscription authority and timed passes are deferred to the server/BM phase.
    public static class CombatSpeedAccess
    {
        public const string LockedMessage = "현재는 사용할 수 없는 배속입니다";
        public static bool CanSelect(float requested) => requested == 1f;
        public static float Resolve(float storedOrRequested) => 1f;
    }
}
