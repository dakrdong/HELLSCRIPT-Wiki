using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Explicit, isolated development fixture. Never enabled in an ordinary player session.
    public sealed class RuntimeRaritySmoke : MonoBehaviour
    {
        GameController game;
        string directory;
        int capture;
        static void Require(bool value,string message){if(!value)throw new InvalidOperationException(message);}
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if(!Debug.isDebugBuild||!Environment.GetCommandLineArgs().Contains("-hellscriptRaritySmoke"))return;
            Application.runInBackground=true;
            Application.logMessageReceived+=(m,s,t)=>{if(t==LogType.Exception)Application.Quit(1);};
            new GameObject("Rarity reward validation").AddComponent<RuntimeRaritySmoke>();
        }
        IEnumerator Capture(string label,int width,int height,float scroll=1)
        {
            Screen.SetResolution(width,height,FullScreenMode.Windowed);
            float end=Time.realtimeSinceStartup+6;
            while((Screen.width!=width||Screen.height!=height)&&Time.realtimeSinceStartup<end)yield return null;
            Require(Screen.width==width&&Screen.height==height,"Native window resize failed.");
            yield return new WaitForSecondsRealtime(.4f);
            foreach(var view in game.UI.GetComponentsInChildren<ScrollRect>())view.verticalNormalizedPosition=scroll;
            Canvas.ForceUpdateCanvases();yield return new WaitForSecondsRealtime(.15f);
            foreach(var text in game.UI.GetComponentsInChildren<Text>())
                Require(text.preferredHeight<=text.rectTransform.rect.height+1,"Clipped reward text: "+text.text);
            Require(Loc.MissingCount==0,"Reward screen has untranslated text: "+string.Join("; ",Loc.Missing));
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,$"{++capture:00}-{label}.png"));
            yield return new WaitForSecondsRealtime(.2f);
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();
            Require(args.Contains("-hellscriptSavePath"),"Use an isolated account.");
            for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptScreenshots")directory=args[i+1];
            Require(!string.IsNullOrEmpty(directory),"Use a dedicated evidence directory.");Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1);
            game=FindAnyObjectByType<GameController>();game.enabled=false;
            game.Store.Data.Hero.highestClear=50;game.SelectedStage=10;
            game.Store.Data.guide.hintsHidden=true;
            game.ApplyLanguage("ko");game.UI.ShowRiftKeeper();
            var button=game.UI.GetComponentsInChildren<Button>().Single(b=>b.onClick!=null&&b.GetComponentInChildren<Text>()?.text==Loc.T("단계별 등급 확률"));
            button.onClick.Invoke();
            string before=JsonUtility.ToJson(game.Store.Data);
            yield return Capture("korean-portrait-top",720,1280);
            yield return Capture("korean-portrait-sweep",720,1280,0);
            game.ApplyLanguage("en");game.UI.ShowRiftRewards();
            yield return Capture("english-wide-top",1280,720);
            yield return Capture("english-portrait-sweep",720,1280,0);
            Require(before==JsonUtility.ToJson(game.Store.Data),"Viewing reward probabilities changed account state.");
            game.Begin(seed:91367);game.Combat.State.paused=true;
            game.SelectedStage=1;game.UI.ShowRiftRewards();
            Require(game.UI.GetComponentsInChildren<Text>().Any(t=>t.text.Contains("Rift 10")),"Active run stage was replaced by selected stage or highest record.");
            yield return Capture("active-stage10-record50",1280,720);
            File.WriteAllText(Path.Combine(directory,"runtime-rarity-smoke.txt"),"PASS: native macOS development player; keeper reward button; Korean and English; 720x1280 and 1280x720; no clipped labels or missing translations; viewing does not mutate account; current stage 10 survives selected stage 1 and highest record 50.\nThis is an automated UI/flow fixture, not a drop-balance playtest.\n");
            Debug.Log("HELLSCRIPT_RARITY_RUNTIME_OK");Application.Quit(0);
        }
    }
}
