using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Hellscript
{
    // Single-step edits for the editor. Every call canonicalizes first and returns a new document,
    // so the caller's draft is never left half-changed by a rejected value.
    public static class HuntEdictV2Editing
    {
        public static HuntEdictV2Document WithGlobal(HuntEdictV2Document source,string id,string value)
        {
            var next=HuntEdictV2.Canonical(source);
            var definition=EdictOptions.Global.SingleOrDefault(o=>o.id==id)??throw new ArgumentException(Loc.F("알 수 없는 전역 설정입니다: {0}", id));
            next.global.Single(o=>o.id==id).value=definition.CanonicalValue(value,next.heroClass);
            return HuntEdictV2.Canonical(next);
        }

        // Numbers move by their declared step in decimal so a 0.1 step never drifts off the grid.
        public static string Stepped(EdictOptionDefinition definition,string value,int direction)
        {
            if(definition.kind!=EdictOptionKind.Number)throw new ArgumentException(Loc.F("{0}: 숫자 설정이 아닙니다.", definition.id));
            decimal current=decimal.Parse(definition.CanonicalValue(value,"WARRIOR"),CultureInfo.InvariantCulture);
            decimal min=(decimal)definition.min,max=(decimal)definition.max,step=(decimal)definition.step;
            decimal next=Math.Min(max,Math.Max(min,current+step*Math.Sign(direction)));
            next=min+Math.Round((next-min)/step)*step;
            return next==0?"0":next.ToString("0.###",CultureInfo.InvariantCulture);
        }
        public static string Stepped(EdictCoreOptionDefinition definition,string value,int direction)
        {
            if(!definition.Numeric)throw new ArgumentException(Loc.F("{0}: 숫자 설정이 아닙니다.", definition.id));
            decimal current=decimal.Parse(definition.CanonicalValue(value),CultureInfo.InvariantCulture);
            decimal next=Math.Min(definition.max,Math.Max(definition.min,current+definition.step*Math.Sign(direction)));
            next=definition.min+Math.Round((next-definition.min)/definition.step)*definition.step;
            return next==0?"0":next.ToString("0.###",CultureInfo.InvariantCulture);
        }

        public static string NextChoice(IReadOnlyList<string> choices,string value,int direction=1)
        {
            int index=choices.ToList().IndexOf(value);if(index<0)index=0;
            return choices[((index+Math.Sign(direction))%choices.Count+choices.Count)%choices.Count];
        }

        // Order values are comma lists that must keep every item exactly once; only neighbours swap.
        public static string MovedInOrder(string value,string item,int delta)
        {
            var items=value.Split(',').ToList();int index=items.IndexOf(item);
            if(index<0)throw new ArgumentException(Loc.F("순서 목록에 없는 항목입니다: {0}", item));
            int target=index+Math.Sign(delta);if(target<0||target>=items.Count)return value;
            (items[index],items[target])=(items[target],items[index]);return string.Join(",",items);
        }
        public static string ToggledInSet(EdictOptionDefinition definition,string value,string item)
        {
            if(definition.kind!=EdictOptionKind.Set)throw new ArgumentException(Loc.F("{0}: 복수 선택 설정이 아닙니다.", definition.id));
            if(!definition.choices.Contains(item))throw new ArgumentException(Loc.F("{0}: 선택할 수 없는 항목입니다: {1}", definition.id, item));
            var selected=(value==""?Array.Empty<string>():value.Split(',')).ToList();
            if(selected.Contains(item))selected.Remove(item);else selected.Add(item);
            // Canonical order is the declared choice order, never the order the player clicked in.
            return string.Join(",",definition.choices.Where(selected.Contains));
        }

        public static HuntEdictV2Document WithSkillOrderMoved(HuntEdictV2Document source,string skillId,int delta)
        {
            var next=HuntEdictV2.Canonical(source);
            next.skillOrder=MovedInOrder(string.Join(",",next.skillOrder),skillId,delta).Split(',');
            return HuntEdictV2.Canonical(next);
        }
    }

    // Korean names for the wire values and groups of the global options. The wire format keeps its
    // identifiers; only what the player reads changes here.
    public static class EdictOptionLabels
    {
        static readonly Dictionary<string,string> Groups=new Dictionary<string,string>(StringComparer.Ordinal)
        {
            {"dodge","회피 규칙"},{"survival","긴급 생존·회복"},{"position","전투 위치·몰이"},{"target","공격 대상·추적"},
            {"loot","전리품 회수"},{"bag","가방·자동 정리"},{"explore","탐색·상호작용"},{"repeat","반복 사냥·중단"},{"common","공통 적용 기준"}
        };
        public static readonly string[] GroupOrder={"survival","dodge","position","target","loot","bag","explore","repeat","common"};
        public static string Group(string id)=>Groups.TryGetValue(id,out var label)?label:id;

        static readonly Dictionary<string,string> Rarity=new Dictionary<string,string>(StringComparer.Ordinal)
        {{"NORMAL","일반"},{"MAGIC","마법"},{"RARE","희귀"},{"LEGENDARY","전설"},{"SET","세트"}};

        static readonly Dictionary<string,Dictionary<string,string>> Values=Build();
        static Dictionary<string,Dictionary<string,string>> Build()
        {
            var v=new Dictionary<string,Dictionary<string,string>>(StringComparer.Ordinal);
            void Add(string prefix,params (string code,string label)[] pairs)
            {var map=new Dictionary<string,string>(StringComparer.Ordinal);foreach(var p in pairs)map[p.code]=p.label;v[prefix]=map;}
            var collect=new[]{("IGNORE","획득 안 함"),("PASSING","지나가며 획득"),("AFTER_COMBAT","전투 후"),("PRIORITY","전투 중 우선")};
            Add("dodge.policy",("OFF","사용 안 함"),("ALWAYS","항상 회피 시도"),("DAMAGE","피해 기준으로 회피"));
            Add("dodge.control",("STUN","기절"),("FREEZE","빙결"),("ROOT","속박"),("PULL","끌어당기기"));
            Add("dodge.method",("WALK_FIRST","걷기 우선"),("SKILL_FIRST","회피기 우선"),("SKILL_IF_NEEDED","걷기로 어려울 때 회피기"));
            Add("dodge.interrupt",("CANCEL_ALLOWED","중단 가능한 공격 취소"),("FINISH","현재 공격 완료 후 회피"));
            Add("survival.order",("DEFENSE","지정 방어기"),("ESCAPE","지정 회피기"),("WALK","보행 후퇴"));
            Add("survival.fallback",("WALK","보행 후퇴"),("OTHER_SKILL","다른 지정 생존기"),("KEEP_FIGHTING","전투 유지"));
            Add("position.engage",("APPROACH","즉시 접근"),("STAND","제자리에서 맞이"),("DISTANCE","거리 유지"),("LURE","길목 유인"));
            Add("position.mode",("CENTER","무리 중심"),("EDGE","가장자리"),("DISTANCE","거리 유지"),("ORBIT","선회"),("STAND","제자리"));
            Add("position.distanceSource",("BASIC_RANGE","기본 공격 사거리 기준"),("EXPLICIT","직접 지정"));
            Add("position.surrounded",("FIGHT_CENTER","중심에서 전투"),("MOVE_EDGE","외곽으로 이탈해 한쪽에 모으기"),("ESCAPE","회피기 이탈"));
            Add("target.default",("NEAREST","가까운 적"),("LOW_HP","낮은 HP"),("HIGH_HP","높은 HP"),("DENSE","밀집한 곳"));
            Add("target.special",("BOSS","보스"),("ELITE","정예"),("SUPPORT","회복·지원형"),("RANGED","원거리형"));
            Add("target.switch",("UNTIL_DEATH","처치까지 유지"),("PRIORITY","더 높은 우선순위로 변경"));
            Add("target.lostSight",("STOP","추적 중단"),("LAST_SEEN","마지막으로 본 위치까지 확인"));
            Add("target.bossFight",("BOSS","보스 우선"),("ADDS","소환된 적 우선"),("DANGEROUS_SUPPORT","위험한 지원형 먼저"));
            Add("loot.collect",collect);
            Add("loot.gold",("PASSING","지나가며 획득"),("AFTER_COMBAT","전투 후 추적"),("PRIORITY","전투 중 우선 추적"));
            Add("loot.class",("ALL","모든 직업"),("OWN","현재 직업"));
            Add("loot.slots",("WEAPON","무기"),("HEAD","머리"),("CHEST","몸통"),("HANDS","손"),("FEET","발"),("WAIST","허리"),("AMULET","목걸이"),("RING","반지"));
            Add("loot.danger",("WAIT","위험 해소 대기"),("SAFE_PATH","안전 경로 이용"),("BELOW_DODGE_THRESHOLD","회피 기준 이하 피해 감수"));
            Add("loot.finish",("COLLECT","남은 획득 대상 회수 후 종료"),("LEAVE","남은 장비를 두고 종료"));
            Add("bag.trigger",("FULL","가방이 가득 찼을 때"),("FREE_SLOTS","빈칸 기준 이하"));
            Add("bag.policy",("PORTAL","마을에서 정리하고 복귀"),("REPLACE","낮은 가치의 가방 장비 교체"),("IGNORE","더 줍지 않고 사냥 계속"));
            Add("bag.replacementRank",("RARITY","등급만"),("RARITY_LEVEL_PRICE","등급 → 아이템 레벨 → 판매가"));
            Add("bag.replacementFail",("LEAVE","새 장비 포기"),("PORTAL","마을 정리"));
            Add("bag.cleanupAt",("OFF","사용 안 함"),("PORTAL","정리 귀환 시"),("AFTER_RIFT","매 균열 종료 후"));
            Add("bag.cleanup",("KEEP","가방 보관"),("SELL","판매"),("SALVAGE","분해"),("WAREHOUSE","창고 이동"));
            Add("bag.warehouseFull",("KEEP","가방에 보관"),("STOP","반복 중단 후 정리 화면"));
            Add("bag.stillFull",("STOP","반복 중단"),("LIMIT_LOOT","획득을 제한하고 계속"));
            Add("explore.mode",("NEAREST_UNSEEN","가까운 미탐색 지역"),("LEFT_WALL","왼쪽 벽"),("RIGHT_WALL","오른쪽 벽"),("DETECTED_ENEMIES","감지한 적"));
            Add("explore.order",("ENEMIES","적"),("LOOT","전리품"),("CHESTS","상자"),("SHRINES","성소"));
            Add("explore.chest",("IGNORE","무시"),("ON_PATH","이동 경로에서 개봉"),("PRIORITY","발견하면 우선 개봉"));
            Add("explore.cursedChest",("OFF","열지 않음"),("AFTER_COMBAT","전투 후 개봉"),("CONDITIONAL","조건부 개봉"));
            Add("explore.shrine",("OFF","이용 안 함"),("FOUND","발견하면 이용"),("NEEDED","필요한 효과일 때 이용"));
            Add("explore.bossUnlocked",("BOSS","보스로 이동"),("FINISH_CURRENT","현재 전투·회수 후 이동"),("EXPLORE","추가 탐색"));
            Add("repeat.success",("SAME","같은 단계"),("NEXT","다음 단계"),("STOP","중단"));
            Add("repeat.failure",("SAME","같은 단계 재도전"),("LOWER","한 단계 하향"),("STOP","중단"));
            Add("common.order",("EMERGENCY","긴급 생존"),("DODGE","회피"),("PRIORITY_LOOT","우선 회수"),("ATTACK","공격"),("AFTER_COMBAT_LOOT","전투 후 회수"),("EXPLORE","탐색"));
            return v;
        }

        // Which label table an option reads from. Several ids share one table.
        static string Table(string optionId)
        {
            if(optionId.StartsWith("dodge.")&&optionId.EndsWith(".policy"))return "dodge.policy";
            if(optionId=="target.specialEnabled"||optionId=="target.specialOrder")return "target.special";
            if(optionId=="loot.material"||optionId=="loot.gem"||optionId=="loot.core"||Rarity.Keys.Any(r=>optionId=="loot."+r))return "loot.collect";
            if(optionId.StartsWith("bag.cleanup."))return "bag.cleanup";
            if(optionId=="explore.normalChest"||optionId=="explore.sealedChest")return "explore.chest";
            return optionId;
        }

        public static string Value(EdictOptionDefinition definition,string value,Func<string,string> skillName=null)
        {
            if(definition.kind==EdictOptionKind.Toggle)return value=="ON"?"켜짐":"꺼짐";
            if(definition.kind==EdictOptionKind.Number)return value;
            if(definition.kind==EdictOptionKind.SkillReference)return value==""?"지정 안 함":skillName?.Invoke(value)??value;
            if(definition.kind==EdictOptionKind.Choice)return Item(definition,value);
            if(value=="")return "선택 없음";
            return string.Join(" · ",value.Split(',').Select(v=>Loc.T(Item(definition,v))));
        }
        public static string Item(EdictOptionDefinition definition,string code)
        {
            if(Values.TryGetValue(Table(definition.id),out var map)&&map.TryGetValue(code,out var label))return label;
            if(Rarity.TryGetValue(code,out var rarity))return rarity;
            return code;   // content ids such as LW01 or SW read as themselves
        }
        static readonly System.Text.RegularExpressions.Regex ContentId=new System.Text.RegularExpressions.Regex("^(L[WAMC][0-9]{2}|S(W|WB|A|AB|M|MB))$");
        // Legendary and set ids are content identifiers the player already knows from the item screens.
        public static bool HasLabel(EdictOptionDefinition definition,string code)=>
            Values.TryGetValue(Table(definition.id),out var map)&&map.ContainsKey(code)||Rarity.ContainsKey(code)||ContentId.IsMatch(code);
        public static string Option(EdictOptionDefinition definition)
        {
            foreach(var pair in Rarity)
                if(definition.label.StartsWith(pair.Key+" "))return Loc.T(pair.Value+definition.label.Substring(pair.Key.Length));
            return Loc.T(definition.label);
        }
    }
}
