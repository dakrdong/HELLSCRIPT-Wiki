using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed class RuntimeActionSmoke : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Install()
        {
            if(!Environment.GetCommandLineArgs().Contains("-hellscriptActionSmoke"))return;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Action smoke validation").AddComponent<RuntimeActionSmoke>();
        }
        static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
        static RunState Arena(GameController game,int skill)
        {
            if(game.Running)game.ReturnTown();var account=game.Store.Data;account.selectedHero=skill/6;var hero=account.Hero;hero.level=30;
            hero.build=GameCatalog.Preset(hero.heroClass,0);hero.build.rules.Clear();hero.build.rules.Add(new Rule(skill));hero.build.passives=Array.Empty<int>();hero.build.potionThreshold=0;
            hero.build.activeSkills.Clear();hero.build.activeSkills.Add(skill);
            hero.build.movement=MovementMode.Stand;hero.build.distance=2;hero.build.autoRepeat=false;
            // Controlled legacy arena, saved through the real normal-run persistence path.
            var fixture=new CombatSimulation(account,game.catalog,1,1,seed:40031);var run=fixture.State;run.training=-1;run.position=RiftMap.Rooms[0];run.enemies.Clear();
            run.enemies.Add(new EnemyState{id=900,kind=0,position=run.position+Vector2.up*6,health=10000,maxHealth=10000,cooldown=1000,speed=0,attack=0});
            account.suspendedRun=run;game.Begin(resume:true);game.SetSpeed(1);game.Combat.State.paused=true;return game.Combat.State;
        }
        static IEnumerator WaitFor(Func<bool> ready,RunState run,float seconds=5)
        {
            float deadline=Time.realtimeSinceStartup+seconds;
            while(!ready()&&Time.realtimeSinceStartup<deadline){Require(string.IsNullOrEmpty(run.navigationError),run.navigationError);yield return null;}
            Require(ready(),"Action fixture did not reach the expected phase: "+run.action);
        }
        static IEnumerator Capture(GameController game,string directory,string name)
        {
            game.Combat.State.paused=true;game.UI.RefreshHud();yield return new WaitForSecondsRealtime(.3f);
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,name));yield return new WaitForSecondsRealtime(.2f);
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();string directory="";for(int n=0;n<args.Length-1;n++)if(args[n]=="-hellscriptScreenshots")directory=args[n+1];
            Require(args.Contains("-hellscriptSavePath")&&!string.IsNullOrEmpty(directory),"Action smoke requires isolated save and screenshot paths.");Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1);var game=FindAnyObjectByType<GameController>();
            if(!args.Contains("-hellscriptActionResume"))
            {
                var run=Arena(game,1);
                game.EditBuild();game.UI.CancelBuild();Require(run.paused,"Cancel resumed a previously paused run.");
                run.paused=false;game.EditBuild();game.UI.CancelBuild();Require(!run.paused,"Cancel did not restore the running state.");
                run.paused=true;game.EditBuild();
                FindObjectsByType<UnityEngine.UI.Button>(FindObjectsSortMode.None).First(b=>b.name=="설정 적용").onClick.Invoke();Require(run.paused,"Apply resumed a previously paused run.");
                yield return new WaitForSecondsRealtime(.5f);
                run.paused=false;yield return WaitFor(()=>run.heroAction.phase==HeroActionPhase.Preparing,run);run.decisionTime=100;
                yield return Capture(game,directory,"01-leap-preparation.png");run.paused=false;
                yield return WaitFor(()=>run.heroAction.phase==HeroActionPhase.Travelling&&run.heroAction.elapsed>=.2f,run);
                Require(run.dealt==0&&game.Combat.HeroAirHeight>1,"Leap damage or air pose occurred at the wrong time.");yield return Capture(game,directory,"02-leap-flight.png");
                run.paused=false;yield return WaitFor(()=>run.actionEvents.Any(e=>e.skill==1&&e.kind=="ACTION_RELEASE"),run);Require(run.dealt>0,"Leap landing caused no damage.");yield return Capture(game,directory,"03-leap-landed.png");
                run=Arena(game,8);yield return new WaitForSecondsRealtime(.5f);run.paused=false;yield return WaitFor(()=>run.heroAction.phase==HeroActionPhase.Preparing,run);run.decisionTime=100;
                yield return WaitFor(()=>run.traps.Count>0&&run.traps[0].arm>0,run);Require(run.dealt==0,"Unarmed trap caused damage.");yield return Capture(game,directory,"04-trap-arming.png");
                run.paused=false;yield return WaitFor(()=>run.traps.Count>0&&run.traps[0].triggered&&run.dealt>0,run);yield return Capture(game,directory,"05-trap-active.png");
                run=Arena(game,12);yield return new WaitForSecondsRealtime(.5f);run.paused=false;yield return WaitFor(()=>run.heroAction.phase==HeroActionPhase.Preparing,run);run.decisionTime=100;
                yield return Capture(game,directory,"06-fireball-preparation.png");run.paused=false;
                yield return WaitFor(()=>run.projectiles.Any(p=>Vector2.Distance(p.position,p.origin)>2),run);Require(run.dealt==0,"Fireball dealt damage before impact.");
                yield return Capture(game,directory,"07-fireball-flight.png");game.Save();File.WriteAllText(Path.Combine(directory,"checkpoint.json"),JsonUtility.ToJson(run,true));
                Debug.Log("ACTION_SMOKE_CHECKPOINT_READY");Application.Quit();yield break;
            }
            var saved=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(directory,"checkpoint.json")));GameStore.NormalizeRun(saved);game.Begin(resume:true);var restored=game.Combat.State;
            Require(restored.id==saved.id&&restored.time==saved.time&&restored.health==saved.health&&restored.rng==saved.rng,"Action run checkpoint changed on restart.");
            Require(JsonUtility.ToJson(restored.projectiles[0])==JsonUtility.ToJson(saved.projectiles[0])&&restored.actionEvents.Count==saved.actionEvents.Count,"Projectile or action history was reset.");
            yield return Capture(game,directory,"08-restored-projectile.png");restored.paused=false;game.SetSpeed(1);yield return WaitFor(()=>restored.projectiles.Count==0&&restored.dealt>0,restored);
            yield return Capture(game,directory,"09-fireball-impact.png");Require(restored.actionEvents.Count(e=>e.skill==12&&e.kind=="ACTION_START")==1,"Fireball was charged a second time on resume.");
            game.Save();File.WriteAllText(Path.Combine(directory,"completed.json"),JsonUtility.ToJson(restored,true));
            File.WriteAllText(Path.Combine(directory,"runtime-actions-smoke.txt"),$"PASS: real macOS player, leap preparation/flight/landing, trap arming/trigger/tick, fireball preparation/physical flight, actual process restart with unchanged projectile snapshot and action history, one impact and one action start after the restart.\nControlled fixture: level 30, original starter weapon, one skill at a time, no passives, stationary target with 10000 HP, fixed legacy training arena persisted as a normal development run. No natural exploration or balance claim.\nrunId={restored.id}\ncheckpointTime={saved.time:F2}\nimpactTime={restored.time:F2}\ndamage={restored.dealt:F2}\nScreen={Screen.width}x{Screen.height}\n");
            Debug.Log("HELLSCRIPT_ACTION_RUNTIME_SMOKE_OK");Application.Quit();
        }
    }
}
