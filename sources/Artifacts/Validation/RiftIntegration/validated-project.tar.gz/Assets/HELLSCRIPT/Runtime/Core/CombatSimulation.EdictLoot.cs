using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        bool EdictLootCombatClear=>!State.enemies.Any(Perceived)&&!InDanger;
        DropState FindEdictLoot()
        {
            bool clear=EdictLootCombatClear;
            DropState chosen=null;float best=float.PositiveInfinity;int bestRank=int.MaxValue;
            foreach(var drop in State.drops)
            {
                if(drop.claimed||drop.ignored||Vector2.Distance(State.position,drop.position)>12||!Map.LineClear(State.position,drop.position))continue;
                var mode=edictLoot.Mode(drop.item,Hero.heroClass);
                if(mode==EdictLootMode.Ignore||mode==EdictLootMode.Passing||mode==EdictLootMode.AfterCombat&&!clear)continue;
                var path=Map.FindPath(State.position,drop.position);float length=RiftNavigation.Length(path);
                if(float.IsInfinity(length)||length>edictLoot.maximumPath)continue;
                if(edictLoot.waitForDanger&&!LootPathSafe(path))continue;
                int rank=mode==EdictLootMode.Priority?0:1;
                if(rank>bestRank||rank==bestRank&&(length>best||length==best&&chosen!=null&&drop.id>=chosen.id))continue;
                chosen=drop;best=length;bestRank=rank;
            }
            return chosen;
        }
        bool LootPathSafe(System.Collections.Generic.IReadOnlyList<Vector2> path)
        {
            if(path==null||path.Count==0)return false;
            for(int i=0;i<path.Count;i++)
            {
                Vector2 from=i==0?State.position:path[i-1],to=path[i];int steps=Mathf.Max(1,Mathf.CeilToInt(Vector2.Distance(from,to)/.5f));
                for(int n=0;n<=steps;n++)if(DangerAt(Vector2.Lerp(from,to,n/(float)steps),1.5f))return false;
            }
            return true;
        }
    }
}
