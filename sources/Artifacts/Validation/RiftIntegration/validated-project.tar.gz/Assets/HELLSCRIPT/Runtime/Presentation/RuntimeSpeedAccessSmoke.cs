using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimeSpeedAccessSmoke : MonoBehaviour
    {
        GameController game;
        string directory,saveDirectory;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if(!Debug.isDebugBuild || !Environment.GetCommandLineArgs().Contains("-hellscriptSpeedAccessSmoke"))return;
            Application.runInBackground=true;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Speed access validation").AddComponent<RuntimeSpeedAccessSmoke>();
        }
        static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
        static string Json(object value)=>JsonUtility.ToJson(value);
        static string Account(AccountSave source){var copy=JsonUtility.FromJson<AccountSave>(Json(source));copy.lastSeenUtc=0;return Json(copy);}
        void Click(string name)
        {var button=game.UI.GetComponentsInChildren<Button>().Single(b=>b.name==name);Require(button.IsInteractable(),"Inaccessible button: "+name);button.onClick.Invoke();}
        void RejectInputs()
        {
            string run=Json(game.Combat.State),account=Account(game.Store.Data),disk=File.ReadAllText(Path.Combine(saveDirectory,"hellscript-local-v1.json"));
            Click("1.5배속 잠김");Click("2배속 잠김");Click("1배속");
            foreach(float speed in new[]{1.5f,2f,3f,0f,-1f,float.NaN,float.PositiveInfinity})
            {game.SetSpeed(speed);Require(game.Notice==CombatSpeedAccess.LockedMessage && game.EffectiveSpeed==1,"Bypass input changed actual speed.");}
            Require(run==Json(game.Combat.State) && account==Account(game.Store.Data),"Rejected input changed game state.");
            Require(disk==File.ReadAllText(Path.Combine(saveDirectory,"hellscript-local-v1.json")),"Rejected input wrote account data.");
        }
        IEnumerator RunAtOneDespiteStoredTwo(string label)
        {
            game.Store.Data.speed=2;game.Combat.State.paused=false;
            float start=game.Combat.State.time,real=0;
            // Accumulate the same per-frame input used by GameController, including slow-frame clamping.
            while(real<1.2f){yield return null;real+=Mathf.Min(Time.unscaledDeltaTime,.25f);}
            float progressed=game.Combat.State.time-start;game.Combat.State.paused=true;
            Require(Mathf.Abs(progressed-real)<.2f,label+" advanced at a locked speed: combat="+progressed+" real="+real);
            Require(game.EffectiveSpeed==1,label+" exposed stored speed.");
            File.AppendAllText(Path.Combine(directory,"speed-checks.txt"),$"PASS {label} real={real:F3} combat={progressed:F3} applied={game.EffectiveSpeed}\n");
            game.Save();Require(game.Store.Data.speed==1,"Save retained bypass value.");
        }
        IEnumerator Capture(string name)
        {
            yield return new WaitForSecondsRealtime(.2f);Canvas.ForceUpdateCanvases();
            foreach(var label in game.UI.GetComponentsInChildren<Text>())Require(label.preferredHeight<=label.rectTransform.rect.height+1,"Clipped text: "+label.text);
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,name+".png"));yield return new WaitForSecondsRealtime(.2f);
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();
            for(int i=0;i<args.Length-1;i++){if(args[i]=="-hellscriptSavePath")saveDirectory=args[i+1];if(args[i]=="-hellscriptScreenshots")directory=args[i+1];}
            Require(!string.IsNullOrEmpty(directory)&&!string.IsNullOrEmpty(saveDirectory),"Use isolated save and evidence paths.");Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1);game=FindAnyObjectByType<GameController>();Require(game.Store!=null && game.Store.Data.speed==1,"Load did not normalize the legacy speed.");
            if(args.Contains("-hellscriptSpeedAccessResume"))
            {
                Require(Account(game.Store.Data)==File.ReadAllText(Path.Combine(directory,"expected-account.json")),"Legacy speed normalization changed saved account or rift.");
                var before=game.Store.Data.suspendedRun;Require(before!=null&&before.paused,"Missing paused checkpoint.");string id=before.id;float time=before.time,hp=before.health;uint rng=before.rng;
                game.Begin(resume:true);
                Require(game.Combat.State.id==id&&game.Combat.State.time==time&&game.Combat.State.health==hp&&game.Combat.State.rng==rng,"Resume reset checkpoint.");
                // Explicit Continue resumes play under the existing game policy. Re-pause before rendering checks.
                Require(!game.Combat.State.paused,"Explicit Continue did not resume play.");game.TogglePause();yield return new WaitForSecondsRealtime(.2f);
                Require(game.Combat.State.time==time&&game.Combat.State.paused,"Manual pause advanced combat.");
                RejectInputs();yield return Capture("04-resumed-rift-lock");yield return RunAtOneDespiteStoredTwo("resumed rift");
                File.WriteAllText(Path.Combine(directory,"runtime-speed-access-resume.txt"),"PASS: separate process loaded a legacy 2x saved account at 1x, preserved account/run checkpoint, rejected locked buttons and bypass inputs, resumed actual rift at 1x.\n");
                Debug.Log("HELLSCRIPT_SPEED_ACCESS_RESUME_OK");Application.Quit(0);yield break;
            }
            game.Store.Data.guide.hintsHidden=true;
            game.Begin(2,seed:991177);game.Combat.State.paused=true;game.Save();yield return null;RejectInputs();yield return Capture("01-training-locked-speeds");
            yield return RunAtOneDespiteStoredTwo("owned training");game.ReturnTown();
            game.BeginComparison(1);game.Combat.State.paused=true;game.Save();yield return null;Require(game.ComparisonRun,"Comparison fixture failed.");RejectInputs();
            yield return RunAtOneDespiteStoredTwo("comparison A");game.ReturnTown();
            game.Begin(seed:778899);game.Combat.State.paused=true;game.Save();yield return null;RejectInputs();yield return Capture("02-rift-locked-speeds");
            game.UI.ShowCombatOverview();yield return Capture("03-speed-policy-overview");Click("닫기");
            yield return RunAtOneDespiteStoredTwo("generated rift");game.Save();
            File.WriteAllText(Path.Combine(directory,"expected-account.json"),Account(game.Store.Data));
            File.WriteAllText(Path.Combine(directory,"runtime-speed-access-smoke.txt"),"PASS: locked controls and invalid inputs preserve run/account/disk; owned training, comparison A and generated rift advance at 1x despite stored 2x; save normalizes speed. Native UI callbacks and Metal, no physical touch or idle-mode claim.\n");
            Debug.Log("HELLSCRIPT_SPEED_ACCESS_RUNTIME_SMOKE_OK");Application.Quit(0);
        }
    }
}
