using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimeBuildSaveSmoke : MonoBehaviour
    {
        GameController game;
        string directory,savePath;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]static void Install()
        {
            if(!Environment.GetCommandLineArgs().Contains("-hellscriptBuildSaveSmoke"))return;
            Application.runInBackground=true;Application.logMessageReceived+=(m,s,t)=>{if(t==LogType.Exception)Application.Quit(1);};
            new GameObject("Current build save validation").AddComponent<RuntimeBuildSaveSmoke>();
        }
        static void Require(bool valid,string reason){if(!valid)throw new InvalidOperationException(reason);}
        static string Json(object value)=>JsonUtility.ToJson(value);
        static string AccountSnapshot(AccountSave value){var copy=JsonUtility.FromJson<AccountSave>(Json(value));copy.lastSeenUtc=0;return Json(copy);}
        Slider Distance()=>game.UI.GetComponentsInChildren<Slider>().Single(s=>s.transform.parent.GetComponentsInChildren<Text>().Any(t=>t.text.StartsWith("목표 거리",StringComparison.Ordinal)));
        void Click(string name){var b=game.UI.GetComponentsInChildren<Button>().Single(b=>b.name==name);Require(b.interactable,"Disabled button: "+name);b.onClick.Invoke();}
        IEnumerator Capture(string name)
        {
            if(!game.enabled&&game.Active)
            {
                // The test freezes controller ticks, so explicitly synchronize the view too.
                // Otherwise a just-restored scene still shows its construction positions.
                string before=Json(game.Combat.State);game.World.Present(game.Combat.State,.2f);game.UI.RefreshHud();
                Require(Json(game.Combat.State)==before,"Capturing the restored view changed simulation state.");
            }
            yield return new WaitForSecondsRealtime(.2f);Canvas.ForceUpdateCanvases();
            foreach(var t in game.UI.GetComponentsInChildren<Text>().Where(t=>t.transform.parent.name=="Notice"))Require(t.preferredHeight<=t.rectTransform.rect.height+1,"Save error text is clipped.");
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,name));yield return new WaitForSecondsRealtime(.2f);
        }
        void FailApply(float distance)
        {
            Distance().value=distance;var hero=game.Store.Data.Hero;var original=hero.build;var guide=hero.guide;
            var run=game.Active?game.Combat.State:null;var action=run?.heroAction;
            string before=Json(game.Store.Data),beforeRun=run==null?"":Json(run),disk=File.ReadAllText(savePath);
            Directory.CreateDirectory(savePath+".tmp");Click("설정 적용");
            Require(game.UI.Page=="build"&&Distance().value==distance,"Failed save left the editor or lost the draft.");
            Require(Json(game.Store.Data)==before&&File.ReadAllText(savePath)==disk&&ReferenceEquals(original,hero.build)&&ReferenceEquals(guide,hero.guide),"Failed save changed the account, guide, or disk.");
            if(run!=null)Require(Json(run)==beforeRun&&ReferenceEquals(action,run.heroAction)&&run.paused,"Failed save changed the live action or resumed combat.");
            Directory.Delete(savePath+".tmp");Debug.developerConsoleVisible=false;
        }
        IEnumerator WaitForCast(int skill=12)
        {
            float end=Time.realtimeSinceStartup+45;
            var phase=skill==0?HeroActionPhase.Channeling:HeroActionPhase.Preparing;
            while(game.Active&&!(game.Combat.State.heroAction.skill==skill&&game.Combat.State.heroAction.phase==phase)&&Time.realtimeSinceStartup<end)yield return null;
            Require(game.Active&&game.Combat.State.heroAction.skill==skill&&game.Combat.State.heroAction.phase==phase,"The generated rift did not reach the requested natural action: "+skill);
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();string saveDirectory="";
            for(int n=0;n<args.Length-1;n++){if(args[n]=="-hellscriptSavePath")saveDirectory=args[n+1];if(args[n]=="-hellscriptScreenshots")directory=args[n+1];}
            Require(!string.IsNullOrEmpty(saveDirectory)&&!string.IsNullOrEmpty(directory),"Use isolated save and evidence paths.");Directory.CreateDirectory(directory);savePath=Path.Combine(saveDirectory,"hellscript-local-v1.json");
            Screen.SetResolution(720,1280,FullScreenMode.Windowed);yield return new WaitForSecondsRealtime(1);game=FindAnyObjectByType<GameController>();
            if(args.Contains("-hellscriptBuildSaveResume"))
            {
                var expected=JsonUtility.FromJson<AccountSave>(File.ReadAllText(Path.Combine(directory,"expected-account.json")));
                Require(AccountSnapshot(expected)==AccountSnapshot(game.Store.Data),"Restart changed the saved account or suspended build transition.");
                bool channelResume=args.Contains("-hellscriptChannelResume");
                var saved=JsonUtility.FromJson<RunState>(Json(expected.suspendedRun));Require(saved!=null&&saved.heroAction.skill==(channelResume?0:12),"Expected the saved in-flight action.");
                game.Begin(-1,true);game.enabled=false;saved.paused=false;
                Require(Json(saved)==Json(game.Combat.State),"Resuming changed the saved action, cooldowns, HP, RNG, or build.");
                if(channelResume)
                {
                    var state=game.Combat.State;var pending=state.heroAction;float paid=pending.cost,dealt=state.dealt,expectedResource=state.resource,remaining=state.channelTick;
                    Require(pending.exitChannelForBuild,"Channel exit request was lost on restart.");
                    yield return Capture("12-resumed-channel-pending.png");int ticks=0;
                    while(ReferenceEquals(pending,state.heroAction)&&ticks<6)
                    {
                        expectedResource=Mathf.Min(100,expectedResource+game.Combat.Stats.regen*CombatSimulation.Step);
                        game.Combat.Tick(CombatSimulation.Step);ticks++;
                    }
                    Require(!ReferenceEquals(pending,state.heroAction)&&Mathf.Abs(ticks*CombatSimulation.Step-remaining)<.001f,"Channel did not exit at its original quarter-second boundary.");
                    Require(pending.cost==paid&&state.dealt==dealt&&Mathf.Abs(state.resource-expectedResource)<.001f,"Pending channel spent more resource or produced another damage tick.");
                    Require(state.actionEvents.Count(e=>e.actionId==pending.id&&e.kind=="ACTION_END"&&e.buildVersion==pending.policy.buildVersion)==1,"Expected one completion attributed to the original policy.");
                    state.paused=true;yield return Capture("13-channel-exited-at-boundary.png");game.Save();
                    File.WriteAllText(Path.Combine(directory,"runtime-action-continuity-smoke.txt"),"PASS: changed fireball policy persisted without cancelling the original preparation; failed write and no-op save preserved state; new process resumed exact action and emitted one original-policy release; natural warrior channel retained its timer and paid cost on changed save; third process resumed exact pending exit and completed at the existing 0.25-second boundary without an extra cost or damage tick. UI callbacks, native macOS Metal rendering and deterministic ticks; no physical input or mobile-device claim.\n");
                    Debug.Log("HELLSCRIPT_ACTION_CONTINUITY_RUNTIME_SMOKE_OK");Application.Quit(0);yield break;
                }
                yield return Capture("10-resumed-in-flight-build.png");
                if(args.Contains("-hellscriptActionContinuity"))
                {
                    var fire=game.Combat.State.heroAction;string sourceVersion=fire.policy.buildVersion;
                    Require(sourceVersion!=game.Combat.State.build.version,"Expected an action whose source differs from the saved new policy.");
                    for(int n=0;n<20&&!fire.released;n++)game.Combat.Tick(CombatSimulation.Step);
                    Require(fire.released&&game.Combat.State.actionEvents.Count(e=>e.actionId==fire.id&&e.kind=="ACTION_RELEASE"&&e.buildVersion==sourceVersion)==1,"Restored preparation did not release exactly once under its original policy.");
                    yield return Capture("11-original-fireball-released.png");game.ReturnTown();game.SelectHero(0);game.enabled=true;
                    game.Begin(-1,seed:118811);game.SetSpeed(1);yield return WaitForCast(0);game.TogglePause();game.UI.ShowBuild();
                    var channel=game.Combat.State.heroAction;float tickBefore=game.Combat.State.channelTick,costBefore=channel.cost;
                    Distance().value=4.5f;Click("설정 적용");
                    Require(game.Combat.State.paused&&ReferenceEquals(channel,game.Combat.State.heroAction)&&channel.exitChannelForBuild&&channel.cost==costBefore&&game.Combat.State.channelTick==tickBefore,"Channel save lost the paused action or changed its billing clock.");
                    Require(Json(game.Combat.State)==Json(JsonUtility.FromJson<AccountSave>(File.ReadAllText(savePath)).suspendedRun),"Channel adoption differs from committed disk state.");
                    game.enabled=false;yield return Capture("06-changed-channel-awaits-boundary.png");game.Save();
                    File.WriteAllText(Path.Combine(directory,"expected-account.json"),JsonUtility.ToJson(game.Store.Data,true));
                    Debug.Log("HELLSCRIPT_CHANNEL_CHECKPOINT_READY");Application.Quit(0);yield break;
                }
                File.WriteAllText(Path.Combine(directory,"runtime-build-save-smoke.txt"),"PASS: town failed-save keeps editor/draft/hero/guide/disk; retry persists; owned training apply performs no account write; generated rift natural fireball preparation survives failed and successful changed saves; retry runtime snapshot equals disk; original pause state restored; unchanged settings preserve the in-flight action; actual process restart restores the account and resumes the exact saved run (pause released). UI callbacks and native Metal rendering, not physical input/mobile proof. Active replacement and v0.2 integration remain pending.\n");
                Debug.Log("HELLSCRIPT_BUILD_SAVE_RUNTIME_SMOKE_OK");Application.Quit(0);yield break;
            }
            game.SelectHero(2);Require(game.Store.Data.Hero.level==1,"Use a fresh isolated account.");
            game.UI.ShowBuild();FailApply(5.5f);yield return Capture("01-town-save-failure.png");Click("설정 적용");
            Require(game.UI.Page=="town"&&game.Store.Data.Hero.build.distance==5.5f,"Town retry did not apply the saved draft.");
            Require(string.IsNullOrEmpty(game.Notice)&&!game.UI.GetComponentsInChildren<Text>().Any(t=>t.text.Contains("사냥 설정을 저장하지 못했습니다")),"Successful retry still displays the previous save failure.");
            Require(Json(game.Store.Data.Hero.build)==Json(JsonUtility.FromJson<AccountSave>(File.ReadAllText(savePath)).Hero.build),"Town runtime build differs from disk.");
            yield return Capture("02-town-save-success.png");
            game.Begin(0);game.Combat.State.paused=true;game.UI.ShowBuild();Distance().value=4.5f;
            string account=Json(game.Store.Data),diskBeforeTraining=File.ReadAllText(savePath);
            Directory.CreateDirectory(savePath+".tmp");Click("설정 적용");
            Require(game.UI.Page=="battle"&&game.Combat.State.build.distance==4.5f&&game.Combat.State.paused,"Training did not apply its temporary draft.");
            Require(Json(game.Store.Data)==account&&File.ReadAllText(savePath)==diskBeforeTraining,"Temporary training apply wrote real account settings.");Directory.Delete(savePath+".tmp");
            yield return Capture("03-temporary-training-apply.png");game.ReturnTown();
            game.Begin(-1,seed:118811);game.SetSpeed(1);yield return WaitForCast();game.UI.ShowBuild();
            Require(game.Combat.State.paused,"Opening build editor did not pause.");game.Save();FailApply(6.5f);yield return Capture("04-rift-save-failure.png");
            var run=game.Combat.State;var started=run.heroAction;string beforeChangedSave=Json(started);float hp=run.health,resource=run.resource;var cooldowns=run.cooldowns.ToArray();Click("설정 적용");
            Require(game.UI.Page=="battle"&&!run.paused&&run.health==hp&&run.resource==resource&&run.cooldowns.SequenceEqual(cooldowns),"Retry changed resources or failed to restore the running state.");
            Require(ReferenceEquals(started,run.heroAction)&&Json(started)==beforeChangedSave,"Successful changed save interrupted or reconfigured the in-flight fireball.");
            Require(Json(run)==Json(JsonUtility.FromJson<AccountSave>(File.ReadAllText(savePath)).suspendedRun),"Applied rift transition differs from the persisted snapshot.");
            yield return WaitForCast();game.TogglePause();game.UI.ShowBuild();var action=run.heroAction;string actionBefore=Json(action);Click("설정 적용");
            Require(run.paused&&ReferenceEquals(action,run.heroAction)&&Json(action)==actionBefore,"No-op save interrupted a cast or resumed an already paused rift.");
            game.enabled=false;yield return Capture("05-no-op-keeps-paused-cast.png");game.Save();
            File.WriteAllText(Path.Combine(directory,"expected-account.json"),JsonUtility.ToJson(game.Store.Data,true));
            Debug.Log("HELLSCRIPT_BUILD_SAVE_CHECKPOINT_READY");Application.Quit(0);
        }
    }
}
