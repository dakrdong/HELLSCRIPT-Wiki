using System;
using System.Linq;

namespace Hellscript
{
    public static class BuildEditing
    {
        [Serializable] internal sealed class BehaviorProfile
        {
            public TargetMode target;
            public MovementMode movement;
            public float distance,potionThreshold;
            public bool clockwise;
            public System.Collections.Generic.List<Rule> rules;
            public int[] activeSkills,passives;
        }
        internal static BehaviorProfile Profile(BuildConfig build,bool loadout)
        {
            var rules=build.rules.Select(r=>r.Copy()).ToList();foreach(var r in rules){r.id="";r.schema=BehaviorRules.Version;r.condition=ConditionKind.Always;r.threshold=0;}
            return new BehaviorProfile{target=build.target,movement=build.movement,distance=build.distance,potionThreshold=build.potionThreshold,clockwise=build.clockwise,rules=rules,
                activeSkills=loadout?build.activeSkills.ToArray():Array.Empty<int>(),passives=loadout?build.passives:Array.Empty<int>()};
        }
        public static string CombatSignature(BuildConfig build)=>UnityEngine.JsonUtility.ToJson(Profile(build,true));
        public static System.Collections.Generic.List<string> DescribeCombatChanges(BuildConfig before,BuildConfig after,GameCatalog catalog,HeroClass heroClass)
        {
            var result=new System.Collections.Generic.List<string>();
            string[] targets={"가까운 적","정예·보스 우선","지원형 우선","낮은 HP","밀집 중심"};
            if(before.target!=after.target)result.Add(Loc.F("목표: {0} → {1}", targets[(int)before.target], targets[(int)after.target]));
            if(before.movement!=after.movement||before.distance!=after.distance)result.Add(Loc.F("이동: {0} {1:0.#}m → {2} {3:0.#}m", BehaviorRules.Movements[(int)before.movement], before.distance, BehaviorRules.Movements[(int)after.movement], after.distance));
            if(before.clockwise!=after.clockwise)result.Add(Loc.F("선회 방향: {0} → {1}", (before.clockwise?"시계 방향":"반시계 방향"), (after.clockwise?"시계 방향":"반시계 방향")));
            if(before.potionThreshold!=after.potionThreshold)result.Add(Loc.F("물약: HP {0:0}% 이하 → {1:0}% 이하", before.potionThreshold, after.potionThreshold));
            string Skills(BuildConfig b)=>string.Join(", ",b.activeSkills.Select(i=>catalog.skills[i].name));
            int hero=(int)heroClass;
            string Passives(BuildConfig b)=>string.Join(", ",b.passives.Select(i=>GameCatalog.Passives[hero*6+i]));
            if(!before.activeSkills.SequenceEqual(after.activeSkills))result.Add(Loc.F("장착 스킬\nA: {0}\nB: {1}", Skills(before), Skills(after)));
            if(!before.passives.SequenceEqual(after.passives))result.Add(Loc.F("패시브\nA: {0}\nB: {1}", Passives(before), Passives(after)));
            string RuleText(Rule r)
            {
                string name=r.action==RuleAction.Skill?catalog.skills[r.skill].name:r.action==RuleAction.Basic?"기본 공격":r.action==RuleAction.Loot?"장비 회수":r.action==RuleAction.Chest?"상자 개봉":"탐색";
                string movement=r.overrideMovement?Loc.F("{0} {1:0.#}m",BehaviorRules.Movements[(int)r.movement],r.distance):"전체 이동 설정";
                return Loc.F("{0} · {1} · {2}\n목표 {3} {4:0.#}m · {5}\n{6} · 설치 {7} · {8} · {9}", name, (r.enabled?"켜짐":"꺼짐"), BehaviorRules.Summary(r), BehaviorRules.Targets[(int)r.target], r.targetRadius, movement, BehaviorRules.Purposes[(int)r.positionPurpose], new[]{"목표 위치","무리 중심","자신 아래","관측한 이동 경로"}[(int)r.areaAim], (r.blizzardMode==BlizzardMode.Follow?"목표 추적":"위치 고정"), (r.escape?"생존용":"공격용"));
            }
            var a=Profile(before,false).rules;var b=Profile(after,false).rules;
            for(int i=0;i<Math.Max(a.Count,b.Count);i++)
            {
                if(i<a.Count&&i<b.Count&&UnityEngine.JsonUtility.ToJson(a[i])==UnityEngine.JsonUtility.ToJson(b[i]))continue;
                result.Add(Loc.F("{0}번 규칙\nA: {1}\nB: {2}", i+1, (i<a.Count?RuleText(a[i]):"없음"), (i<b.Count?RuleText(b[i]):"없음")));
            }
            return result;
        }
        public static bool HasPreset(BuildConfig preset)=>preset!=null&&!preset.emptySlot;
        public static bool SettingsEqual(BuildConfig left,BuildConfig right)
        {
            if(!HasPreset(left)||!HasPreset(right))return false;
            if(BehaviorRules.InputValueIssue(left)!=""||BehaviorRules.InputValueIssue(right)!="")return false;
            string Key(BuildConfig value)
            {
                var copy=value.Copy();copy.name=copy.version="";
                foreach(var rule in copy.rules)rule.id="";
                return UnityEngine.JsonUtility.ToJson(copy);
            }
            return Key(left)==Key(right);
        }
        // Copy an explicit set of combat-editable fields. New loadout fields stay protected by default.
        public static BuildConfig DuringRift(BuildConfig current,BuildConfig requested,bool preserveMissingRules=false)
        {
            current=current.Copy();requested=requested.Copy();BehaviorRules.Normalize(current);BehaviorRules.Normalize(requested);
            var next=current.Copy();next.name=requested.name;next.version=requested.version;
            next.target=requested.target;next.movement=requested.movement;next.distance=requested.distance;next.clockwise=requested.clockwise;
            next.potionThreshold=requested.potionThreshold;next.autoRepeat=requested.autoRepeat;next.advanceOnWin=requested.advanceOnWin;next.stopAfterFailures=requested.stopAfterFailures;
            next.bagPolicy=requested.bagPolicy;next.minimumRarity=requested.minimumRarity;next.pursueRarity=requested.pursueRarity;next.exploration=requested.exploration;
            next.openChests=requested.openChests;next.commonChests=requested.commonChests;next.sealedChests=requested.sealedChests;next.chestsAfterBoss=requested.chestsAfterBoss;next.chestDetour=requested.chestDetour;
            next.useShrines=requested.useShrines;next.guideShrines=requested.guideShrines;next.resolveShrines=requested.resolveShrines;next.allowCursedChests=requested.allowCursedChests;
            next.shrineDetour=requested.shrineDetour;next.cursedMinimumTime=requested.cursedMinimumTime;
            var equipped=current.activeSkills;
            next.rules=requested.rules.Where(r=>r.action!=RuleAction.Skill||equipped.Contains(r.skill)).Select(r=>r.Copy()).ToList();
            if(preserveMissingRules)foreach(int skill in equipped)if(!next.rules.Any(r=>r.action==RuleAction.Skill&&r.skill==skill))
            {foreach(var old in current.rules.Where(r=>r.action==RuleAction.Skill&&r.skill==skill)){var kept=old.Copy();while(next.rules.Any(r=>r.id==kept.id))kept.id="kept-"+kept.id;next.rules.Add(kept);}}
            return next;
        }
        public static int ChangedRows(BuildConfig before,BuildConfig after)
        {
            int count=0;
            for(int i=0;i<Math.Max(before.rules.Count,after.rules.Count);i++)
            {
                if(i>=before.rules.Count||i>=after.rules.Count){count++;continue;}
                var a=before.rules[i];var b=after.rules[i];
                if(UnityEngine.JsonUtility.ToJson(a)!=UnityEngine.JsonUtility.ToJson(b))count++;
            }
            return count;
        }
    }
}
