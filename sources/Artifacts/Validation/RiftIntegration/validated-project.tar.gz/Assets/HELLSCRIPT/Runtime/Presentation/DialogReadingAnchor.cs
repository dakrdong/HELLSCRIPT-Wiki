using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Preserve the content being read instead of a percentage of the whole document.
    // A paragraph can change height or move to another pane when the window changes.
    internal sealed class DialogReadingAnchor
    {
        readonly RectTransform row;
        readonly float hiddenFraction,gap;
        DialogReadingAnchor(RectTransform row,float hiddenFraction,float gap)
        {this.row=row;this.hiddenFraction=hiddenFraction;this.gap=gap;}
        static Rect Bounds(RectTransform rect,Transform relative)
        {
            var b=RectTransformUtility.CalculateRelativeRectTransformBounds(relative,rect);
            return new Rect(b.min.x,b.min.y,b.size.x,b.size.y);
        }
        public static DialogReadingAnchor Capture(ScrollRect scroll)
        {
            if(scroll==null||!scroll.gameObject.activeInHierarchy)return null;
            float top=scroll.viewport.rect.yMax;
            foreach(RectTransform child in scroll.content)
            {
                var b=Bounds(child,scroll.viewport);
                if(!child.gameObject.activeSelf||b.yMin>=top)continue;
                return new DialogReadingAnchor(child,Mathf.Clamp01((b.yMax-top)/Mathf.Max(1,b.height)),Mathf.Min(0,b.yMax-top));
            }
            return null;
        }
        public void Restore()
        {
            if(row==null)return;var scroll=row.GetComponentInParent<ScrollRect>();if(scroll==null||!scroll.gameObject.activeInHierarchy)return;
            var b=Bounds(row,scroll.viewport);float target=scroll.viewport.rect.yMax+hiddenFraction*b.height+gap;
            Move(scroll,target-b.yMax);
        }
        public static void Show(RectTransform row)
        {
            if(row==null)return;var scroll=row.GetComponentInParent<ScrollRect>();if(scroll==null)return;
            var b=Bounds(row,scroll.viewport);var v=scroll.viewport.rect;
            if(b.yMax>v.yMax)Move(scroll,v.yMax-b.yMax);
            else if(b.yMin<v.yMin)Move(scroll,Mathf.Min(v.yMin-b.yMin,v.yMax-b.yMax));
        }
        static void Move(ScrollRect scroll,float delta)
        {
            var p=scroll.content.anchoredPosition;p.y=Mathf.Clamp(p.y+delta,0,Mathf.Max(0,scroll.content.rect.height-scroll.viewport.rect.height));
            scroll.StopMovement();scroll.content.anchoredPosition=p;
        }
    }
}
