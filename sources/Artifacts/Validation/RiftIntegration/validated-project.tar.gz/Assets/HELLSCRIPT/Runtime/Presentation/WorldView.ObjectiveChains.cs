using System.Collections.Generic;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class WorldView
    {
        readonly Dictionary<string,GameObject> carrierViews=new Dictionary<string,GameObject>(),offeringViews=new Dictionary<string,GameObject>();
        GameObject offeringAltarView;LineRenderer offeringProgress;
        readonly List<GameObject> offeringSlots=new List<GameObject>();
        void ClearObjectiveChains(){carrierViews.Clear();offeringViews.Clear();offeringSlots.Clear();offeringAltarView=null;offeringProgress=null;}
        void BuildObjectiveChains(RunState run)
        {
            foreach(var point in run.layout.carriers)
            {
                var root=new GameObject("Essence "+point.id);root.transform.SetParent(world.transform,false);
                var gem=Shape("Essence mark",PrimitiveType.Cube,root.transform,Vector3.up*3,new Vector3(.6f,.6f,.6f),purple);
                gem.transform.localRotation=Quaternion.Euler(0,45,45);
                Ring(root.transform,Vector3.up*.08f,.85f,purple,.1f);carrierViews.Add(point.id,root);root.SetActive(false);
            }
            foreach(var point in run.layout.offerings)
            {
                var root=new GameObject("Offering "+point.id);root.transform.SetParent(world.transform,false);root.transform.position=Position(point.position);
                Shape("Offering vessel",PrimitiveType.Cylinder,root.transform,Vector3.up*.3f,new Vector3(.7f,.3f,.7f),trim);
                Shape("Offering flame",PrimitiveType.Sphere,root.transform,Vector3.up*.9f,new Vector3(.4f,.65f,.4f),ember);
                Ring(root.transform,Vector3.up*.06f,.8f,purple,.08f);offeringViews.Add(point.id,root);root.SetActive(false);
            }
            var altar=run.layout.altar;if(altar==null||string.IsNullOrEmpty(altar.id))return;
            offeringAltarView=new GameObject("Offering altar");offeringAltarView.transform.SetParent(world.transform,false);offeringAltarView.transform.position=Position(altar.position);
            Shape("Altar base",PrimitiveType.Cube,offeringAltarView.transform,Vector3.up*.5f,new Vector3(1.2f,1,1.2f),darkStone);
            Shape("Altar rim",PrimitiveType.Cube,offeringAltarView.transform,Vector3.up*1.08f,new Vector3(1.35f,.18f,1.35f),trim);
            for(int i=0;i<3;i++)
                offeringSlots.Add(Shape("Offering slot "+i,PrimitiveType.Sphere,offeringAltarView.transform,new Vector3((i-1)*.4f,1.4f,0),Vector3.one*.3f,purple));
            offeringProgress=Ring(offeringAltarView.transform,Vector3.up*.08f,1.1f,ember,.12f).GetComponent<LineRenderer>();
            offeringAltarView.SetActive(false);
        }
        void PresentObjectiveChains(RunState run)
        {
            foreach(var point in run.layout.carriers)
            {
                if(!carrierViews.TryGetValue(point.id,out var root))continue;
                root.SetActive(point.discovered&&Vector2.Distance(run.position,point.position)<25);
                root.transform.position=Position(point.position);var mark=root.transform.Find("Essence mark");
                mark.localPosition=Vector3.up*(point.completed?.35f:3+Mathf.Sin(run.time*3)*.1f);
                mark.GetComponent<Renderer>().sharedMaterial=point.completed?green:purple;
            }
            foreach(var point in run.layout.offerings)
            {
                if(!offeringViews.TryGetValue(point.id,out var root))continue;
                root.SetActive(point.discovered&&!point.collected&&Vector2.Distance(run.position,point.position)<25);
                root.transform.Find("Offering flame").GetComponent<Renderer>().sharedMaterial=point.available?ember:purple;
            }
            var altar=run.layout.altar;if(offeringAltarView==null||altar==null)return;
            offeringAltarView.SetActive(altar.discovered&&Vector2.Distance(run.position,altar.position)<25);
            bool done=altar.phase==OfferingAltarPhase.Offered;int count=RiftObjectives.Completed(run.layout);
            for(int i=0;i<offeringSlots.Count;i++)offeringSlots[i].GetComponent<Renderer>().sharedMaterial=done?green:i<count?ember:purple;
            float fraction=Mathf.Clamp01(altar.progress/RiftOfferingAltar.Duration);offeringProgress.gameObject.SetActive(fraction>0);offeringProgress.sharedMaterial=done?green:ember;
            offeringProgress.positionCount=49;
            for(int i=0;i<49;i++){float a=i/48f*Mathf.PI*2*fraction;offeringProgress.SetPosition(i,new Vector3(Mathf.Cos(a)*1.1f,0,Mathf.Sin(a)*1.1f));}
        }
    }
}
