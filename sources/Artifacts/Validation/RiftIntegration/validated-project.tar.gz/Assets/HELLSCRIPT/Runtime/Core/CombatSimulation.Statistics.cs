using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        readonly List<TickDamageSource> pendingTickDamage = new List<TickDamageSource>();
        readonly List<BlockedSkillAttempt> pendingTickBlocked = new List<BlockedSkillAttempt>();
        // Damage can also land outside a tick (fixtures call Hurt directly), so the pending lists are capped.
        const int PendingLimit = 512;
        static readonly List<TickDamageSource> NoDamage = new List<TickDamageSource>();
        static readonly List<BlockedSkillAttempt> NoBlocked = new List<BlockedSkillAttempt>();

        static bool BlockedRuleCode(string code, out BlockReason reason)
        {
            switch (code)
            {
                case "COOLDOWN": reason = BlockReason.Cooldown; return true;
                case "RESOURCE": reason = BlockReason.Resource; return true;
                case "ACTION_LOCK": case "CHANNELING": reason = BlockReason.ActionLock; return true;
                case "LEVEL_LOCK": reason = BlockReason.Other; return true;
                // Range, sightline, target and condition codes describe positioning, not a locked-out skill.
                default: reason = BlockReason.Other; return false;
            }
        }

        void RecordBlockedDecision(Rule rule, string code, string detail)
        {
            if (rule == null || rule.action != RuleAction.Skill) return;
            if (!BlockedRuleCode(code, out var reason)) return;
            RecordBlockedSkill(rule.skill, reason, detail);
        }

        void ObserveMovementStart(HeroActionState movement)
        {
            // Only the owned danger fixture's real N10 warnings have a verified warning-to-impact link here.
            if(!OwnedTraining||State.training!=2)return;
            var stats=State.statistics;
            foreach(var enemy in State.enemies.Where(e=>!e.dead&&e.kind==9&&e.brain.action.phase==EnemyActionPhase.Preparing))
            {
                int attack=enemy.brain.action.id;
                if(stats.pendingEvasions.Any(e=>e.attackId==attack))continue;
                var threat=EnemyCombat.Threats(State,Map).FirstOrDefault(t=>t.key=="action-"+attack);
                if(threat.key==null||!EnemyCombat.Contains(threat,State.position)||!Map.LineClear(threat.origin,State.position))continue;
                stats.pendingEvasions.Add(new EvasionObservation{enemyId=enemy.id,attackId=attack,movementId=movement.id,startedAt=State.time});stats.evasionAttempts++;
            }
        }
        void ObserveHazardImpact(EnemyHazard hazard,bool inside,bool visible)
        {
            if(!OwnedTraining||State.training!=2||hazard.definitionId!="N10")return;
            var stats=State.statistics;
            foreach(var observation in stats.pendingEvasions.Where(e=>e.attackId==hazard.actionId&&e.enemyId==hazard.enemyId).ToArray())
            {
                if(!inside)stats.evasionSuccesses++;else if(visible)stats.evasionHits++;else stats.evasionExcluded++;
                stats.pendingEvasions.Remove(observation);
            }
        }
        void RemoveCancelledEvasions()
        {
            var stats=State.statistics;if(stats.pendingEvasions.Count==0)return;
            foreach(var observation in stats.pendingEvasions.ToArray())
            {
                bool preparing=State.enemies.Any(e=>!e.dead&&e.id==observation.enemyId&&e.brain.action.id==observation.attackId&&e.brain.action.phase==EnemyActionPhase.Preparing);
                bool pending=State.enemyHazards.Any(h=>h.enemyId==observation.enemyId&&h.actionId==observation.attackId);
                if(preparing||pending)continue;stats.evasionExcluded++;stats.pendingEvasions.Remove(observation);
            }
        }

        public void RecordBlockedSkill(int skill, BlockReason reason, string detail)
        {
            if (pendingTickBlocked.Count >= PendingLimit) return;
            string skillId = SkillId(skill);
            string skillName = (catalog != null && skill >= 0 && skill < catalog.skills.Count) ? catalog.skills[skill].name : skillId;
            pendingTickBlocked.Add(new BlockedSkillAttempt
            {
                skill = skill,
                skillId = skillId,
                skillName = skillName,
                reason = reason,
                detail = detail,
                time = State.time
            });
        }

        void RecordTickIncomingDamage(float damage, float hpLoss, string caster, string definition)
        {
            if (pendingTickDamage.Count >= PendingLimit) return;
            string srcName = definition;
            bool boss = false;
            if (int.TryParse(caster, out int enemyId))
            {
                var enemy = State.enemies.Find(e => e.id == enemyId);
                if (enemy != null)
                {
                    boss = enemy.boss;
                    srcName = Loc.F("{0} · {1}", (boss ? GameCatalog.BossNames[enemy.pattern] : GameCatalog.EnemyNames[enemy.kind]), (definition ?? "일반 공격"));
                }
            }
            else if (definition == "N10") srcName = "맹독 바닥 (N10)";
            else if (definition == "ENEMY_GROUND") srcName = "적 장판 피해";
            else if (definition == "ENEMY_ATTACK") srcName = "적 일반 공격";

            pendingTickDamage.Add(new TickDamageSource
            {
                sourceId = definition ?? caster ?? "ENEMY",
                sourceName = srcName ?? "적 공격",
                damage = damage,
                hpLoss = hpLoss,
                isBoss = boss,
                isHazard = definition != null && (definition.StartsWith("N") || definition.Contains("GROUND") || definition.Contains("HAZARD"))
            });
        }

        void RecordTickTelemetry()
        {
            if (State?.statistics == null) { pendingTickDamage.Clear(); pendingTickBlocked.Clear(); return; }
            float totalIncoming = 0, totalHpLoss = 0;
            foreach (var d in pendingTickDamage) { totalIncoming += d.damage; totalHpLoss += d.hpLoss; }
            State.statistics.RecordSnapshot(new CombatTickSnapshot
            {
                tick = State.statistics.ticks,
                time = State.time,
                hp = Mathf.Max(0, State.health),
                maxHp = Stats?.hp ?? 100f,
                resource = State.resource,
                incomingDamage = totalIncoming,
                hpLoss = totalHpLoss,
                // Quiet ticks share one empty list; captured lists are read-only from here on.
                damageSources = pendingTickDamage.Count > 0 ? new List<TickDamageSource>(pendingTickDamage) : NoDamage,
                blockedAttempts = pendingTickBlocked.Count > 0 ? new List<BlockedSkillAttempt>(pendingTickBlocked) : NoBlocked
            });
            pendingTickDamage.Clear();
            pendingTickBlocked.Clear();
        }
    }
}
