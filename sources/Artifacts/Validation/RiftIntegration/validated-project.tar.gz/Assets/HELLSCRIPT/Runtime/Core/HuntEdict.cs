using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    [Serializable] public sealed class EdictOption
    {
        public string id,value;
        public EdictOption(string id,string value){this.id=id;this.value=value;}
    }
    [Serializable] public sealed class EdictAction
    {
        public string id;
        public bool automatic=true;
    }
    [Serializable] public sealed class EdictCondition
    {
        public string id="SC01",comparison="AtMost",choiceId="",skillId="";
        public float value=30,upper=8,radius=3,window=2;
        public bool predicted;
    }
    [Serializable] public sealed class EdictConditionGroup
    {public List<EdictCondition> conditions=new List<EdictCondition>();}
    [Serializable] public sealed class EdictRule
    {
        public string actionId;
        public int slot=1;
        public bool enabled=true,always=true,overrideMovement,escape;
        public string target="Default",positionPurpose="Default",areaAim="Target",blizzardMode="Follow",movement="Approach";
        public float distance=2,targetRadius=3;
        public List<EdictConditionGroup> groups=new List<EdictConditionGroup>();
        public List<EdictOption> options=new List<EdictOption>();
        public string Key=>actionId+":"+slot;
    }
    [Serializable] public sealed class HuntEdictDocument
    {
        public int schema=HuntEdict.Version,contentVersion=HuntEdict.ContentVersion;
        public string heroClass;
        public string[] slots={"","","",""};
        public List<EdictOption> global=new List<EdictOption>();
        public List<EdictAction> actions=new List<EdictAction>();
        // This is the full ordered storage, including unequipped skills; runtime projection is separate.
        public List<EdictRule> rules=new List<EdictRule>();
        public HuntEdictDocument Copy()=>JsonUtility.FromJson<HuntEdictDocument>(JsonUtility.ToJson(this));
    }
    public static class HuntEdict
    {
        public const int Version=1,ContentVersion=1,PresetSlots=5,ActiveSlots=4,MaxRules=93;
        public static readonly string[] ClassIds={"WARRIOR","RANGER","MAGE"};
        public static readonly string[] UtilityIds={"BASIC","LOOT","CHEST","EXPLORE"};
        public static int RuleLimit(string actionId)=>actionId=="LOOT"||actionId=="CHEST"||actionId=="EXPLORE"?24:3;
        public static string ClassId(HeroClass hero)=>ClassIds[(int)hero];
        public static int ClassIndex(string id)=>Array.IndexOf(ClassIds,id);
        public static string[] SkillIds(string heroClass)
        {
            int hero=ClassIndex(heroClass);if(hero<0)throw new ArgumentException("알 수 없는 직업입니다.");
            string prefix=new[]{"W","A","M"}[hero];return Enumerable.Range(1,6).Select(i=>prefix+i.ToString("00")).ToArray();
        }
        public static string[] ActionIds(string heroClass)=>UtilityIds.Concat(SkillIds(heroClass)).ToArray();
        public static HuntEdictDocument Create(HeroClass hero)
        {
            var result=new HuntEdictDocument{heroClass=ClassId(hero),global=EdictOptions.Defaults(EdictOptions.Global)};
            foreach(string id in ActionIds(result.heroClass))
            {result.actions.Add(new EdictAction{id=id});result.rules.Add(NewRule(id,1,result.heroClass));}
            return result;
        }
        public static EdictRule NewRule(string actionId,int slot,string heroClass)=>new EdictRule{actionId=actionId,slot=slot,options=EdictOptions.Defaults(EdictOptions.ForAction(actionId,heroClass))};
        public static void SelectSlot(HuntEdictDocument draft,int slot,string skillId)
        {
            if(draft==null||draft.slots==null||draft.slots.Length!=ActiveSlots||slot<0||slot>=ActiveSlots)throw new ArgumentException("사용 스킬 칸은 1~4입니다.");
            if(skillId==null||skillId!=""&&!SkillIds(draft.heroClass).Contains(skillId))throw new ArgumentException("같은 직업의 스킬을 선택하세요.");
            int previous=Array.IndexOf(draft.slots,skillId);
            if(skillId!=""&&previous>=0&&previous!=slot){string displaced=draft.slots[slot];draft.slots[slot]=skillId;draft.slots[previous]=displaced;}
            else draft.slots[slot]=skillId;
        }
    }
}
