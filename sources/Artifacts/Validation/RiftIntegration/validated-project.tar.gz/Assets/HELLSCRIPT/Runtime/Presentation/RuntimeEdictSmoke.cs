using System;
using System.Collections;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Opt-in native development-player evidence for the hunt edict editor and share screens.
    // Always requires an isolated account path; never touches a real player's save.
    public sealed class RuntimeEdictSmoke : MonoBehaviour
    {
        GameController game;
        string directory,saveDirectory;
        int captureIndex;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if(!Debug.isDebugBuild||!Environment.GetCommandLineArgs().Contains("-hellscriptEdictSmoke"))return;
            Application.runInBackground=true;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Hunt edict editor validation").AddComponent<RuntimeEdictSmoke>();
        }
        static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
        static string Json(object value)=>JsonUtility.ToJson(value);
        static string Account(AccountSave source){var copy=JsonUtility.FromJson<AccountSave>(Json(source));copy.lastSeenUtc=0;return Json(copy);}
        T Field<T>(object target,string name)=>(T)target.GetType().GetField(name,BindingFlags.Instance|BindingFlags.NonPublic).GetValue(target);
        HuntEdictV2Document Draft=>Field<HuntEdictV2Document>(game.UI,"edictDraft");
        Button[] Buttons=>game.UI.GetComponentsInChildren<Button>();
        Button Named(string name)=>Buttons.Single(b=>b.name==name);
        Button Containing(string part)=>Buttons.Single(b=>b.name.Contains(part));
        // Step and order buttons repeat on the page, so they are found through the label of their own row.
        Button InRow(string buttonName,string rowLabelStart)=>Buttons.Single(b=>b.name==buttonName&&b.transform.parent.GetComponentsInChildren<Text>().Any(t=>t.text.StartsWith(rowLabelStart,StringComparison.Ordinal)));
        void Click(Button button){Require(button.IsInteractable(),"Disabled: "+button.name);button.onClick.Invoke();}
        void ScrollTo(Button button)
        {
            Canvas.ForceUpdateCanvases();var row=(RectTransform)button.transform;if(row.parent.name=="Card")row=(RectTransform)row.parent;
            var scroll=row.GetComponentInParent<ScrollRect>();if(scroll==null)return;
            scroll.content.anchoredPosition=new Vector2(0,Mathf.Clamp(-(row.localPosition.y+row.rect.yMax),0,Mathf.Max(0,scroll.content.rect.height-scroll.viewport.rect.height)));scroll.StopMovement();
        }
        bool TextShown(string part)=>game.UI.GetComponentsInChildren<Text>().Any(t=>t.text.Contains(part));
        static string G(HuntEdictV2Document d,string id)=>d.global.Single(o=>o.id==id).value;
        void Note(string line)=>File.AppendAllText(Path.Combine(directory,"runtime-edict-smoke.txt"),line+"\n");
        IEnumerator Capture(string label)
        {
            yield return new WaitForSecondsRealtime(.2f);Canvas.ForceUpdateCanvases();
            var safe=UiSafeArea.Current;var corners=new Vector3[4];
            foreach(var button in Buttons.Where(b=>b.transform.parent.name=="Footer"))
            {((RectTransform)button.transform).GetWorldCorners(corners);Require(corners.All(c=>c.x>=safe.xMin-1&&c.x<=safe.xMax+1&&c.y>=safe.yMin-1&&c.y<=safe.yMax+1),"Footer button outside safe area: "+button.name);}
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,$"{++captureIndex:00}-{label}.png"));yield return new WaitForSecondsRealtime(.2f);
        }
        IEnumerator Resize(int width,int height)
        {
            Screen.SetResolution(width,height,FullScreenMode.Windowed);float deadline=Time.realtimeSinceStartup+6;
            while((Screen.width!=width||Screen.height!=height)&&Time.realtimeSinceStartup<deadline)yield return null;
            Require(Screen.width==width&&Screen.height==height,$"Native window did not reach {width}x{height}; actual {Screen.width}x{Screen.height}.");
            yield return new WaitForSecondsRealtime(.2f);
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();
            for(int i=0;i<args.Length-1;i++){if(args[i]=="-hellscriptScreenshots")directory=args[i+1];if(args[i]=="-hellscriptSavePath")saveDirectory=args[i+1];}
            Require(!string.IsNullOrEmpty(directory)&&!string.IsNullOrEmpty(saveDirectory),"Use isolated save and evidence directories.");Directory.CreateDirectory(directory);
            Screen.SetResolution(1280,720,FullScreenMode.Windowed);yield return new WaitForSecondsRealtime(1);
            game=FindAnyObjectByType<GameController>();Require(game.Store!=null,"Store failed to open.");
            if(args.Contains("-hellscriptEdictResume")){yield return Resume();yield break;}
            game.SelectHero(2);var hero=game.Store.Data.Hero;
            Require(hero.level==1&&!hero.useEdict&&!HuntEdictV2Storage.IsAbsent(hero.edict),"Use a fresh account with a default document.");
            string saved=Json(hero.edict);string account=Account(game.Store.Data);

            // ---- editor: global settings ----
            Click(Named("사냥 칙령 v0.2 편집"));Require(game.UI.Page=="edict","Editor did not open.");
            Require(TextShown("저장된 설정과 같습니다"),"A fresh draft must read as unchanged.");
            // Unscrolled: shows how much of the option list a landscape window reveals above the fold.
            yield return Capture("editor-top-1280x720");
            ScrollTo(Containing("체력 위기 대응"));yield return Capture("editor-global-1280x720");
            Click(Containing("체력 위기 대응"));Require(G(Draft,"survival.lowHp")=="ON","Toggle did not turn on.");Require(TextShown("저장하지 않은 변경 1개"),"Change count missing after one edit.");
            Click(InRow("+","후퇴 시작 HP"));Require(G(Draft,"survival.lowHpPercent")=="31","Step + did not add one percent.");
            Click(InRow("-","후퇴 시작 HP"));Click(InRow("-","후퇴 시작 HP"));Require(G(Draft,"survival.lowHpPercent")=="29","Step - did not subtract.");
            Click(InRow("▼ 아래로","1. 지정 방어기"));Require(G(Draft,"survival.order")=="ESCAPE,DEFENSE,WALK","Order move did not swap the first two items.");
            Click(Containing("지정 회피기"));Require(G(Draft,"survival.escapeSkill")=="M04","Skill reference did not cycle to the class escape skill.");
            Require(Json(hero.edict)==saved&&Account(game.Store.Data)==account,"Editing the draft changed the saved account.");
            Click(Named("회피 규칙"));Click(Containing("+ 기절"));Require(G(Draft,"dodge.control")=="STUN","Set toggle did not add the item.");
            Click(Containing("회피 수단"));Require(G(Draft,"dodge.method")=="SKILL_FIRST","Choice did not advance to the next value.");
            ScrollTo(Containing("+ 빙결"));yield return Capture("editor-dodge-1280x720");

            // ---- editor: slots and shared order ----
            Click(Named("사용 스킬·순서"));string firstOrder=Draft.skillOrder[0];
            Click(InRow("▼ 아래로","1. "));Require(Draft.skillOrder[1]==firstOrder,"Attack order move did not shift the first skill down.");
            string firstSlot=Draft.slots[0];Click(Containing("1번 칸"));
            Require(Draft.slots[0]!=firstSlot&&(Draft.slots[0]==""||game.catalog.skills.Single(s=>s.id==Draft.slots[0]).unlock<=hero.level),"Slot cycle chose a locked skill or did not move.");
            ScrollTo(Containing("1번 칸"));yield return Capture("editor-slots-1280x720");

            // ---- editor: per-skill options ----
            Click(Named("스킬 설정"));Click(Named("기본 공격"));
            Click(Containing("자동 사용"));Require(HuntEdictV2.Value(Draft,"BASIC",1)=="OFF","Basic attack automatic toggle did not turn off.");
            Click(Containing("사용 방식"));Require(HuntEdictV2.Value(Draft,"BASIC",2)=="RESOURCE","Basic attack second option did not advance.");
            Require(TextShown("비활성"),"Turning automatic use off should surface an inactive note.");
            ScrollTo(Containing("자동 사용"));yield return Capture("editor-skill-1280x720");
            yield return Resize(720,1280);ScrollTo(Containing("자동 사용"));yield return Capture("editor-skill-720x1280");
            yield return Resize(640,360);ScrollTo(Containing("자동 사용"));yield return Capture("editor-skill-640x360");
            yield return Resize(1280,720);

            // ---- save writes the file first, then the hero ----
            string disk=File.ReadAllText(Path.Combine(saveDirectory,"hellscript-local-v1.json"));
            Click(Named("저장 및 적용"));
            Require(G(hero.edict,"survival.lowHp")=="ON"&&G(hero.edict,"dodge.method")=="SKILL_FIRST"&&HuntEdictV2.Value(hero.edict,"BASIC",1)=="OFF","Save did not apply the draft to the hero.");
            Require(File.ReadAllText(Path.Combine(saveDirectory,"hellscript-local-v1.json"))!=disk,"Save did not write the file.");
            var reopened=new GameStore(saveDirectory,game.catalog);Require(Json(reopened.Data.Hero.edict)==Json(hero.edict),"The saved file does not match the hero in memory.");
            Require(TextShown("저장된 설정과 같습니다"),"After saving the draft must read as unchanged.");

            // ---- leaving with unsaved changes offers a choice; revert restores ----
            Click(Named("전역 설정"));Click(Named("긴급 생존·회복"));Click(Containing("치명적 피해 대응"));Require(G(Draft,"survival.lethal")=="ON","Second edit did not apply.");
            Click(Named("돌아가기"));Require(Buttons.Any(b=>b.name=="저장하고 나가기")&&Buttons.Any(b=>b.name=="저장하지 않고 나가기")&&Buttons.Any(b=>b.name=="계속 편집하기"),"Leave choices missing.");
            yield return Capture("editor-leave-choices");
            Click(Named("계속 편집하기"));Require(G(Draft,"survival.lethal")=="ON","Continue lost the draft.");
            Click(Named("되돌리기"));Require(G(Draft,"survival.lethal")=="OFF"&&TextShown("저장된 설정과 같습니다"),"Revert did not restore the saved document.");

            // ---- share: export through the clipboard ----
            Click(Named("공유"));Require(game.UI.Page=="edict-share","Share screen did not open.");
            Click(Named("코드 복사"));string code=GUIUtility.systemCopyBuffer;
            Require(code.StartsWith("HED2.",StringComparison.Ordinal),"Clipboard does not hold a HED2 code.");
            Require(Json(HuntEdictV2Codec.Decode(code))==Json(HuntEdictV2.Canonical(hero.edict)),"Exported code does not decode to the saved document.");
            yield return Capture("share-1280x720");

            // ---- share: import a changed code, inspect, apply ----
            var incoming=HuntEdictV2Editing.WithGlobal(hero.edict,"survival.lethal","ON");
            GUIUtility.systemCopyBuffer=HuntEdictV2Codec.Encode(incoming);
            // Import clears slots the hero has not unlocked, and each cleared slot is itself a listed change.
            int locked=hero.edict.slots.Count(s=>s!=""&&game.catalog.skills.Single(k=>k.id==s).unlock>hero.level);
            Click(Named("클립보드의 코드 확인"));
            Require(TextShown($"바뀌는 값 {1+locked}개"),$"Import preview should list one option change plus {locked} cleared locked slots.");
            Require(TextShown("치명적 피해 대응"),"The changed option must be named in the preview.");
            Require(locked==0||TextShown("비운 채로 가져옵니다"),"Cleared locked slots must be announced.");
            yield return Capture("share-import-preview");
            Click(Named("이 코드로 적용"));Require(G(hero.edict,"survival.lethal")=="ON","Import did not apply.");
            Require(hero.edict.slots.All(s=>s==""||game.catalog.skills.Single(k=>k.id==s).unlock<=hero.level),"Applied import kept a locked skill in a slot.");
            Require(G(new GameStore(saveDirectory,game.catalog).Data.Hero.edict,"survival.lethal")=="ON","Imported document did not reach the file.");
            GUIUtility.systemCopyBuffer="not a code";Click(Named("클립보드의 코드 확인"));Require(TextShown("코드를 사용할 수 없습니다"),"A damaged code must be reported on screen.");

            // ---- share: the switch persists ----
            Click(Named("사냥 칙령 v0.2 사용하기"));Require(hero.useEdict&&new GameStore(saveDirectory,game.catalog).Data.Hero.useEdict,"Switch did not persist.");
            yield return Capture("share-enabled");

            File.WriteAllText(Path.Combine(directory,"expected-account.json"),Json(game.Store.Data));
            Note("PASS: editor toggle/step/order/reference/set/choice, attack order and slot, per-skill toggle and choice, save writes file then hero, leave choices and revert, clipboard export decodes, import preview/apply/damaged code, switch persisted.");
            Debug.Log("HELLSCRIPT_EDICT_CHECKPOINT_READY");Application.Quit(0);
        }
        IEnumerator Resume()
        {
            var expected=JsonUtility.FromJson<AccountSave>(File.ReadAllText(Path.Combine(directory,"expected-account.json")));
            Require(Account(expected)==Account(game.Store.Data),"Restart changed the edict, the switch or the account.");
            var hero=game.Store.Data.Hero;
            Require(hero.useEdict&&G(hero.edict,"survival.lethal")=="ON"&&G(hero.edict,"dodge.method")=="SKILL_FIRST","Restart lost saved edict values.");
            game.UI.ShowEdictEditor();Require(TextShown("저장된 설정과 같습니다"),"Editor after restart must read the saved document as unchanged.");
            yield return Capture("editor-after-restart");
            Note("PASS: independent process restart kept the edict document, the switch and the account.");
            Debug.Log("HELLSCRIPT_EDICT_RUNTIME_SMOKE_OK");Application.Quit(0);
        }
    }
}
