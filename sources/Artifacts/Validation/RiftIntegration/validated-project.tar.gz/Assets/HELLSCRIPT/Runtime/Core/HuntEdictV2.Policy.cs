using System;
using System.Globalization;
using System.Linq;

namespace Hellscript
{
    // Derives the legacy global policy fields the simulation already reads from a v0.2 document.
    // The result is a copy: the live BuildConfig, its rules and its loadout are never rewritten,
    // so turning the edict off returns the hero to exactly the behaviour it had before.
    public static class EdictPolicyBridge
    {
        static readonly string[] LegacyRarities={"NORMAL","MAGIC","RARE","LEGENDARY"};

        public static BuildConfig Apply(BuildConfig source,HuntEdictV2Document document,HeroClass hero)
        {
            if(source==null)throw new ArgumentException("전투 설정이 없습니다.");
            var d=HuntEdictV2.Canonical(document);var b=source.Copy();
            string G(string id)=>d.global.Single(o=>o.id==id).value;
            bool On(string id)=>G(id)=="ON";
            float N(string id)=>float.Parse(G(id),CultureInfo.InvariantCulture);

            // 공격 대상: the legacy mode is single-valued. HIGH_HP and RANGED have no counterpart and fall
            // through to the next enabled preference rather than inventing one.
            b.target=G("target.default") switch{"LOW_HP"=>TargetMode.LowHealth,"DENSE"=>TargetMode.Dense,_=>TargetMode.Nearest};
            var special=new System.Collections.Generic.HashSet<string>(G("target.specialEnabled").Split(',',StringSplitOptions.RemoveEmptyEntries));
            foreach(string item in G("target.specialOrder").Split(','))
            {
                if(!special.Contains(item))continue;
                if(item=="BOSS"||item=="ELITE"){b.target=TargetMode.Elite;break;}
                if(item=="SUPPORT"){b.target=TargetMode.Support;break;}
            }

            // 전투 위치: EDGE has no exact legacy mode; orbiting is the closest reading of "가장자리".
            b.movement=G("position.mode") switch{"CENTER"=>MovementMode.Approach,"DISTANCE"=>MovementMode.KeepDistance,"STAND"=>MovementMode.Stand,_=>MovementMode.Orbit};
            b.distance=G("position.distanceSource")=="BASIC_RANGE"?(hero==HeroClass.Warrior?2f:10f):N("position.distance");
            b.clockwise=On("position.clockwise");

            // 자동 물약: 0 never fires because a living hero is always above 0%.
            b.potionThreshold=On("survival.potion")?N("survival.potionHpPercent"):0f;

            // 전리품: the legacy engine has two thresholds. Anything not ignored is picked up in passing;
            // anything collected after or during combat is chased. SET has no legacy channel.
            int minimum=4,pursue=4;
            for(int i=0;i<LegacyRarities.Length;i++)
            {
                string mode=G("loot."+LegacyRarities[i]);
                if(mode!="IGNORE"&&minimum==4)minimum=i;
                if((mode=="AFTER_COMBAT"||mode=="PRIORITY")&&pursue==4)pursue=i;
            }
            b.minimumRarity=minimum;b.pursueRarity=Math.Max(pursue,minimum);
            b.bagPolicy=G("bag.policy") switch{"REPLACE"=>BagPolicy.Replace,"IGNORE"=>BagPolicy.Ignore,_=>BagPolicy.Portal};

            // 탐색·상호작용
            b.exploration=G("explore.mode") switch{"NEAREST_UNSEEN"=>ExplorationPolicy.NearestUnexplored,"LEFT_WALL"=>ExplorationPolicy.LeftWall,"DETECTED_ENEMIES"=>ExplorationPolicy.FollowEnemies,_=>ExplorationPolicy.RightWall};
            b.openChests=On("explore.chests");
            b.commonChests=G("explore.normalChest")!="IGNORE";
            b.sealedChests=G("explore.sealedChest")!="IGNORE";
            b.chestDetour=N("explore.chestDetour");
            b.chestsAfterBoss=On("explore.chestsAfterBoss");
            b.allowCursedChests=G("explore.cursedChest")!="OFF";
            b.cursedMinimumTime=N("explore.cursedMinimumTime");
            b.useShrines=G("explore.shrine")!="OFF";
            b.guideShrines=On("explore.guideShrine");
            b.resolveShrines=On("explore.resolveShrine");
            b.shrineDetour=N("explore.shrineDetour");

            // 반복: "stop after a success" cannot be expressed by the legacy flags, so it is read as no
            // automatic repeat at all - the conservative reading that never starts a run the player did not ask for.
            b.autoRepeat=On("repeat.enabled")&&G("repeat.success")!="STOP";
            b.advanceOnWin=G("repeat.success")=="NEXT";
            b.stopAfterFailures=(int)N("repeat.failures");
            return b;
        }
    }
}
