using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Opt-in native development-player evidence; always requires an isolated account path.
    // Measures every reachable control against the 48dp touch minimum and against the area it
    // is allowed to occupy, at portrait and landscape window shapes including 20:9 phones.
    public sealed class RuntimeTouchLayoutSmoke : MonoBehaviour
    {
        GameController game;
        string directory, saveDirectory;
        int captureIndex;
        readonly List<string> findings = new List<string>();
        readonly List<string> measured = new List<string>();
        readonly List<string> pending = new List<string>();
        // The rule editor, the edict editor and the battle HUD pack many widgets into fixed bands, so
        // raising them to the touch minimum is a layout change of its own. They are measured and
        // recorded here rather than enforced, and they still have to keep every control reachable.
        static bool Enforced(string page) => page != "행동 설계" && page != "사냥 칙령 편집" && page != "전투";
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if (!Debug.isDebugBuild || !Environment.GetCommandLineArgs().Contains("-hellscriptTouchLayoutSmoke")) return;
            Application.runInBackground = true;
            Application.logMessageReceived += (message, stack, type) => { if (type == LogType.Exception) Application.Quit(1); };
            new GameObject("Touch layout validation").AddComponent<RuntimeTouchLayoutSmoke>();
        }
        static void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
        void Click(string name, Transform parent = null)
        { var button = (parent ?? game.UI.transform).GetComponentsInChildren<Button>().Single(b => b.name == name); Require(button.IsInteractable(), "Disabled: " + name); button.onClick.Invoke(); }
        IEnumerator Resize(int width, int height)
        {
            Screen.SetResolution(width, height, FullScreenMode.Windowed); float deadline = Time.realtimeSinceStartup + 6;
            while ((Screen.width != width || Screen.height != height) && Time.realtimeSinceStartup < deadline) yield return null;
            Require(Screen.width == width && Screen.height == height, $"Native window did not reach {width}x{height}; actual {Screen.width}x{Screen.height}.");
            yield return new WaitForSecondsRealtime(.25f);
        }
        static RectTransform Clip(RectTransform target)
        {
            for (var parent = target.parent as RectTransform; parent != null; parent = parent.parent as RectTransform)
                if (parent.GetComponent<RectMask2D>() != null) return parent;
            return null;
        }
        static Rect Relative(RectTransform target, RectTransform container)
        { var b = RectTransformUtility.CalculateRelativeRectTransformBounds(container, target); return new Rect(b.min.x, b.min.y, b.size.x, b.size.y); }
        void Audit(string page, RectTransform area)
        {
            bool enforceSize = Enforced(page);
            Canvas.ForceUpdateCanvases();
            var canvas = area.GetComponentInParent<Canvas>().rootCanvas;
            var scaler = canvas.GetComponent<CanvasScaler>();
            bool constant = scaler.uiScaleMode == CanvasScaler.ScaleMode.ConstantPixelSize;
            float across = ((RectTransform)canvas.transform).rect.width;
            float minimum = constant ? TouchLayout.ConstantMinimum() : TouchLayout.ScaledMinimum();
            int counted = 0;
            foreach (var selectable in area.GetComponentsInChildren<Selectable>())
            {
                if (!selectable.gameObject.activeInHierarchy || !selectable.IsInteractable()) continue;
                var rect = (RectTransform)selectable.transform; var size = rect.rect.size;
                var container = Clip(rect) ?? area; var control = Relative(rect, container);
                var scroll = container.GetComponentInParent<ScrollRect>();
                bool scrolls = scroll != null && scroll.viewport == container && scroll.vertical;
                counted++;
                string where = $"{page} {Screen.width}x{Screen.height} {selectable.name}";
                // Anything a vertical list can bring into view is reachable; only the sideways fit matters there.
                bool inside = scrolls
                    ? control.xMin >= container.rect.xMin - 1 && control.xMax <= container.rect.xMax + 1
                    : TouchLayout.Inside(control, container.rect);
                if (!inside)
                    findings.Add($"OUTSIDE {where} control=({control.xMin:0},{control.yMin:0},{control.width:0},{control.height:0}) inside {container.name}=({container.rect.xMin:0},{container.rect.yMin:0},{container.rect.width:0},{container.rect.height:0})");
                if (!TouchLayout.Meets(size, minimum))
                {
                    if (enforceSize) findings.Add($"SMALL {where} size=({size.x:0},{size.y:0}) minimum={minimum:0.0}");
                    else pending.Add($"{where} size=({size.x:0},{size.y:0}) minimum={minimum:0.0}");
                }
            }
            measured.Add($"{page} {Screen.width}x{Screen.height} canvas={across:0} minimum={minimum:0.0} controls={counted} enforced={enforceSize}");
            Require(counted > 0, "No reachable control on " + page);
        }
        RectTransform Safe => (RectTransform)game.UI.transform.Find("HELLSCRIPT UI/Safe area");
        IEnumerator Page(string button, string page, bool shot = false)
        {
            game.UI.ShowTown(); yield return null;
            Click(button); yield return new WaitForSecondsRealtime(.2f);
            Audit(page, Safe);
            if (shot) { ScreenCapture.CaptureScreenshot(Path.Combine(directory, $"{++captureIndex:00}-{page}-{Screen.width}x{Screen.height}.png")); yield return new WaitForSecondsRealtime(.2f); }
        }
        IEnumerator Sweep(bool shots)
        {
            game.UI.ShowTown(); yield return new WaitForSecondsRealtime(.2f); Audit("성소", Safe);
            if (shots) { ScreenCapture.CaptureScreenshot(Path.Combine(directory, $"{++captureIndex:00}-town-{Screen.width}x{Screen.height}.png")); yield return new WaitForSecondsRealtime(.2f); }
            yield return Page("균열 관리자 · 단계·소탕·훈련", "균열 관리자", shots);
            yield return Page("자동 행동 설계", "행동 설계");
            yield return Page("사냥 칙령 v0.2 편집", "사냥 칙령 편집", shots);
            yield return Page("사냥 칙령 공유 · v0.2 사용", "사냥 칙령 공유");
            yield return Page("성장과 스킬", "성장");
            yield return Page("장비 · 대장간 · 창고", "장비", shots);
            yield return Page("고정 훈련장", "훈련장");
            yield return Page("수수께끼 상인 · 제작", "상점");
            yield return Page("전투 기록", "전투 기록");
            game.UI.ShowTown(); yield return null;
            Click("성소 거닐기 · NPC 방문"); yield return new WaitForSecondsRealtime(.3f); Audit("광장", Safe);
            if (shots) { ScreenCapture.CaptureScreenshot(Path.Combine(directory, $"{++captureIndex:00}-plaza-{Screen.width}x{Screen.height}.png")); yield return new WaitForSecondsRealtime(.2f); }
            game.UI.ShowTown(); yield return null;
            game.UI.ShowScreenSettings(); yield return new WaitForSecondsRealtime(.2f);
            Audit("설정·안내", (RectTransform)game.UI.transform.Find("Screen and help modal"));
            game.UI.CloseCommonPanel(); yield return null;
            game.Begin(seed: 907712); yield return new WaitForSecondsRealtime(.6f);
            Audit("전투", Safe);
            if (shots) { ScreenCapture.CaptureScreenshot(Path.Combine(directory, $"{++captureIndex:00}-battle-{Screen.width}x{Screen.height}.png")); yield return new WaitForSecondsRealtime(.2f); }
            game.Combat.Abandon(); yield return new WaitForSecondsRealtime(1.2f);
            Audit("결과", Safe);
            game.ReturnTown(); yield return null;
        }
        IEnumerator Start()
        {
            var args = Environment.GetCommandLineArgs();
            for (int i = 0; i < args.Length - 1; i++) { if (args[i] == "-hellscriptSavePath") saveDirectory = args[i + 1]; if (args[i] == "-hellscriptScreenshots") directory = args[i + 1]; }
            Require(!string.IsNullOrEmpty(saveDirectory) && !string.IsNullOrEmpty(directory), "Use isolated save and evidence paths."); Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1); game = FindAnyObjectByType<GameController>(); Require(game.Store != null, "Account failed to load.");
            game.Store.Data.Hero.highestClear = 12; game.SelectedStage = 3; game.Save();
            foreach (var size in new[] { new Vector2Int(720, 1280), new Vector2Int(720, 1600), new Vector2Int(1280, 720), new Vector2Int(1600, 720) })
            { yield return Resize(size.x, size.y); yield return Sweep(size.y == 1600 || size.x == 1600); }
            // A stand-in notch and home bar: controls must stay inside the usable area while the
            // backdrop keeps covering the display.
            yield return Resize(720, 1600);
            UiSafeArea.Simulate(0, 96, 0, 132); game.UI.ShowTown(); yield return new WaitForSecondsRealtime(.4f);
            Require(UiSafeArea.Simulating, "The development build refused to stand in for a notch.");
            var safe = UiSafeArea.Current; var corners = new Vector3[4];
            Safe.GetWorldCorners(corners);
            Require(Mathf.Abs(corners[0].y - safe.yMin) < 2 && Mathf.Abs(corners[1].y - safe.yMax) < 2, $"Content did not follow the inset: {corners[0].y}..{corners[1].y} against {safe.yMin}..{safe.yMax}.");
            foreach (var name in new[] { "Display/Backdrop", "Display/Header apron", "Display/Footer apron" })
                Require(game.UI.transform.Find("HELLSCRIPT UI/" + name) != null, "Missing display layer: " + name);
            ((RectTransform)game.UI.transform.Find("HELLSCRIPT UI/Display/Backdrop")).GetWorldCorners(corners);
            Require(corners[0].y < 1 && corners[1].y > Screen.height - 1, "The backdrop stopped at the inset instead of covering the display.");
            ((RectTransform)game.UI.transform.Find("HELLSCRIPT UI/Display/Footer apron")).GetWorldCorners(corners);
            Require(Mathf.Abs(corners[1].y - safe.yMin) < 2 && corners[0].y < 1, "The footer colour did not continue into the home bar band.");
            Audit("성소(노치)", Safe);
            ScreenCapture.CaptureScreenshot(Path.Combine(directory, $"{++captureIndex:00}-town-simulated-notch.png")); yield return new WaitForSecondsRealtime(.3f);
            UiSafeArea.StopSimulating(); yield return new WaitForSecondsRealtime(.3f);
            File.WriteAllText(Path.Combine(directory, "touch-layout-measurements.txt"), string.Join("\n", measured) + "\n");
            File.WriteAllText(Path.Combine(directory, "touch-layout-findings.txt"), findings.Count == 0 ? "none\n" : string.Join("\n", findings) + "\n");
            File.WriteAllText(Path.Combine(directory, "touch-layout-pending.txt"), pending.Count == 0 ? "none\n" : string.Join("\n", pending) + "\n");
            if (findings.Count > 0) throw new InvalidOperationException($"{findings.Count} controls fail the touch minimum or leave their area; see touch-layout-findings.txt. First: {findings[0]}");
            File.WriteAllText(Path.Combine(directory, "runtime-touch-layout-smoke.txt"), $"PASS: {measured.Count} page and window combinations. Every control stays inside its own area sideways at 16:9 and 20:9 in both directions, and every control on the enforced pages is at least {TouchLayout.AuthoredMinimum:0} units, which is {TouchLayout.MinimumDp:0}dp on the reference phone. {pending.Count} measurements on the rule editor, the edict editor and the battle HUD are recorded in touch-layout-pending.txt instead of enforced. A stand-in notch and home bar keeps controls inside the usable area while the backdrop covers the display. UI callbacks and Metal rendering; no physical touch or device.\n");
            Debug.Log("HELLSCRIPT_TOUCH_LAYOUT_SMOKE_OK"); Application.Quit(0);
        }
    }
}
