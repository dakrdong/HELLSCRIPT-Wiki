using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimeAreaSmoke : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Install()
        {
            if(!Environment.GetCommandLineArgs().Contains("-hellscriptAreaSmoke"))return;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Area smoke validation").AddComponent<RuntimeAreaSmoke>();
        }
        static void Require(bool pass,string reason){if(!pass)throw new InvalidOperationException(reason);}
        static Button Prefix(string name)=>FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name.StartsWith(name));
        static IEnumerator Click(string name){Prefix(name).onClick.Invoke();yield return null;}
        static void ScrollTo(string prefix)
        {
            Canvas.ForceUpdateCanvases();var row=(RectTransform)Prefix(prefix).transform;var scroll=row.GetComponentInParent<ScrollRect>();
            while(row.parent!=scroll.content)row=(RectTransform)row.parent;
            scroll.content.anchoredPosition=new Vector2(0,Mathf.Clamp(-(row.localPosition.y+row.rect.yMax),0,Mathf.Max(0,scroll.content.rect.height-scroll.viewport.rect.height)));scroll.StopMovement();
        }
        static IEnumerator Until(Func<bool> ready,float timeout=10)
        {float end=Time.realtimeSinceStartup+timeout;while(!ready()&&Time.realtimeSinceStartup<end)yield return null;Require(ready(),"Area fixture did not reach its expected state.");}
        static IEnumerator Capture(GameController game,string directory,string file)
        {game.Combat.State.paused=true;game.UI.RefreshHud();yield return new WaitForSecondsRealtime(.3f);ScreenCapture.CaptureScreenshot(Path.Combine(directory,file));yield return new WaitForSecondsRealtime(.2f);}
        static RunState Arena(GameController game,HeroClass heroClass,string set,string legendary,int first)
        {
            if(game.Running)game.ReturnTown();var account=game.Store.Data;account.selectedHero=(int)heroClass;var hero=account.Hero;hero.level=30;hero.inventory.Clear();uint rng=726;
            foreach(string id in Enumerable.Range(1,4).Select(i=>set+i).Append(legendary))
            {var d=ItemCatalog.Unique(id);Require(!hero.inventory.Any(i=>i.equipped&&i.slot==d.slot),"Fixture tried to equip conflicting item slots.");var item=ItemGenerator.Create(heroClass,d.slot,3,30,ref rng,uniqueId:id);item.equipped=true;hero.inventory.Add(item);}
            hero.build=GameCatalog.Preset(heroClass,0);hero.build.passives=Array.Empty<int>();hero.build.rules.Clear();hero.build.rules.Add(BehaviorRules.Make(first));
            hero.build.activeSkills=heroClass==HeroClass.Mage?new[]{13,12}.ToList():new[]{8,6}.ToList();hero.build.movement=MovementMode.Stand;hero.build.distance=2;hero.build.potionThreshold=0;hero.build.autoRepeat=false;
            var sim=new CombatSimulation(account,game.catalog,1,1,seed:49057);var run=sim.State;run.training=-1;run.position=RiftMap.Rooms[0];run.enemies.Clear();
            run.enemies.Add(new EnemyState{id=900,kind=0,position=run.position+Vector2.up*2,health=100000,maxHealth=100000,speed=0,cooldown=1000});
            account.suspendedRun=run;game.Begin(resume:true);game.SetSpeed(1);game.Combat.State.paused=true;Require(game.Combat.Stats.SetPieces(set)==4,"Four-piece set not active.");return game.Combat.State;
        }
        static void SkillRule(GameController game,int skill)
        {var build=game.Combat.State.build.Copy();build.rules.Clear();build.rules.Add(BehaviorRules.Make(skill));Require(game.Combat.ApplyBuild(build),"Skill rule rejected.");game.Combat.State.decisionTime=0;game.UI.ShowBattle();}
        static void SaveCheckpoint(GameController game,string directory,string file)
        {game.Save();Require(game.Store.Error==""||game.Store.Error==null,"Checkpoint save failed.");File.WriteAllText(Path.Combine(directory,file),JsonUtility.ToJson(game.Combat.State,true));}
        static RunState Restore(GameController game,string directory,string file)
        {
            var saved=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(directory,file)));GameStore.NormalizeRun(saved);game.Begin(resume:true);var run=game.Combat.State;run.paused=true;
            Require(run.id==saved.id&&run.time==saved.time&&run.rng==saved.rng&&run.health==saved.health&&run.resource==saved.resource&&JsonUtility.ToJson(run.heroAction)==JsonUtility.ToJson(saved.heroAction)
                &&run.effects.Count==saved.effects.Count&&!run.effects.Where((f,i)=>JsonUtility.ToJson(f)!=JsonUtility.ToJson(saved.effects[i])).Any()
                &&run.enemies.Count==saved.enemies.Count&&!run.enemies.Where((e,i)=>JsonUtility.ToJson(e)!=JsonUtility.ToJson(saved.enemies[i])).Any(),"Area state changed across the actual process restart.");return run;
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();string directory="";for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptScreenshots")directory=args[i+1];
            Require(args.Contains("-hellscriptSavePath")&&!string.IsNullOrEmpty(directory),"Area smoke requires isolated save and output paths.");Directory.CreateDirectory(directory);Screen.SetResolution(540,960,FullScreenMode.Windowed);
            yield return new WaitForSecondsRealtime(1);var game=FindAnyObjectByType<GameController>();RunState run;
            if(!args.Contains("-hellscriptAreaResume")&&!args.Contains("-hellscriptPoisonResume"))
            {
                run=Arena(game,HeroClass.Mage,"SM","LM01",13);game.EditBuild();yield return Click("설치 위치");yield return Click("설치 위치");yield return Click("눈보라 이동");
                ScrollTo("설치 위치");yield return Capture(game,directory,"01-fixed-setting.png");yield return Click("설정 적용");
                Require(run.build.rules[0].areaAim==AreaAim.Self&&run.build.rules[0].blizzardMode==BlizzardMode.Fixed&&run.paused,"Actual editor did not commit ground settings or preserve pause.");
                yield return new WaitForSecondsRealtime(.5f);run.paused=false;yield return Until(()=>run.effects.Any(f=>f.kind==13));run.paused=true;run.decisionTime=100;
                var first=run.effects.Single(f=>f.kind==13);Vector2 origin=first.position;Require(!first.followsTarget,"Fixed setting created a moving field.");
                game.EditBuild();yield return Click("눈보라 이동");ScrollTo("눈보라 이동");yield return Capture(game,directory,"02-follow-setting.png");yield return Click("설정 적용");
                Require(!first.followsTarget,"Editing changed an existing field.");run.cooldowns[13]=0;run.resource=100;run.decisionTime=0;
                run.paused=false;yield return Until(()=>run.effects.Count(f=>f.kind==13)==2);run.paused=true;run.decisionTime=100;
                run.paused=false;yield return Until(()=>run.enemies[0].exposure>=1.35f);run.paused=true;
                Require(first.position==origin&&run.effects.Any(f=>f.kind==13&&f.followsTarget&&f.moved>0)&&run.enemies[0].frostMarkTime==0,"Fixed/follow or overlap exposure state is incorrect.");
                game.UI.ShowCombatEffects();yield return Capture(game,directory,"03-area-checkpoint.png");SaveCheckpoint(game,directory,"mage-checkpoint.json");Debug.Log("AREA_SMOKE_CHECKPOINT_READY");Application.Quit();yield break;
            }
            if(args.Contains("-hellscriptAreaResume"))
            {
                run=Restore(game,directory,"mage-checkpoint.json");game.UI.ShowCombatEffects();yield return Capture(game,directory,"04-restored-areas.png");game.UI.ShowBattle();game.SetSpeed(1);run.paused=false;
                yield return Until(()=>run.enemies[0].frostMarkTime>0);run.paused=true;Require(run.effectEvents.Count(e=>e.definitionId=="SM4"&&e.kind=="EXPOSURE_READY")==1,"Overlapping fields duplicated a mark.");
                game.UI.ShowCombatEffects();yield return Capture(game,directory,"05-frost-ready.png");SkillRule(game,12);run.paused=false;yield return Until(()=>run.damageEvents.Any(d=>d.definitionId=="SM4"));run.paused=true;run.decisionTime=100;
                Require(run.damageEvents.Count(d=>d.definitionId=="SM4")==1&&run.enemies[0].frostMarkTime==0&&run.enemies[0].frostCooldown>0,"Actual fireball did not consume exactly one mark.");
                game.UI.ShowCombatEffects();yield return Capture(game,directory,"06-frost-consumed.png");File.WriteAllText(Path.Combine(directory,"mage-completed.json"),JsonUtility.ToJson(run,true));
                run=Arena(game,HeroClass.Ranger,"SA","LA01",8);yield return new WaitForSecondsRealtime(.5f);run.paused=false;yield return Until(()=>CombatEffects.OwnTrapPoison(run.enemies[0],run.heroId));run.paused=true;
                SkillRule(game,6);run.paused=false;yield return Until(()=>run.enemies[0].setPoisonTime>0);run.paused=true;run.decisionTime=100;float applicationTime=run.time;
                run.paused=false;yield return Until(()=>run.time>=applicationTime+.35f);run.paused=true;Require(!run.damageEvents.Any(d=>d.definitionId=="SA4"),"First poison tick arrived before one second.");
                game.UI.ShowCombatEffects();yield return Capture(game,directory,"07-poison-checkpoint.png");SaveCheckpoint(game,directory,"poison-checkpoint.json");Debug.Log("POISON_SMOKE_CHECKPOINT_READY");Application.Quit();yield break;
            }
            run=Restore(game,directory,"poison-checkpoint.json");game.UI.ShowCombatEffects();yield return Capture(game,directory,"08-restored-poison.png");game.UI.ShowBattle();game.SetSpeed(1);run.paused=false;
            yield return Until(()=>run.damageEvents.Count(d=>d.definitionId=="SA4")==2);run.paused=true;game.UI.ShowCombatEffects();yield return Capture(game,directory,"09-poison-two-ticks.png");game.UI.ShowBattle();run.paused=false;
            yield return Until(()=>run.enemies[0].setPoisonTime==0);run.paused=true;var ticks=run.damageEvents.Where(d=>d.definitionId=="SA4").ToArray();
            Require(ticks.Length==3&&ticks.All(d=>!d.critical&&d.kind==DamageKind.Periodic)&&run.enemies[0].setPoisonInstance==0,"Restored poison lost, repeated or retained an expired tick.");
            Require(Mathf.Abs(ticks[1].time-ticks[0].time-1)<.001f&&Mathf.Abs(ticks[2].time-ticks[1].time-1)<.001f,"Poison phase changed after restart.");
            game.UI.ShowCombatEffects();yield return Capture(game,directory,"10-poison-expired.png");SaveCheckpoint(game,directory,"poison-completed.json");
            File.WriteAllText(Path.Combine(directory,"runtime-areas-smoke.txt"),$"PASS: actual UI callbacks commit Self/Fixed and Follow settings; existing fixed field retains its position; actual LM01 + SM4 casts create one fixed and one moving field; overlap exposure and both fields survive process restart; one actual M01 consumes one SM4 mark. Actual A03 and A01 with legal LA01 + SA4 create one periodic poison; pending timer and snapshot survive another process restart and deliver exactly three noncritical ticks at one-second intervals.\nControlled fixtures: level 30, four unique set slots plus one legendary weapon, harmless stationary high-HP target; M02 cooldown/resource reset once to create overlap. Isolated normal save; no physical-input, Android, balance or live service claim.\nRenderer={SystemInfo.graphicsDeviceType}\nScreen={Screen.width}x{Screen.height}\n");
            Debug.Log("HELLSCRIPT_AREA_RUNTIME_SMOKE_OK");Application.Quit();
        }
    }
}
