using System;
using System.IO;
using System.Text;
using UnityEngine;

namespace Hellscript
{
    // Reading comfort preference. Deliberately separate from AccountSave and from the display
    // direction file so a damaged preference can never disturb progress or the other setting.
    public static class InterfaceScaleOptions
    {
        public const int Default = 100;
        public const int Minimum = 100;
        public const int Maximum = 140;
        public static readonly int[] Steps = { 100, 115, 130, 140 };
        public static bool IsStep(int percent) => Array.IndexOf(Steps, percent) >= 0;
        public static int Nearest(int percent)
        {
            int best = Default;
            foreach (int step in Steps) if (Math.Abs(step - percent) < Math.Abs(best - percent)) best = step;
            return best;
        }
        public static float Factor(int percent) => Nearest(percent) / 100f;
        public static string Label(int percent) => Nearest(percent) + "%";
    }

    public sealed class InterfaceScaleStore
    {
        [Serializable] sealed class Record { public int version; public int percent; }
        public string Path { get; }
        public string Error { get; private set; } = "";
        public InterfaceScaleStore(string directory) { Path = System.IO.Path.Combine(directory, "hellscript-interface-scale-v1.json"); }
        public int Read()
        {
            Error = "";
            try
            {
                if (!File.Exists(Path)) return InterfaceScaleOptions.Default;
                if (new FileInfo(Path).Length > 1024) throw new InvalidDataException();
                var record = JsonUtility.FromJson<Record>(File.ReadAllText(Path));
                if (record == null || record.version != 1 || !InterfaceScaleOptions.IsStep(record.percent)) throw new InvalidDataException();
                return record.percent;
            }
            catch (Exception) { Error = "글자 크기 설정을 읽지 못했습니다. 기본 100%로 시작하며 기존 파일은 그대로 보존했습니다."; return InterfaceScaleOptions.Default; }
        }
        public bool Write(int percent)
        {
            if (!InterfaceScaleOptions.IsStep(percent)) throw new ArgumentOutOfRangeException(nameof(percent));
            Error = "";
            try
            {
                Directory.CreateDirectory(System.IO.Path.GetDirectoryName(Path));
                var record = new Record { version = 1, percent = percent };
                // Flush before the atomic replacement so a failed write leaves the previous preference intact.
                using (var stream = new FileStream(Path + ".tmp", FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    byte[] bytes = Encoding.UTF8.GetBytes(JsonUtility.ToJson(record));
                    stream.Write(bytes, 0, bytes.Length); stream.Flush(true);
                }
                if (File.Exists(Path)) File.Replace(Path + ".tmp", Path, null); else File.Move(Path + ".tmp", Path);
                return true;
            }
            catch (Exception) { Error = "선택한 크기는 화면에 적용했지만 기기에 저장하지 못했습니다. 저장을 다시 시도해 주세요."; return false; }
        }
    }

    // The chosen size always reaches the screen immediately; only the device file can fail.
    public sealed class InterfaceScaleSession
    {
        readonly Func<int, bool> save;
        public int Percent { get; private set; }
        public int Saved { get; private set; }
        public bool CanRetrySave { get; private set; }
        public string Message { get; private set; } = "";
        public float Factor => InterfaceScaleOptions.Factor(Percent);
        public InterfaceScaleSession(int saved, Func<int, bool> save)
        {
            this.save = save ?? throw new ArgumentNullException(nameof(save));
            Percent = Saved = InterfaceScaleOptions.Nearest(saved);
        }
        public bool Apply(int percent)
        {
            int chosen = InterfaceScaleOptions.Nearest(percent);
            Percent = chosen;
            bool success; try { success = save(chosen); } catch (Exception) { success = false; }
            CanRetrySave = !success;
            if (success) { Saved = chosen; Message = Loc.F("글자 크기를 {0}%로 적용하고 이 기기에 저장했습니다.", chosen); }
            else Message = Loc.F("글자 크기 {0}%를 지금 화면에 적용했지만 기기에 저장하지 못했습니다. 다시 시도하지 않으면 다음 실행에는 저장해 둔 {1}%를 사용합니다.", chosen, Saved);
            return success;
        }
        public bool RetrySave() => CanRetrySave && Apply(Percent);
    }
}
