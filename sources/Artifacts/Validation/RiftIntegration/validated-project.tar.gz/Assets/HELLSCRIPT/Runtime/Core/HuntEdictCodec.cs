using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;

namespace Hellscript
{
    public static class HuntEdictCodec
    {
        public const int MaxJsonBytes=256*1024,MaxDepth=16,MaxCodeCharacters=70+((MaxJsonBytes+2)/3)*4;
        static readonly UTF8Encoding Utf8=new UTF8Encoding(false,true);
        static string Hash(byte[] bytes)
        {using(var sha=SHA256.Create())return string.Concat(sha.ComputeHash(bytes).Select(b=>b.ToString("x2")));}
        public static string CanonicalJson(HuntEdictDocument document)=>JsonUtility.ToJson(EdictValidation.Canonical(document));
        public static string Encode(HuntEdictDocument document)
        {
            byte[] bytes=Utf8.GetBytes(CanonicalJson(document));
            if(bytes.Length>MaxJsonBytes)throw new ArgumentException("공유할 설정이 너무 큽니다.");
            return "HED1."+Convert.ToBase64String(bytes).TrimEnd('=').Replace('+','-').Replace('/','_')+"."+Hash(bytes);
        }
        static void CheckDepth(string json)
        {
            int depth=0;bool quoted=false,escaped=false;
            foreach(char c in json)
            {
                if(quoted){if(escaped){escaped=false;continue;}if(c=='\\'){escaped=true;continue;}if(c=='"')quoted=false;continue;}
                if(c=='"'){quoted=true;continue;}
                if(c=='{'||c=='['){if(++depth>MaxDepth)throw new ArgumentException("코드의 중첩이 너무 깊습니다.");}
                else if(c=='}'||c==']'){if(--depth<0)throw new ArgumentException("코드의 자료 구조가 손상됐습니다.");}
            }
            if(depth!=0||quoted||escaped)throw new ArgumentException("코드의 자료 구조가 잘렸습니다.");
        }
        public static HuntEdictDocument Decode(string code)
        {
            if(code==null||code.Length>MaxCodeCharacters)throw new ArgumentException("공유 코드가 없거나 너무 깁니다.");
            var pieces=code.Trim().Split('.');if(pieces.Length!=3||pieces[0]!="HED1")throw new ArgumentException("지원하는 HED1 코드가 아닙니다.");
            string payload=pieces[1];if(payload.Length==0||payload.Length%4==1||payload.Any(c=>!(c>='A'&&c<='Z'||c>='a'&&c<='z'||c>='0'&&c<='9'||c=='-'||c=='_')))throw new ArgumentException("공유 코드의 문자가 손상됐습니다.");
            byte[] bytes=Convert.FromBase64String(payload.Replace('-','+').Replace('_','/')+new string('=',(4-payload.Length%4)%4));
            if(bytes.Length>MaxJsonBytes||pieces[2].Length!=64||pieces[2]!=Hash(bytes))throw new ArgumentException("공유 코드가 손상됐습니다. 원본을 다시 복사해 주세요.");
            string json=Utf8.GetString(bytes);CheckDepth(json);
            var document=JsonUtility.FromJson<HuntEdictDocument>(json);var canonical=EdictValidation.Canonical(document);
            if(JsonUtility.ToJson(canonical)!=json)throw new ArgumentException("코드에 누락·추가·중복 항목 또는 지원하지 않는 표현이 있습니다.");
            // Reject alternate Base64 encodings with nonzero unused bits as well as noncanonical JSON.
            if(Encode(canonical)!=code.Trim())throw new ArgumentException("코드의 정규 표현을 확인해 주세요.");
            return canonical;
        }
        public static bool TryDecode(string code,out HuntEdictDocument document,out string error)
        {
            document=null;error="";
            try{document=Decode(code);return true;}
            catch(Exception e) when(e is ArgumentException||e is FormatException||e is InvalidOperationException)
            {error=e.Message;return false;}
        }
    }
}
