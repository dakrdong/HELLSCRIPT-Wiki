using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimeTrainingSmoke : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Install()
        {
            if(!Environment.GetCommandLineArgs().Contains("-hellscriptTrainingSmoke"))return;
            Application.runInBackground=true;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Player training validation").AddComponent<RuntimeTrainingSmoke>();
        }
        static void Require(bool value,string message){if(!value)throw new InvalidOperationException(message);}
        static string Snapshot(AccountSave account)
        {var copy=JsonUtility.FromJson<AccountSave>(JsonUtility.ToJson(account));copy.lastSeenUtc=0;copy.speed=1;return JsonUtility.ToJson(copy);}
        static void Click(GameController game,string prefix)
        {var button=game.UI.GetComponentsInChildren<Button>().Single(b=>b.name.StartsWith(prefix,StringComparison.Ordinal));button.onClick.Invoke();}
        static IEnumerator Until(Func<bool> ready,float seconds=38)
        {float end=Time.realtimeSinceStartup+seconds;while(!ready()&&Time.realtimeSinceStartup<end)yield return null;Require(ready(),"Training condition timed out.");}
        static IEnumerator Capture(string dir,string file)
        {
            yield return new WaitForSecondsRealtime(.25f);Canvas.ForceUpdateCanvases();
            foreach(var button in FindAnyObjectByType<GameController>().UI.GetComponentsInChildren<Button>().Where(b=>b.transform.parent.name=="Footer"))
            {
                var corners=new Vector3[4];((RectTransform)button.transform).GetWorldCorners(corners);
                Require(corners.All(c=>c.x>=-1&&c.x<=Screen.width+1&&c.y>=-1&&c.y<=Screen.height+1),"Footer button outside screen: "+button.name);
            }
            ScreenCapture.CaptureScreenshot(Path.Combine(dir,file));yield return new WaitForSecondsRealtime(.25f);
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();string dir="";for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptScreenshots")dir=args[i+1];
            Require(args.Contains("-hellscriptSavePath")&&!string.IsNullOrEmpty(dir),"Training smoke requires an isolated save and image directory.");
            Directory.CreateDirectory(dir);Screen.SetResolution(540,960,FullScreenMode.Windowed);yield return new WaitForSecondsRealtime(1);
            var game=FindAnyObjectByType<GameController>();
            if(args.Contains("-hellscriptTrainingResume"))
            {
                var expected=JsonUtility.FromJson<AccountSave>(File.ReadAllText(Path.Combine(dir,"expected-account.json")));
                Require(Snapshot(expected)==Snapshot(game.Store.Data),"Training changed progress or its explicit preset did not survive restart.");
                Require(game.Store.Data.suspendedRun==null&&game.Store.Data.Hero.level==1,"Training must not resume as a real rift or promote the hero.");
                Require(!BuildEditing.HasPreset(game.Store.Data.Hero.presets[0])&&game.Store.Data.Hero.presets[1].distance==5.5f,"An empty preset slot was replaced or the explicit slot was lost.");
                game.UI.ShowTraining();yield return Capture(dir,"07-restarted-training-menu.png");
                Click(game,"02  다수 적");game.Combat.State.paused=true;
                Require(game.Combat.OwnedTraining&&game.Combat.EffectiveLevel==1&&game.Combat.State.enemies.Count==8,"Fresh owned training did not use the actual hero.");
                yield return Capture(dir,"08-fresh-owned-training.png");game.ReturnTown();
                Require(Snapshot(expected)==Snapshot(game.Store.Data),"Restarted practice changed the account.");
                File.WriteAllText(Path.Combine(dir,"runtime-training-smoke.txt"),"PASS: actual level-one mage and gear, locked skill HUD and rules, copied settings, 1200-tick training at 2x, explicit preset-only save, real danger preparation, isolated developer Lv.30 entry, process restart preserving account and preset without a suspended training rift.\nRenderer="+SystemInfo.graphicsDeviceType+"\nScreen="+Screen.width+"x"+Screen.height+"\nUI callbacks; no physical-input or Android proof.\n");
                Debug.Log("HELLSCRIPT_TRAINING_RUNTIME_SMOKE_OK");Application.Quit(0);yield break;
            }
            game.SelectHero(2);var account=game.Store.Data;Require(account.Hero.level==1&&account.heroes.All(h=>h.highestClear==0),"Use a fresh isolated account.");
            string baseline=Snapshot(account);string originalBuild=JsonUtility.ToJson(account.Hero.build);game.UI.ShowTraining();yield return Capture(dir,"01-owned-training-menu.png");
            Click(game,"01  단일 적");var run=game.Combat.State;run.paused=true;
            Require(game.Combat.OwnedTraining&&game.Combat.EffectiveLevel==1&&game.Combat.Stats.hp==new HeroStats(account.Hero).hp,"Training replaced the real level or equipment stats.");
            Require(game.UI.GetComponentsInChildren<Text>().Any(t=>t.text=="Lv.3 해금"),"Locked skill HUD missing.");
            yield return Capture(dir,"02-level-one-and-locked-skills.png");
            var edit=run.build.Copy();edit.distance=5.5f;edit.name="훈련 거리 시험";game.CommitBuild(edit,true);
            Require(Snapshot(account)==baseline,"Applying trial rules modified real progression or the current build.");
            game.SetSpeed(1);run.paused=false;yield return Until(()=>!game.Active,90);
            Require(Mathf.RoundToInt(run.time/CombatSimulation.Step)==1200&&run.phase==RunPhase.Cleared&&run.dealt>0,"Owned practice did not complete at 60 combat seconds.");
            Require(Snapshot(account)==baseline,"Completed training changed account rewards or records.");
            game.UI.ShowResult();yield return null;Canvas.ForceUpdateCanvases();
            var summary=game.UI.GetComponentsInChildren<Text>().Single(t=>t.text.Contains("전투 초당"));Require(summary.preferredHeight<=summary.rectTransform.rect.height+.5f,"Training result summary was clipped.");
            File.WriteAllText(Path.Combine(dir,"completed-training.json"),JsonUtility.ToJson(run,true));yield return Capture(dir,"03-sixty-second-result.png");
            Click(game,"시험한 설정을 슬롯에 저장");yield return Capture(dir,"04-explicit-preset-save.png");Click(game,"슬롯 2 ·");Click(game,"프리셋 저장");yield return null;
            Require(account.Hero.presets[1].distance==5.5f&&JsonUtility.ToJson(account.Hero.build)==originalBuild,"Saving a preset replaced the current build or missed trial rules.");
            game.ReturnTown();string afterPreset=Snapshot(account);
            game.Begin(2);game.SetSpeed(1);run=game.Combat.State;
            yield return Until(()=>run.enemyEvents.Any(e=>e.kind=="HAZARD_CREATED"),12);run.paused=true;game.UI.RefreshHud();yield return Capture(dir,"05-real-danger-training.png");
            game.ReturnTown();Require(Snapshot(account)==afterPreset,"Danger practice changed the account.");
            game.BeginDeveloperTraining(0);game.Combat.State.paused=true;
            Require(!game.Combat.OwnedTraining&&game.Combat.EffectiveLevel==30&&account.Hero.level==1,"Development mode was not isolated from actual hero level.");
            yield return Capture(dir,"06-explicit-developer-training.png");game.ReturnTown();Require(Snapshot(account)==afterPreset,"Development practice changed real progress.");
            game.Save();Require(string.IsNullOrEmpty(game.Store.Error),"Training preset save failed.");File.WriteAllText(Path.Combine(dir,"expected-account.json"),JsonUtility.ToJson(account,true));
            Debug.Log("HELLSCRIPT_TRAINING_CHECKPOINT_READY");Application.Quit(0);
        }
    }
}
