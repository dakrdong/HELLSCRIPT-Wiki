using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        EdictTargetPolicy edictTarget;
        EdictTargetPolicy TargetPolicy=>HeroActionBusy&&State.heroAction.phase==HeroActionPhase.Channeling?
            State.heroAction.policy?.edictTarget?.version==EdictTargetPolicy.CurrentVersion?State.heroAction.policy.edictTarget:null:edictTarget;
        float BasicReach=>Hero.heroClass==HeroClass.Warrior?2:10;
        bool EdictTargetEligible(EnemyState enemy)=>Perceived(enemy)&&!(State.edictTarget?.excluded?.Contains(enemy.id)??false);
        void TrackEdictTarget(EnemyState target)
        {
            if(TargetPolicy==null||target==null||!Perceived(target))return;
            var state=State.edictTarget??=new EdictTargetState();
            if(state.enemyId!=target.id){state.enemyId=target.id;state.origin=State.position;state.pursuitSeconds=0;}
            state.lastSeen=target.position;state.seenAt=State.time;state.searching=false;
        }
        void EndEdictPursuit(string reason,bool exclude)
        {
            var state=State.edictTarget;if(state==null||state.enemyId<0)return;
            int id=state.enemyId;if(exclude&&!state.excluded.Contains(id))state.excluded.Add(id);
            var memory=State.exploration.enemies.Find(e=>e.id==id);if(memory!=null)memory.investigated=true;
            state.enemyId=-1;state.searching=false;state.pursuitSeconds=0;
            if(State.targetId==id)SelectTarget(null,reason);
            State.action=Loc.T(reason);Log("EDICT_PURSUIT_END",Loc.F("대상 {0} · {1}",id,reason));State.decisionTime=0;
        }
        void ObserveEdictTarget()
        {
            var policy=TargetPolicy;var state=State.edictTarget;if(policy==null||state==null)return;
            state.excluded??=new System.Collections.Generic.List<int>();
            // A new sighting or a target that approaches into attack reach is a new engagement.
            state.excluded.RemoveAll(id=>!sensed.Any(e=>e.id==id)||sensed.Any(e=>e.id==id&&Vector2.Distance(State.position,e.position)<=BasicReach));
            if(state.enemyId<0)return;
            var visible=sensed.Find(e=>e.id==state.enemyId);
            if(visible!=null){state.lastSeen=visible.position;state.seenAt=State.time;state.searching=false;return;}
            if(State.enemies.Any(e=>e.id==state.enemyId&&e.dead)){EndEdictPursuit("대상을 처치해 추적을 마쳤습니다.",false);return;}
            if(!policy.investigate){EndEdictPursuit("대상의 시야를 잃어 추적을 중단했습니다.",false);return;}
            state.searching=true;
            if(Vector2.Distance(State.position,state.lastSeen)<=.75f)EndEdictPursuit("마지막 관측 위치를 확인했습니다.",false);
        }
        bool EdictLastSeenGoal(out Vector2 goal)
        {
            goal=State.position;var state=State.edictTarget;
            if(TargetPolicy==null||!TargetPolicy.investigate||state==null||state.enemyId<0||!state.searching||sensed.Any(EdictTargetEligible))return false;
            if(State.movementAction==RuleAction.Loot||State.movementAction==RuleAction.Chest)return false;
            goal=state.lastSeen;return true;
        }
        bool AdvanceEdictPursuit(float dt,bool searching,EnemyState target,Rule rule)
        {
            var policy=TargetPolicy;var state=State.edictTarget;if(policy==null||state==null||state.enemyId<0)return true;
            if(!PursuingEdictTarget(searching,target,rule))return true;
            if(Vector2.Distance(State.position,state.origin)>=policy.chaseDistance-.0001f)
            {EndEdictPursuit("추적 거리 한도에 도달했습니다.",true);return false;}
            state.pursuitSeconds=Mathf.Min(policy.chaseTime,state.pursuitSeconds+dt);
            if(state.pursuitSeconds>=policy.chaseTime-.0001f)
            {EndEdictPursuit("추적 시간 한도에 도달했습니다.",true);return false;}
            return true;
        }
        bool PursuingEdictTarget(bool searching,EnemyState target,Rule rule)
        {
            float reach=rule!=null&&rule.action==RuleAction.Skill&&rule.skill>=0?catalog.skills[rule.skill].range:BasicReach;
            return searching||target!=null&&(Vector2.Distance(State.position,target.position)>reach||!Map.LineClear(State.position,target.position));
        }
        bool EdictPursuitStepAllowed(Vector2 next,bool searching,EnemyState target,Rule rule)
        {
            var state=State.edictTarget;var policy=TargetPolicy;
            if(state==null||state.enemyId<0||policy==null||!PursuingEdictTarget(searching,target,rule))return true;
            if(Vector2.Distance(next,state.origin)<=policy.chaseDistance+.0001f)return true;
            EndEdictPursuit("추적 거리 한도에 도달했습니다.",true);return false;
        }
        bool CanEdictInterrupt(EnemyState enemy)
        {
            var action=enemy.brain.action;
            if(action.phase!=EnemyActionPhase.Preparing||action.released||!Perceived(enemy)||HeroActionBusy||CombatEffects.Has(enemy,StatusKind.Stun)||CombatEffects.Has(enemy,StatusKind.Freeze))return false;
            bool threat=enemy.kind==4||enemy.boss&&action.kind==(int)BossAttack.Summon||EnemyCombat.Threats(State,Map)
                .Any(t=>(t.key=="action-"+action.id||t.key.StartsWith("action-"+action.id+"-")||t.key=="boss-"+action.id||t.key.StartsWith("boss-"+action.id+"-"))&&EnemyCombat.Contains(t,State.position));
            if(!threat||Vector2.Distance(State.position,enemy.position)>3)return false;
            foreach(var r in State.build.rules.Where(r=>r.enabled&&r.action==RuleAction.Skill&&r.skill>=0&&r.skill<catalog.skills.Count&&
                (catalog.skills[r.skill].kind==SkillKind.Slam||catalog.skills[r.skill].kind==SkillKind.Nova)&&State.build.activeSkills.Contains(r.skill)))
            {
                var skill=catalog.skills[r.skill];var timing=CombatActions.Timing(r.skill,Hero.heroClass,Stats.attackSpeed);
                if(skill.unlock>EffectiveLevel||State.cooldowns[r.skill]>0||Cost(skill)>State.resource||timing.prepare>=action.remaining||HuntEdictV2.Value(edictSource,skill.id,1)!="ON")continue;
                if(!RuleMatches(r,enemy,out _))continue;
                if(enemy.boss&&(enemy.bossControl.staggered>0||enemy.bossControl.immunity>0||enemy.bossControl.meter+15<100))continue;
                return true;
            }
            return false;
        }
    }
}
