using System;
using System.Collections;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimeRuleSmoke : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void ConfigureSmokeRuntime()
        {
            var flags=new[]{"-hellscriptRuleSmoke","-hellscriptActionSmoke","-hellscriptRiftSmoke","-hellscriptFieldSmoke","-hellscriptSmoke","-hellscriptEffectSmoke","-hellscriptChargeSmoke","-hellscriptOutcomeSmoke","-hellscriptAreaSmoke","-hellscriptEnemySmoke","-hellscriptBossSmoke","-hellscriptPassiveSmoke"};
            if(Environment.GetCommandLineArgs().Any(flags.Contains))Application.runInBackground=true;
        }
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Install()
        {
            if(!Environment.GetCommandLineArgs().Contains("-hellscriptRuleSmoke"))return;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Rule editor validation").AddComponent<RuntimeRuleSmoke>();
        }
        static void Require(bool pass,string reason){if(!pass)throw new InvalidOperationException(reason);}
        static Button Find(string name)=>FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name==name);
        static Button Prefix(string prefix)=>FindObjectsByType<Button>(FindObjectsSortMode.None).First(b=>b.name.StartsWith(prefix));
        static IEnumerator Click(string name,bool prefix=false)
        {(prefix?Prefix(name):Find(name)).onClick.Invoke();yield return null;}
        static void ScrollTo(string prefix)
        {
            Canvas.ForceUpdateCanvases();var button=Prefix(prefix);var row=(RectTransform)button.transform;var scroll=row.GetComponentInParent<ScrollRect>();
            if(scroll==null)return;while(row.parent!=scroll.content)row=(RectTransform)row.parent;
            float offset=-(row.localPosition.y+row.rect.yMax),max=Mathf.Max(0,scroll.content.rect.height-scroll.viewport.rect.height);
            scroll.content.anchoredPosition=new Vector2(0,Mathf.Clamp(offset,0,max));scroll.StopMovement();
        }
        static IEnumerator Capture(string directory,string file)
        {yield return new WaitForSecondsRealtime(.3f);ScreenCapture.CaptureScreenshot(Path.Combine(directory,file));yield return new WaitForSecondsRealtime(.2f);}
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();string directory="";for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptScreenshots")directory=args[i+1];
            Require(args.Contains("-hellscriptSavePath")&&!string.IsNullOrEmpty(directory),"Rule smoke requires isolated save/output paths.");Directory.CreateDirectory(directory);
            Screen.SetResolution(540,960,FullScreenMode.Windowed);
            yield return new WaitForSecondsRealtime(1);var game=FindAnyObjectByType<GameController>();
            if(!args.Contains("-hellscriptRuleResume"))
            {
                var hero=game.Store.Data.Hero;hero.level=30;hero.build=GameCatalog.Preset(HeroClass.Warrior,0);hero.build.potionThreshold=0;game.Save();game.EditBuild();
                yield return Capture(directory,"01-rule-editor.png");yield return Click("+ 행동 규칙 추가");yield return Click(game.catalog.skills[0].name+" 규칙 추가");
                yield return Click("✓ 항상 검사");yield return Click("AND 1  ",true);
                Require(FindObjectsByType<Button>(FindObjectsSortMode.None).Count(b=>b.name.StartsWith("SC"))==22,"Condition picker does not expose all 22 definitions.");
                yield return Capture(directory,"02-condition-picker.png");ScrollTo("SC22 ");yield return Capture(directory,"02b-condition-picker-bottom.png");
                yield return Click("SC06 ",true);yield return Click("+ AND 조건 추가");yield return Click("SC01 ",true);
                yield return Click("+ OR 묶음 추가");yield return Click("설정 적용");Require(game.UI.Page=="build","Empty OR group was accepted.");
                FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b=>b.name=="+ AND 조건 추가").OrderByDescending(b=>b.transform.GetSiblingIndex()).First().onClick.Invoke();yield return null;yield return Click("SC07 ",true);
                ScrollTo("AND 1  ");float offset=Prefix("AND 1  ").GetComponentInParent<ScrollRect>().content.anchoredPosition.y;
                Require(offset>500,"Expanded condition was not scrolled into view.");yield return Click("비교",true);
                Require(Mathf.Abs(Prefix("AND 1  ").GetComponentInParent<ScrollRect>().content.anchoredPosition.y-offset)<2,"Editing a condition reset the scroll position.");
                yield return Capture(directory,"03-or-and-groups.png");
                ScrollTo("05  ");yield return Capture(directory,"03b-rule-summary.png");
                yield return Click("이 규칙 복제");yield return Click("이 규칙 복제");
                Require(FindObjectsByType<Text>(FindObjectsSortMode.None).Any(t=>t.text=="스킬 하나의 규칙은 최대 3개입니다."),"Fourth rule was not rejected.");
                yield return Click("이 규칙 삭제 · 장착 유지");yield return Click("설정 적용");Require(game.UI.Page=="town","Valid edited build did not commit: "+string.Join(" / ",FindObjectsByType<Text>(FindObjectsSortMode.None).Select(t=>t.text)));
                Require(hero.build.activeSkills.Count==4&&hero.build.rules.Any(r=>r.skill==0&&r.groups.Count==2&&r.groups[0].conditions.Count==2),"OR/AND groups or equipped slots were lost on apply.");
                game.BeginDeveloperTraining(1);game.SetSpeed(1);var run=game.Combat.State;run.training=-1;run.position=RiftMap.Rooms[0];run.resource=0;run.health=game.Combat.Stats.hp*.2f;game.Combat.Stats.regen=0;
                foreach(var e in run.enemies){e.health=e.maxHealth=10000;e.speed=0;e.attack=0;e.cooldown=1000;e.windup=0;}
                yield return new WaitForSecondsRealtime(.6f);game.UI.ShowRuleDecisions();
                Require(run.decisions.Any(d=>d.code=="SELECTED")&&run.decisions.Any(d=>d.code=="RESOURCE"),"Selected/blocked decisions were not recorded.");
                yield return Capture(directory,"04-decision-log.png");game.Save();File.WriteAllText(Path.Combine(directory,"checkpoint.json"),JsonUtility.ToJson(run,true));
                Debug.Log("RULE_SMOKE_CHECKPOINT_READY");Application.Quit();yield break;
            }
            var saved=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(directory,"checkpoint.json")));GameStore.NormalizeRun(saved);game.Begin(resume:true);var restored=game.Combat.State;
            Require(restored.id==saved.id&&restored.time==saved.time&&restored.rng==saved.rng,"Rule checkpoint identity or clock changed.");
            Require(JsonUtility.ToJson(restored.build)==JsonUtility.ToJson(saved.build)&&restored.decisions.Count==saved.decisions.Count,"Rule groups or decisions changed on process restart.");
            for(int i=0;i<saved.decisions.Count;i++)Require(JsonUtility.ToJson(restored.decisions[i])==JsonUtility.ToJson(saved.decisions[i]),"Decision history changed on restart.");
            restored.paused=true;game.UI.ShowRuleDecisions();yield return Capture(directory,"05-restored-decisions.png");Find("전투로 돌아가기").onClick.Invoke();Require(restored.paused,"Decision view changed the previous pause state.");
            restored.paused=false;yield return new WaitForSecondsRealtime(.3f);Require(restored.time>saved.time,"Rule execution did not resume.");game.Save();
            File.WriteAllText(Path.Combine(directory,"runtime-rules-smoke.txt"),$"PASS: native player UI callbacks, 22-condition picker, AND and OR creation, empty-group rejection, 3-rules-per-skill limit, independent equipped slots, apply, selected/blocked diagnostics, actual process restart preserving build and decision history, resumed execution.\nFixture: level 30 Warrior in a controlled legacy arena; high-HP stationary harmless targets and zero resource regeneration while collecting a blocked-resource case. Separate save only.\nRenderer={SystemInfo.graphicsDeviceType}\nrunId={restored.id}\nruleCount={restored.build.rules.Count}\ndecisions={saved.decisions.Count}\nScreen={Screen.width}x{Screen.height}\n");
            Debug.Log("HELLSCRIPT_RULE_RUNTIME_SMOKE_OK");Application.Quit();
        }
    }
}
