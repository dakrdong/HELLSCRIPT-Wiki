using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed partial class GameUI
    {
        // The draft is always canonical: every edit goes through a helper that validates and returns a
        // new document, so a rejected value never leaves the draft half-changed.
        HuntEdictV2Document edictDraft;
        string edictTab="global",edictGroup="survival",edictSkill="BASIC";
        bool edictLeaving,edictResetScroll;
        float edictScrollOffset;
        float edictLayoutWidth=-1;
        RectTransform edictLaidOutContent;

        HeroSave EdictHero=>game.Store.Data.Hero;
        IReadOnlyList<EdictDifference> EdictChanges=>edictDraft==null?(IReadOnlyList<EdictDifference>)Array.Empty<EdictDifference>():HuntEdictV2Diff.Describe(EdictHero.edict,edictDraft);
        string SkillName(string id)=>id=="BASIC"?"기본 공격":game.catalog.skills.Single(s=>s.id==id).name;

        public void ShowEdictEditor()
        {
            var hero=EdictHero;
            if(HuntEdictV2Storage.IsAbsent(hero.edict))
            {
                pageRepaint=()=>ShowEdictEditor();Base("edict","사냥 칙령 v0.2","");
                Note(content,"이 캐릭터에 저장된 사냥 칙령 원본이 없습니다.",22,70,muted);
                FooterButton(0,1,"돌아가기",ShowTown);return;
            }
            edictDraft=hero.edict.Copy();edictTab="global";edictGroup="survival";
            edictSkill=hero.edict.slots.FirstOrDefault(s=>s!="")??"BASIC";
            edictLeaving=false;edictResetScroll=true;
            RenderEdictEditor();
        }

        void RenderEdictEditor()
        {
            var hero=EdictHero;int changes=EdictChanges.Count;
            pageRepaint=()=>RenderEdictEditor();Base("edict","사냥 칙령 v0.2",changes==0?"저장된 설정과 같습니다":Loc.F("저장하지 않은 변경 {0}개 · 저장 및 적용을 눌러야 반영됩니다", changes));
            if(edictResetScroll){edictScrollOffset=0;edictResetScroll=false;}
            var tabs=Row(content,50);
            EdictTab(tabs,0,"전역 설정","global");EdictTab(tabs,1,"사용 스킬·순서","slots");EdictTab(tabs,2,"스킬 설정","skills");
            var share=Button(tabs,"공유",()=>
            {
                if(EdictChanges.Count>0){ShowToast("먼저 저장하거나 되돌린 뒤 공유 화면으로 이동하세요.");return;}
                edictDraft=null;ClearEdictShare();ShowEdictShare();
            });AnchorButton(share,3,4);
            if(edictLeaving){RenderEdictLeave(hero);return;}
            var issues=InspectEdictDraft(hero);
            if(edictTab=="global"&&edictGroup=="target")
                Note(content,"HP는 남은 비율로 비교합니다. 추적 시간은 접근·관측 위치 확인 중에만 흐릅니다.",18,60,gold);
            if(edictTab=="global"&&edictGroup=="loot"&&edictDraft.global.Any(o=>o.id=="loot.slots"&&o.value==""))
                Note(content,"회수할 장비 부위를 선택하지 않았습니다. 필터 예외로 지정한 장비만 회수할 수 있습니다.",18,60,gold);
            if(issues.Count>0)Note(content,Loc.F("현재 장비·장착 기준으로 {0}개 항목이 비활성·대체·충돌 상태입니다. 해당 항목 아래에서 사유를 확인하세요.", issues.Count),18,44,gold);
            if(edictTab=="global")RenderEdictGlobal(hero,issues);
            else if(edictTab=="slots")RenderEdictSlots(hero);
            else RenderEdictSkills(hero,issues);
            FooterButton(0,3,"돌아가기",()=>{if(EdictChanges.Count>0){edictLeaving=true;edictResetScroll=true;RenderEdictEditor();}else{edictDraft=null;ShowTown();}});
            FooterButton(1,3,"되돌리기",()=>{edictDraft=hero.edict.Copy();RenderEdictEditor();ShowToast("저장된 설정으로 되돌렸습니다.");});
            FooterButton(2,3,"저장 및 적용",()=>SaveEdictDraft(),true);
            edictLayoutWidth=-1;ReflowEdictRows();RestoreEdictScroll();
        }

        void EdictTab(Transform row,int index,string title,string tab)
        {
            var b=Button(row,title,()=>{edictTab=tab;edictResetScroll=true;RenderEdictEditor();},tab==edictTab?(Color?)(gold*.55f):null);
            AnchorButton(b,index,4);
        }

        IReadOnlyList<EdictConfigurationIssue> InspectEdictDraft(HeroSave hero)
        {
            try{return HuntEdictV2Availability.Inspect(edictDraft,hero,game.catalog);}
            catch(Exception){return Array.Empty<EdictConfigurationIssue>();}
        }

        static string IssueKind(EdictConfigurationIssueKind kind)=>kind switch
        {
            EdictConfigurationIssueKind.Inactive=>"비활성",EdictConfigurationIssueKind.Unavailable=>"사용 불가",
            EdictConfigurationIssueKind.Fallback=>"대체 적용",_=>"충돌"
        };
        void IssueNotes(IReadOnlyList<EdictConfigurationIssue> issues,string optionId,string skillId=null)
        {
            foreach(var issue in issues.Where(i=>i.optionId==optionId&&(skillId==null||i.skillId==skillId)))
                Note(content,Loc.F("  ↳ {0}: {1}{2}", IssueKind(issue.kind), issue.reason, (issue.fallbackValue!=""?Loc.F(" (현재 판단값 {0})", issue.fallbackValue):"")),18,66,muted);
        }

        // ---- 전역 설정 ----
        void RenderEdictGlobal(HeroSave hero,IReadOnlyList<EdictConfigurationIssue> issues)
        {
            // Two rows of five and four keep every group one tap away while leaving the first option
            // row visible on a landscape window; three rows of three pushed it below the fold.
            var groups=EdictOptionLabels.GroupOrder;
            for(int r=0;r<groups.Length;r+=5)
            {
                int count=Math.Min(5,groups.Length-r);var row=Row(content,44);
                for(int c=0;c<count;c++)
                {
                    string g=groups[r+c];
                    var b=Button(row,EdictOptionLabels.Group(g),()=>{edictGroup=g;edictResetScroll=true;RenderEdictEditor();},g==edictGroup?(Color?)(gold*.55f):null);
                    AnchorButton(b,c,count);
                }
            }
            Note(content,EdictOptionLabels.Group(edictGroup),22,40,gold);
            foreach(var definition in EdictOptions.Global.Where(o=>o.group==edictGroup))RenderGlobalOption(definition,issues);
        }

        void RenderGlobalOption(EdictOptionDefinition d,IReadOnlyList<EdictConfigurationIssue> issues)
        {
            string value=edictDraft.global.Single(o=>o.id==d.id).value;string title=EdictOptionLabels.Option(d);
            void Set(string v)
            {
                try{edictDraft=HuntEdictV2Editing.WithGlobal(edictDraft,d.id,v);RenderEdictEditor();}
                catch(Exception e){RenderEdictEditor();ShowToast(e.Message);}
            }
            switch(d.kind)
            {
                case EdictOptionKind.Toggle:
                    BigButton(content,Loc.F("{0}{1}{2}", (value=="ON"?"✓ ":""), title, (value=="ON"?"":"  ·  꺼짐")),()=>Set(value=="ON"?"OFF":"ON"),value=="ON");break;
                case EdictOptionKind.Number:
                    StepRow(title,value,d.min,d.max,d.step,dir=>Set(HuntEdictV2Editing.Stepped(d,value,dir)));break;
                case EdictOptionKind.Choice:
                    BigButton(content,Loc.F("{0}  ·  {1}",title,EdictOptionLabels.Item(d,value)),()=>Set(HuntEdictV2Editing.NextChoice(d.choices,value)));break;
                case EdictOptionKind.SkillReference:
                {
                    var choices=new List<string>{""};
                    choices.AddRange(HuntEdict.SkillIds(edictDraft.heroClass).Where(id=>d.choices.Length==0||d.choices.Contains(id)));
                    BigButton(content,Loc.F("{0}  ·  {1}",title,EdictOptionLabels.Value(d,value,SkillName)),()=>Set(HuntEdictV2Editing.NextChoice(choices,value)));break;
                }
                case EdictOptionKind.Set:
                {
                    Note(content,Loc.F("{0}  ·  {1}",title,EdictOptionLabels.Value(d,value)),21,46,pale);
                    var selected=new HashSet<string>(value==""?Array.Empty<string>():value.Split(','));
                    foreach(string item in d.choices)
                    {string it=item;bool on=selected.Contains(it);BigButton(content,Loc.F("{0}{1}",(on?"✓ ":"+ "),EdictOptionLabels.Item(d,it)),()=>Set(HuntEdictV2Editing.ToggledInSet(d,value,it)));}
                    break;
                }
                case EdictOptionKind.Order:
                {
                    Note(content,title,21,46,pale);var items=value.Split(',');
                    for(int i=0;i<items.Length;i++)
                    {string it=items[i];OrderRow(Loc.F("{0}. {1}",i+1,EdictOptionLabels.Item(d,it)),i>0,i<items.Length-1,dir=>Set(HuntEdictV2Editing.MovedInOrder(value,it,dir)));}
                    break;
                }
            }
            IssueNotes(issues,d.id);
        }

        // ---- 사용 스킬·순서 ----
        void RenderEdictSlots(HeroSave hero)
        {
            Note(content,"사용 스킬 칸 1~4",24,50,gold);
            if(RiftLoadoutLocked)Note(content,"균열 진행 중에는 사용 스킬 칸을 바꾸지 않습니다. 원본의 칸이 실제 장착과 어긋나면 전투 판단이 차단됩니다.",19,84,muted);
            else Note(content,"칸을 누르면 해금한 다음 스킬로 바뀝니다. 다른 칸에 있던 스킬을 고르면 두 칸을 맞바꿉니다.",19,66,muted);
            var choices=new List<string>{""};choices.AddRange(HuntEdict.SkillIds(edictDraft.heroClass));
            for(int n=0;n<4;n++)
            {
                int slot=n;string current=edictDraft.slots[n];
                BigButton(content,Loc.F("{0}번 칸  ·  {1}", n+1, (current==""?"비어 있음":SkillName(current))),()=>
                {
                    if(RiftLoadoutLocked){ShowToast("사용 스킬 칸은 성소와 훈련장에서 바꿀 수 있습니다.");return;}
                    string next=current;
                    for(int k=0;k<choices.Count;k++)
                    {
                        next=HuntEdictV2Editing.NextChoice(choices,next);
                        if(next==""||game.catalog.skills.Single(s=>s.id==next).unlock<=hero.level)break;
                    }
                    try{edictDraft=HuntEdictV2.WithSlot(edictDraft,slot,next,hero,game.catalog);RenderEdictEditor();}
                    catch(Exception e){RenderEdictEditor();ShowToast(e.Message);}
                });
            }
            Note(content,"공통 공격 순서  ·  미장착 스킬도 자리를 보관합니다",24,50,gold);
            var order=edictDraft.skillOrder;
            for(int i=0;i<order.Length;i++)
            {
                string id=order[i];bool carried=id=="BASIC"||edictDraft.slots.Contains(id);
                OrderRow(Loc.F("{0}. {1}{2}", i+1, SkillName(id), (carried?"":"  (미장착)")),i>0,i<order.Length-1,dir=>
                {
                    try{edictDraft=HuntEdictV2Editing.WithSkillOrderMoved(edictDraft,id,dir);RenderEdictEditor();}
                    catch(Exception e){RenderEdictEditor();ShowToast(e.Message);}
                });
            }
        }

        // ---- 스킬 설정 ----
        void RenderEdictSkills(HeroSave hero,IReadOnlyList<EdictConfigurationIssue> issues)
        {
            var ids=HuntEdictV2.SkillIds(edictDraft.heroClass);
            if(!ids.Contains(edictSkill))edictSkill="BASIC";
            for(int r=0;r<ids.Length;r+=4)
            {
                var row=Row(content,44);int count=Math.Min(4,ids.Length-r);
                for(int c=0;c<count;c++)
                {
                    string id=ids[r+c];
                    var b=Button(row,SkillName(id),()=>{edictSkill=id;edictResetScroll=true;RenderEdictEditor();},id==edictSkill?(Color?)(gold*.55f):null);
                    AnchorButton(b,c,4);
                }
            }
            string state=edictSkill=="BASIC"?"항상 사용":edictDraft.slots.Contains(edictSkill)
                ?(game.catalog.skills.Single(s=>s.id==edictSkill).unlock<=hero.level?"장착 중":Loc.F("장착 중 · Lv.{0} 해금 필요", game.catalog.skills.Single(s=>s.id==edictSkill).unlock))
                :"미장착 · 선택값은 보관됩니다";
            Note(content,Loc.F("{0}  ·  {1}",SkillName(edictSkill),state),24,50,gold);
            var definitions=HuntEdictV2Options.ForSkill(edictSkill,edictDraft.heroClass);
            var skill=edictDraft.skills.Single(s=>s.id==edictSkill);
            for(int n=0;n<definitions.Count;n++)
            {
                var d=definitions[n];string value=skill.options[n].value;int option=n+1;string owner=edictSkill;
                void Set(string v)
                {
                    try{edictDraft=HuntEdictV2.WithOption(edictDraft,owner,option,v);RenderEdictEditor();}
                    catch(Exception e){RenderEdictEditor();ShowToast(e.Message);}
                }
                if(d.Numeric)StepRow(d.label,value,(float)d.min,(float)d.max,(float)d.step,dir=>Set(HuntEdictV2Editing.Stepped(d,value,dir)),"m");
                else if(n==0)BigButton(content,Loc.F("{0}{1}  ·  {2}",(value=="ON"?"✓ ":""),d.label,d.Describe(value)),()=>Set(value=="ON"?"OFF":"ON"),value=="ON");
                else BigButton(content,Loc.F("{0}  ·  {1}",d.label,d.Describe(value)),()=>Set(HuntEdictV2Editing.NextChoice(d.choices,value)));
                IssueNotes(issues,d.id,edictSkill);
            }
        }

        // ---- 나가기·저장 ----
        void RenderEdictLeave(HeroSave hero)
        {
            var changes=EdictChanges;
            Note(content,Loc.F("저장하지 않은 변경 {0}개가 있습니다.", changes.Count),24,50,gold);
            foreach(var change in changes.Take(8))Note(content,Loc.F("• {0}",change),19,50,pale);
            if(changes.Count>8)Note(content,Loc.F("… 그 밖에 {0}개", changes.Count-8),19,44,muted);
            BigButton(content,"저장하고 나가기",()=>{if(SaveEdictDraft(false)){edictDraft=null;ShowTown();}},true);
            BigButton(content,"저장하지 않고 나가기",()=>{edictDraft=null;ShowTown();});
            BigButton(content,"계속 편집하기",()=>{edictLeaving=false;RenderEdictEditor();});
        }

        bool SaveEdictDraft(bool rerender=true)
        {
            var hero=EdictHero;
            if(game.Store.SaveHeroEdict(hero.id,edictDraft,game.catalog))
            {
                edictDraft=hero.edict.Copy();
                // A run already in progress prepared its copy at start; let it read the saved document.
                if(game.Active)game.Combat.RefreshEdict();
                if(rerender){RenderEdictEditor();ShowToast("사냥 칙령을 저장했습니다.");}
                return true;
            }
            if(rerender)RenderEdictEditor();ShowToast(game.Store.Error);return false;
        }

        // ---- 위젯 ----
        void StepRow(string title,string value,float min,float max,float step,Action<int> stepped,string unit="")
        {
            var row=Row(content,64);
            var label=Label(row,Loc.F("{0}  ·  {1}{2}   ({3:0.###}~{4:0.###} · {5:0.###} 단위)", title, value, unit, min, max, step),19,pale);
            label.rectTransform.anchorMin=Vector2.zero;label.rectTransform.anchorMax=new Vector2(.62f,1);
            label.rectTransform.offsetMin=new Vector2(16,0);label.rectTransform.offsetMax=Vector2.zero;
            AnchorSpan(Button(row,"-",()=>stepped(-1)),.64f,.81f);AnchorSpan(Button(row,"+",()=>stepped(1)),.83f,1f);
        }
        void OrderRow(string title,bool canUp,bool canDown,Action<int> move)
        {
            var row=Row(content,76);
            var label=Label(row,title,20,pale);
            label.rectTransform.anchorMin=Vector2.zero;label.rectTransform.anchorMax=new Vector2(.58f,1);
            label.rectTransform.offsetMin=new Vector2(16,0);label.rectTransform.offsetMax=Vector2.zero;
            var up=Button(row,"▲ 위로",()=>move(-1));var down=Button(row,"▼ 아래로",()=>move(1));
            up.interactable=canUp;down.interactable=canDown;
            AnchorSpan(up,.59f,.79f);AnchorSpan(down,.8f,1f);
        }
        static void AnchorSpan(Button b,float from,float to)
        {var r=(RectTransform)b.transform;r.anchorMin=new Vector2(from,0);r.anchorMax=new Vector2(to,1);r.offsetMin=new Vector2(4,6);r.offsetMax=new Vector2(-4,-6);}
        void ReflowEdictRows()
        {
            if(Page!="edict"||content==null||edictLaidOutContent==content&&Mathf.Abs(content.rect.width-edictLayoutWidth)<.5f)return;
            Canvas.ForceUpdateCanvases();edictLayoutWidth=content.rect.width;edictLaidOutContent=content;
            var reading=DialogReadingAnchor.Capture(content.GetComponentInParent<ScrollRect>());
            foreach(RectTransform row in content)
            {
                var layout=row.GetComponent<LayoutElement>();if(layout==null)continue;
                float height=layout.minHeight;
                foreach(var text in row.GetComponentsInChildren<Text>())
                {
                    float needed=text.preferredHeight;
                    for(var rect=text.rectTransform;rect!=row;rect=rect.parent as RectTransform)
                    {
                        float fraction=rect.anchorMax.y-rect.anchorMin.y;
                        if(fraction<=0){needed=0;break;}
                        needed=(needed-rect.offsetMax.y+rect.offsetMin.y)/fraction;
                    }
                    height=Mathf.Max(height,needed);
                }
                layout.preferredHeight=Mathf.Ceil(height);
            }
            Canvas.ForceUpdateCanvases();reading?.Restore();
        }
        void RestoreEdictScroll()
        {
            Canvas.ForceUpdateCanvases();var scroll=content.GetComponentInParent<ScrollRect>();if(scroll==null)return;
            scroll.StopMovement();
            content.anchoredPosition=new Vector2(0,Mathf.Clamp(edictScrollOffset,0,Mathf.Max(0,content.rect.height-scroll.viewport.rect.height)));
        }
    }
}
