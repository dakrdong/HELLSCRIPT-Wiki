using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        bool TeleportLandingValid(Vector2 origin,Vector2 point)
        {
            float distance=Vector2.Distance(origin,point);
            return Finite(point)&&distance>=2-.0001f&&distance<=catalog.skills[15].range+.0001f&&Map.CanLand(point)&&Map.LineClear(origin,point)&&
                !ForecastSeen().Any(e=>Vector2.Distance(e.position,point)<(e.boss?1.2f:.4f)+.45f);
        }
        Vector2 LegalLegacyTeleportDestination(Vector2 requested)
        {
            if(TeleportLandingValid(State.position,requested))return requested;
            // Old target-point rules can request the enemy body's center. Keep their intent by
            // choosing the closest legal point, rather than paying for an impossible landing.
            return EdictRadialPoints(catalog.skills[15].range).Where(p=>TeleportLandingValid(State.position,p))
                .OrderBy(p=>(p-requested).sqrMagnitude).ThenBy(p=>(p-State.position).sqrMagnitude).ThenBy(p=>p.x).ThenBy(p=>p.y)
                .Select(p=>(Vector2?)p).FirstOrDefault()??State.position;
        }
        // Ordinary positioning is an idle action. Emergency/dodge teleport belongs to the global
        // survival executor, including targetless environmental hazards and its explicit fallback.
        public EdictResponseCandidate PlanEdictTeleport(HuntEdictV2Document source,EnemyState globalTarget)
        {
            var d=HuntEdictV2.Canonical(source);HuntEdictV2.ValidateReceiver(d,Hero,catalog);
            var values=d.global.ToDictionary(o=>o.id,o=>o.value,StringComparer.Ordinal);
            float cost=Cost(catalog.skills[15]);Vector2 point=State.position;
            EdictResponseCandidate Result(string code,string detail,bool ready=false)=>new EdictResponseCandidate("POSITION","M04",15,globalTarget?.id??-1,point,cost,code,detail,ready,true,.2f,EdictRuleOrder.TeleportRule());
            string block=EdictResponseBlock(d);if(block!="")return Result("STATE",block);
            if(!d.slots.Contains("M04"))return Result("NOT_EQUIPPED","순간이동을 장착하지 않았습니다.");
            if(!HuntEdictV2.Automatic(d,"M04"))return Result("EDICT_OFF","사냥 칙령에서 자동 사용을 껐습니다.");
            if(catalog.skills[15].unlock>EffectiveLevel)return Result("LEVEL_LOCK",Loc.F("해금 레벨 {0}",catalog.skills[15].unlock));
            if(HuntEdictV2.Value(d,"M04",2)!="DISTANCE")return Result("PURPOSE","생존용 순간이동은 전역 긴급 생존·회피 판단에서 사용합니다.");
            if(HeroActionBusy)return Result("ACTION_LOCK","거리 조정은 진행 중인 주 행동이 끝난 뒤 판단합니다.");
            if(State.cooldowns[15]>0)return Result("COOLDOWN",Loc.F("남은 CD {0:0.00}초",State.cooldowns[15]));
            if(State.resource<cost)return Result("RESOURCE",Loc.F("필요 {0:0.##} / 현재 {1:0.##}",cost,State.resource));
            var assessment=AssessEdictSurvival(d,State.edictResponse?.memory,null,values);
            if(assessment.emergency||assessment.DodgeRequested)return Result("SURVIVAL","현재 위험 대응은 전역 생존·회피 판단을 따릅니다.");
            if(assessment.preserveEscapeForEmergency&&values["survival.escapeSkill"]=="M04")return Result("RESERVED","긴급용으로 보존한 순간이동은 일반 거리 조정에 사용하지 않습니다.");
            var seen=ForecastSeen();globalTarget=seen.FirstOrDefault(e=>e.id==globalTarget?.id&&EdictTargetEligible(e));
            if(globalTarget==null)return Result("NO_TARGET","거리 조정의 기준이 될 유효한 감지 대상이 없습니다.");
            var risks=new Dictionary<Vector2,EdictSurvivalAssessment>{{State.position,assessment}};
            EdictSurvivalAssessment Risk(Vector2 p)
            {if(!risks.TryGetValue(p,out var a)){a=AssessEdictSurvival(d,null,p,values);risks[p]=a;}return a;}
            var destination=EdictEscapePoint(d,values,15,catalog.skills[15].range,seen,globalTarget,Risk,true,true);
            if(!destination.HasValue)return Result("LANDING","희망 거리의 오차를 2m 이상 줄이며 위험 기준을 만족하는 착지점이 없습니다.");
            point=destination.Value;return Result("READY","희망 거리의 오차를 2m 이상 줄이는 유효한 착지점입니다.",true);
        }
    }
}
