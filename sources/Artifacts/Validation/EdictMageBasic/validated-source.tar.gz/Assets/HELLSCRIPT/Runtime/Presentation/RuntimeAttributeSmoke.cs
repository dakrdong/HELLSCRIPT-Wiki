using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Opt-in native UI regression fixture. Gameplay numbers and time are controlled explicitly;
    // navigation, language changes and pause restoration use the actual screen actions.
    public sealed class RuntimeAttributeSmoke:MonoBehaviour
    {
        GameController game;
        string directory;
        int capture;
        readonly List<string> failures=new List<string>();
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if(!Debug.isDebugBuild||!Environment.GetCommandLineArgs().Contains("-hellscriptAttributeSmoke"))return;
            Application.runInBackground=true;
            Application.logMessageReceived+=(m,s,t)=>{if(t==LogType.Exception)Application.Quit(1);};
            new GameObject("Attribute integration validation").AddComponent<RuntimeAttributeSmoke>();
        }
        static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
        void Check(bool condition,string message){if(!condition)failures.Add(message);}
        string[] Lines()=>game.UI.GetComponentsInChildren<Text>().Select(t=>t.text).ToArray();
        Button Find(string name)=>game.UI.GetComponentsInChildren<Button>().Single(b=>b.name==name);
        void Click(string name){var button=Find(name);Require(button.IsInteractable(),"Disabled action: "+name);button.onClick.Invoke();}
        void ToggleEmpty()
        {
            var button=game.UI.GetComponentsInChildren<Button>().Single(b=>b.name=="아직 얻지 못한 줄 접기"||b.name=="아직 얻지 못한 줄 보기");
            button.onClick.Invoke();
        }
        IEnumerator Capture(string name,int width,int height,string focus=null)
        {
            Screen.SetResolution(width,height,FullScreenMode.Windowed);float deadline=Time.realtimeSinceStartup+6;
            while((Screen.width!=width||Screen.height!=height)&&Time.realtimeSinceStartup<deadline)yield return null;
            Require(Screen.width==width&&Screen.height==height,"Attribute screen resize failed.");
            yield return new WaitForSecondsRealtime(.3f);
            if(focus!=null)
            {
                var target=game.UI.GetComponentsInChildren<Text>().First(t=>t.text.StartsWith(focus,StringComparison.Ordinal));
                DialogReadingAnchor.Show(target.rectTransform);yield return new WaitForSecondsRealtime(.2f);
            }
            Canvas.ForceUpdateCanvases();
            foreach(var line in game.UI.GetComponentsInChildren<Text>())
                Check(line.preferredHeight<=line.rectTransform.rect.height+1,"Clipped on "+name+": "+line.text);
            // Language selectors intentionally retain each language's native name.
            var missing=Loc.Missing.Where(key=>!LanguageOptions.All.Any(option=>option.NativeName==key)).ToArray();
            Check(missing.Length==0,"Missing translations on "+name+": "+string.Join("; ",missing));
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,$"{++capture:00}-{name}.png"));
            yield return new WaitForSecondsRealtime(.2f);
        }
        void CheckMovement()
        {
            string prefix=Loc.IsSource?"이동 속도":"Movement Speed";
            var line=Lines().Single(s=>s.StartsWith(prefix+"   ",StringComparison.Ordinal));
            Check(line.Contains("m/s")&&!line.Contains("%"),"Movement sheet uses the wrong unit: "+line);
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();int save=Array.IndexOf(args,"-hellscriptSavePath"),evidence=Array.IndexOf(args,"-hellscriptScreenshots");
            Require(save>=0&&save+1<args.Length&&!args[save+1].StartsWith("-"),"Use an isolated attribute account.");
            Require(evidence>=0&&evidence+1<args.Length&&!args[evidence+1].StartsWith("-"),"Use a dedicated attribute evidence directory.");
            directory=args[evidence+1];Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1);game=FindAnyObjectByType<GameController>();
            Require(game?.Store!=null,"Attribute fixture failed to load.");game.enabled=false;game.Store.Data.guide.hintsHidden=true;
            game.Store.Data.Hero.level=30;game.Store.Data.Hero.highestClear=10;game.Store.Data.Hero.build.autoRepeat=false;
            game.SelectedStage=1;game.Begin(seed:13);var sim=game.Combat;
            Require(sim!=null&&game.Active,"Attribute fixture failed to enter a rift.");
            foreach(var enemy in sim.State.enemies){enemy.speed=0;enemy.attack=0;enemy.cooldown=10000;}
            sim.Stats.maxResource=140;sim.State.resource=70;
            foreach(string language in new[]{"ko","en"})
            {
                game.ApplyLanguage(language);game.UI.ShowBattle();game.UI.RefreshHud();
                string expected=language=="ko"?"자원 70 / 140":"Resource 70 / 140";
                Check(Lines().Contains(expected),"HUD omits the actual resource capacity in "+language);
                var fill=(Image)typeof(GameUI).GetField("resourceFill",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(game.UI);
                Check(Mathf.Abs(fill.rectTransform.anchorMax.x-.5f)<.001f,"Resource bar is not half full at 70/140.");
                yield return Capture("capacity-hud-"+language,language=="ko"?720:640,language=="ko"?1280:360);
                game.UI.ShowCombatOverview();
                Check(Lines().Any(s=>s.Contains(expected)),"Combat overview omits the actual resource capacity in "+language);
                yield return Capture("capacity-overview-"+language,1280,720);game.UI.CloseCommonPanel();
            }
            game.ApplyLanguage("ko");sim.State.paused=false;game.UI.ShowGrowth();Click("능력치");
            Check(sim.State.paused,"Attribute entry did not pause combat.");CheckMovement();
            yield return Capture("folded-ko",720,1280);
            ToggleEmpty();game.ApplyLanguage("en");CheckMovement();
            yield return Capture("expanded-utility-en",640,360,"Movement Speed");
            Click("전투로 돌아가기");Check(!sim.State.paused,"Attribute fold/language redraw lost the running entry state.");

            // A player who deliberately paused must remain paused after the same navigation.
            sim.State.paused=true;game.UI.ShowGrowth();Click("능력치");ToggleEmpty();game.ApplyLanguage("ko");
            Click("성장과 스킬");game.ApplyLanguage("en");Click("전투로 돌아가기");
            Check(sim.State.paused,"Attribute/growth navigation resumed a manually paused battle.");

            sim.State.paused=false;game.UI.ShowGrowth();game.ApplyLanguage("ko");Click("능력치");
            ToggleEmpty();Click("성장과 스킬");game.ApplyLanguage("en");Click("전투로 돌아가기");
            Check(!sim.State.paused,"Growth/attribute round trip lost the running entry state.");

            sim.State.paused=false;game.UI.ShowGrowth();game.ApplyLanguage("ko");
            var recommendation=game.UI.GetComponentsInChildren<Button>().First(b=>b.name.Contains("현재 레벨 추천"));
            recommendation.onClick.Invoke();game.UI.CancelBuild();
            Check(game.UI.Page=="battle"&&!sim.State.paused,"Growth redraw/recommendation/cancel did not restore battle.");

            sim.State.paused=false;game.UI.ShowAttributes();game.ApplyInterfaceScale(140);game.ApplyLanguage("en");
            yield return Capture("large-text-en",720,1280);game.ApplyLanguage("ko");
            yield return Capture("large-text-ko",720,1280);Click("전투로 돌아가기");
            Check(!sim.State.paused,"Large-text attribute view lost the running entry state.");game.ApplyInterfaceScale(100);

            sim.Abandon();game.UI.ShowResult();bool terminalPause=sim.State.paused;
            game.UI.ShowGrowth();Click("능력치");ToggleEmpty();Click("결과로 돌아가기");
            Check(game.UI.Page=="result"&&sim.State.paused==terminalPause,"Attribute view did not restore the terminal result state.");
            game.ReturnTown();game.ApplyLanguage("ko");game.UI.ShowGrowth();Click("능력치");CheckMovement();
            yield return Capture("town-attributes-ko",720,1280);game.ApplyLanguage("en");ToggleEmpty();
            yield return Capture("town-attributes-en",1280,720);Click("성소로");
            Check(game.UI.Page=="town"&&game.Combat==null,"Town attribute view did not return to town.");

            string report=failures.Count==0?"PASS: actual resource capacity/bar, sheet movement units, running and paused entry, fold/language/scale redraw, growth round trip, recommendation cancel, terminal result and town navigation. Automated native UI fixtures; not manual combat or mobile-device validation.\n":string.Join("\n",failures)+"\n";
            File.WriteAllText(Path.Combine(directory,"runtime-attribute-smoke.txt"),report);
            Debug.Log(failures.Count==0?"HELLSCRIPT_ATTRIBUTE_RUNTIME_OK":"HELLSCRIPT_ATTRIBUTE_RUNTIME_FAIL\n"+report);
            Application.Quit(failures.Count==0?0:1);
        }
    }
}
