using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Opt-in native UI/save evidence. Enemy positions and simulation time are controlled fixtures;
    // option edits, saving, drawing and resuming use the actual player code.
    public sealed class RuntimeMageBasicSmoke:MonoBehaviour
    {
        GameController game;
        string directory,saveDirectory;
        int capture;
        readonly List<string> failures=new List<string>();
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if(!Debug.isDebugBuild||!Environment.GetCommandLineArgs().Contains("-hellscriptMageBasicSmoke"))return;
            Application.runInBackground=true;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Mage basic edict validation").AddComponent<RuntimeMageBasicSmoke>();
        }
        static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
        void Check(bool condition,string message){if(!condition)failures.Add(message);}
        static string Json(object value)=>JsonUtility.ToJson(value);
        Button[] Buttons=>game.UI.GetComponentsInChildren<Button>();
        void Click(string name){var b=Buttons.Single(b=>b.name==name);Require(b.IsInteractable(),"Disabled: "+name);b.onClick.Invoke();}
        void Choice(string label){var b=Buttons.Single(b=>b.name.Contains(label));Require(b.IsInteractable(),"Disabled: "+label);b.onClick.Invoke();}
        void Skills(string skill="기본 공격"){game.UI.ShowEdictEditor();Click("스킬 설정");Click(skill);}
        string[] Lines()=>game.UI.GetComponentsInChildren<Text>().Select(t=>t.text).ToArray();
        static int Starts(CombatSimulation sim)=>sim.State.actionEvents.Count(a=>a.skill<0&&a.kind=="ACTION_START");
        static int Hits(CombatSimulation sim)=>sim.State.damageEvents.Count(d=>!d.incoming&&d.definitionId=="BASIC");
        void Advance(int ticks)
        {game.Combat.State.paused=false;for(int i=0;i<ticks;i++)game.Combat.Tick(CombatSimulation.Step);game.World.Present(game.Combat.State,.05f);game.UI.RefreshHud();}
        void Enemy(float x,float y,int kind=0,int elite=-1)
        {
            var run=game.Combat.State;
            run.enemies.Add(new EnemyState{id=900+run.enemies.Count,kind=kind,elite=elite,position=run.position+new Vector2(x,y),health=1000000,maxHealth=1000000,speed=0,attack=0,cooldown=1000});
        }
        IEnumerator Capture(string name,int width,int height,string focus=null)
        {
            Screen.SetResolution(width,height,FullScreenMode.Windowed);float deadline=Time.realtimeSinceStartup+6;
            while((Screen.width!=width||Screen.height!=height)&&Time.realtimeSinceStartup<deadline)yield return null;
            Require(Screen.width==width&&Screen.height==height,"Native resize failed: "+name);
            yield return new WaitForSecondsRealtime(.3f);
            if(focus!=null)
            {
                var line=game.UI.GetComponentsInChildren<Text>().First(t=>t.text.Contains(focus));
                DialogReadingAnchor.Show(line.rectTransform);yield return new WaitForSecondsRealtime(.2f);
            }
            Canvas.ForceUpdateCanvases();
            foreach(var line in game.UI.GetComponentsInChildren<Text>())
                Check(line.preferredHeight<=line.rectTransform.rect.height+1,"Clipped on "+name+": "+line.text);
            var safe=UiSafeArea.Current;var corners=new Vector3[4];
            foreach(var button in Buttons.Where(b=>b.transform.parent.name=="Footer"))
            {((RectTransform)button.transform).GetWorldCorners(corners);Check(corners.All(c=>c.x>=safe.xMin-1&&c.x<=safe.xMax+1&&c.y>=safe.yMin-1&&c.y<=safe.yMax+1),"Footer outside safe area: "+name+" / "+button.name);}
            var missing=Loc.Missing.Where(key=>!LanguageOptions.All.Any(o=>o.NativeName==key)).ToArray();
            Check(missing.Length==0,"Missing translation: "+string.Join("; ",missing));
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,$"{++capture:00}-{name}.png"));yield return new WaitForSecondsRealtime(.2f);
        }
        static void Controlled(CombatSimulation sim)
        {
            sim.Stats.armor=sim.Stats.resistance=sim.Stats.regen=sim.Stats.crit=sim.Stats.costReduction=0;
            for(int i=(int)StatId.VulnerableDamage;i<StatCatalog.Count;i++)sim.Stats.bonuses[i]=0;
            sim.Stats.dodge=sim.Stats.blockChance=sim.Stats.blockedReduction=sim.Stats.lifeRegen=sim.Stats.damageReduction=sim.Stats.closeReduction=sim.Stats.distantReduction=sim.Stats.injuredReduction=sim.Stats.physicalReduction=0;
        }
        void Finish(string stage,string detail)
        {
            string result=failures.Count==0?"PASS: "+detail+" Controlled native UI/combat fixtures; not mobile-device or natural-play balance validation.":string.Join("\n",failures);
            File.WriteAllText(Path.Combine(directory,stage+"-result.txt"),result+"\n");Debug.Log(failures.Count==0?"HELLSCRIPT_MAGE_BASIC_"+stage.ToUpperInvariant()+"_OK":"HELLSCRIPT_MAGE_BASIC_RUNTIME_FAIL\n"+result);Application.Quit(failures.Count==0?0:1);
        }
        void SaveCheckpoint(string name)
        {var run=game.Combat.State;run.training=-1;run.paused=false;game.Save();File.WriteAllText(Path.Combine(directory,name),Json(run));}
        CombatSimulation Restored(string name)
        {
            Require(game.Store.Data.suspendedRun!=null,"The saved pending battle was lost.");game.Begin(resume:true);
            Require(game.Combat!=null,"The saved battle did not restore.");var sim=game.Combat;var expected=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(directory,name)));
            Require(sim.State.time==expected.time&&sim.State.resource==expected.resource&&Json(sim.State.heroAction)==Json(expected.heroAction),"The committed action, time or resource changed on restart.");
            Require(Json(sim.State.itemEffects)==Json(expected.itemEffects),"Item charges or elemental history changed on restart.");Require(sim.State.projectiles.Count==expected.projectiles.Count&&sim.State.projectiles.Select(p=>Json(p)).SequenceEqual(expected.projectiles.Select(p=>Json(p))),"In-flight projectiles changed on restart.");Controlled(sim);return sim;
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();int save=Array.IndexOf(args,"-hellscriptSavePath"),output=Array.IndexOf(args,"-hellscriptScreenshots");
            Require(save>=0&&save+1<args.Length&&output>=0&&output+1<args.Length,"Use dedicated save and evidence paths.");
            saveDirectory=args[save+1];directory=args[output+1];Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1);game=FindAnyObjectByType<GameController>();Require(game?.Store!=null,"Store unavailable.");game.enabled=false;
            if(args.Contains("-hellscriptMageBoltResume")){yield return BoltResume();yield break;}
            if(args.Contains("-hellscriptMageBasicResume")){yield return Resume();yield break;}
            Require(game.Store.Data.heroes.All(h=>h.level==1)&&game.Store.Data.suspendedRun==null,"Use a fresh test account.");
            game.SelectHero(2);var hero=game.Store.Data.Hero;hero.level=30;hero.inventory.Clear();game.Store.Data.guide.hintsHidden=true;
            hero.build.activeSkills=new List<int>{12,17};hero.build.passives=new[]{4,5};hero.build.autoRepeat=false;
            hero.build.rules=new List<Rule>{BehaviorRules.Make(12,BehaviorRules.C("SC06",Comparison.AtLeast,99,predicted:true)),BehaviorRules.Make(17,BehaviorRules.C("SC06",Comparison.AtLeast,99,predicted:true))};
            uint rng=176113;var item=ItemGenerator.Create(HeroClass.Mage,ItemCatalog.Unique("LC02").slot,3,30,ref rng,uniqueId:"LC02");hero.inventory.Add(item);Require(Economy.Equip(hero,item),"Could not equip LC02.");
            hero.edict=HuntEdictV2Storage.CreateForHero(hero);
            foreach(var p in new[]{("position.mode","STAND"),("target.default","HIGH_HP"),("survival.potion","OFF"),("survival.lowHp","OFF"),("survival.lethal","OFF")})hero.edict=HuntEdictV2Editing.WithGlobal(hero.edict,p.Item1,p.Item2);
            game.Save();string original=Json(hero.edict);Skills();yield return Capture("basic-options-ko",1280,720,"자동 사용");
            game.ApplyLanguage("en");yield return Capture("basic-options-en",1280,720,"Automatic use");game.ApplyInterfaceScale(140);
            yield return Capture("basic-options-large-en",720,1280,"Lightning Bolt restores");yield return Capture("basic-options-small-en",640,360,"Lightning Bolt restores");
            game.ApplyLanguage("ko");yield return Capture("basic-options-large-ko",720,1280,"조준 방식");game.ApplyInterfaceScale(100);
            Choice("자동 사용");Choice("자동 사용");Choice("사용 방식");Choice("사용 방식");for(int i=0;i<4;i++)Choice("우선 대상");Choice("조준 방식");Choice("조준 방식");
            Require(Json(hero.edict)==original,"Editing the draft changed the saved document.");Click("저장 및 적용");
            Require(HuntEdictV2.Value(hero.edict,"BASIC",2)=="DISCOUNT"&&HuntEdictV2.Value(hero.edict,"BASIC",3)=="GLOBAL"&&HuntEdictV2.Value(hero.edict,"BASIC",4)=="PREDICTED","The four basic options did not save.");
            Require(Json(new GameStore(saveDirectory,game.catalog).Data.Hero.edict)==Json(hero.edict),"Fresh file read disagrees with the saved edict.");Click("공유");Click("사냥 칙령 v0.2 사용하기");
            game.BeginDeveloperTraining(1);var sim=game.Combat;Require(sim?.EdictActive==true,"Training edict unavailable.");Controlled(sim);
            sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();sim.State.exploration.enemies.Clear();Enemy(0,2);Enemy(0,5);sim.State.enemies[0].health=100000;
            sim.State.cooldowns[12]=sim.State.cooldowns[17]=1000;sim.State.resource=0;game.World.BuildDungeon(sim.State);Advance(1);
            Require(sim.State.heroAction.skill<0&&sim.State.heroAction.policy.rule.id=="edict:MAGE:BASIC"&&sim.State.heroAction.targetId==sim.State.enemies[1].id,"Missing legacy BASIC did not derive the global high-HP shot.");
            Require(Hits(sim)==0&&sim.State.resource==0&&sim.State.itemEffects.basicCount==0,"Preparation granted hit rewards.");
            for(int i=0;i<40&&Hits(sim)<1;i++)Advance(1);
            Require(Hits(sim)==1&&sim.State.resource==5&&sim.State.itemEffects.basicCount==1&&sim.State.itemEffects.lastBasic==sim.State.enemies[0].id,"The front collision did not credit the actual victim and five resource.");
            game.UI.ShowBattle();yield return Capture("front-collision-ko",1280,720);
            for(int i=0;i<40&&Starts(sim)<2;i++)Advance(1);
            Require(Starts(sim)==2&&sim.State.heroAction.targetId==sim.State.enemies[0].id&&sim.State.heroAction.phase==HeroActionPhase.Preparing,"DISCOUNT did not prefer the real unfinished hit target.");
            int action=sim.State.heroAction.id;Skills();Choice("자동 사용");Choice("사용 방식");Choice("사용 방식");Choice("우선 대상");Choice("우선 대상");Choice("조준 방식");Click("저장 및 적용");
            Require(sim.State.heroAction.id==action&&sim.State.resource==5&&sim.State.itemEffects.basicCount==1,"Editing replaced the committed basic or changed its rewards.");
            game.ApplyLanguage("en");game.UI.ShowBattle();yield return Capture("second-preparation-before-restart-en",1280,720);SaveCheckpoint("expected-basic-run.json");
            Finish("checkpoint","Real UI edited all four Mage basic options with isolated drafts and matching file reads. Missing legacy BASIC still fired; a front collision credited its actual victim and five resource. DISCOUNT selected that unfinished hit target for the next cast. OFF/RESOURCE/LOW_HP/CURRENT edits preserved its committed preparation.");
        }
        IEnumerator Resume()
        {
            var sim=Restored("expected-basic-run.json");Require(sim.State.heroAction.skill<0&&!HuntEdictV2.Automatic(sim.Hero.edict,"BASIC"),"Expected a committed disabled basic.");
            for(int i=0;i<40&&Hits(sim)<2;i++)Advance(1);
            Require(Hits(sim)==2&&Starts(sim)==2&&sim.State.resource==10&&sim.State.itemEffects.basicCount==2&&!sim.State.itemEffects.reducedNext,"The restored second shot did not credit exactly one hit.");
            game.UI.ShowCombatEffects();game.ApplyLanguage("ko");yield return Capture("two-real-hits-after-restart-ko",1280,720,"절제 준비");Click("전투로 돌아가기");
            Skills();Choice("자동 사용");Click("저장 및 적용");Advance(30);
            Require(Starts(sim)==2&&Hits(sim)==2&&sim.State.resource==10,"RESOURCE fired without an otherwise eligible unfunded active.");game.UI.ShowRuleDecisions();yield return Capture("resource-not-needed-ko",1280,720,"자원 보충 불필요");Click("전투로 돌아가기");
            sim.State.cooldowns[12]=0;sim.State.decisionTime=0;Advance(1);
            Require(Starts(sim)==3&&sim.State.heroAction.skill<0&&sim.State.resource==10,"An eligible cost-25 Fireball did not make RESOURCE basic available.");
            for(int i=0;i<30&&sim.State.projectiles.Count==0;i++)Advance(1);
            Require(sim.State.projectiles.Count==1&&Hits(sim)==2&&sim.State.itemEffects.basicCount==2,"Expected the third bolt in flight before impact.");
            Skills();Choice("자동 사용");Click("저장 및 적용");Skills("화염구");Choice("자동 사용");Click("저장 및 적용");
            game.ApplyLanguage("en");game.UI.ShowBattle();yield return Capture("third-bolt-before-restart-en",1280,720);SaveCheckpoint("expected-bolt-run.json");
            Finish("resume","The saved preparation hit once, retaining two real hits and ten resource. RESOURCE waited while actives were unavailable, then started a third bolt for an otherwise eligible unfunded Fireball. The in-flight bolt was saved after disabling both BASIC and Fireball through actual UI.");
        }
        IEnumerator BoltResume()
        {
            var sim=Restored("expected-bolt-run.json");Require(sim.State.projectiles.Count==1,"Expected one saved bolt.");
            for(int i=0;i<40&&Hits(sim)<3;i++)Advance(1);
            Require(Hits(sim)==3&&Starts(sim)==3&&sim.State.resource==15&&sim.State.itemEffects.reducedNext&&sim.State.itemEffects.lc02Charge>4.9f,"The third actual hit did not grant one five-second LC02 charge and five resource.");
            Require(sim.State.effectEvents.Count(e=>e.definitionId=="LC02"&&e.kind=="CHARGE")==1&&!sim.State.actionEvents.Any(a=>a.kind=="ACTION_START"&&a.skill==12),"The discount replayed or forced Fireball.");
            game.UI.ShowCombatEffects();game.ApplyLanguage("en");game.ApplyInterfaceScale(140);yield return Capture("real-discount-after-bolt-restart-en",720,1280,"Restraint");Click("전투로 돌아가기");game.ApplyLanguage("ko");game.ApplyInterfaceScale(100);
            for(int i=0;i<40&&sim.HeroActionBusy;i++)Advance(1);Require(!sim.HeroActionBusy,"The restored basic did not finish.");
            sim.State.resource=100;sim.State.cooldowns[17]=0;sim.State.enemies[1].position=sim.State.position+new Vector2(1,2);
            Skills("서리 폭발");Choice("사용 목적");Click("저장 및 적용");sim.State.decisionTime=0;Advance(1);
            Require(sim.State.heroAction.skill==17&&sim.State.heroAction.cost==10&&sim.State.resource==90&&!sim.State.itemEffects.reducedNext,"The deliberately enabled GROUP Nova did not consume the actual earned discount once.");
            Skills("서리 폭발");Choice("자동 사용");Click("저장 및 적용");game.UI.ShowBattle();yield return Capture("earned-discount-consumed-ko",1280,720);Advance(12);
            Require(sim.State.damageEvents.Any(d=>!d.incoming&&d.definitionId=="M06")&&sim.State.itemEffects.elementBuff>0,"Actual cold after the real lightning hits did not activate MP06.");
            Require(sim.State.effectEvents.Count(e=>e.definitionId=="LC02"&&e.kind=="CONSUMED")==1&&sim.State.resource==90&&Starts(sim)==3,"The discount, resource or basic cast replayed.");
            game.UI.ShowCombatEffects();game.ApplyLanguage("en");game.ApplyInterfaceScale(140);yield return Capture("actual-element-crossover-en",720,1280,"Element Crossover");
            File.WriteAllText(Path.Combine(directory,"final-run.json"),Json(sim.State));Finish("bolt","A second independent restart preserved the original in-flight bolt. Its third real hit granted one LC02 charge and exactly five resource with MP05 equipped. No active was forced. A later UI-selected GROUP Nova consumed that actual discount once, then its cold hit followed real basic lightning to activate MP06.");
        }
    }
}
