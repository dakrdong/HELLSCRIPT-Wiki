using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Opt-in native UI/save evidence. Enemy positions and simulation time are controlled fixtures;
    // option edits, saving, drawing and resuming use the actual player code.
    public sealed class RuntimeTeleportSmoke:MonoBehaviour
    {
        GameController game;
        string directory,saveDirectory;
        int capture;
        readonly List<string> failures=new List<string>();
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if(!Debug.isDebugBuild||!Environment.GetCommandLineArgs().Contains("-hellscriptTeleportEdictSmoke"))return;
            Application.runInBackground=true;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Teleport edict validation").AddComponent<RuntimeTeleportSmoke>();
        }
        static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
        void Check(bool condition,string message){if(!condition)failures.Add(message);}
        static string Json(object value)=>JsonUtility.ToJson(value);
        Button[] Buttons=>game.UI.GetComponentsInChildren<Button>();
        void Click(string name){var b=Buttons.Single(b=>b.name==name);Require(b.IsInteractable(),"Disabled: "+name);b.onClick.Invoke();}
        void Choice(string label){var b=Buttons.Single(b=>b.name.Contains(label));Require(b.IsInteractable(),"Disabled: "+label);b.onClick.Invoke();}
        void Skills(){game.UI.ShowEdictEditor();Click("스킬 설정");Click("순간이동");}
        string[] Lines()=>game.UI.GetComponentsInChildren<Text>().Select(t=>t.text).ToArray();
        static int Starts(CombatSimulation sim)=>sim.State.statistics.skills.SingleOrDefault(s=>s.definitionId=="M04")?.starts??0;
        void Advance(int ticks)
        {game.Combat.State.paused=false;for(int i=0;i<ticks;i++)game.Combat.Tick(CombatSimulation.Step);game.World.Present(game.Combat.State,.05f);game.UI.RefreshHud();}
        void Enemy(float x,float y,int kind=0,int elite=-1)
        {
            var run=game.Combat.State;
            run.enemies.Add(new EnemyState{id=900+run.enemies.Count,kind=kind,elite=elite,position=run.position+new Vector2(x,y),health=1000000,maxHealth=1000000,speed=0,attack=0,cooldown=1000});
        }
        IEnumerator Capture(string name,int width,int height,string focus=null)
        {
            Screen.SetResolution(width,height,FullScreenMode.Windowed);float deadline=Time.realtimeSinceStartup+6;
            while((Screen.width!=width||Screen.height!=height)&&Time.realtimeSinceStartup<deadline)yield return null;
            Require(Screen.width==width&&Screen.height==height,"Native resize failed: "+name);
            yield return new WaitForSecondsRealtime(.3f);
            if(focus!=null)
            {
                var line=game.UI.GetComponentsInChildren<Text>().First(t=>t.text.Contains(focus));
                DialogReadingAnchor.Show(line.rectTransform);yield return new WaitForSecondsRealtime(.2f);
            }
            Canvas.ForceUpdateCanvases();
            foreach(var line in game.UI.GetComponentsInChildren<Text>())
                Check(line.preferredHeight<=line.rectTransform.rect.height+1,"Clipped on "+name+": "+line.text);
            var safe=UiSafeArea.Current;var corners=new Vector3[4];
            foreach(var button in Buttons.Where(b=>b.transform.parent.name=="Footer"))
            {((RectTransform)button.transform).GetWorldCorners(corners);Check(corners.All(c=>c.x>=safe.xMin-1&&c.x<=safe.xMax+1&&c.y>=safe.yMin-1&&c.y<=safe.yMax+1),"Footer outside safe area: "+name+" / "+button.name);}
            var missing=Loc.Missing.Where(key=>!LanguageOptions.All.Any(o=>o.NativeName==key)).ToArray();
            Check(missing.Length==0,"Missing translation: "+string.Join("; ",missing));
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,$"{++capture:00}-{name}.png"));yield return new WaitForSecondsRealtime(.2f);
        }
        void Finish(bool resumed)
        {
            string detail=resumed?"Independent restart preserved the paid destination, resource and cast time after options changed to SURVIVAL/OFF. Exactly one release, no queued attack, correct pause restoration; a targetless visible hazard then used global Teleport survival.":"Actual UI edited DISTANCE, arrival preference and NO_DAMAGE; drafts stayed isolated and saved source matched a fresh file read. Distance adjustment prepared a paid destination that survived option edits and OFF. Korean/English and 140% layouts passed.";
            string result=failures.Count==0?"PASS: "+detail+" Controlled native fixtures; not mobile-device or natural-play balance validation.":string.Join("\n",failures);
            File.WriteAllText(Path.Combine(directory,resumed?"resume-result.txt":"checkpoint-result.txt"),result+"\n");
            Debug.Log(failures.Count==0?(resumed?"HELLSCRIPT_TELEPORT_RUNTIME_OK":"HELLSCRIPT_TELEPORT_CHECKPOINT_READY"):"HELLSCRIPT_TELEPORT_RUNTIME_FAIL\n"+result);Application.Quit(failures.Count==0?0:1);
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();int save=Array.IndexOf(args,"-hellscriptSavePath"),outIndex=Array.IndexOf(args,"-hellscriptScreenshots");
            Require(save>=0&&save+1<args.Length&&outIndex>=0&&outIndex+1<args.Length,"Use dedicated save and evidence paths.");
            saveDirectory=args[save+1];directory=args[outIndex+1];Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1);game=FindAnyObjectByType<GameController>();Require(game?.Store!=null,"Store unavailable.");game.enabled=false;
            if(args.Contains("-hellscriptTeleportEdictResume")){yield return Resume();yield break;}
            Require(game.Store.Data.heroes.All(h=>h.level==1)&&game.Store.Data.suspendedRun==null,"Use a fresh test account.");
            game.SelectHero(2);var hero=game.Store.Data.Hero;hero.level=30;hero.inventory.Clear();game.Store.Data.guide.hintsHidden=true;
            hero.build.activeSkills=new List<int>{15};hero.build.passives=Array.Empty<int>();hero.build.autoRepeat=false;
            hero.build.rules=new List<Rule>{BehaviorRules.Make(15,BehaviorRules.C("SC06",Comparison.AtLeast,99,predicted:true))};
            hero.edict=HuntEdictV2.WithOption(HuntEdictV2Storage.CreateForHero(hero),"BASIC",1,"OFF");
            foreach(var pair in new[]{("position.mode","STAND"),("position.distanceSource","EXPLICIT"),("position.distance","8"),("survival.potion","OFF"),("survival.lowHp","OFF"),("survival.lethal","OFF")})
                hero.edict=HuntEdictV2Editing.WithGlobal(hero.edict,pair.Item1,pair.Item2);
            game.Save();string original=Json(hero.edict);Skills();
            yield return Capture("options-ko",1280,720,"자동 사용");game.ApplyLanguage("en");
            yield return Capture("options-en",1280,720,"Automatic use");game.ApplyInterfaceScale(140);
            yield return Capture("options-large-en",720,1280,"Survival Teleport requires");
            yield return Capture("options-small-en",640,360,"Survival Teleport requires");game.ApplyLanguage("ko");
            yield return Capture("options-large-ko",720,1280,"도착지 허용 기준");game.ApplyInterfaceScale(100);
            Choice("사용 목적");Choice("도착 위치");Choice("도착 위치");Choice("도착지 허용 기준");
            Require(Json(hero.edict)==original,"Draft changed the saved hero.");Click("저장 및 적용");
            Require(HuntEdictV2.Value(hero.edict,"M04",2)=="DISTANCE"&&HuntEdictV2.Value(hero.edict,"M04",3)=="DISTANCE"&&HuntEdictV2.Value(hero.edict,"M04",4)=="NO_DAMAGE","Options did not save.");
            Require(Json(new GameStore(saveDirectory,game.catalog).Data.Hero.edict)==Json(hero.edict),"Saved options disagree with the file.");
            Click("공유");Click("사냥 칙령 v0.2 사용하기");Require(hero.useEdict,"Edict switch did not enable.");
            game.BeginDeveloperTraining(1);var sim=game.Combat;Require(sim!=null&&sim.EdictActive,"Training did not start with the edict.");
            sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();sim.State.exploration.enemies.Clear();sim.Stats.crit=0;sim.Stats.regen=0;Enemy(0,2);
            game.World.BuildDungeon(sim.State);var origin=sim.State.position;Advance(1);
            Require(Starts(sim)==1&&sim.State.heroAction.skill==15&&sim.State.heroAction.phase==HeroActionPhase.Preparing,"Distance Teleport did not prepare.");
            Require(sim.State.position==origin&&Mathf.Abs(Vector2.Distance(sim.State.heroAction.destination,sim.State.enemies[0].position)-8)<.01f,"Teleport moved early or failed to restore desired range.");
            string action=Json(sim.State.heroAction);Skills();Choice("사용 목적");Choice("도착 위치");Choice("도착지 허용 기준");Choice("자동 사용");Click("저장 및 적용");
            Require(HuntEdictV2.Value(hero.edict,"M04",1)=="OFF"&&HuntEdictV2.Value(hero.edict,"M04",2)=="SURVIVAL"&&action==Json(sim.State.heroAction),"Editing rewrote the paid destination.");
            game.UI.ShowBattle();game.World.Present(sim.State,.05f);yield return Capture("preparation-before-restart",1280,720);
            sim.State.training=-1;sim.State.paused=false;game.Save();File.WriteAllText(Path.Combine(directory,"expected-run.json"),Json(sim.State));File.WriteAllText(Path.Combine(directory,"expected-edict.json"),Json(hero.edict));Finish(false);
        }
        IEnumerator Resume()
        {
            var expected=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(directory,"expected-run.json")));
            Require(Json(game.Store.Data.Hero.edict)==File.ReadAllText(Path.Combine(directory,"expected-edict.json"))&&game.Store.Data.Hero.useEdict,"Saved edict or switch was lost.");
            Require(game.Store.Data.suspendedRun!=null,"Pending run was lost.");game.Begin(resume:true);var sim=game.Combat;Require(sim!=null&&sim.EdictActive,"Saved run did not resume.");
            Require(sim.State.time==expected.time&&sim.State.resource==expected.resource&&Json(sim.State.heroAction)==Json(expected.heroAction),"Restart changed paid preparation.");
            sim.Stats.crit=0;sim.Stats.regen=0;Advance(5);
            Require(sim.State.position==expected.heroAction.destination&&Starts(sim)==1&&sim.State.resource==expected.resource,"Teleport lost its destination or paid twice.");
            Require(sim.State.actionEvents.Count(e=>e.skill==15&&e.kind=="ACTION_RELEASE")==1&&!sim.State.damageEvents.Any(d=>!d.incoming),"Release duplicated or queued an attack.");
            yield return Capture("teleport-after-restart",1280,720);game.UI.ShowRuleDecisions();game.ApplyLanguage("en");game.ApplyInterfaceScale(140);
            yield return Capture("resume-decisions-en",640,360,"Teleport hunt edict");game.ApplyLanguage("ko");
            yield return Capture("resume-decisions-ko",720,1280,"순간이동 사냥 칙령");Click("전투로 돌아가기");Check(!sim.State.paused,"Decision screen lost the running entry state.");
            sim.State.paused=true;game.UI.ShowRuleDecisions();game.ApplyLanguage("en");Click("전투로 돌아가기");Check(sim.State.paused,"Decision screen lost the manually paused entry state.");
            Advance(50);Require(Starts(sim)==1,"OFF started another Teleport.");
            game.ApplyLanguage("ko");game.ApplyInterfaceScale(100);Skills();Choice("자동 사용");Click("저장 및 적용");var hero=game.Store.Data.Hero;
            foreach(var pair in new[]{("survival.escapeSkill","M04"),("dodge.area.policy","ALWAYS"),("dodge.method","SKILL_FIRST")})hero.edict=HuntEdictV2Editing.WithGlobal(hero.edict,pair.Item1,pair.Item2);
            sim.RefreshEdict();sim.State.enemies[0].position=sim.State.position+Vector2.up*40;sim.State.cooldowns[15]=0;sim.State.decisionTime=0;
            sim.State.enemyHazards.Add(new EnemyHazard{id=800,actionId=800,enemyId=900,definitionId="TELEPORT_DANGER",position=sim.State.position,shape=AttackShape.Circle,radius=2,damage=20,delay=1,createdAt=-1});
            Advance(1);Require(Starts(sim)==2&&sim.State.heroAction.targetId==-1&&sim.State.heroAction.policy.rule.id=="HED2:SURVIVAL:M04","Targetless global escape did not start.");
            var escape=sim.State.heroAction;var destination=escape.destination;Advance(4);
            // The same tick may resume global pursuit after landing. Check the real completion
            // event rather than incorrectly requiring the hero to remain at the destination.
            Require(sim.State.actionEvents.Any(e=>e.actionId==escape.id&&e.kind=="ACTION_END"&&e.position==destination),"Targetless escape failed to land.");
            File.WriteAllText(Path.Combine(directory,"environment-escape-run.json"),Json(sim.State));
            game.UI.ShowBattle();game.World.Present(sim.State,.05f);yield return Capture("environment-escape",1280,720);Finish(true);
        }
    }
}
