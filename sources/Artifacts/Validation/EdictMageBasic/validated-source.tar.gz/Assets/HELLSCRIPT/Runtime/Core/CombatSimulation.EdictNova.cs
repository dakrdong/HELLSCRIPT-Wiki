using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        const float NovaRadius=3, NovaPreparation=.35f;
        bool NovaNewControl(EnemyState e,float arrival)=>e.boss?
            e.bossControl.staggered<=0&&e.bossControl.immunity<=0&&e.bossControl.meter+15>=100-.0001f:
            Mathf.Max(CombatEffects.Remaining(e,StatusKind.Stun),CombatEffects.Remaining(e,StatusKind.Freeze))<=arrival+.00001f;
        bool NovaInterruptibleCast(EnemyState e,float arrival,Vector2 position)
        {
            var a=e.brain.action;
            if(a.phase!=EnemyActionPhase.Preparing||a.released||a.remaining<=arrival+.00001f||!NovaNewControl(e,arrival))return false;
            return !e.boss&&e.kind==4||e.boss&&a.kind==(int)BossAttack.Summon||EnemyCombat.Threats(State,Map).Any(t=>
                (t.key=="action-"+a.id||t.key.StartsWith("action-"+a.id+"-")||t.key=="boss-"+a.id||t.key.StartsWith("boss-"+a.id+"-"))&&EnemyCombat.Contains(t,position));
        }
        EnemyState[] NovaVictims(HuntEdictV2Document d,Vector2 position,EnemyState[] seen)
        {
            var victims=seen.Where(e=>e.health>0&&Vector2.Distance(position,e.position)<=NovaRadius&&Map.LineClear(position,e.position)).ToArray();
            string boss=HuntEdictV2.Value(d,"M06",4);
            if(boss=="HOLD_ALONE"&&victims.All(e=>e.boss))return Array.Empty<EnemyState>();
            return boss=="STAGGER_ONLY"?victims.Where(e=>!e.boss||e.bossControl.staggered<=0&&e.bossControl.immunity<=0).ToArray():victims;
        }
        string NovaPurpose(HuntEdictV2Document d,out string issue)
        {
            issue="";string purpose=HuntEdictV2.Value(d,"M06",2);
            if(purpose!="CHAIN_CHARGE")return purpose;
            if(Stats.SetPieces("SMB")<4){issue="연쇄 충전 준비에는 SMB 4세트 장착이 필요합니다.";return purpose;}
            return d.slots.Contains("M03")&&HuntEdictV2.Automatic(d,"M03")&&catalog.skills[14].unlock<=EffectiveLevel?purpose:"CONTROL";
        }
        bool NovaPurposeMet(string purpose,EnemyState[] victims,EdictSurvivalAssessment assessment,float arrival,Vector2 position,bool survival)
        {
            if(victims.Length==0||survival&&!victims.Any(e=>NovaNewControl(e,arrival)))return false;
            if(purpose=="GROUP")return victims.Length>=2;
            if(purpose=="CHAIN_CHARGE")return ItemEffects.chainCharges<=0||ItemEffects.chainCharge<=1+.00001f;
            return (assessment.emergency||assessment.DodgeRequested)&&victims.Any(e=>NovaNewControl(e,arrival))||victims.Any(e=>NovaInterruptibleCast(e,arrival,position));
        }
        bool NovaPointAllowed(HuntEdictV2Document d,Dictionary<string,string> values,Vector2 p,EnemyState[] seen)
        {
            if(!Map.CanLand(p)||seen.Any(e=>Vector2.Distance(e.position,p)<(e.boss?1.2f:.4f)+.45f))return false;
            var risk=AssessEdictSurvival(d,null,p,values);if(risk.DodgeRequested||risk.lethal)return false;
            // Only remembered observations can warn about an additional group. Never inspect a
            // hidden enemy's current position or promise protection from undiscovered enemies.
            return values["position.addEnemies"]=="ON"||!State.exploration.enemies.Any(e=>!e.investigated&&State.time-e.seenAt<=30&&
                !seen.Any(v=>v.id==e.id)&&Vector2.Distance(p,e.position)<=14&&Map.LineClear(p,e.position)&&
                (Vector2.Distance(State.position,e.position)>14||!Map.LineClear(State.position,e.position)));
        }
        IEnumerable<Vector2> NovaApproachPoints(EnemyState[] seen)
        {
            for(int i=0;i<seen.Length;i++)
            {
                var p=seen[i].position;yield return Vector2.MoveTowards(State.position,p,Mathf.Max(0,Vector2.Distance(State.position,p)-2.5f));
                for(int j=i+1;j<seen.Length;j++)
                    if(Vector2.Distance(p,seen[j].position)<=NovaRadius*2)yield return (p+seen[j].position)*.5f;
            }
        }
        public EdictResponseCandidate PlanEdictNova(HuntEdictV2Document source,EnemyState globalTarget=null,bool survival=false)
            =>PlanEdictNovaCandidate(source,globalTarget,survival,false);
        EdictResponseCandidate PlanEdictNovaCandidate(HuntEdictV2Document source,EnemyState globalTarget,bool survival,bool ignoreResource)
        {
            var d=HuntEdictV2.Canonical(source);HuntEdictV2.ValidateReceiver(d,Hero,catalog);
            float cost=Cost(catalog.skills[17]);Vector2 point=State.position;EnemyState target=null;
            EdictResponseCandidate C(string code,string detail,bool ready=false,float arrival=NovaPreparation)=>new EdictResponseCandidate("DEFENSE","M06",17,target?.id??-1,point,cost,code,detail,ready,true,arrival,EdictRuleOrder.NovaRule());
            string block=EdictResponseBlock(d);if(block!="")return C("STATE",block);
            if(!d.slots.Contains("M06"))return C("NOT_EQUIPPED","서리 폭발을 장착하지 않았습니다.");
            if(!HuntEdictV2.Automatic(d,"M06"))return C("EDICT_OFF","사냥 칙령에서 자동 사용을 껐습니다.");
            if(catalog.skills[17].unlock>EffectiveLevel)return C("LEVEL_LOCK",Loc.F("해금 레벨 {0}",catalog.skills[17].unlock));
            if(State.cooldowns[17]>0)return C("COOLDOWN",Loc.F("남은 CD {0:0.00}초",State.cooldowns[17]));
            if(!ignoreResource&&State.resource<cost)return C("RESOURCE",Loc.F("필요 {0:0.##} / 현재 {1:0.##}",cost,State.resource));
            string purpose=NovaPurpose(d,out string issue);if(issue!="")return C("REFERENCE",issue);
            var values=d.global.ToDictionary(o=>o.id,o=>o.value,StringComparer.Ordinal);
            var assessment=AssessEdictSurvival(d,State.edictResponse?.memory,null,values);
            if(!ignoreResource&&!assessment.emergency&&State.resource-cost<assessment.escapeResource-.00001f)return C("RESERVED","일반 공격을 위해 생존용 자원을 사용하지 않습니다.");
            if(HeroActionBusy&&(!survival&&purpose!="CONTROL"||!EdictCanInterrupt(assessment)))return C("ACTION_LOCK","전역 방침과 현재 행동 구간에서 서리 폭발로 전환할 수 없습니다.");
            if(purpose=="CHAIN_CHARGE"&&ItemEffects.chainCharges>0&&ItemEffects.chainCharge>1+.00001f)return C("CHARGE_ACTIVE","이미 유효한 연쇄 강화가 남아 있습니다.");
            var seen=ForecastSeen().Where(EdictTargetEligible).ToArray();
            EnemyState Pick(EnemyState[] victims)=>victims.OrderBy(e=>purpose=="CONTROL"&&NovaInterruptibleCast(e,NovaPreparation,State.position)?0:1).ThenBy(e=>e==globalTarget?0:1).ThenBy(e=>(e.position-State.position).sqrMagnitude).ThenBy(e=>e.id).FirstOrDefault();
            var here=NovaVictims(d,point,seen);
            if(NovaPurposeMet(purpose,here,assessment,NovaPreparation,point,survival))
            {
                target=Pick(here);
                string reason=purpose!="CONTROL"?"현재 자기 중심 범위에서 선택한 목적을 충족했습니다.":assessment.emergency||assessment.DodgeRequested?
                    "전역 긴급·회피 요청에 따라 범위 안의 적을 새로 제어합니다.":"준비가 끝나기 전에 끊을 수 있는 위험 시전을 제어합니다.";
                return C("READY",reason,true);
            }
            if(survival)return C("NO_CONTROL","지정한 목적과 보스 제한을 지키며 새로 제어할 범위 대상이 없습니다.");
            if(HuntEdictV2.Value(d,"M06",3)!="APPROACH")return C("PURPOSE","설정한 목적에 맞는 실제 범위 대상이 부족합니다.");
            if(HeroActionBusy||assessment.emergency||assessment.DodgeRequested)return C("DANGER","전역 위험 대응 중에는 서리 폭발을 위해 접근하지 않습니다.");
            float speed=MovementSpeed(false)*(State.enemySlowTime>0?.65f:1);if(speed<=0)return C("NO_PATH","현재 보행 속도로 이동할 수 없습니다.");
            var policy=EdictTargetPolicy.Compile(d);var choices=new List<(Vector2 point,EnemyState target,float distance)>();
            foreach(var p in NovaApproachPoints(seen).Distinct())
            {
                if(!Map.LineClear(State.position,p)||!NovaPointAllowed(d,values,p,seen))continue;
                var victims=NovaVictims(d,p,seen);var t=Pick(victims);if(t==null)continue;
                var path=Map.FindPath(State.position,p);if(path==null)continue;float length=RiftNavigation.Length(path),arrival=length/speed+NovaPreparation;
                var chase=State.edictTarget;bool same=chase?.enemyId==t.id;
                if(Vector2.Distance(p,same?chase.origin:State.position)>policy.chaseDistance+.0001f||length/speed+(same?chase.pursuitSeconds:0)>policy.chaseTime+.0001f)continue;
                if(!NovaPurposeMet(purpose,victims,assessment,arrival,p,false))continue;
                bool safe=true;
                for(int i=1;i<path.Count&&safe;i++)
                {
                    int steps=Mathf.Max(1,Mathf.CeilToInt(Vector2.Distance(path[i-1],path[i])/.5f));
                    for(int n=1;n<=steps;n++)if(!NovaPointAllowed(d,values,Vector2.Lerp(path[i-1],path[i],n/(float)steps),seen)){safe=false;break;}
                }
                if(safe)choices.Add((p,t,length));
            }
            if(choices.Count==0)return C("NO_PATH","현재 교전 안에서 목적·위험·추적 한도를 만족하는 접근 위치가 없습니다.");
            var chosen=choices.OrderBy(c=>c.distance).ThenBy(c=>c.target.id).ThenBy(c=>c.point.x).ThenBy(c=>c.point.y).First();point=chosen.point;target=chosen.target;
            return C("APPROACH","현재 교전의 적을 자기 범위에 넣도록 접근합니다.",true,chosen.distance/speed+NovaPreparation);
        }
        bool MoveEdictNova(float dt)
        {
            if(edictSource==null||HeroActionBusy||State.movementRule<0||State.targetRuleId!="edict:M06"||State.movementAction!=RuleAction.Skill)return false;
            var plan=PlanEdictNova(edictSource,Target);
            if(plan.code!="APPROACH"||!plan.ready){State.decisionTime=0;State.movementRule=-1;return true;}
            if(plan.targetId!=State.targetId){State.decisionTime=0;return true;}
            var target=State.enemies.Find(e=>e.id==plan.targetId);var rule=EdictRuleOrder.NovaRule();
            if(!AdvanceEdictPursuit(dt,false,target,rule))return true;
            float speed=MovementSpeed(false)*(State.enemySlowTime>0?.65f:1);
            var p=Map.Move(State.position,plan.destination,speed*dt,0,State.time);
            if(!EdictPursuitStepAllowed(p,false,target,rule))return true;
            var seen=ForecastSeen().Where(EdictTargetEligible).ToArray();var values=edictSource.global.ToDictionary(o=>o.id,o=>o.value);
            if(!NovaPointAllowed(edictSource,values,p,seen)){State.decisionTime=0;return true;}
            State.moveDistance+=Vector2.Distance(State.position,p);State.position=p;State.destination=plan.destination;
            State.action=Loc.T("현재 교전의 적을 자기 범위에 넣도록 접근합니다.");
            if(!State.layout.legacy&&!RiftExploration.TrackMovement(State,Map,plan.destination,false))
            {State.decisionTime=0;State.movementRule=-1;Log("PATH_RETRY","같은 목표 접근 실패 · 다른 관찰 지점 탐색");}
            return true;
        }
    }
}
