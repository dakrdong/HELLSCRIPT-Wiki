using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    // A geometric forecast from the currently perceived world, not a damage or hit promise.
    // Repeated IDs are accepted visits/arrows; no gear proc, echo or secondary explosion is included.
    public sealed class AttackForecast
    {
        public readonly Vector2 origin,aim,impact;
        public readonly IReadOnlyList<int> hits;
        public readonly int uniqueTargets;
        internal AttackForecast(Vector2 origin,Vector2 aim,Vector2 impact,IEnumerable<int> hits)
        {this.origin=origin;this.aim=aim;this.impact=impact;this.hits=System.Array.AsReadOnly(hits.ToArray());uniqueTargets=this.hits.Distinct().Count();}
        public int TotalHits=>hits.Count;
        public int HitsOn(int target)=>hits.Count(id=>id==target);
        public int FirstHitIndex(int target)
        {for(int i=0;i<hits.Count;i++)if(hits[i]==target)return i;return -1;}
    }
    public sealed class EdictAimPlan
    {
        public readonly bool supported,available;
        public readonly int targetId;
        public readonly string reason;
        public readonly string blockCode;
        public readonly AttackForecast forecast;
        internal EdictAimPlan(bool supported,bool available,string reason,AttackForecast forecast,int targetId=-1,string blockCode="EDICT_AIM")
        {this.supported=supported;this.available=available;this.reason=reason;this.forecast=forecast;this.targetId=targetId;this.blockCode=blockCode;}
    }
}
