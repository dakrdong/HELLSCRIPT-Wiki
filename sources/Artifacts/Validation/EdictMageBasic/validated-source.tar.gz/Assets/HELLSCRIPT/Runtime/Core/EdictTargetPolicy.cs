using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    // Serializable as part of a running action's policy. Settings edits must not change its source.
    [Serializable] public sealed class EdictTargetPolicy
    {
        public const int CurrentVersion=1;
        public int version;
        public string basis,bossFight;
        public string[] specials;
        public bool keepTarget,investigate,interrupt;
        public float chaseDistance,chaseTime;
        public static EdictTargetPolicy Compile(HuntEdictV2Document document)
        {
            var values=HuntEdictV2.Canonical(document).global.ToDictionary(o=>o.id,o=>o.value,StringComparer.Ordinal);
            var enabled=new HashSet<string>(values["target.specialEnabled"].Split(','),StringComparer.Ordinal);
            return new EdictTargetPolicy{version=CurrentVersion,basis=values["target.default"],bossFight=values["target.bossFight"],
                specials=values["target.specialOrder"].Split(',').Where(enabled.Contains).ToArray(),
                keepTarget=values["target.switch"]=="UNTIL_DEATH",investigate=values["target.lostSight"]=="LAST_SEEN",interrupt=values["target.interruptCaster"]=="ON",
                chaseDistance=float.Parse(values["target.chaseDistance"],CultureInfo.InvariantCulture),chaseTime=float.Parse(values["target.chaseTime"],CultureInfo.InvariantCulture)};
        }
        public static bool Support(EnemyState e)=>!e.boss&&(e.kind==4||e.kind==10);
        public static bool Ranged(EnemyState e)=>!e.boss&&(e.kind==2||e.kind==3||e.kind==8||e.kind==9);
        int Rank(EnemyState e,RunState run)
        {
            int special=Array.FindIndex(specials??Array.Empty<string>(),s=>s=="BOSS"?e.boss:s=="ELITE"?!e.boss&&e.elite>=0:s=="SUPPORT"?Support(e):s=="RANGED"&&Ranged(e));
            int encounter=0;
            if(run.phase==RunPhase.Boss)
            {
                bool preferred=bossFight=="ADDS"?e.add&&!e.boss&&e.summonerId==run.bossId:bossFight=="DANGEROUS_SUPPORT"?Support(e):e.boss;
                encounter=preferred?0:e.boss?1:2;
            }
            return encounter*10+(special<0?4:special);
        }
        public EnemyState Select(IReadOnlyList<EnemyState> visible,RunState run,int current,float radius,Func<EnemyState,bool> canInterrupt,Func<Vector2,Vector2,bool> lineClear)
        {
            int Urgency(EnemyState e)=>interrupt&&canInterrupt(e)?0:1;
            float Basis(EnemyState e)=>basis=="LOW_HP"?e.health/Mathf.Max(.001f,e.maxHealth):basis=="HIGH_HP"?-e.health/Mathf.Max(.001f,e.maxHealth):
                basis=="DENSE"?-visible.Count(other=>Vector2.Distance(e.position,other.position)<=radius&&lineClear(e.position,other.position)):0;
            var selected=visible.OrderBy(Urgency).ThenBy(e=>Rank(e,run)).ThenBy(Basis).ThenBy(e=>(e.position-run.position).sqrMagnitude).ThenBy(e=>e.id).FirstOrDefault();
            var old=visible.FirstOrDefault(e=>e.id==current);
            if(keepTarget&&old!=null&&selected!=null&&Urgency(old)<=Urgency(selected))return old;
            return selected;
        }
    }
    [Serializable] public sealed class EdictPursuitExclusion
    {public int enemyId;public float reach;}
    [Serializable] public sealed class EdictTargetState
    {
        public int enemyId=-1;
        public Vector2 origin,lastSeen;
        public float pursuitSeconds,seenAt;
        public bool searching;
        public List<int> excluded=new List<int>();
        public List<EdictPursuitExclusion> excludedReaches=new List<EdictPursuitExclusion>();
    }
}
