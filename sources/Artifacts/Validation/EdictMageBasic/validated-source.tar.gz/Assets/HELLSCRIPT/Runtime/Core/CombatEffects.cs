using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public enum StatusKind { Poisoned, Slow, Root, Stun, Freeze, Mark }
    public enum DamageKind { Direct, Basic, Periodic, Legendary, Set, Shadow, Spread }
    [Serializable] public sealed class ProcReceipt {public int rootCastId,targetId;public string definitionId;public bool originScoped;}
    [Serializable] public sealed class StatusEffect
    {
        public int id,rootCastId,targetId,createdTick,areaId;
        public string definitionId,casterId;
        public StatusKind kind;
        public float remaining,strength;
    }
    [Serializable] public sealed class BossControlState
    {
        public float meter,staggered,immunity;
        public List<string> credited=new List<string>();
    }
    [Serializable] public sealed class ShieldEffect
    {
        public int id,rootCastId,createdTick;
        public string definitionId;
        public float remaining,amount,createdMaxHp,absorbed;
        public bool manaPaid;
    }
    [Serializable] public sealed class EffectEvent
    {
        public int instanceId,rootCastId,targetId=-1,tick;
        public float time,value;
        public string definitionId,kind,reason;
    }
    [Serializable] public sealed class DamageEvent
    {
        public int id,rootCastId,effectInstanceId,targetId=-1,triggerTargetId=-1,element,tick;
        public string definitionId,casterId;
        public DamageKind kind;
        public bool incoming,critical,projectile;
        public Vector2 attackOrigin;
        public float time,baseAttack,additive,independent,criticalMultiplier,attackBeforeDefense,defenseReduction,buffReduction,finalDamage,absorbed,hpLoss;
    }
    public readonly struct DamageNumbers
    {
        public readonly float beforeDefense,defenseReduction,buffReduction,final;
        public DamageNumbers(float beforeDefense,float defenseReduction,float buffReduction)
        {this.beforeDefense=beforeDefense;this.defenseReduction=defenseReduction;this.buffReduction=buffReduction;final=beforeDefense*(1-defenseReduction)*(1-buffReduction);}
    }
    public static class DamageMath
    {
        // The ceiling on stacked reduction. Half is what this project has always allowed a buff,
        // and the hero's own defensive sheet is the one caller that is allowed further.
        public const float BuffCeiling=.5f;
        public static DamageNumbers Calculate(float baseAttack,float additive,float independent,float critical,float defense,int attackerLevel,int element,float reduction,float ceiling=BuffCeiling)
        {
            float defended=Mathf.Max(0,defense);
            float mitigation=Mathf.Min(element==0?.75f:.7f,defended/(defended+100+10*Mathf.Max(1,attackerLevel)));
            return new DamageNumbers(Mathf.Max(0,baseAttack)*Mathf.Max(0,1+additive)*Mathf.Max(0,independent)*Mathf.Max(1,critical),mitigation,Mathf.Clamp(reduction,0,Mathf.Clamp(ceiling,0,1)));
        }
    }
    public static class CombatEffects
    {
        public const int Version=5;
        public static bool Has(EnemyState enemy,StatusKind kind)
        {
            if(enemy==null||enemy.dead)return false;
            if(enemy.boss&&(kind==StatusKind.Root||kind==StatusKind.Stun||kind==StatusKind.Freeze))return false;
            if(enemy.statuses!=null&&enemy.statuses.Any(s=>s.kind==kind&&s.remaining>0))return true;
            switch(kind)
            {case StatusKind.Poisoned:return enemy.poison>0;case StatusKind.Slow:return enemy.slow>0;case StatusKind.Root:return enemy.root>0;case StatusKind.Stun:return enemy.stun>0;case StatusKind.Freeze:return enemy.freeze>0;case StatusKind.Mark:return enemy.mark>0;default:return false;}
        }
        public static bool OwnTrapPoison(EnemyState enemy,string caster)
            =>enemy!=null&&!enemy.dead&&enemy.statuses!=null&&enemy.statuses.Any(s=>s.remaining>0&&s.kind==StatusKind.Poisoned&&s.casterId==caster&&(s.definitionId=="A03"||s.definitionId=="LA03"));
        public static float Remaining(EnemyState enemy,StatusKind kind)
        {
            if(enemy.boss&&(kind==StatusKind.Root||kind==StatusKind.Stun||kind==StatusKind.Freeze))return 0;
            float legacy=kind==StatusKind.Poisoned?enemy.poison:kind==StatusKind.Slow?enemy.slow:kind==StatusKind.Root?enemy.root:kind==StatusKind.Stun?enemy.stun:kind==StatusKind.Freeze?enemy.freeze:enemy.mark;
            return Mathf.Max(0,Mathf.Max(legacy,enemy.statuses.Where(s=>s.kind==kind).Select(s=>s.remaining).DefaultIfEmpty(0).Max()));
        }
        public static void Normalize(RunState run)
        {
            if(run.effectVersion>Version)throw new NotSupportedException("더 새로운 전투 효과 버전이 필요합니다. 저장 파일은 보존했습니다.");
            run.shields??=new List<ShieldEffect>();run.effectEvents??=new List<EffectEvent>();run.damageEvents??=new List<DamageEvent>();
            // A run saved before the sheet existed carries no stream of its own; derive one from
            // the seed it already has so that two runs of the same seed still roll alike.
            if(run.sheetRng==0)run.sheetRng=run.rng*2654435761u+2654435769u|1u;
            run.procHits??=new List<ProcReceipt>();
            run.enemies??=new List<EnemyState>();run.itemEffects??=new CombatEffectState();
            foreach(var enemy in run.enemies)
            {enemy.statuses??=new List<StatusEffect>();enemy.bossControl??=new BossControlState();enemy.bossControl.credited??=new List<string>();}
            if(run.effectVersion==0)
            {
                if(run.shield>0&&run.shieldTime>0&&run.shields.Count==0)
                    run.shields.Add(new ShieldEffect{id=run.nextId++,definitionId="LEGACY_SHIELD",remaining=run.shieldTime,amount=run.shield});
                // The old field was shared by LW04 and LC02; retain its remaining restriction for both.
                run.itemEffects.lw04Cooldown=Mathf.Max(run.itemEffects.lw04Cooldown,run.itemEffects.procCooldown);
            }
            if(run.effectVersion<2)
            {
                var fx=run.itemEffects;var a=run.heroAction;
                if(fx.reducedNext)fx.lc02Charge=5;
                if(!a.released)
                {
                    if(a.phase==HeroActionPhase.Travelling)
                    {
                        a.travelStarted=true;a.legacyRetreatTrapOnLanding=a.skill==9;
                        if(a.skill==1&&fx.whirlwindCharge>0){a.whirlwindReserved=true;fx.whirlwindCharge=0;}
                    }
                    if(a.phase==HeroActionPhase.Preparing)
                    {
                        if(a.skill==2&&fx.crushCharge>0){a.crushBonus=true;fx.crushCharge=0;}
                        if(a.skill==6&&fx.pierceCharge>0){a.pierceBonus=true;fx.pierceCharge=0;}
                        if(a.skill==14&&fx.chainCharge>0&&fx.chainCharges>0){a.chainBonus=2;fx.chainCharges--;}
                    }
                }
            }
            if(run.effectVersion<3)foreach(var enemy in run.enemies.Where(e=>e.boss))MigrateBossControl(run,enemy);
            if(run.effectVersion<4)
            {
                foreach(var enemy in run.enemies)
                {
                    if(enemy.setPoisonTime>0&&string.IsNullOrEmpty(enemy.setPoisonCasterId))enemy.setPoisonCasterId=run.heroId;
                    if(enemy.frostMarkTime>0){enemy.frostCasterId=run.heroId;if(enemy.frostMarkId==0)enemy.frostMarkId=run.nextId++;}
                }
                foreach(var fx in run.effects.Where(f=>!f.hostile&&f.kind==13&&string.IsNullOrEmpty(f.casterId)))fx.casterId=run.heroId;
                foreach(var enemy in run.enemies)foreach(var status in enemy.statuses.Where(s=>s.definitionId=="M02"&&s.areaId==0&&s.casterId==run.heroId))
                {var area=run.effects.Find(f=>!f.hostile&&f.kind==13&&f.rootCastId==status.rootCastId);if(area!=null)status.areaId=area.id;}
            }
            if(run.itemEffects.elementHitTicks==null||run.itemEffects.elementHitTicks.Length!=6)
                run.itemEffects.elementHitTicks=new[]{-1000000,-1000000,-1000000,-1000000,-1000000,-1000000};
            if(run.effectVersion<5)
            {
                var passive=run.itemEffects;Array.Fill(passive.elementHitTicks,-1000000);
                if(passive.lastElement>=0&&passive.lastElement<6&&passive.lastElementTime<=run.time)
                    passive.elementHitTicks[passive.lastElement]=Mathf.RoundToInt(passive.lastElementTime/CombatSimulation.Step);
            }
            run.effectVersion=Version;
            foreach(var trap in run.traps)
            {if(string.IsNullOrEmpty(trap.definitionId))trap.definitionId=trap.duration<5?"LA03":"A03";if(string.IsNullOrEmpty(trap.casterId))trap.casterId=run.heroId;}
        }
        static void MigrateBossControl(RunState run,EnemyState enemy)
        {
            var control=enemy.bossControl;
            float credit=10*(Mathf.Max(0,enemy.stun)+Mathf.Max(0,enemy.freeze)+Mathf.Max(0,enemy.root));
            foreach(var status in enemy.statuses.Where(s=>s.kind==StatusKind.Root||s.kind==StatusKind.Stun||s.kind==StatusKind.Freeze))
            {
                string key=status.rootCastId+":"+status.definitionId;
                if(control.credited.Contains(key))continue;
                control.credited.Add(key);credit+=Mathf.Max(0,status.remaining)*10;
            }
            enemy.stun=enemy.freeze=enemy.root=0;
            enemy.statuses.RemoveAll(s=>s.kind==StatusKind.Root||s.kind==StatusKind.Stun||s.kind==StatusKind.Freeze);
            if(enemy.slow>0)
                enemy.statuses.Add(new StatusEffect{id=run.nextId++,targetId=enemy.id,definitionId="LEGACY_SLOW",casterId="LEGACY",kind=StatusKind.Slow,remaining=enemy.slow,strength=.35f});
            enemy.slow=0;
            // Original durations/cast identities are unavailable in scalar saves; only remaining control is converted once.
            if(enemy.dead||credit<=0||control.staggered>0||control.immunity>0)return;
            control.meter=Mathf.Min(100,control.meter+credit);
            if(control.meter>=100-.0001f)
            {control.meter=0;control.staggered=3;if(enemy.windup>0){enemy.windup=0;enemy.cooldown=Mathf.Max(6,enemy.cooldown);}}
            run.effectEvents.Add(new EffectEvent{definitionId="LEGACY_BOSS_CONTROL",kind="MIGRATED",targetId=enemy.id,time=run.time,tick=Mathf.RoundToInt(run.time/CombatSimulation.Step),value=credit});
        }
    }
}
