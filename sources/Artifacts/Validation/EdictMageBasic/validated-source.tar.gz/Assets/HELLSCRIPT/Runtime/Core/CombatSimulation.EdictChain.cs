using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        EdictAimPlan PlanEdictChain(HuntEdictV2Document document,EnemyState globalTarget,EnemyState[] seen)
        {
            string V(int n)=>HuntEdictV2.Value(document,"M03",n);
            bool Preferred(EnemyState enemy)=>V(3)=="ELITE"?(enemy.boss||enemy.elite>=0):V(3)=="SUPPORT"&&enemy.kind%6==4;
            float TieDistance(EnemyState enemy)=>(enemy.position-(globalTarget?.position??State.position)).sqrMagnitude;
            var eligible=seen.Where(EdictTargetEligible).ToArray();
            var possible=eligible.Where(e=>ChainFirstTargetValid(State.position,e)).ToArray();
            if(possible.Length==0)
            {
                var approach=eligible.OrderBy(e=>Preferred(e)?0:1).ThenBy(TieDistance).ThenBy(e=>e.id).FirstOrDefault();
                if(approach==null)return new EdictAimPlan(true,false,"연쇄 번개의 유효한 첫 대상이 없습니다.",null,-1,"NO_TARGET");
                return new EdictAimPlan(true,false,Loc.F("스킬 사거리 {0}m 밖",catalog.skills[14].range),null,approach.id,"RANGE");
            }
            var preferred=possible.Where(Preferred).ToArray();if(preferred.Length>0)possible=preferred;
            bool total=V(4)=="TOTAL_HITS"&&Stats.specials.Contains("LM04");
            var rule=EdictRuleOrder.ChainRule();
            var forecasts=possible.Select(e=>(target:e,forecast:ForecastAttack(rule,e,observed:seen))).ToArray();
            var chosen=forecasts.OrderByDescending(f=>total?f.forecast.TotalHits:f.forecast.uniqueTargets)
                .ThenBy(f=>TieDistance(f.target)).ThenBy(f=>f.target.id).First();
            bool expiring=Stats.SetPieces("SMB")>=4&&ItemEffects.chainCharges>0&&ItemEffects.chainCharge>0&&ItemEffects.chainCharge<=1+.00001f;
            int required=V(2)=="SINGLE"||V(2)=="SAVE_CHARGE"&&expiring?1:2;
            if(chosen.forecast.uniqueTargets<required)
                return new EdictAimPlan(true,false,"선택한 방식에 필요한 고유 연결 대상이 부족합니다.",chosen.forecast,chosen.target.id);
            string reason=V(4)=="TOTAL_HITS"&&!total?"LM04가 없어 고유 대상 수로 판단합니다.":
                V(2)=="SAVE_CHARGE"&&Stats.SetPieces("SMB")<4?"SMB 4세트가 없어 연결되는 적 위주로 판단합니다.":"첫 대상별 실제 연결 규칙을 비교했습니다.";
            return new EdictAimPlan(true,true,reason,chosen.forecast,chosen.target.id);
        }
    }
}
