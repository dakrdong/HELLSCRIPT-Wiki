using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Opt-in native UI/save evidence. Enemy positions and simulation time are controlled fixtures;
    // option edits, saving, drawing and resuming use the actual player code.
    public sealed class RuntimeNovaSmoke:MonoBehaviour
    {
        GameController game;
        string directory,saveDirectory;
        int capture;
        readonly List<string> failures=new List<string>();
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if(!Debug.isDebugBuild||!Environment.GetCommandLineArgs().Contains("-hellscriptNovaEdictSmoke"))return;
            Application.runInBackground=true;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Nova edict validation").AddComponent<RuntimeNovaSmoke>();
        }
        static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
        void Check(bool condition,string message){if(!condition)failures.Add(message);}
        static string Json(object value)=>JsonUtility.ToJson(value);
        Button[] Buttons=>game.UI.GetComponentsInChildren<Button>();
        void Click(string name){var b=Buttons.Single(b=>b.name==name);Require(b.IsInteractable(),"Disabled: "+name);b.onClick.Invoke();}
        void Choice(string label){var b=Buttons.Single(b=>b.name.Contains(label));Require(b.IsInteractable(),"Disabled: "+label);b.onClick.Invoke();}
        void Skills(string skill="서리 폭발"){game.UI.ShowEdictEditor();Click("스킬 설정");Click(skill);}
        string[] Lines()=>game.UI.GetComponentsInChildren<Text>().Select(t=>t.text).ToArray();
        static int Starts(CombatSimulation sim)=>sim.State.statistics.skills.SingleOrDefault(s=>s.definitionId=="M06")?.starts??0;
        void Advance(int ticks)
        {game.Combat.State.paused=false;for(int i=0;i<ticks;i++)game.Combat.Tick(CombatSimulation.Step);game.World.Present(game.Combat.State,.05f);game.UI.RefreshHud();}
        void Enemy(float x,float y,int kind=0,int elite=-1)
        {
            var run=game.Combat.State;
            run.enemies.Add(new EnemyState{id=900+run.enemies.Count,kind=kind,elite=elite,position=run.position+new Vector2(x,y),health=1000000,maxHealth=1000000,speed=0,attack=0,cooldown=1000});
        }
        IEnumerator Capture(string name,int width,int height,string focus=null)
        {
            Screen.SetResolution(width,height,FullScreenMode.Windowed);float deadline=Time.realtimeSinceStartup+6;
            while((Screen.width!=width||Screen.height!=height)&&Time.realtimeSinceStartup<deadline)yield return null;
            Require(Screen.width==width&&Screen.height==height,"Native resize failed: "+name);
            yield return new WaitForSecondsRealtime(.3f);
            if(focus!=null)
            {
                var line=game.UI.GetComponentsInChildren<Text>().First(t=>t.text.Contains(focus));
                DialogReadingAnchor.Show(line.rectTransform);yield return new WaitForSecondsRealtime(.2f);
            }
            Canvas.ForceUpdateCanvases();
            foreach(var line in game.UI.GetComponentsInChildren<Text>())
                Check(line.preferredHeight<=line.rectTransform.rect.height+1,"Clipped on "+name+": "+line.text);
            var safe=UiSafeArea.Current;var corners=new Vector3[4];
            foreach(var button in Buttons.Where(b=>b.transform.parent.name=="Footer"))
            {((RectTransform)button.transform).GetWorldCorners(corners);Check(corners.All(c=>c.x>=safe.xMin-1&&c.x<=safe.xMax+1&&c.y>=safe.yMin-1&&c.y<=safe.yMax+1),"Footer outside safe area: "+name+" / "+button.name);}
            var missing=Loc.Missing.Where(key=>!LanguageOptions.All.Any(o=>o.NativeName==key)).ToArray();
            Check(missing.Length==0,"Missing translation: "+string.Join("; ",missing));
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,$"{++capture:00}-{name}.png"));yield return new WaitForSecondsRealtime(.2f);
        }
        static void Controlled(CombatSimulation sim)
        {
            sim.Stats.armor=sim.Stats.resistance=sim.Stats.regen=sim.Stats.crit=sim.Stats.costReduction=0;
            for(int i=(int)StatId.VulnerableDamage;i<StatCatalog.Count;i++)sim.Stats.bonuses[i]=0;
            sim.Stats.dodge=sim.Stats.blockChance=sim.Stats.blockedReduction=sim.Stats.lifeRegen=sim.Stats.damageReduction=sim.Stats.closeReduction=sim.Stats.distantReduction=sim.Stats.injuredReduction=sim.Stats.physicalReduction=0;
        }
        void Finish(string stage,string detail)
        {
            string result=failures.Count==0?"PASS: "+detail+" Controlled native UI/combat fixtures; not mobile-device or natural-play balance validation.":string.Join("\n",failures);
            File.WriteAllText(Path.Combine(directory,stage+"-result.txt"),result+"\n");Debug.Log(failures.Count==0?"HELLSCRIPT_NOVA_"+stage.ToUpperInvariant()+"_OK":"HELLSCRIPT_NOVA_RUNTIME_FAIL\n"+result);Application.Quit(failures.Count==0?0:1);
        }
        void SaveCheckpoint(string name)
        {var run=game.Combat.State;run.training=-1;run.paused=false;game.Save();File.WriteAllText(Path.Combine(directory,name),Json(run));}
        CombatSimulation Restored(string name)
        {
            Require(game.Store.Data.suspendedRun!=null,"The saved pending battle was lost.");game.Begin(resume:true);
            Require(game.Combat!=null,"The saved battle did not restore.");var sim=game.Combat;var expected=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(directory,name)));
            Require(sim.State.time==expected.time&&sim.State.resource==expected.resource&&Json(sim.State.heroAction)==Json(expected.heroAction),"The committed action, time or resource changed on restart.");
            Require(Json(sim.State.itemEffects)==Json(expected.itemEffects),"Item charges or elemental history changed on restart.");Controlled(sim);return sim;
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();int save=Array.IndexOf(args,"-hellscriptSavePath"),outIndex=Array.IndexOf(args,"-hellscriptScreenshots");
            Require(save>=0&&save+1<args.Length&&outIndex>=0&&outIndex+1<args.Length,"Use dedicated save and evidence paths.");
            saveDirectory=args[save+1];directory=args[outIndex+1];Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1);game=FindAnyObjectByType<GameController>();Require(game?.Store!=null,"Store unavailable.");game.enabled=false;
            if(args.Contains("-hellscriptNovaChainResume")){yield return ChainResume();yield break;}
            if(args.Contains("-hellscriptNovaEdictResume")){yield return Resume();yield break;}
            Require(game.Store.Data.heroes.All(h=>h.level==1)&&game.Store.Data.suspendedRun==null,"Use a fresh test account.");
            game.SelectHero(2);var hero=game.Store.Data.Hero;hero.level=30;hero.inventory.Clear();game.Store.Data.guide.hintsHidden=true;
            hero.build.activeSkills=new List<int>{17,14};hero.build.passives=new[]{5};hero.build.autoRepeat=false;
            hero.build.rules=new List<Rule>{BehaviorRules.Make(17,BehaviorRules.C("SC06",Comparison.AtLeast,99,predicted:true)),BehaviorRules.Make(14,BehaviorRules.C("SC06",Comparison.AtLeast,99,predicted:true))};
            uint rng=176031;
            foreach(string id in new[]{"SMB1","SMB2","SMB3","SMB4","LC02"})
            {var item=ItemGenerator.Create(HeroClass.Mage,ItemCatalog.Unique(id).slot,3,30,ref rng,uniqueId:id);hero.inventory.Add(item);Require(Economy.Equip(hero,item),"Could not equip "+id);}
            hero.edict=HuntEdictV2.WithOption(HuntEdictV2Storage.CreateForHero(hero),"BASIC",1,"OFF");
            foreach(var p in new[]{("position.mode","STAND"),("survival.potion","OFF"),("survival.lowHp","OFF"),("survival.lethal","OFF")})hero.edict=HuntEdictV2Editing.WithGlobal(hero.edict,p.Item1,p.Item2);
            game.Save();string original=Json(hero.edict);Skills();
            yield return Capture("options-ko",1280,720,"자동 사용");game.ApplyLanguage("en");yield return Capture("options-en",1280,720,"Automatic use");game.ApplyInterfaceScale(140);
            yield return Capture("options-large-en",720,1280,"Checks actual targets");yield return Capture("options-small-en",640,360,"Checks actual targets");
            game.ApplyLanguage("ko");yield return Capture("options-large-ko",720,1280,"보스에게 사용");game.ApplyInterfaceScale(100);
            Choice("사용 목적");Choice("사용 목적");Choice("시전 위치");Choice("시전 위치");Choice("보스에게 사용");Choice("보스에게 사용");Choice("보스에게 사용");
            Require(Json(hero.edict)==original,"The editor draft changed the saved source.");Click("저장 및 적용");
            Require(HuntEdictV2.Value(hero.edict,"M06",2)=="CHAIN_CHARGE"&&HuntEdictV2.Value(hero.edict,"M06",3)=="HERE"&&HuntEdictV2.Value(hero.edict,"M06",4)=="PURPOSE","The four policies did not save.");
            Require(Json(new GameStore(saveDirectory,game.catalog).Data.Hero.edict)==Json(hero.edict),"Fresh file read disagrees with the applied edict.");Click("공유");Click("사냥 칙령 v0.2 사용하기");
            game.BeginDeveloperTraining(1);var sim=game.Combat;Require(sim?.EdictActive==true,"Training edict unavailable.");Controlled(sim);
            sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();sim.State.exploration.enemies.Clear();Enemy(0,2);Enemy(1,1);sim.State.resource=100;sim.State.cooldowns[14]=1000;
            sim.State.itemEffects.lc02Charge=5;sim.State.itemEffects.reducedNext=true;game.World.BuildDungeon(sim.State);Advance(1);
            Require(sim.State.heroAction.skill==17&&sim.State.heroAction.phase==HeroActionPhase.Preparing,"Nova did not prepare independently of its blocked legacy row.");
            Require(sim.State.heroAction.cost==10&&sim.State.resource==90&&!sim.State.itemEffects.reducedNext&&sim.State.itemEffects.chainCharges==0,"The discounted cost or pre-hit charge state is wrong.");
            int action=sim.State.heroAction.id;Skills();Choice("사용 목적");Choice("시전 위치");Choice("보스에게 사용");Choice("보스에게 사용");Choice("자동 사용");Click("저장 및 적용");
            Skills("연쇄 번개");Choice("자동 사용");Click("저장 및 적용");Require(sim.State.heroAction.id==action,"Option edits replaced the committed Nova.");
            game.UI.ShowBattle();yield return Capture("preparation-before-restart",1280,720);SaveCheckpoint("expected-nova-run.json");
            Finish("checkpoint","Actual UI edited all M06 options and saved an isolated draft. A real LC02 charge paid 10 resource for Nova despite blocked legacy rows. CONTROL/APPROACH/HOLD_ALONE/OFF and M03 OFF edits retained the committed preparation.");
        }
        IEnumerator Resume()
        {
            var sim=Restored("expected-nova-run.json");Require(sim.State.heroAction.skill==17&&!HuntEdictV2.Automatic(sim.Hero.edict,"M06"),"Expected a committed disabled Nova.");
            int action=sim.State.heroAction.id;Advance(12);
            Require(Starts(sim)==1&&sim.State.actionEvents.Count(a=>a.actionId==action&&a.kind=="ACTION_RELEASE")==1&&sim.State.resource==90,"Nova did not release exactly once at the saved cost.");
            Require(sim.State.itemEffects.chainCharges==2&&sim.State.itemEffects.chainCharge>0&&sim.State.itemEffects.elementBuff==0,"Real Nova hits did not grant exactly two charges or incorrectly granted MP06 for only one element.");
            Require(sim.State.enemies.All(e=>CombatEffects.Has(e,StatusKind.Freeze))&&sim.State.damageEvents.Count(d=>!d.incoming&&d.definitionId=="M06")==2,"Actual cold damage and freeze do not match the local area.");
            game.UI.ShowBattle();yield return Capture("nova-after-restart",1280,720);game.UI.ShowCombatEffects();game.ApplyLanguage("en");game.ApplyInterfaceScale(140);
            yield return Capture("charges-after-restart-en",720,1280);Click("전투로 돌아가기");Check(!sim.State.paused,"The effects screen did not restore a running battle.");game.ApplyInterfaceScale(100);game.ApplyLanguage("ko");
            game.UI.ShowRuleDecisions();yield return Capture("decisions-after-restart-ko",1280,720);Click("전투로 돌아가기");
            Skills("연쇄 번개");Choice("자동 사용");Click("저장 및 적용");sim.State.cooldowns[14]=0;sim.State.decisionTime=0;Advance(1);
            Require(sim.State.heroAction.skill==14&&sim.State.heroAction.chainBonus==2&&sim.State.itemEffects.chainCharges==1,"The ordinary chain decision did not reserve one of Nova's real charges.");
            Require(Mathf.Abs(sim.State.heroAction.cost-21.25f)<.001f&&Mathf.Abs(sim.State.resource-68.75f)<.001f,"The subsequent chain did not pay its actual SMB2 cost.");
            Skills("연쇄 번개");Choice("자동 사용");Click("저장 및 적용");game.ApplyLanguage("en");game.UI.ShowBattle();yield return Capture("chain-preparation-before-restart",1280,720);
            SaveCheckpoint("expected-chain-run.json");Finish("resume","Independent restart released one Nova, dealt actual cold damage, froze two targets and granted two SMB4 charges. The ordinary M03 decision paid 21.25 resource and reserved one charge; its preparation was saved with automatic use disabled.");
        }
        IEnumerator ChainResume()
        {
            var sim=Restored("expected-chain-run.json");Require(sim.State.heroAction.skill==14&&sim.State.heroAction.chainBonus==2,"The reserved chain was not restored.");
            for(int i=0;i<40&&!sim.State.damageEvents.Any(d=>d.definitionId=="M03");i++)Advance(1);
            Require(sim.State.damageEvents.Any(d=>d.definitionId=="M03")&&sim.State.itemEffects.elementBuff>0,"Actual lightning after cold did not activate MP06.");
            Require(Mathf.Abs(sim.State.resource-68.75f)<.001f&&sim.State.itemEffects.chainCharges==1,"Restoration charged the chain twice or consumed a second charge.");
            Require(sim.State.effectEvents.Count(e=>e.definitionId=="LC02"&&e.kind=="CONSUMED")==1&&sim.State.effectEvents.Count(e=>e.definitionId=="SMB4"&&e.kind=="RESERVED")==1,"Cost or set effects replayed.");
            game.UI.ShowCombatEffects();game.ApplyLanguage("en");game.ApplyInterfaceScale(140);yield return Capture("element-cycle-after-chain-restart",720,1280);Click("전투로 돌아가기");game.ApplyLanguage("ko");game.ApplyInterfaceScale(100);
            for(int i=0;i<30&&sim.HeroActionBusy;i++)Advance(1);Require(!sim.HeroActionBusy,"The saved chain never completed.");
            sim.State.enemies.Clear();sim.State.exploration.enemies.Clear();Enemy(0,6);Enemy(1,6);sim.State.resource=100;sim.State.cooldowns[17]=0;
            Skills();Choice("사용 목적");Choice("자동 사용");Click("저장 및 적용");Require(HuntEdictV2.Value(sim.Hero.edict,"M06",2)=="GROUP"&&HuntEdictV2.Value(sim.Hero.edict,"M06",3)=="APPROACH","Approach policies did not apply.");
            game.World.BuildDungeon(sim.State);game.UI.ShowBattle();Vector2 origin=sim.State.position;sim.State.decisionTime=0;Advance(1);
            Require(Starts(sim)==1&&sim.State.resource==100&&Vector2.Distance(origin,sim.State.position)>0,"Approach did not walk without paying or cast outside range.");
            yield return Capture("approach-without-cost-ko",1280,720);
            for(int i=0;i<120&&Starts(sim)<2;i++)Advance(1);Require(Starts(sim)==2&&sim.State.enemies.All(e=>Vector2.Distance(e.position,sim.State.position)<=3),"Approach did not enter the actual area before preparing.");
            Require(sim.State.resource==80,"The approached Nova did not pay its ordinary cost once.");Advance(12);yield return Capture("nova-after-approach-ko",1280,720);
            Require(Starts(sim)==2&&sim.State.actionEvents.Count(a=>a.skill==14&&a.kind=="ACTION_START")==1,"A follow-up skill was forced or a committed action replayed.");
            File.WriteAllText(Path.Combine(directory,"final-run.json"),Json(sim.State));Finish("chain","A second independent restart retained Nova-generated charges, the paid chain and its reserved bonus. Actual lightning activated MP06 after cold without duplicate payment. Actual UI then enabled GROUP/APPROACH; walking spent nothing and Nova paid once after entering 3m, with no forced follow-up.");
        }
    }
}
