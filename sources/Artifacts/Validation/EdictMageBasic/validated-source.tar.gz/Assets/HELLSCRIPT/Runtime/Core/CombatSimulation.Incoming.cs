using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        sealed class ForecastPulse
        {public string key,definition,group;public IncomingCategory category;public IncomingControl control;public int element,phase,order;public float after,damage;}
        sealed class ForecastShield {public int id;public float expires,amount;}
        // Armour answers physical damage and the element's own resistance answers the rest, the
        // split Diablo IV's sheet draws. A forecast has no attacker to measure a distance against,
        // so it sees only the reductions that apply wherever the hero stands.
        DamageNumbers IncomingDamageNumbers(float raw,int element,float? reduction=null)
            =>DamageMath.Calculate(raw,0,1,1,Stats.Resistance(element),Mathf.Min(30,State.stage),element,reduction??IncomingReduction(null,element,false),SheetReductionCeiling);
        static float IncomingTick(float seconds)=>Mathf.Max(Step,Mathf.Ceil((seconds-.00001f)/Step)*Step);
        static float FirstMovementTick(float delay)=>(Mathf.Floor((delay+.00001f)/Step)+1)*Step;
        bool ObservedThreatOrigin(Vector2 origin,float radius=0)=>Vector2.Distance(State.position,origin)<=14+radius&&Map.LineClear(State.position,origin);
        float ObservedEnemyAttack(EnemyState enemy)=>enemy.attack*(1+(Perceived(enemy)?.1f*enemy.brain.rageStacks+(enemy.brain.auraSource>=0?.2f:0):0));

        // Snapshot at a completed simulation tick. Assumes the candidate remains at position;
        // already announced attacks and existing effects only, never future AI decisions.
        public IncomingForecast ForecastIncoming(float seconds=1.5f,Vector2? position=null)
        {
            if(float.IsNaN(seconds)||float.IsInfinity(seconds)||seconds<Step||seconds>10)throw new ArgumentException("피해 예측 시간은 0.05~10초입니다.");
            Vector2 point=position??State.position;if(!Finite(point))throw new ArgumentException("피해 예측 위치가 유효하지 않습니다.");
            var sources=new List<ObservedIncomingSource>();var pulses=new List<ForecastPulse>();int ordinal=0;
            void Source(string key,string definition,IncomingCategory category,float begins,IncomingControl control=IncomingControl.None)
            {if(begins<=seconds+.00001f)sources.Add(new ObservedIncomingSource(key,definition,category,control,Mathf.Max(0,begins)));}
            void Pulse(string key,string definition,IncomingCategory category,float after,float damage,int element,int phase,string group=null,IncomingControl control=IncomingControl.None)
            {
                float time=IncomingTick(after);
                if(time>seconds+.00001f||damage<0||float.IsNaN(damage)||float.IsInfinity(damage))return;
                pulses.Add(new ForecastPulse{key=key,definition=definition,category=category,after=time,damage=damage,element=element,phase=phase,order=ordinal++,group=group,control=control});
            }
            bool Inside(EnemyThreat threat)=>ObservedThreatOrigin(threat.origin,threat.radius)&&EnemyCombat.Contains(threat,point)&&Map.LineClear(threat.origin,point);
            void Area(string key,string definition,EnemyThreat shape,float delay,float duration,float interval,float tick,float damage,int element,int phase)
            {
                if(!Inside(shape)||interval>0&&duration<=0&&tick>0)return;
                var category=interval>0?IncomingCategory.Ground:IncomingCategory.Area;Source(key,definition,category,delay);
                if(interval<=0){Pulse(key,definition,category,delay,damage,element,phase);return;}
                for(float at=Mathf.Max(0,tick);at<=duration+.00001f&&delay+at<=seconds+.00001f;at+=interval)
                    Pulse(key,definition,category,delay+at,damage,element,phase);
            }
            void Projectile(string key,string definition,Vector2 from,Vector2 direction,float range,float radius,float speed,float delay,float damage,int element,string group=null,IncomingControl control=IncomingControl.None)
            {
                if(speed<=0||range<=0||!ObservedThreatOrigin(from,radius))return;
                Vector2 end=ClipProjectile(from,from+direction.normalized*range,radius,out _);float entry=Entry(from,end,point,radius+.45f);
                if(float.IsInfinity(entry))return;
                // Existing delayed arrows need positive movement time; newly released arrows
                // cannot move in the same tick as creation, even if already touching the hero.
                float at=Mathf.Max(FirstMovementTick(delay),delay+Vector2.Distance(from,Vector2.Lerp(from,end,entry))/speed);
                Source(key,definition,IncomingCategory.Direct,at,control);Pulse(key,definition,IncomingCategory.Direct,at,damage,element,1,group,control);
            }
            void Charge(EnemyState enemy,EnemyActionState action,string definition,float preparation)
            {
                if(action.hitHero||!ObservedThreatOrigin(enemy.position,enemy.boss?.95f:1.05f))return;
                Vector2 from=action.phase==EnemyActionPhase.Charging?enemy.position:action.origin;
                float distance=Mathf.Max(0,8-(action.phase==EnemyActionPhase.Charging?action.moved:0));
                Vector2 end=Map.MoveDirect(from,action.aim,Mathf.Min(distance,Vector2.Distance(from,action.aim)),enemy.boss?1.2f:.4f);
                float hit=Entry(from,end,point,enemy.boss?.95f:1.05f);if(float.IsInfinity(hit)||!Map.LineClear(from,point))return;
                float at=Mathf.Max(preparation+Step,preparation+Vector2.Distance(from,Vector2.Lerp(from,end,hit))/(enemy.boss?10:12)),damage=action.phase==EnemyActionPhase.Charging?action.damage:ObservedEnemyAttack(enemy)*1.5f;
                string key="action-"+action.id;Source(key,definition,IncomingCategory.Direct,at);Pulse(key,definition,IncomingCategory.Direct,at,damage,0,0);
            }
            // Existing flight is independent of whether its original caster remains alive/visible.
            foreach(var p in State.projectiles.Where(p=>p.hostile))
            {
                var group=State.projectileGroups.Find(g=>g.actionId==p.actionId);
                if(group!=null&&group.victims.Any(v=>v.id==-1))continue;
                Projectile("projectile-"+p.id,p.definitionId??"ENEMY_ARROW",p.position,p.direction,p.remaining,p.radius,p.speed,Mathf.Max(0,p.delay),p.damage,p.element,
                    group==null?null:"projectile-group-"+p.actionId,p.pullDistance>0?IncomingControl.Pull:IncomingControl.None);
            }
            foreach(var h in State.enemyHazards)
            {
                string key="hazard-"+h.id;float delay=Mathf.Max(0,h.delay);
                if(h.shardBurst)
                {
                    foreach(float angle in new[]{-30f,0,30})Projectile(key,h.definitionId,h.position,EnemyCombat.Rotate(h.direction,angle),8,.2f,12,IncomingTick(delay),h.damage,0,"projectile-group-"+h.actionId);
                }
                else Area(key,h.definitionId,EnemyCombat.HazardThreat(h),delay,Mathf.Max(0,h.duration),h.interval,h.tick,h.damage,h.element,3);
            }
            foreach(var enemy in State.enemies.Where(e=>!e.dead))
            {
                var a=enemy.brain.action;
                if(a.phase==EnemyActionPhase.Idle&&enemy.windup>0)
                {
                    Vector2 direction=(enemy.aim-enemy.position).normalized;if(direction==Vector2.zero)direction=enemy.brain.facing;
                    a=new EnemyActionState{id=-enemy.id-1,kind=enemy.boss?(int)BossAttack.Legacy:enemy.kind,phase=EnemyActionPhase.Preparing,origin=enemy.position,aim=enemy.aim,direction=direction,remaining=enemy.windup};
                    if(!enemy.boss&&(enemy.kind==1||enemy.kind==7))a.aim=Map.MoveDirect(a.origin,a.origin+direction*8,8,.4f);
                }
                if(a.phase==EnemyActionPhase.Idle||a.phase==EnemyActionPhase.Recovering)continue;
                float delay=Mathf.Max(0,a.remaining),attack=ObservedEnemyAttack(enemy);string key="action-"+a.id,definition=EnemyCombat.Id(a.kind);
                if(a.phase==EnemyActionPhase.Charging||!enemy.boss&&(a.kind==1||a.kind==7)||enemy.boss&&a.kind==(int)BossAttack.Charge)
                {Charge(enemy,a,definition,a.phase==EnemyActionPhase.Charging?0:IncomingTick(delay));continue;}
                if(a.phase!=EnemyActionPhase.Preparing)continue;delay=IncomingTick(delay);
                if(enemy.boss)
                {
                    var kind=(BossAttack)a.kind;
                    if(kind==BossAttack.Summon)continue;
                    if(kind==BossAttack.Hook){Projectile(key,definition,a.origin,a.direction,10,.5f,12,delay,attack,0,control:IncomingControl.Pull);continue;}
                    if(kind==BossAttack.Beam)
                    {Area(key,definition,new EnemyThreat(key,definition,AttackShape.Line,a.origin,a.aim,a.direction,.75f),delay,2,.25f,.25f,attack*.375f,5,3);continue;}
                    if(kind==BossAttack.Blasts)
                    {for(int i=0;i<a.points.Count;i++)Area(key+"-"+i,definition,new EnemyThreat(key,definition,AttackShape.Circle,a.points[i],a.points[i],a.direction,2.5f),delay+i*.35f,0,0,0,attack*1.5f,5,i==0?0:3);continue;}
                    if(kind==BossAttack.Legacy)
                    {
                        if(enemy.pattern==1){LegacyGround(key,definition,a.aim,2.5f,0,2,0,attack*1.5f,0,4,point,seconds,Source,Pulse,delay);continue;}
                        if(ObservedThreatOrigin(a.aim,3)&&Vector2.Distance(point,a.aim)<3&&Map.LineClear(a.origin,point))
                        {Source(key,definition,IncomingCategory.Area,delay);Pulse(key,definition,IncomingCategory.Area,delay,attack*2,0,0);}continue;
                    }
                    var shape=new EnemyThreat(key,definition,AttackShape.Sector,a.origin,a.aim,a.direction,kind==BossAttack.Slam?4:3);
                    Area(key,definition,shape,delay,0,0,0,attack*(kind==BossAttack.Slam?2:1),0,0);
                    if(kind==BossAttack.Slam&&a.remainingCharges>1)Area(key+"-followup",definition,shape,delay+.7f,0,0,0,attack*2,0,0);
                }
                else if(a.kind==4||a.kind==10)continue;
                else if(a.kind==2||a.kind==8)
                {
                    foreach(float angle in a.kind==8?new[]{-10f,0,10}:new[]{0f})Projectile(key,definition,a.origin,EnemyCombat.Rotate(a.direction,angle),9,.2f,10,delay,attack,0,a.kind==8?"projectile-group-"+a.id:null);
                }
                else if(a.kind==3||a.kind==9)
                    Area(key,definition,new EnemyThreat(key,definition,AttackShape.Circle,a.aim,a.aim,a.direction,2.5f),delay,a.kind==3?4:3,.5f,.5f,attack*(a.kind==3?.25f:.3f),a.kind==3?4:1,3);
                else Area(key,definition,new EnemyThreat(key,definition,AttackShape.Sector,a.origin,a.aim,a.direction,2.5f),delay,0,0,0,attack,0,0);
            }
            foreach(var f in State.effects.Where(f=>f.hostile&&f.duration>0))
                LegacyGround("ground-"+f.id,f.definitionId??"ENEMY_GROUND",f.position,f.radius,Mathf.Max(0,f.delay),f.duration,f.tick,f.damage,f.element,f.kind,point,seconds,Source,Pulse);
            var shields=State.shields.Where(s=>s.amount>0&&s.remaining>0).Select(s=>new ForecastShield{id=s.id,amount=s.amount,expires=s.remaining}).OrderBy(s=>s.expires).ThenBy(s=>s.id).ToArray();
            var hits=new List<ObservedIncomingHit>();var groups=new HashSet<string>();
            int elapsedTicks=0;float remainingLeap=leapDefense,remainingShrine=State.resolveShrineTime;
            foreach(var p in pulses.OrderBy(p=>p.after).ThenBy(p=>p.phase).ThenBy(p=>p.order))
            {
                if(p.group!=null&&!groups.Add(p.group))continue;
                // Tick copies in the actual timer order. A single duration subtraction can
                // disagree at a float boundary with repeated fixed-step expiry in the live run.
                int tick=Mathf.RoundToInt(p.after/Step);
                for(;elapsedTicks<tick;elapsedTicks++)
                {
                    remainingShrine=Mathf.Max(0,remainingShrine-Step);
                    remainingLeap=Mathf.Max(0,remainingLeap-Step);if(remainingLeap<=.00001f)remainingLeap=0;
                    foreach(var shield in shields)shield.expires=Mathf.Max(0,shield.expires-Step);
                }
                float reduction=Mathf.Min(.5f,(remainingLeap>0?.15f:0)+(remainingShrine>0?.1f:0));
                float final=IncomingDamageNumbers(p.damage,p.element,reduction).final,remaining=final;
                foreach(var shield in shields)
                {
                    if(shield.expires<=.00001f||shield.amount<=0)continue;
                    float absorbed=Mathf.Min(shield.amount,remaining);shield.amount-=absorbed;remaining-=absorbed;if(remaining<=0)break;
                }
                hits.Add(new ObservedIncomingHit(p.key,p.definition,p.category,p.control,p.element,p.after,p.damage,final,final-remaining));
            }
            return new IncomingForecast(point,seconds,sources.GroupBy(s=>s.key).Select(g=>g.OrderBy(s=>s.begins).First()).OrderBy(s=>s.begins).ThenBy(s=>s.key,StringComparer.Ordinal),hits);
        }
        void LegacyGround(string key,string definition,Vector2 origin,float radius,float delay,float duration,float tick,float damage,int element,int kind,Vector2 point,float seconds,
            Action<string,string,IncomingCategory,float,IncomingControl> source,
            Action<string,string,IncomingCategory,float,float,int,int,string,IncomingControl> pulse,float bornAfter=0)
        {
            float distance=Vector2.Distance(origin,point);
            if(!ObservedThreatOrigin(origin,radius)||distance>=radius||kind==6&&distance<=2)return;
            var category=duration<=.11f?IncomingCategory.Area:IncomingCategory.Ground;source(key,definition,category,bornAfter+delay,IncomingControl.None);
            // Legacy ground updates full fixed steps after its delay. Preserve the stored final
            // pulse rule rather than silently replacing old effects with the new hazard timing.
            float remainingDelay=delay,remaining=duration,next=tick;
            for(float after=Step;after<=seconds+.00001f&&remaining>0;after+=Step)
            {
                if(after<=bornAfter+.00001f)continue;
                remainingDelay-=Step;if(remainingDelay>.0001f)continue;remaining-=Step;next-=Step;
                if(next<=.00001f){next+=.5f;pulse(key,definition,category,after,remaining<.11f&&kind!=8?damage:damage*.5f,element,2,null,IncomingControl.None);}
            }
        }
    }
}
