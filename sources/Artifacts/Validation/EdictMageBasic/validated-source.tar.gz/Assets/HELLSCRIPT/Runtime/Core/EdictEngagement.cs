using System;

namespace Hellscript
{
    // Per-run opening opportunity. It survives UI edits and independent process restoration.
    [Serializable] public sealed class EdictEngagementState
    {
        public int version=1;
        public string heroId,runId;
        public bool active,openingChecked;
        public static void Normalize(RunState run)
        {
            var s=run.edictEngagement;
            if(s==null)return;
            if(s!=null&&s.version>1)throw new NotSupportedException("더 새로운 교전 시작 상태 버전이 필요합니다. 저장 파일은 보존했습니다.");
            if(s.heroId!=run.heroId||s.runId!=run.id)run.edictEngagement=null;
            else s.version=1;
        }
    }
}
