using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        IEnumerable<Vector2> EdictDirections(int skill,EnemyState target,EnemyState[] seen)
        {
            // Test circle/cone boundaries and the intervals between them. This includes rays
            // between enemies, which aiming only at enemy centers cannot represent.
            var angles=new List<float>();
            void Add(float value)=>angles.Add(Mathf.Repeat(value,360));
            foreach(var enemy in seen)
            {
                Vector2 offset=enemy.position-State.position;float center=Mathf.Atan2(offset.y,offset.x)*Mathf.Rad2Deg;
                float half=skill==2?50:Mathf.Asin(Mathf.Min(1,((skill==6?.3f:.2f)+(enemy.boss?1.2f:.4f))/Mathf.Max(.0001f,offset.magnitude)))*Mathf.Rad2Deg;
                float spread=MultiShotHalfAngle(Stats.specials.Contains("LA02"));
                foreach(float ray in skill==7?new[]{-spread,0,spread}:new[]{0f})
                {Add(center-ray);Add(center-half-ray);Add(center+half-ray);}
            }
            var boundaries=angles.Distinct().OrderBy(a=>a).ToArray();
            for(int i=0;i<boundaries.Length;i++)
            {float a=boundaries[i],b=i+1<boundaries.Length?boundaries[i+1]:boundaries[0]+360;Add(a-.001f);Add(a+.001f);Add((a+b)*.5f);}
            foreach(float a in angles.Distinct().OrderBy(a=>a))yield return State.position+new Vector2(Mathf.Cos(a*Mathf.Deg2Rad),Mathf.Sin(a*Mathf.Deg2Rad))*catalog.skills[skill].range;
            yield return target.position;
        }

        // A fixed-policy aiming stage. The caller supplies the global target after the common
        // target/tracking policy. "available" means an aim meets this skill's purpose, not that
        // cooldown, cost, emergency priority, movement or the action lock authorizes a cast.
        public EdictAimPlan PlanEdictAim(HuntEdictV2Document source,string skillId,EnemyState globalTarget)
        {
            var d=HuntEdictV2.Canonical(source);HuntEdictV2.ValidateReceiver(d,Hero,catalog);
            EdictAimPlan No(string reason,bool supported=true)=>new EdictAimPlan(supported,false,reason,null);
            if(skillId=="BASIC"&&d.heroClass=="MAGE")return PlanEdictMageBasic(d,globalTarget,ForecastSeen());
            if(!new[]{"W03","A01","A02","M01","M02","M03"}.Contains(skillId))return No("이 스킬의 핵심 조준 판단은 아직 연결하지 않았습니다.",false);
            if(!HuntEdict.SkillIds(d.heroClass).Contains(skillId))throw new ArgumentException("다른 직업의 조준 요청입니다.");
            int index=catalog.skills.FindIndex(s=>s.id==skillId);string V(int n)=>HuntEdictV2.Value(d,skillId,n);
            if(!d.slots.Contains(skillId)||catalog.skills[index].unlock>EffectiveLevel)return No("미장착 또는 미해금 스킬입니다.");
            if(V(1)!="ON")return No("자동 사용을 껐습니다.");
            var seen=ForecastSeen();globalTarget=globalTarget==null?null:seen.FirstOrDefault(e=>e.id==globalTarget.id);
            if(skillId=="M01")return PlanEdictFireball(d,globalTarget,seen);
            if(skillId=="M02")return PlanEdictBlizzard(d,globalTarget,seen);
            if(skillId=="M03")return PlanEdictChain(d,globalTarget,seen);
            var current=seen.FirstOrDefault(e=>e.id==State.targetId);
            var rule=BehaviorRules.Make(index);
            EnemyState Pick(IEnumerable<EnemyState> candidates)=>candidates.OrderBy(e=>e==globalTarget?0:1).ThenBy(e=>(e.position-State.position).sqrMagnitude).ThenBy(e=>e.id).FirstOrDefault();
            EnemyState target=globalTarget??Pick(seen);
            bool Elite(EnemyState e)=>e.boss||e.elite>=0;
            string mode=V(skillId=="W03"?2:3);
            if(mode=="CURRENT"&&current!=null)target=current;
            else if(mode=="ELITE")target=Pick(seen.Where(Elite))??target;
            else if(mode=="LOW_HP")target=seen.OrderBy(e=>e.health/Mathf.Max(.0001f,e.maxHealth)).ThenBy(e=>(e.position-State.position).sqrMagnitude).ThenBy(e=>e.id).FirstOrDefault();
            else if(mode=="OWN_POISON")target=Pick(seen.Where(e=>CombatEffects.OwnTrapPoison(e,State.heroId)))??target;
            if(target==null)return No("현재 감지한 대상이 없습니다.");
            if(Vector2.Distance(State.position,target.position)>catalog.skills[index].range+.0001f)return No("선택 대상이 스킬 사거리 밖에 있습니다.");
            if(skillId=="A02"&&(V(2)=="FOCUS"||V(4)=="FOCUS")&&!Stats.specials.Contains("LA02"))return No("선택한 집중 사격에는 LA02 장착이 필요합니다.");
            if(skillId=="W03"&&V(4)=="CRUSH_CHARGE"&&(Stats.SetPieces("SWB")<4||!d.slots.Contains("W02")||ItemEffects.crushCharge<=0))return No("분쇄 충전이 있을 때만 사용하는 설정입니다.");
            bool search=skillId=="A02"||skillId=="W03"&&V(3)!="TARGET"||skillId=="A01"&&V(4)=="MOST_HITS";
            var aims=search?EdictDirections(index,target,seen):new[]{target.position};
            var candidates=aims.Select(a=>ForecastAttack(rule,target,a)).Where(f=>f.HitsOn(target.id)>0);
            if(skillId=="W03"&&V(3)=="ISOLATED")candidates=candidates.Where(f=>f.uniqueTargets==1);
            if(skillId=="A02"&&V(2)=="FOCUS")candidates=candidates.Where(f=>f.HitsOn(target.id)>=2);
            var best=candidates.OrderByDescending(f=>skillId=="A02"&&V(2)=="FOCUS"?f.HitsOn(target.id):f.uniqueTargets)
                .ThenByDescending(f=>skillId=="A01"&&Stats.specials.Contains("LA01")?f.FirstHitIndex(target.id):0)
                .ThenBy(f=>Vector2.Angle(target.position-State.position,f.aim-State.position)).ThenBy(f=>f.aim.x).ThenBy(f=>f.aim.y).FirstOrDefault();
            if(best==null)return No("선택 대상을 포함하며 지정한 조준 조건을 만족하는 방향이 없습니다.");
            int minimum=skillId=="W03"?(V(4)=="GROUP"?2:1):skillId=="A01"?(V(2)=="TWO"||V(2)=="ELITE_OR_GROUP"&&!Elite(target)?2:1):V(2)=="GROUP"&&!Elite(target)?2:1;
            if(best.uniqueTargets<minimum)return No("선택한 방향의 예상 고유 대상 수가 부족합니다.");
            return new EdictAimPlan(true,true,"선택한 대상과 방향의 실제 충돌·적중 상한으로 판단했습니다.",best,target.id);
        }
    }
}
