using System;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        // The distances and life ratios Diablo IV's conditional stats are measured against,
        // rewritten for this project's metre scale.
        public const float CloseRange=3, DistantRange=7, InjuredRatio=.35f, HealthyRatio=.8f;
        // The share of direct hits that overpower. Diablo IV rolls this on every direct hit.
        public const float OverpowerChance=.03f;
        // How far the hero's own stacked reductions may go. The buffs that predate the sheet keep
        // their own half ceiling; this one is what a fully built defensive sheet can reach.
        public const float SheetReductionCeiling=.85f;

        // Dodge, block, overpower and lucky hit draw from a stream of their own. Spending the
        // main stream on them would move every roll that follows it, so a saved run would replay
        // differently than it did before these stats existed.
        float SheetRoll()=>RandomStream.Unit(ref State.sheetRng);

        // The enemy that landed a hit, when the caster id still names one this run knows about.
        EnemyState Attacker(string caster)
            =>int.TryParse(caster,out int id)?State.enemies.Find(e=>e.id==id):null;

        static bool Controlled(EnemyState enemy)
            =>CombatEffects.Has(enemy,StatusKind.Stun)||CombatEffects.Has(enemy,StatusKind.Freeze)
            ||CombatEffects.Has(enemy,StatusKind.Root)||CombatEffects.Has(enemy,StatusKind.Slow);

        // A dodged hit deals nothing at all, as in Diablo IV. The roll is skipped entirely when
        // the hero has no dodge, so a sheet without it draws nothing from the stream.
        bool DodgeIncoming()=>Stats.dodge>0&&SheetRoll()<Stats.dodge;
        bool BlockIncoming()=>Stats.blockChance>0&&SheetRoll()<Stats.blockChance;

        // Every reduction the sheet carries, stacked the way Diablo IV stacks them: separately
        // and multiplicatively, never added together into one number.
        float IncomingReduction(EnemyState attacker,int element,bool blocked)
        {
            float distance=attacker!=null?Vector2.Distance(attacker.position,State.position):0;
            bool measured=attacker!=null;
            return StatCatalog.Combine(BuffDamageReduction,Stats.damageReduction,
                measured&&distance<=CloseRange?Stats.closeReduction:0,
                measured&&distance>=DistantRange?Stats.distantReduction:0,
                State.health<=Stats.hp*InjuredRatio?Stats.injuredReduction:0,
                element==Element.Physical?Stats.physicalReduction:0,
                blocked?Stats.blockedReduction:0);
        }

        // The conditional damage lines of the sheet. Each one that applies adds its own share to
        // the additive bonus the hit already carries.
        float ConditionalBonus(EnemyState enemy,DamageKind kind)
        {
            if(enemy==null)return 0;
            float bonus=0,distance=Vector2.Distance(State.position,enemy.position);
            if(distance<=CloseRange)bonus+=Stats.Conditional(DamageCondition.Close);
            if(distance>=DistantRange)bonus+=Stats.Conditional(DamageCondition.Distant);
            if(kind==DamageKind.Periodic)bonus+=Stats.Conditional(DamageCondition.OverTime);
            if(Controlled(enemy))bonus+=Stats.Conditional(DamageCondition.CrowdControlled);
            if(enemy.maxHealth>0&&enemy.health<=enemy.maxHealth*InjuredRatio)bonus+=Stats.Conditional(DamageCondition.Injured);
            if(enemy.maxHealth>0&&enemy.health>enemy.maxHealth*HealthyRatio)bonus+=Stats.Conditional(DamageCondition.Healthy);
            return bonus;
        }

        // Overpower only answers a hit the hero aimed, never a periodic tick or a proc. A sheet
        // with nothing to add draws nothing from the stream, the same rule dodge and block follow.
        bool OverpowerRoll(DamageKind kind)
            =>Stats.overpower>0&&(kind==DamageKind.Direct||kind==DamageKind.Basic)&&SheetRoll()<OverpowerChance;

        // Life steal returns a share of the damage dealt. It cannot revive a dead hero and never
        // carries past full life.
        void StealLife(float dealt)
        {
            if(Stats.lifeSteal<=0||dealt<=0||State.health<=0||State.health>=Stats.hp)return;
            float healed=Mathf.Min(Stats.hp-State.health,dealt*Stats.lifeSteal*Stats.healing);
            if(healed<=0)return;
            State.health+=healed;EffectEvent("LIFE_STEAL","HEAL",value:healed);
        }

        // A lucky hit returns resource, the effect Diablo IV most often hangs off that roll.
        void LuckyHit(float dealt)
        {
            if(Stats.luckyHit<=0||dealt<=0||State.resource>=Stats.maxResource)return;
            if(SheetRoll()>=Stats.luckyHit/100)return;
            float before=State.resource;State.resource=Mathf.Min(Stats.maxResource,State.resource+5);
            if(State.resource>before)EffectEvent("LUCKY_HIT","RESOURCE",value:State.resource-before);
        }

        // Thorns answer whoever landed the hit. They are physical, cannot crit and never trigger
        // anything that would answer them back.
        void ApplyThorns(EnemyState attacker)
        {
            if(Stats.thorns<=0||attacker==null||attacker.dead)return;
            ApplyOutgoing(attacker,Stats.thorns,0,1,1,false,Element.Physical,CaptureDamage(),"THORNS",0,0,DamageKind.Periodic);
        }

        // Gold find scales a payout. A run never earns less than the payout it was written with,
        // so a rounding loss cannot turn the bonus into a penalty.
        int Gold(int amount)=>amount<=0?amount:Mathf.Max(amount,Mathf.FloorToInt(amount*Stats.goldFind));

        // Only what the gear rolled regenerates. Diablo IV also gives every character a baseline
        // trickle, but this project settles a fight with potions and passives on purpose, and a
        // free trickle would heal the hero through fights it is meant to lose.
        void RegenerateLife(float dt)
        {
            if(Stats.lifeRegen<=0||State.health<=0||State.health>=Stats.hp||dt<=0)return;
            State.health=Mathf.Min(Stats.hp,State.health+Stats.lifeRegen*dt);
        }
    }
}
