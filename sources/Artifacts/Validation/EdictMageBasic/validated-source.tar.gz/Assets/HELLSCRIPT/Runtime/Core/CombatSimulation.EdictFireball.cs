using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        sealed class FireballCandidate
        {
            public EnemyState target;
            public AttackForecast forecast;
            public float impactDelay;
            public int echoTargets;
        }
        Vector2 FireballObservedVelocity(EnemyState enemy)
        {
            var observation=State.exploration.enemies.Find(e=>e.id==enemy.id);
            if(observation==null||!observation.motionSampled||State.time-observation.seenAt<-.00001f||
                State.time-observation.seenAt>.4f||!Finite(observation.velocity)||Immobilized(enemy))return Vector2.zero;
            return observation.velocity;
        }
        Vector2 FireballObservedPosition(EnemyState enemy,Vector2 velocity,float delay)
        {
            Vector2 offset=velocity*delay;
            return offset.sqrMagnitude<.0000001f?enemy.position:Map.MoveDirect(enemy.position,enemy.position+offset,offset.magnitude,.1f);
        }
        FireballCandidate ForecastEdictFireball(EnemyState target,EnemyState[] seen,bool predicted)
        {
            Vector2 origin=State.position,aim=predicted?ObservedProjectileAim(12,target):target.position;
            float prepare=CombatActions.Timing(12,Hero.heroClass,Stats.attackSpeed).prepare;
            Vector2 direction=(aim-origin).normalized;float distance=Mathf.Min(10,Vector2.Distance(origin,aim));
            Vector2 impact=origin;float flight=0;
            var motion=seen.ToDictionary(e=>e.id,e=>predicted?FireballObservedVelocity(e):Vector2.zero);
            Vector2 Position(EnemyState enemy,float time)=>FireballObservedPosition(enemy,motion[enemy.id],time);
            if(!predicted)
            {
                // Preserve the current-position option's geometric snapshot; it does not lead motion.
                var geometric=ForecastAttack(BehaviorRules.Make(12),target,aim);
                impact=geometric.impact;flight=Vector2.Distance(origin,impact)/14;
            }
            else
            {
                // Sweep relative projectile/enemy motion in at most 15 flight segments. Only
                // observed velocities are projected; enemy intent and unseen actors are not read.
                float remaining=distance;
                while(remaining>.00001f)
                {
                    float stepDistance=Mathf.Min(14*Step,remaining);
                    Vector2 end=ClipProjectile(impact,impact+direction*stepDistance,.25f,out bool wall);
                    float travelled=Vector2.Distance(impact,end),dt=travelled/14;
                    float first=float.PositiveInfinity;int firstId=int.MaxValue;
                    foreach(var enemy in seen)
                    {
                        Vector2 before=Position(enemy,prepare+flight),after=Position(enemy,prepare+flight+dt);
                        float entry=Entry(impact-before,end-after,Vector2.zero,.25f+(enemy.boss?1.2f:.4f));
                        if(entry<first||entry==first&&enemy.id<firstId){first=entry;firstId=enemy.id;}
                    }
                    if(!float.IsInfinity(first)){impact=Vector2.Lerp(impact,end,first);flight+=dt*first;break;}
                    impact=end;flight+=dt;remaining-=travelled;
                    if(wall||travelled<.00001f)break;
                }
            }
            float delay=prepare+flight;
            int[] hits=seen.Where(e=>Vector2.Distance(impact,Position(e,delay))<=2.5f&&Map.LineClear(impact,Position(e,delay))).Select(e=>e.id).ToArray();
            int echo=Stats.specials.Contains("LM02")?seen.Count(e=>Vector2.Distance(impact,Position(e,delay+.4f))<=3.5f&&Map.LineClear(impact,Position(e,delay+.4f))):0;
            return new FireballCandidate{target=target,forecast=new AttackForecast(origin,aim,impact,hits),impactDelay=delay,echoTargets=echo};
        }
        EdictAimPlan PlanEdictFireball(HuntEdictV2Document document,EnemyState globalTarget,EnemyState[] seen)
        {
            string V(int n)=>HuntEdictV2.Value(document,"M01",n);
            bool predicted=V(4)=="PREDICTED";
            var eligible=seen.Where(EdictTargetEligible).ToArray();
            var reachable=eligible.Where(e=>Vector2.Distance(State.position,e.position)<=10+.0001f&&Map.ProjectileClear(State.position,e.position,.25f)).ToArray();
            if(reachable.Length==0)
            {
                var approach=eligible.OrderBy(e=>e==globalTarget?0:1).ThenBy(e=>(e.position-State.position).sqrMagnitude).ThenBy(e=>e.id).FirstOrDefault();
                if(approach==null)return new EdictAimPlan(true,false,"현재 감지한 대상이 없습니다.",null,-1,"NO_TARGET");
                bool far=Vector2.Distance(State.position,approach.position)>10+.0001f;
                return new EdictAimPlan(true,false,far?Loc.F("스킬 사거리 {0}m 밖",10):"투사체가 통과하지 못하는 사선",null,approach.id,far?"RANGE":"LINE_OF_FIRE");
            }
            var candidates=reachable.Select(e=>ForecastEdictFireball(e,seen,predicted)).Where(c=>c.forecast.HitsOn(c.target.id)>0).ToArray();
            if(V(2)=="GROUP")candidates=candidates.Where(c=>c.forecast.uniqueTargets>=3).ToArray();
            if(candidates.Length==0)return new EdictAimPlan(true,false,V(2)=="GROUP"?"화염구 원 폭발에 맞을 것으로 예상되는 적이 3명 미만입니다.":"화염구로 맞힐 수 있는 감지한 대상이 없습니다.",null);
            bool exposure=V(2)=="EXPOSURE"&&Stats.SetPieces("SM")>=4;
            if(exposure)
            {
                var marked=candidates.Where(c=>c.target.frostCasterId==State.heroId&&c.target.frostMarkTime>c.impactDelay+.00001f).ToArray();
                if(marked.Length>0)candidates=marked;else exposure=false;
            }
            var preferred=candidates.Where(c=>V(3)=="ELITE"?(c.target.boss||c.target.elite>=0):V(3)=="SUPPORT"&&c.target.kind%6==4).ToArray();
            if(preferred.Length>0)candidates=preferred;
            bool dense=V(3)=="DENSE";
            // A requested target category takes precedence. LM02 only breaks ties in primary
            // explosion score, and never contributes toward the three-target group threshold.
            var chosen=candidates.OrderBy(c=>dense?0:c.target==globalTarget?0:1)
                .ThenByDescending(c=>c.forecast.uniqueTargets).ThenByDescending(c=>c.echoTargets)
                .ThenBy(c=>c.target==globalTarget?0:1).ThenBy(c=>(c.target.position-State.position).sqrMagnitude).ThenBy(c=>c.target.id).First();
            string reason=exposure?"착탄까지 남을 것으로 예상되는 자기 세트 노출을 우선합니다.":V(2)=="EXPOSURE"?"유효한 자기 세트 노출이 없어 꾸준히 공격합니다.":predicted?"관측한 이동으로 화염구의 첫 충돌과 원 폭발을 예상했습니다.":"현재 위치를 기준으로 화염구의 첫 충돌과 원 폭발을 확인했습니다.";
            return new EdictAimPlan(true,true,reason,chosen.forecast,chosen.target.id);
        }
    }
}
