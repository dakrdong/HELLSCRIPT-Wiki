using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    [Serializable]
    public sealed class GrowthEvent
    {
        public int experience,fromLevel,toLevel,fromXp,toXp;
        public float time,oldMaxHp,newMaxHp,healthBefore,healthAfter;
        public List<int> unlockedSkills=new List<int>();
    }
    public sealed partial class CombatSimulation
    {
        // Experience gain scales the reward the way Diablo IV's own bonus does, after the stage
        // multiplier the caller already applied.
        void QueueExperience(int amount)
        {if(State.training<0&&amount>0)State.pendingExperience+=Mathf.Max(1,Mathf.FloorToInt(amount*Stats.experienceGain));}
        void CommitExperience()
        {
            if(State.training>=0||State.pendingExperience<=0)return;
            int amount=State.pendingExperience;State.pendingExperience=0;
            int previous=Hero.level,previousXp=Hero.xp;float oldHp=Stats.hp,before=State.health;
            Economy.AddXp(Hero,amount);if(Hero.level==previous)return;
            var statsHero=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(Hero));statsHero.build=State.build;Stats=new HeroStats(statsHero);
            State.health=before<=0?0:Stats.hp*Mathf.Clamp01(before/Mathf.Max(.0001f,oldHp));
            var change=new GrowthEvent{experience=amount,fromLevel=previous,toLevel=Hero.level,fromXp=previousXp,toXp=Hero.xp,time=State.time,
                oldMaxHp=oldHp,newMaxHp=Stats.hp,healthBefore=before,healthAfter=State.health,
                unlockedSkills=catalog.skills.Select((skill,index)=>(skill,index)).Where(x=>x.skill.heroClass==Hero.heroClass&&x.skill.unlock>previous&&x.skill.unlock<=Hero.level).Select(x=>x.index).ToList()};
            State.growthEvents.Add(change);if(State.growthEvents.Count>30)State.growthEvents.RemoveAt(0);
            Log("LEVEL_UP",Loc.F("Lv.{0} → {1} · HP 비율 유지{2}", previous, Hero.level, (change.unlockedSkills.Count>0?Loc.F(" · 해금: {0} · 행동 설계에서 설정을 확인하세요.", string.Join(", ",change.unlockedSkills.Select(i=>catalog.skills[i].name))):"")));
        }
    }
}
