using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        // This is a read-only affordability probe: cooldown, equipment, purpose and physical
        // eligibility remain real. It never funds an action or changes the player's resource.
        bool MageActiveNeedsResource(HuntEdictV2Document document,EnemyState globalTarget)
        {
            foreach(int index in new[]{12,13,14,17})
            {
                var skill=catalog.skills[index];
                if(!document.slots.Contains(skill.id)||!HuntEdictV2.Automatic(document,skill.id)||skill.unlock>EffectiveLevel||State.cooldowns[index]>0)continue;
                float cost=Cost(skill);if(cost<=0||State.resource>=cost)continue;
                if(index==17)
                {
                    var nova=PlanEdictNovaCandidate(document,globalTarget,false,true);
                    if(nova.ready&&nova.code=="READY")return true;
                }
                else if(PlanEdictAim(document,skill.id,globalTarget).available)return true;
            }
            return false;
        }
        EdictAimPlan PlanEdictMageBasic(HuntEdictV2Document document,EnemyState globalTarget,EnemyState[] perceived)
        {
            string V(int n)=>HuntEdictV2.Value(document,"BASIC",n);
            var seen=perceived.Where(EdictTargetEligible).ToArray();
            globalTarget=seen.FirstOrDefault(e=>e.id==globalTarget?.id)??seen.OrderBy(e=>(e.position-State.position).sqrMagnitude).ThenBy(e=>e.id).FirstOrDefault();
            var target=globalTarget;
            EdictAimPlan No(string reason,string code="EDICT_AIM")=>new EdictAimPlan(true,false,reason,null,target?.id??-1,code);
            if(V(1)!="ON")return No("자동 사용을 껐습니다.","EDICT_OFF");
            if(HeroActionBusy)return No("진행 중인 주 행동이 있습니다.","ACTION_LOCK");
            string mode=V(2);
            if(mode=="DISCOUNT"&&!Stats.specials.Contains("LC02"))return No("절제 충전 준비에는 LC02 장착이 필요합니다.","REFERENCE");
            if(mode=="RESOURCE"&&!MageActiveNeedsResource(document,globalTarget))return No("자원 부족만 해결하면 실행할 수 있는 유료 액티브가 없습니다.","RESOURCE_NOT_NEEDED");
            if(V(3)=="CURRENT")target=seen.FirstOrDefault(e=>e.id==State.targetId)??target;
            else if(V(3)=="LOW_HP")target=seen.OrderBy(e=>e.health/Mathf.Max(.0001f,e.maxHealth)).ThenBy(e=>(e.position-State.position).sqrMagnitude).ThenBy(e=>e.id).FirstOrDefault();
            else if(V(3)=="OWN_BLIZZARD")target=seen.Where(e=>State.effects.Any(f=>LiveOwnBlizzard(f)&&BlizzardCovers(f,e)))
                .OrderBy(e=>e==globalTarget?0:1).ThenBy(e=>(e.position-State.position).sqrMagnitude).ThenBy(e=>e.id).FirstOrDefault()??target;
            bool chargeTarget=mode=="DISCOUNT"&&ItemEffects.lc02Charge<=0&&ItemEffects.procCooldown<=.00001f&&ItemEffects.basicCount>0;
            if(chargeTarget)target=seen.FirstOrDefault(e=>e.id==ItemEffects.lastBasic)??target;
            if(target==null)return No("현재 감지한 대상이 없습니다.","NO_TARGET");
            if(Vector2.Distance(State.position,target.position)>10+.0001f)return No(Loc.F("기본 공격 사거리 {0}m 밖",10),"RANGE");
            if(!Map.ProjectileClear(State.position,target.position,.2f))return No("투사체가 통과하지 못하는 사선","LINE_OF_FIRE");
            Vector2 aim=V(4)=="PREDICTED"?ObservedProjectileAim(-1,target):target.position;
            var forecast=ForecastAttack(EdictRuleOrder.MageBasicRule(),target,aim);
            return new EdictAimPlan(true,true,chargeTarget&&target.id==ItemEffects.lastBasic?"절제의 유효한 연속 적중 대상을 우선합니다.":
                V(4)=="PREDICTED"?"관측한 이동과 준비·비행 시간을 반영해 번개탄을 조준합니다.":"준비 시작 때 선택한 대상의 현재 위치로 번개탄을 조준합니다.",forecast,target.id);
        }
    }
}
