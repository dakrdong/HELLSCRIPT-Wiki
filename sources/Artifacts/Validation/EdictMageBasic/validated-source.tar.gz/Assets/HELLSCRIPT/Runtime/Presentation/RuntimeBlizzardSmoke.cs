using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Opt-in native UI/save evidence. Enemy positions and simulation time are controlled fixtures;
    // option edits, saving, drawing and resuming use the actual player code.
    public sealed class RuntimeBlizzardSmoke:MonoBehaviour
    {
        GameController game;
        string directory,saveDirectory;
        int capture;
        readonly List<string> failures=new List<string>();
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if(!Debug.isDebugBuild||!Environment.GetCommandLineArgs().Contains("-hellscriptBlizzardSmoke"))return;
            Application.runInBackground=true;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Blizzard edict validation").AddComponent<RuntimeBlizzardSmoke>();
        }
        static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
        void Check(bool condition,string message){if(!condition)failures.Add(message);}
        static string Json(object value)=>JsonUtility.ToJson(value);
        Button[] Buttons=>game.UI.GetComponentsInChildren<Button>();
        void Click(string name){var b=Buttons.Single(b=>b.name==name);Require(b.IsInteractable(),"Disabled: "+name);b.onClick.Invoke();}
        void Choice(string label){var b=Buttons.Single(b=>b.name.Contains(label));Require(b.IsInteractable(),"Disabled: "+label);b.onClick.Invoke();}
        void Skills(){game.UI.ShowEdictEditor();Click("스킬 설정");Click("눈보라");}
        string[] Lines()=>game.UI.GetComponentsInChildren<Text>().Select(t=>t.text).ToArray();
        static int Starts(CombatSimulation sim)=>sim.State.statistics.skills.SingleOrDefault(s=>s.definitionId=="M02")?.starts??0;
        void Advance(int ticks)
        {game.Combat.State.paused=false;for(int i=0;i<ticks;i++)game.Combat.Tick(CombatSimulation.Step);game.World.Present(game.Combat.State,.05f);game.UI.RefreshHud();}
        void Enemy(float x,float y)
        {
            var run=game.Combat.State;
            run.enemies.Add(new EnemyState{id=900+run.enemies.Count,position=run.position+new Vector2(x,y),health=1000000,maxHealth=1000000,speed=0,attack=0,cooldown=1000});
        }
        IEnumerator Capture(string name,int width,int height,string focus=null)
        {
            Screen.SetResolution(width,height,FullScreenMode.Windowed);float deadline=Time.realtimeSinceStartup+6;
            while((Screen.width!=width||Screen.height!=height)&&Time.realtimeSinceStartup<deadline)yield return null;
            Require(Screen.width==width&&Screen.height==height,"Native resize failed: "+name);
            yield return new WaitForSecondsRealtime(.3f);
            if(focus!=null)
            {
                var line=game.UI.GetComponentsInChildren<Text>().First(t=>t.text.Contains(focus));
                DialogReadingAnchor.Show(line.rectTransform);yield return new WaitForSecondsRealtime(.2f);
            }
            Canvas.ForceUpdateCanvases();
            foreach(var line in game.UI.GetComponentsInChildren<Text>())
                Check(line.preferredHeight<=line.rectTransform.rect.height+1,"Clipped on "+name+": "+line.text);
            var safe=UiSafeArea.Current;var corners=new Vector3[4];
            foreach(var button in Buttons.Where(b=>b.transform.parent.name=="Footer"))
            {((RectTransform)button.transform).GetWorldCorners(corners);Check(corners.All(c=>c.x>=safe.xMin-1&&c.x<=safe.xMax+1&&c.y>=safe.yMin-1&&c.y<=safe.yMax+1),"Footer outside safe area: "+name+" / "+button.name);}
            var missing=Loc.Missing.Where(key=>!LanguageOptions.All.Any(o=>o.NativeName==key)).ToArray();
            Check(missing.Length==0,"Missing translation: "+string.Join("; ",missing));
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,$"{++capture:00}-{name}.png"));yield return new WaitForSecondsRealtime(.2f);
        }
        void Finish(bool resumed)
        {
            string text=failures.Count==0?"PASS: "+(resumed?"independent process restored existing fields and paid FOLLOW preparation despite saved FIXED/OFF; one release replaces only the oldest area, the new field follows, no extra casts; translated decisions and pause restoration.":"M02 five options edited through UI, draft isolation and file save; GROUP waits at one target, KEEP preserves two fields, REPLACE starts a paid FOLLOW cast, FIXED/OFF edits preserve that preparation; Korean/English and 140% layouts.")+" Controlled native fixtures, not mobile-device or balance validation.":string.Join("\n",failures);
            File.WriteAllText(Path.Combine(directory,resumed?"resume-result.txt":"checkpoint-result.txt"),text+"\n");
            Debug.Log(failures.Count==0?(resumed?"HELLSCRIPT_BLIZZARD_RUNTIME_OK":"HELLSCRIPT_BLIZZARD_CHECKPOINT_READY"):"HELLSCRIPT_BLIZZARD_RUNTIME_FAIL\n"+text);
            Application.Quit(failures.Count==0?0:1);
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();int save=Array.IndexOf(args,"-hellscriptSavePath"),outIndex=Array.IndexOf(args,"-hellscriptScreenshots");
            Require(save>=0&&save+1<args.Length&&outIndex>=0&&outIndex+1<args.Length,"Use dedicated save and evidence paths.");
            saveDirectory=args[save+1];directory=args[outIndex+1];Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1);game=FindAnyObjectByType<GameController>();Require(game?.Store!=null,"Store unavailable.");game.enabled=false;
            if(args.Contains("-hellscriptBlizzardResume")){yield return Resume();yield break;}
            Require(game.Store.Data.heroes.All(h=>h.level==1)&&game.Store.Data.suspendedRun==null,"Use a fresh test account.");
            game.SelectHero(2);var hero=game.Store.Data.Hero;hero.level=30;hero.inventory.Clear();game.Store.Data.guide.hintsHidden=true;
            hero.build.activeSkills=new List<int>{13};hero.build.passives=Array.Empty<int>();hero.build.autoRepeat=false;
            hero.build.rules=new List<Rule>{BehaviorRules.Make(13,BehaviorRules.C("SC06",Comparison.AtLeast,99,predicted:true))};
            uint rng=91367;var legendary=ItemGenerator.Create(HeroClass.Mage,ItemCatalog.Unique("LM01").slot,3,30,ref rng,uniqueId:"LM01");
            hero.inventory.Add(legendary);Require(Economy.Equip(hero,legendary),"Cannot equip LM01.");
            hero.edict=HuntEdictV2.WithOption(HuntEdictV2Storage.CreateForHero(hero),"BASIC",1,"OFF");hero.edict=HuntEdictV2Editing.WithGlobal(hero.edict,"position.mode","STAND");
            game.Save();string original=Json(hero.edict);Skills();
            yield return Capture("options-ko",1280,720,"자동 사용");game.ApplyLanguage("en");
            yield return Capture("options-en",1280,720,"Automatic use");game.ApplyInterfaceScale(140);
            yield return Capture("options-large-en",720,1280,"When Hunt Edict");
            yield return Capture("options-small-en",640,360,"Zone movement");game.ApplyLanguage("ko");
            yield return Capture("options-large-ko",720,1280,"장판 이동");game.ApplyInterfaceScale(100);
            Choice("사용 방식");Choice("사용 방식");Choice("설치 위치");Choice("두 장판이 남아 있을 때");Choice("장판 이동");
            Require(Json(hero.edict)==original,"Draft changed the saved hero.");Click("저장 및 적용");
            Require(HuntEdictV2.Value(hero.edict,"M02",2)=="GROUP"&&HuntEdictV2.Value(hero.edict,"M02",3)=="SELF"&&
                HuntEdictV2.Value(hero.edict,"M02",4)=="KEEP"&&HuntEdictV2.Value(hero.edict,"M02",5)=="FOLLOW","Options did not save.");
            Require(Json(new GameStore(saveDirectory,game.catalog).Data.Hero.edict)==Json(hero.edict),"File disagrees with saved options.");
            Click("공유");Click("사냥 칙령 v0.2 사용하기");Require(hero.useEdict,"Switch did not enable.");
            game.BeginDeveloperTraining(1);var sim=game.Combat;Require(sim!=null&&sim.EdictActive,"Training failed to start with the edict.");
            sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();sim.State.exploration.enemies.Clear();sim.Stats.crit=0;sim.Stats.regen=0;Enemy(0,2);game.World.BuildDungeon(sim.State);
            Advance(20);Require(Starts(sim)==0&&sim.State.decisions.Any(d=>d.ruleId=="edict:M02"&&d.code=="EDICT_AIM"),"GROUP did not wait at one target.");
            Enemy(.7f,2);Enemy(-.7f,2);
            foreach(float x in new[]{-4f,4f})sim.State.effects.Add(new GroundEffect{id=sim.State.nextId++,rootCastId=sim.State.nextId++,kind=13,definitionId="M02",casterId=sim.State.heroId,
                position=sim.State.position+new Vector2(x,-2),radius=3,duration=6,createdAt=sim.State.time,damage=0});
            sim.State.decisionTime=0;Advance(1);Require(Starts(sim)==0&&sim.State.effects.Count==2,"KEEP did not preserve two fields.");
            game.UI.ShowRuleDecisions();game.ApplyLanguage("en");game.ApplyInterfaceScale(140);
            Check(Lines().Any(s=>s.Contains("Blizzard hunt edict")),"Missing compiled-policy heading.");
            yield return Capture("keep-wait-large-en",720,1280,"Blizzard hunt edict");Click("전투로 돌아가기");Check(!sim.State.paused,"Language redraw lost the running decision entry.");
            game.ApplyLanguage("ko");game.ApplyInterfaceScale(100);Skills();Choice("두 장판이 남아 있을 때");Click("저장 및 적용");
            sim.State.decisionTime=0;Advance(1);Require(Starts(sim)==1&&sim.State.heroAction.phase==HeroActionPhase.Preparing,"REPLACE did not start preparation.");
            Require(sim.State.heroAction.blizzardMode==BlizzardMode.Follow,"FOLLOW was not captured.");string action=Json(sim.State.heroAction);
            Skills();Choice("장판 이동");Choice("자동 사용");Click("저장 및 적용");
            Require(HuntEdictV2.Value(hero.edict,"M02",1)=="OFF"&&HuntEdictV2.Value(hero.edict,"M02",5)=="FIXED"&&action==Json(sim.State.heroAction),"Editing changed the paid preparation.");
            game.UI.ShowBattle();game.World.BuildDungeon(sim.State);game.World.Present(sim.State,.05f);yield return Capture("preparation-before-restart",1280,720);
            sim.State.training=-1;sim.State.paused=false;game.Save();File.WriteAllText(Path.Combine(directory,"expected-run.json"),Json(sim.State));
            File.WriteAllText(Path.Combine(directory,"expected-edict.json"),Json(hero.edict));Finish(false);
        }
        IEnumerator Resume()
        {
            var expected=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(directory,"expected-run.json")));
            Require(Json(game.Store.Data.Hero.edict)==File.ReadAllText(Path.Combine(directory,"expected-edict.json"))&&game.Store.Data.Hero.useEdict,"Restart lost the saved document or switch.");
            Require(game.Store.Data.suspendedRun!=null,"Restart lost the pending run.");game.Begin(resume:true);var sim=game.Combat;Require(sim!=null&&sim.EdictActive,"Saved run failed to resume.");
            Require(string.Join("|",sim.State.effects.Select(Json))==string.Join("|",expected.effects.Select(Json)),"Restart changed existing fields.");
            Require(sim.State.time==expected.time&&sim.State.resource==expected.resource&&Json(sim.State.heroAction)==Json(expected.heroAction),"Restart changed paid preparation.");
            int oldest=expected.effects.Min(f=>f.id),newest=expected.effects.Max(f=>f.id),root=expected.heroAction.id;
            sim.Stats.crit=0;sim.Stats.regen=0;Advance(30);
            Require(Starts(sim)==1&&sim.State.effects.Count==2&&!sim.State.effects.Any(f=>f.id==oldest)&&sim.State.effects.Any(f=>f.id==newest),"Replacement did not preserve only the newer existing field.");
            var created=sim.State.effects.Single(f=>f.rootCastId==root);
            Require(created.followsTarget&&created.moved>0&&created.moved<=1.5f,"The resumed FOLLOW cast lost its captured movement.");
            Require(sim.State.actionEvents.Count(e=>e.skill==13&&e.kind=="ACTION_RELEASE")==1&&sim.State.resource==expected.resource,"Restart duplicated the release or payment.");
            Require(sim.State.damageEvents.Any(e=>e.definitionId=="M02"&&e.rootCastId==root),"Resumed Blizzard did not deal damage.");
            game.World.Present(sim.State,.05f);yield return Capture("following-area-after-restart",1280,720);
            game.UI.ShowRuleDecisions();game.ApplyLanguage("en");game.ApplyInterfaceScale(140);
            yield return Capture("resume-decisions-en",640,360,"Blizzard hunt edict");game.ApplyLanguage("ko");
            yield return Capture("resume-decisions-ko",720,1280,"눈보라 사냥 칙령");Click("전투로 돌아가기");Check(!sim.State.paused,"Decision return did not resume the entry state.");
            sim.State.paused=true;game.UI.ShowRuleDecisions();game.ApplyLanguage("en");Click("전투로 돌아가기");Check(sim.State.paused,"Decision return resumed a manually paused run.");
            Advance(150);Require(Starts(sim)==1&&sim.State.effects.Count==0,"OFF recreated an area or changed its expiry.");
            Finish(true);
        }
    }
}
