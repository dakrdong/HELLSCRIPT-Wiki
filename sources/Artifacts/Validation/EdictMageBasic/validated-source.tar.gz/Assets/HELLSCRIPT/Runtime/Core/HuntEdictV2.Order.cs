using System;
using System.Collections.Generic;
using System.Linq;

namespace Hellscript
{
    public sealed class EdictOrderedRule
    {
        public readonly Rule rule;
        public readonly int row;
        // Empty when the rule is evaluated; otherwise the reason it is skipped this cycle.
        public readonly string skipReason;
        internal EdictOrderedRule(Rule rule,int row,string skipReason){this.rule=rule;this.row=row;this.skipReason=skipReason;}
    }

    // Decides in which order the legacy rules are inspected when a v0.2 document drives the hero.
    // Pure: it never touches the rules, and with no document it returns them exactly as written.
    public static class EdictRuleOrder
    {
        public static int CompiledSkill(string id)=>id=="edict:M01"?12:id=="edict:M02"?13:id=="edict:M03"?14:id=="edict:M04"?15:id=="edict:M05"?16:id=="edict:M06"?17:-1;
        public static bool IsCompiledRule(string id)=>CompiledSkill(id)>=0||id=="edict:MAGE:BASIC";
        internal static Rule MageBasicRule(){var rule=BehaviorRules.Utility(RuleAction.Basic);rule.id="edict:MAGE:BASIC";return rule;}
        internal static Rule FireballRule(){var rule=BehaviorRules.Make(12);rule.id="edict:M01";return rule;}
        internal static Rule ChainRule(){var rule=BehaviorRules.Make(14);rule.id="edict:M03";return rule;}
        internal static Rule TeleportRule()
        {var rule=BehaviorRules.Make(15);rule.id="edict:M04";rule.overrideMovement=true;rule.movement=MovementMode.Stand;return rule;}
        internal static Rule ShieldRule()
        {var rule=BehaviorRules.Make(16);rule.id="edict:M05";rule.overrideMovement=true;rule.movement=MovementMode.Stand;return rule;}
        internal static Rule NovaRule()
        {var rule=BehaviorRules.Make(17);rule.id="edict:M06";rule.overrideMovement=true;rule.movement=MovementMode.Stand;return rule;}
        internal static Rule BlizzardRule(HuntEdictV2Document document)
        {
            var rule=BehaviorRules.Make(13);rule.id="edict:M02";
            string placement=HuntEdictV2.Value(document,"M02",3);
            rule.areaAim=placement=="SELF"?AreaAim.Self:placement=="PATH"?AreaAim.ObservedPath:placement=="DENSE"?AreaAim.Dense:AreaAim.Target;
            rule.blizzardMode=HuntEdictV2.Value(document,"M02",5)=="FOLLOW"?BlizzardMode.Follow:BlizzardMode.Fixed;return rule;
        }
        // Mage attacks have complete core policies. Executable rules are derived from the document,
        // so hidden legacy conditions, disabled rows or a missing legacy row cannot override it.
        // Other skills retain their existing bridge until their fixed policies are connected.
        public static List<EdictOrderedRule> ForSimulation(IReadOnlyList<Rule> rules,HuntEdictV2Document document)
        {
            if(document==null||document.heroClass!="MAGE")return Order(rules,document);
            var compiled=new Dictionary<int,Rule>();
            if(document.slots.Contains("M01"))compiled.Add(12,FireballRule());
            if(document.slots.Contains("M02"))compiled.Add(13,BlizzardRule(document));
            if(document.slots.Contains("M03"))compiled.Add(14,ChainRule());
            if(document.slots.Contains("M04"))compiled.Add(15,TeleportRule());
            if(document.slots.Contains("M05"))compiled.Add(16,ShieldRule());
            if(document.slots.Contains("M06"))compiled.Add(17,NovaRule());
            compiled.Add(-1,MageBasicRule());
            var derived=new List<Rule>();var rows=new List<int>();var added=new HashSet<int>();
            for(int row=0;row<rules.Count;row++)
            {
                int key=rules[row].action==RuleAction.Basic?-1:rules[row].skill;
                if((rules[row].action==RuleAction.Skill&&key>=0||rules[row].action==RuleAction.Basic)&&compiled.TryGetValue(key,out var policy))
                {if(!added.Add(key))continue;derived.Add(policy);}
                else derived.Add(rules[row]);
                rows.Add(row);
            }
            int nextRow=rules.Count;
            foreach(var entry in compiled.OrderBy(c=>c.Key))
                if(added.Add(entry.Key)){derived.Add(entry.Value);rows.Add(nextRow++);}
            return Order(derived,document).Select(o=>new EdictOrderedRule(o.rule,rows[o.row],o.skipReason)).ToList();
        }
        public static List<EdictOrderedRule> Order(IReadOnlyList<Rule> rules,HuntEdictV2Document document)
        {
            var result=new List<EdictOrderedRule>();
            if(document==null){for(int i=0;i<rules.Count;i++)result.Add(new EdictOrderedRule(rules[i],i,""));return result;}
            var d=HuntEdictV2.Canonical(document);
            string G(string id)=>d.global.Single(o=>o.id==id).value;
            var categories=G("common.order").Split(',');
            int Rank(string category){int index=Array.IndexOf(categories,category);return index<0?categories.Length:index;}
            // Loot rules sit where the document puts loot: before attack when any rarity is collected
            // during combat, otherwise after it.
            bool priorityLoot=new[]{"NORMAL","MAGIC","RARE","LEGENDARY","SET"}.Any(r=>G("loot."+r)=="PRIORITY");
            int lootRank=Rank(priorityLoot?"PRIORITY_LOOT":"AFTER_COMBAT_LOOT"),attackRank=Rank("ATTACK"),exploreRank=Rank("EXPLORE");
            var order=d.skillOrder.ToList();
            string SkillId(Rule r)=>r.action==RuleAction.Basic?"BASIC":r.skill>=0&&r.skill<18?CombatTelemetry.SkillId(r.skill):"";
            int Category(Rule r)=>r.action==RuleAction.Loot?lootRank:r.action==RuleAction.Chest||r.action==RuleAction.Explore?exploreRank:attackRank;
            int Within(Rule r)
            {
                if(r.action!=RuleAction.Skill&&r.action!=RuleAction.Basic)return 0;
                int index=order.IndexOf(SkillId(r));return index<0?order.Count:index;
            }
            var indexed=Enumerable.Range(0,rules.Count).Select(i=>(rule:rules[i],row:i)).ToList();
            foreach(var item in indexed.OrderBy(x=>Category(x.rule)).ThenBy(x=>Within(x.rule)).ThenBy(x=>x.row))
            {
                string skip="";
                if(item.rule.action==RuleAction.Skill||item.rule.action==RuleAction.Basic)
                {
                    string id=SkillId(item.rule);
                    if(id!=""&&d.skills.Any(s=>s.id==id)&&!HuntEdictV2.Automatic(d,id))skip="사냥 칙령에서 자동 사용을 껐습니다.";
                }
                result.Add(new EdictOrderedRule(item.rule,item.row,skip));
            }
            return result;
        }
    }
}
