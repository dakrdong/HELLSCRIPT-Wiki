using System;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        bool OwnElementalShield=>State.shields.Any(s=>s.definitionId=="M05"&&s.amount>0&&s.remaining>0);
        float ElementalShieldAmount=>Mathf.Max(0,Mathf.Min(Stats.hp*.35f*Stats.shieldMultiplier,Stats.hp-State.shields.Sum(s=>s.amount)));
        bool ShieldOpening(EnemyState[] seen)=>!HeroActionBusy&&seen.Length>0&&!(State.edictEngagement?.openingChecked??State.time>0);
        bool DamageDodge(EdictSurvivalAssessment assessment)=>assessment.DodgeRequested&&assessment.forecast.hits.Any(h=>h.after<=EdictSurvivalLookAhead+.00001f&&h.finalDamage>0);
        bool ShieldEncounterAllowed(HuntEdictV2Document d,EnemyState[] seen)
        {
            string group=HuntEdictV2.Value(d,"M05",4);
            return group=="ALL"||seen.Any(e=>group=="BOSS"?e.boss:e.boss||e.elite>=0);
        }
        void EnsureShieldEngagement()
        {
            EdictEngagementState.Normalize(State);
            // Only the Mage needs this record. An older running save cannot prove its opening
            // remains available, so re-arm after combat rather than granting one on restoration.
            State.edictEngagement??=new EdictEngagementState{heroId=State.heroId,runId=State.id,active=State.time>0,openingChecked=State.time>0};
        }
        void ObserveShieldEngagement()
        {
            if(Hero.heroClass!=HeroClass.Mage)return;
            EnsureShieldEngagement();var s=State.edictEngagement;
            if(sensed.Any(EdictTargetEligible))
            {if(!s.active){s.active=true;s.openingChecked=false;}}
            else if(OutOfCombat&&State.time-State.noEnemySince>=3&&!HeroActionBusy&&!InDanger){s.active=false;s.openingChecked=false;}
        }
        void ObserveShieldOpeningAction(int index)
        {
            if(Hero.heroClass!=HeroClass.Mage)return;
            // Mage attacks and M05 spend the opening; Teleport alone does not start an attack.
            if(index<0||index>=12&&index!=15)
            {EnsureShieldEngagement();State.edictEngagement.active=true;State.edictEngagement.openingChecked=true;}
        }
        public EdictResponseCandidate PlanEdictShield(HuntEdictV2Document source,EnemyState globalTarget=null)
        {
            var d=HuntEdictV2.Canonical(source);HuntEdictV2.ValidateReceiver(d,Hero,catalog);
            float cost=Cost(catalog.skills[16]);
            EdictResponseCandidate C(string code,string detail,bool ready=false)=>new EdictResponseCandidate("DEFENSE","M05",16,globalTarget?.id??-1,State.position,cost,code,detail,ready,true,.2f,EdictRuleOrder.ShieldRule());
            string block=EdictResponseBlock(d);if(block!="")return C("STATE",block);
            if(!d.slots.Contains("M05"))return C("NOT_EQUIPPED","원소 보호막을 장착하지 않았습니다.");
            if(!HuntEdictV2.Automatic(d,"M05"))return C("EDICT_OFF","사냥 칙령에서 자동 사용을 껐습니다.");
            if(catalog.skills[16].unlock>EffectiveLevel)return C("LEVEL_LOCK",Loc.F("해금 레벨 {0}",catalog.skills[16].unlock));
            var assessment=AssessEdictSurvival(d,State.edictResponse?.memory);var seen=ForecastSeen().Where(EdictTargetEligible).ToArray();
            string moment=HuntEdictV2.Value(d,"M05",2);
            bool opening=moment=="ENGAGE"&&ShieldOpening(seen);
            if(!assessment.emergency&&!(moment!="EMERGENCY"&&DamageDodge(assessment))&&!opening)
                return C("PURPOSE","설정한 긴급 생존·피격 대비·교전 시작 조건이 아닙니다.");
            if(!EdictCanInterrupt(assessment))return C("ACTION_LOCK","전역 방침과 현재 행동 구간에서 보호막으로 전환할 수 없습니다.");
            if(State.cooldowns[16]>0)return C("COOLDOWN",Loc.F("남은 CD {0:0.00}초",State.cooldowns[16]));
            if(State.resource<cost)return C("RESOURCE",Loc.F("필요 {0:0.##} / 현재 {1:0.##}",cost,State.resource));
            if(OwnElementalShield)return C("EFFECT_ACTIVE","자신의 보호막이 남아 있어 다시 사용하지 않습니다.");
            if(ElementalShieldAmount<=.00001f)return C("SHIELD_CAP","추가로 생성할 수 있는 보호막이 없습니다.");
            // Only a direct global emergency selection bypasses these restrictions. That path
            // runs before ordinary rules, in EdictSurvivalSkill; ordinary eligibility cannot fake it.
            if(HuntEdictV2.Value(d,"M05",3)=="AFTER"&&State.shields.Any(s=>s.amount>0&&s.remaining>0))return C("WAIT_DEFENSE","다른 보호막의 소진·만료를 기다립니다.");
            if(moment!="EMERGENCY"&&!ShieldEncounterAllowed(d,seen))return C("ENCOUNTER","원소 보호막의 일반 사용을 허용한 교전이 아닙니다.");
            return C("READY",opening&&!assessment.emergency&&!DamageDodge(assessment)?"새 교전의 첫 판단에서 보호막을 준비합니다.":"설정한 전역 위험 조건과 실제 보호막 생성량을 확인했습니다.",true);
        }
        RuleCandidate ReviewShieldOpening(RuleCandidate[] candidates,RuleCandidate selected)
        {
            var memory=State.edictEngagement;
            if(edictSource==null||Hero.heroClass!=HeroClass.Mage||memory==null||!memory.active||memory.openingChecked||HeroActionBusy)return selected;
            // Respect a higher-priority loot/exploration category. Within the action category,
            // ENGAGE gets its one review before the first attack even if M05 is ordered later.
            if(selected!=null&&selected.rule.action!=RuleAction.Skill&&selected.rule.action!=RuleAction.Basic)return selected;
            var opening=candidates.FirstOrDefault(c=>c.rule.id=="edict:M05");
            if(opening?.ready==true&&HuntEdictV2.Value(edictSource,"M05",2)=="ENGAGE")selected=opening;
            // An unavailable shield must not hold the opening or pause attacks until its cooldown.
            memory.openingChecked=true;return selected;
        }
    }
}
