using System;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class GameUI
    {
        static string PageTitle(StatPage page)
        {
            switch(page)
            {
                case StatPage.Core: return "핵심 능력치";
                case StatPage.Offense: return "공격 능력치";
                case StatPage.Defense: return "방어 능력치";
                case StatPage.Resource: return "자원 능력치";
                default: return "유틸리티 능력치";
            }
        }
        // The three lines this game has nothing to spend: the hero is never crowd controlled and
        // never spends stamina. They are shown greyed with the reason rather than hidden, so that
        // a sheet read beside Diablo IV's own is not missing rows without explanation.
        static bool Inert(StatId id)
            =>id==StatId.CrowdControlDuration||id==StatId.MaximumStamina||id==StatId.StaminaRegeneration;

        // Fifty-seven lines are more than a screen can hold, so the ones a character has nothing in
        // are folded away by default. They are one button from view, because seeing what is still
        // unearned is half of what this screen is for.
        bool attributesShowEmpty;
        RunState attributesPauseRun;
        bool attributesWasPaused;

        public void ShowAttributes()
        {
            var combat=game.Combat;var run=combat?.State;
            // Redrawing this page must not replace the pause state captured on entry.
            if(Page!="attributes"||attributesPauseRun!=run){attributesPauseRun=run;attributesWasPaused=run?.paused??false;}
            bool paused=attributesWasPaused;if(run!=null)run.paused=true;
            var hero=combat?.Hero??game.Store.Data.Hero;
            var stats=combat?.Stats??new HeroStats(hero);
            int level=combat?.EffectiveLevel??hero.level;
            pageRepaint=()=>ShowAttributes();
            Base("attributes","능력치",Loc.F("{0} Lv.{1} · 장비와 능력치가 만든 값입니다", game.catalog.classNames[(int)hero.heroClass], level));
            Note(content,"핵심 능력치가 나머지 줄을 만듭니다. 힘은 방어도를, 민첩성은 회피를, 지능은 저항을, 의지력은 받는 치유와 압도 피해를 올립니다.",19,86,pale);
            int folded=0;
            foreach(StatPage page in Enum.GetValues(typeof(StatPage)))
            {
                var shown=StatCatalog.Page(page).Where(s=>attributesShowEmpty||Mathf.Abs(stats.Sheet(s.id))>=.0001f).ToList();
                folded+=StatCatalog.Page(page).Count()-shown.Count;
                if(shown.Count==0)continue;
                Note(content,PageTitle(page),24,52,gold);
                foreach(var stat in shown)
                {
                    bool inert=Inert(stat.id);
                    float value=stats.Sheet(stat.id);
                    string line=Loc.F("{0}   {1}", stat.Name, stat.FormatSheet(value));
                    if(inert)line+=Loc.T("   · 이 게임에는 아직 적용되는 곳이 없습니다");
                    Note(content,line,20,44,inert||Mathf.Abs(value)<.0001f?muted:pale);
                }
            }
            // The label is a literal rather than a composed line: a button's object name is the text
            // it was created with, and lookups by name have to read the same in every language.
            if(attributesShowEmpty)BigButton(content,"아직 얻지 못한 줄 접기",()=>{attributesShowEmpty=false;ShowAttributes();});
            else if(folded>0)BigButton(content,"아직 얻지 못한 줄 보기",()=>{attributesShowEmpty=true;ShowAttributes();});
            FooterButton(0,2,"성장과 스킬",()=>{if(run!=null)run.paused=paused;ShowGrowth();});
            FooterButton(1,2,run==null?"성소로":game.Active?"전투로 돌아가기":"결과로 돌아가기",()=>
            {if(run!=null)run.paused=paused;if(run==null)ShowTown();else if(game.Active)ShowBattle();else ShowResult();});
        }
    }
}
