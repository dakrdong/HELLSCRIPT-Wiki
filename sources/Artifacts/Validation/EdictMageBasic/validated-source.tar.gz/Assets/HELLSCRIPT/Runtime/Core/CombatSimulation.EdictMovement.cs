using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        float EdictDistance(Dictionary<string,string> values)=>values["position.distanceSource"]=="BASIC_RANGE"?(Hero.heroClass==HeroClass.Warrior?2:10):float.Parse(values["position.distance"],CultureInfo.InvariantCulture);
        IEnumerable<Vector2> EdictRadialPoints(float maximum,float step=2)
        {
            for(float distance=step;distance<=maximum+.0001f;distance+=step)
                for(int n=0;n<24;n++)yield return State.position+EnemyCombat.Rotate(Vector2.up,n*15)*distance;
        }
        Vector2? EdictEscapePoint(HuntEdictV2Document d,Dictionary<string,string> values,int skill,float maximum,EnemyState[] seen,EnemyState target,Func<Vector2,EdictSurvivalAssessment> risk,bool ordinary,bool adjustDistance=false)
        {
            string preference=skill==9?HuntEdictV2.Value(d,"A04",3):skill==15?HuntEdictV2.Value(d,"M04",3):"SAFE";
            bool noDamage=skill==15&&HuntEdictV2.Value(d,"M04",4)=="NO_DAMAGE";float desired=EdictDistance(values);
            var traps=State.traps.Where(t=>string.IsNullOrEmpty(t.casterId)||t.casterId==State.heroId).ToArray();
            if(preference=="OWN_TRAP"&&traps.Length==0||preference=="DISTANCE"&&target==null)preference="SAFE";
            bool Purpose(Vector2 p)
            {
                if(skill==15&&adjustDistance)return target!=null&&Mathf.Abs(Vector2.Distance(p,target.position)-desired)<=Mathf.Abs(Vector2.Distance(State.position,target.position)-desired)-2+.0001f;
                if(skill!=9||!ordinary)return true;string purpose=HuntEdictV2.Value(d,"A04",2);
                if(purpose=="DISTANCE")return Mathf.Abs(Vector2.Distance(p,target.position)-desired)<=Mathf.Abs(Vector2.Distance(State.position,target.position)-desired)-2+.0001f;
                if(purpose=="PIERCE_LINK")return Vector2.Distance(p,target.position)<=10&&Map.ProjectileClear(p,target.position,.3f)&&ForecastAttack(new Rule(6){action=RuleAction.Skill},target,origin:p,observed:seen).HitsOn(target.id)>0;
                return true;
            }
            var candidates=EdictRadialPoints(maximum).Where(p=>Map.CanLand(p)&&Map.LineClear(State.position,p)&&!seen.Any(e=>Vector2.Distance(e.position,p)<(e.boss?1.2f:.4f)+.45f)&&Purpose(p)).Select(p=>new{point=p,a=risk(p)}).
                Where(c=>!c.a.DodgeRequested&&!c.a.lethal&&(!noDamage||!c.a.forecast.hits.Any(h=>h.after<=EdictSurvivalLookAhead+.00001f&&h.finalDamage>0))).ToArray();
            float Score(Vector2 p)=>preference=="SPARSE"?seen.Count(e=>Vector2.Distance(e.position,p)<=3&&Map.LineClear(p,e.position)):
                preference=="DISTANCE"?Mathf.Abs(Vector2.Distance(p,target.position)-desired):preference=="OWN_TRAP"?traps.Min(t=>Vector2.Distance(t.position,p)):risk(p).forecast.HpLossThrough(EdictSurvivalLookAhead);
            var selected=candidates.OrderBy(c=>Score(c.point)).ThenBy(c=>c.a.forecast.HpLossThrough(EdictSurvivalLookAhead))
                .ThenBy(c=>seen.Count(e=>Vector2.Distance(e.position,c.point)<=3&&Map.LineClear(c.point,e.position)))
                .ThenByDescending(c=>target==null?0:Vector2.Distance(c.point,target.position)).ThenBy(c=>(c.point-State.position).sqrMagnitude).ThenBy(c=>c.point.x).ThenBy(c=>c.point.y).FirstOrDefault();
            return selected==null?(Vector2?)null:selected.point;
        }
        EdictResponseCandidate EdictSurvivalWalk(EdictSurvivalAssessment assessment,EnemyState[] seen,EnemyState target,Func<Vector2,EdictSurvivalAssessment> risk)
        {
            EdictResponseCandidate No(string code,string detail)=>new EdictResponseCandidate("WALK","",-1,-1,State.position,0,code,detail);
            if(!EdictCanInterrupt(assessment))return No("ACTION_LOCK","현재 행동 구간에서는 보행으로 전환할 수 없습니다.");
            float speed=MovementSpeed(false)*(State.enemySlowTime>0?.65f:1);if(speed<=0)return No("NO_PATH","현재 보행 속도로 이동할 수 없습니다.");
            var keys=new HashSet<string>(assessment.dodgeReasons.Select(r=>r.sourceKey));bool overlap=keys.Contains("OVERLAP");
            float deadline=assessment.forecast.hits.Where(h=>overlap||keys.Contains(h.sourceKey)).Select(h=>h.after).DefaultIfEmpty(float.PositiveInfinity).Min();
            float nearest=seen.Select(e=>Vector2.Distance(e.position,State.position)).DefaultIfEmpty(float.PositiveInfinity).Min();
            float loss=assessment.forecast.HpLossThrough(EdictSurvivalLookAhead);var candidates=new List<(Vector2 point,float length,float loss,float separation)>();
            foreach(var point in EdictRadialPoints(6,1))
            {
                if(!Map.CanLand(point)||!Map.LineClear(State.position,point)||seen.Any(e=>Vector2.Distance(e.position,point)<(e.boss?1.2f:.4f)+.45f))continue;
                var end=risk(point);if(end.DodgeRequested||end.lethal)continue;
                float hp=end.forecast.HpLossThrough(EdictSurvivalLookAhead),separation=seen.Select(e=>Vector2.Distance(e.position,point)).DefaultIfEmpty(float.PositiveInfinity).Min();
                if(!assessment.DodgeRequested&&!(hp<loss-.0001f)&&!(seen.Length>0&&separation>nearest+.5f))continue;
                var path=Map.FindPath(State.position,point);if(path==null)continue;float length=RiftNavigation.Length(path);if(float.IsInfinity(length)||length/speed>6)continue;
                // Existing danger can be exited; do not choose a route through an additional
                // observed danger forbidden by the same global policy. This is conservative,
                // not a future moving-body collision simulation or a promise of no damage.
                bool safe=true;
                for(int i=1;i<path.Count&&safe;i++)
                {
                    int count=Mathf.Max(1,Mathf.CeilToInt(Vector2.Distance(path[i-1],path[i])/.5f));
                    for(int n=1;n<=count;n++)
                    {
                        var p=Vector2.Lerp(path[i-1],path[i],n/(float)count);var a=risk(p);
                        if(a.dodgeReasons.Any(r=>r.sourceKey!="OVERLAP"&&!keys.Contains(r.sourceKey))||a.lethal&&!assessment.lethal){safe=false;break;}
                    }
                }
                if(safe)candidates.Add((point,length,hp,separation));
            }
            if(candidates.Count==0)return No("NO_PATH","전역 위험 기준을 만족하며 위험을 줄이는 보행 경로가 없습니다.");
            var best=candidates.OrderBy(c=>c.loss).ThenBy(c=>c.length).ThenByDescending(c=>c.separation).ThenBy(c=>c.point.x).ThenBy(c=>c.point.y).First();float arrival=best.length/speed;
            return new EdictResponseCandidate("WALK","",-1,target?.id??-1,best.point,0,"READY",arrival+Step<deadline?"첫 감지 피격 전에 도착 가능한 후퇴 경로입니다.":"도착 전에 피격될 수 있는 후퇴 경로입니다.",true,arrival+Step<deadline,arrival);
        }
    }
}
