using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Opt-in native UI/save evidence. Enemy positions and simulation time are controlled fixtures;
    // option edits, saving, drawing and resuming use the actual player code.
    public sealed class RuntimeShieldSmoke:MonoBehaviour
    {
        GameController game;
        string directory,saveDirectory;
        int capture;
        readonly List<string> failures=new List<string>();
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Install()
        {
            if(!Debug.isDebugBuild||!Environment.GetCommandLineArgs().Contains("-hellscriptShieldEdictSmoke"))return;
            Application.runInBackground=true;
            Application.logMessageReceived+=(message,stack,type)=>{if(type==LogType.Exception)Application.Quit(1);};
            new GameObject("Shield edict validation").AddComponent<RuntimeShieldSmoke>();
        }
        static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
        void Check(bool condition,string message){if(!condition)failures.Add(message);}
        static string Json(object value)=>JsonUtility.ToJson(value);
        Button[] Buttons=>game.UI.GetComponentsInChildren<Button>();
        void Click(string name){var b=Buttons.Single(b=>b.name==name);Require(b.IsInteractable(),"Disabled: "+name);b.onClick.Invoke();}
        void Choice(string label){var b=Buttons.Single(b=>b.name.Contains(label));Require(b.IsInteractable(),"Disabled: "+label);b.onClick.Invoke();}
        void Skills(){game.UI.ShowEdictEditor();Click("스킬 설정");Click("원소 보호막");}
        string[] Lines()=>game.UI.GetComponentsInChildren<Text>().Select(t=>t.text).ToArray();
        static int Starts(CombatSimulation sim)=>sim.State.statistics.skills.SingleOrDefault(s=>s.definitionId=="M05")?.starts??0;
        void Advance(int ticks)
        {game.Combat.State.paused=false;for(int i=0;i<ticks;i++)game.Combat.Tick(CombatSimulation.Step);game.World.Present(game.Combat.State,.05f);game.UI.RefreshHud();}
        void Enemy(float x,float y,int kind=0,int elite=-1)
        {
            var run=game.Combat.State;
            run.enemies.Add(new EnemyState{id=900+run.enemies.Count,kind=kind,elite=elite,position=run.position+new Vector2(x,y),health=1000000,maxHealth=1000000,speed=0,attack=0,cooldown=1000});
        }
        IEnumerator Capture(string name,int width,int height,string focus=null)
        {
            Screen.SetResolution(width,height,FullScreenMode.Windowed);float deadline=Time.realtimeSinceStartup+6;
            while((Screen.width!=width||Screen.height!=height)&&Time.realtimeSinceStartup<deadline)yield return null;
            Require(Screen.width==width&&Screen.height==height,"Native resize failed: "+name);
            yield return new WaitForSecondsRealtime(.3f);
            if(focus!=null)
            {
                var line=game.UI.GetComponentsInChildren<Text>().First(t=>t.text.Contains(focus));
                DialogReadingAnchor.Show(line.rectTransform);yield return new WaitForSecondsRealtime(.2f);
            }
            Canvas.ForceUpdateCanvases();
            foreach(var line in game.UI.GetComponentsInChildren<Text>())
                Check(line.preferredHeight<=line.rectTransform.rect.height+1,"Clipped on "+name+": "+line.text);
            var safe=UiSafeArea.Current;var corners=new Vector3[4];
            foreach(var button in Buttons.Where(b=>b.transform.parent.name=="Footer"))
            {((RectTransform)button.transform).GetWorldCorners(corners);Check(corners.All(c=>c.x>=safe.xMin-1&&c.x<=safe.xMax+1&&c.y>=safe.yMin-1&&c.y<=safe.yMax+1),"Footer outside safe area: "+name+" / "+button.name);}
            var missing=Loc.Missing.Where(key=>!LanguageOptions.All.Any(o=>o.NativeName==key)).ToArray();
            Check(missing.Length==0,"Missing translation: "+string.Join("; ",missing));
            ScreenCapture.CaptureScreenshot(Path.Combine(directory,$"{++capture:00}-{name}.png"));yield return new WaitForSecondsRealtime(.2f);
        }
        static void Controlled(CombatSimulation sim)
        {
            sim.Stats.armor=sim.Stats.resistance=sim.Stats.regen=sim.Stats.crit=sim.Stats.costReduction=0;
            for(int i=(int)StatId.VulnerableDamage;i<StatCatalog.Count;i++)sim.Stats.bonuses[i]=0;
            sim.Stats.dodge=sim.Stats.blockChance=sim.Stats.blockedReduction=sim.Stats.lifeRegen=sim.Stats.damageReduction=sim.Stats.closeReduction=sim.Stats.distantReduction=sim.Stats.injuredReduction=sim.Stats.physicalReduction=0;
        }
        void Pulse(float damage)
        {
            var run=game.Combat.State;int id=run.nextId++;
            run.enemyHazards.Add(new EnemyHazard{id=id,actionId=id,enemyId=900,definitionId="SHIELD_SMOKE",position=run.position,shape=AttackShape.Circle,radius=2,damage=damage,createdAt=-1});Advance(1);
        }
        void Finish(string stage,string detail)
        {
            string result=failures.Count==0?"PASS: "+detail+" Controlled native UI/combat fixtures; not mobile-device or natural-play balance validation.":string.Join("\n",failures);
            File.WriteAllText(Path.Combine(directory,stage+"-result.txt"),result+"\n");Debug.Log(failures.Count==0?"HELLSCRIPT_SHIELD_"+stage.ToUpperInvariant()+"_OK":"HELLSCRIPT_SHIELD_RUNTIME_FAIL\n"+result);Application.Quit(failures.Count==0?0:1);
        }
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();int save=Array.IndexOf(args,"-hellscriptSavePath"),outIndex=Array.IndexOf(args,"-hellscriptScreenshots");
            Require(save>=0&&save+1<args.Length&&outIndex>=0&&outIndex+1<args.Length,"Use dedicated save and evidence paths.");
            saveDirectory=args[save+1];directory=args[outIndex+1];Directory.CreateDirectory(directory);
            yield return new WaitForSecondsRealtime(1);game=FindAnyObjectByType<GameController>();Require(game?.Store!=null,"Store unavailable.");game.enabled=false;
            if(args.Contains("-hellscriptShieldEdictAbsorbResume")){yield return AbsorbResume();yield break;}
            if(args.Contains("-hellscriptShieldEdictResume")){yield return Resume();yield break;}
            Require(game.Store.Data.heroes.All(h=>h.level==1)&&game.Store.Data.suspendedRun==null,"Use a fresh test account.");
            game.SelectHero(2);var hero=game.Store.Data.Hero;hero.level=30;hero.inventory.Clear();game.Store.Data.guide.hintsHidden=true;
            hero.build.activeSkills=new List<int>{16};hero.build.passives=new[]{3};hero.build.autoRepeat=false;
            hero.build.rules=new List<Rule>{BehaviorRules.Make(16,BehaviorRules.C("SC06",Comparison.AtLeast,99,predicted:true))};
            uint rng=73105;var item=ItemGenerator.Create(HeroClass.Mage,ItemCatalog.Unique("LM03").slot,3,30,ref rng,uniqueId:"LM03");hero.inventory.Add(item);Require(Economy.Equip(hero,item),"LM03 did not equip.");
            hero.edict=HuntEdictV2.WithOption(HuntEdictV2Storage.CreateForHero(hero),"BASIC",1,"OFF");
            foreach(var pair in new[]{("position.mode","STAND"),("survival.potion","OFF"),("survival.lowHp","OFF"),("survival.lethal","OFF")})hero.edict=HuntEdictV2Editing.WithGlobal(hero.edict,pair.Item1,pair.Item2);
            game.Save();string original=Json(hero.edict);Skills();
            yield return Capture("options-ko",1280,720,"자동 사용");game.ApplyLanguage("en");yield return Capture("options-en",1280,720,"Automatic use");game.ApplyInterfaceScale(140);
            yield return Capture("options-large-en",720,1280,"The opening shield");yield return Capture("options-small-en",640,360,"The opening shield");game.ApplyLanguage("ko");
            yield return Capture("options-large-ko",720,1280,"일반 사용을 허용할 교전");game.ApplyInterfaceScale(100);
            Choice("방어 시점");Choice("다른 보호막이 있을 때");Choice("다른 보호막이 있을 때");Choice("일반 사용을 허용할 교전");Choice("일반 사용을 허용할 교전");Choice("일반 사용을 허용할 교전");
            Require(Json(hero.edict)==original,"Draft changed the saved hero.");Click("저장 및 적용");
            Require(HuntEdictV2.Value(hero.edict,"M05",2)=="ENGAGE"&&HuntEdictV2.Value(hero.edict,"M05",3)=="TOGETHER"&&HuntEdictV2.Value(hero.edict,"M05",4)=="ALL","Options did not save.");
            Require(Json(new GameStore(saveDirectory,game.catalog).Data.Hero.edict)==Json(hero.edict),"Saved options disagree with a fresh file read.");
            Click("공유");Click("사냥 칙령 v0.2 사용하기");Require(hero.useEdict,"Edict did not enable.");
            game.BeginDeveloperTraining(1);var sim=game.Combat;Require(sim!=null&&sim.EdictActive,"Training unavailable.");Controlled(sim);sim.State.resource=60;sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();sim.State.exploration.enemies.Clear();Enemy(0,2);
            game.World.BuildDungeon(sim.State);Advance(1);
            Require(Starts(sim)==1&&sim.State.heroAction.skill==16&&sim.State.heroAction.phase==HeroActionPhase.Preparing,"Opening shield did not prepare.");
            Require(sim.State.shields.Count==0&&Mathf.Abs(sim.State.resource-60)<.001f&&sim.State.edictEngagement.openingChecked,"Shield appeared early, committed incorrectly or lost its opening review.");
            string action=Json(sim.State.heroAction);Skills();Choice("다른 보호막이 있을 때");Choice("일반 사용을 허용할 교전");Choice("일반 사용을 허용할 교전");Choice("방어 시점");Choice("자동 사용");Click("저장 및 적용");
            Require(HuntEdictV2.Value(hero.edict,"M05",1)=="OFF"&&HuntEdictV2.Value(hero.edict,"M05",2)=="EMERGENCY"&&action==Json(sim.State.heroAction),"Editing rewrote committed preparation.");
            game.UI.ShowBattle();yield return Capture("preparation-before-restart",1280,720);sim.State.training=-1;sim.State.paused=false;game.Save();
            File.WriteAllText(Path.Combine(directory,"expected-run.json"),Json(sim.State));File.WriteAllText(Path.Combine(directory,"expected-edict.json"),Json(hero.edict));
            Finish("checkpoint","Actual UI edited ENGAGE, stacking and encounter options; drafts and file save agree. M05 began despite a blocked legacy row, spent zero resource and retained preparation after EMERGENCY/AFTER/BOSS/OFF edits.");
        }
        CombatSimulation BeginSaved(string expectedFile)
        {
            var expected=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(directory,expectedFile)));
            Require(Json(game.Store.Data.Hero.edict)==File.ReadAllText(Path.Combine(directory,"expected-edict.json")),"Saved edict was lost.");
            Require(game.Store.Data.suspendedRun!=null,"Pending run was lost.");game.Begin(resume:true);var sim=game.Combat;Require(sim?.EdictActive==true,"Saved run did not resume.");Controlled(sim);
            Require(sim.State.time==expected.time&&sim.State.resource==expected.resource&&Json(sim.State.heroAction)==Json(expected.heroAction)&&sim.State.shields.Select(s=>Json(s)).SequenceEqual(expected.shields.Select(s=>Json(s)))&&Json(sim.State.edictEngagement)==Json(expected.edictEngagement),"Saved shield, opening or action changed.");
            Require(sim.Stats.specials.Contains("LM03"),"Actual equipped LM03 was not restored.");return sim;
        }
        IEnumerator Resume()
        {
            var sim=BeginSaved("expected-run.json");Advance(4);var shield=sim.State.shields.Single(s=>s.definitionId=="M05");
            Require(Mathf.Abs(shield.amount-sim.Stats.hp*.35f*sim.Stats.shieldMultiplier)<.01f&&Starts(sim)==1&&sim.State.resource==60,"Shield generation or payment disagrees.");
            Require(sim.State.actionEvents.Count(e=>e.skill==16&&e.kind=="ACTION_RELEASE")==1,"Shield released more than once.");
            game.UI.ShowBattle();yield return Capture("shield-after-restart",1280,720);game.UI.ShowRuleDecisions();game.ApplyLanguage("en");game.ApplyInterfaceScale(140);
            yield return Capture("resume-decisions-en",640,360,"Elemental Shield hunt edict");game.ApplyLanguage("ko");yield return Capture("resume-decisions-ko",720,1280,"원소 보호막 사냥 칙령");
            Click("전투로 돌아가기");Check(!sim.State.paused,"Decision screen lost its running entry state.");sim.State.paused=true;game.UI.ShowRuleDecisions();game.ApplyLanguage("en");Click("전투로 돌아가기");Check(sim.State.paused,"Decision screen lost its paused entry state.");
            Pulse(shield.createdMaxHp*.1f);Require(Mathf.Abs(shield.absorbed-shield.createdMaxHp*.1f)<.01f&&!shield.manaPaid&&sim.State.resource==60,"Partial actual absorption incorrectly paid mana.");
            game.ApplyLanguage("ko");game.ApplyInterfaceScale(100);game.UI.ShowCombatEffects();yield return Capture("partial-absorption",1280,720,"누적 흡수");Click("전투로 돌아가기");Check(!sim.State.paused,"Partial shield details lost the running entry state.");
            sim.State.paused=false;game.Save();File.WriteAllText(Path.Combine(directory,"expected-shield-run.json"),Json(sim.State));
            Finish("shield","Independent restart released the original committed shield once with actual willpower/MP04 scaling. A real hazard absorbed 10% of creation HP without LM03 reward; its partial absorption and opening record were saved for another process.");
        }
        IEnumerator AbsorbResume()
        {
            var sim=BeginSaved("expected-shield-run.json");var shield=sim.State.shields.Single(s=>s.definitionId=="M05");Require(!shield.manaPaid,"LM03 had already paid.");
            Pulse(shield.createdMaxHp*.05f);Require(shield.manaPaid&&Mathf.Abs(sim.State.resource-80)<.001f&&sim.State.itemEffects.lm03Cooldown>3.9f,"LM03 failed to pay once at 15% actual absorption.");
            Require(sim.State.effectEvents.Count(e=>e.definitionId=="LM03"&&e.kind=="RESOURCE")==1,"LM03 reward duplicated.");game.UI.ShowCombatEffects();game.ApplyLanguage("en");game.ApplyInterfaceScale(140);yield return Capture("lm03-paid-after-restart",720,1280,"Absorbed so far");Click("전투로 돌아가기");Check(!sim.State.paused,"Shield details lost the running entry state after language/scale changes.");sim.State.paused=true;game.UI.ShowCombatEffects();game.ApplyLanguage("ko");Click("전투로 돌아가기");Check(sim.State.paused,"Shield details lost the manually paused entry state.");game.ApplyInterfaceScale(100);
            Pulse(shield.createdMaxHp*.05f);Require(sim.State.resource==80,"Repeated absorption paid LM03 twice.");Advance(90);Require(Starts(sim)==1&&!sim.State.shields.Any(s=>s.definitionId=="M05"),"OFF repeated or shield failed to expire.");
            Skills();Choice("자동 사용");Choice("방어 시점");Choice("방어 시점");Choice("다른 보호막이 있을 때");Choice("일반 사용을 허용할 교전");Click("저장 및 적용");
            Require(HuntEdictV2.Value(game.Store.Data.Hero.edict,"M05",2)=="ENGAGE","Opening setting did not return.");sim.State.cooldowns[16]=0;Advance(5);
            Require(Starts(sim)==1&&sim.State.edictEngagement.openingChecked,"Editing or restarting granted a second opening in the same encounter.");
            game.UI.ShowBattle();yield return Capture("opening-not-repeated",1280,720);File.WriteAllText(Path.Combine(directory,"final-run.json"),Json(sim.State));
            Finish("resume","Second independent restart retained partial absorption and original creation HP. Real hazard damage reached 15%, paying LM03 exactly 20 resource once with a 4-second internal cooldown. OFF and re-enabled ENGAGE did not repeat the same encounter opening.");
        }
    }
}
