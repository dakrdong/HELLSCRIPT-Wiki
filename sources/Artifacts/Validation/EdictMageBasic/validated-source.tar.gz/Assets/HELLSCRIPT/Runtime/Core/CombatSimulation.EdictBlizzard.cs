using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public sealed partial class CombatSimulation
    {
        bool LiveOwnBlizzard(GroundEffect fx)=>OwnBlizzard(fx)&&fx.duration>.00001f&&fx.createdAt<=State.time+.00001f;
        bool BlizzardCovers(GroundEffect fx,EnemyState enemy)=>fx.delay<=.00001f&&
            Vector2.Distance(fx.position,enemy.position)<=fx.radius&&Map.LineClear(fx.position,enemy.position);

        // Include circle intersections: enemy centers and pair midpoints alone miss three
        // enemies on a triangle. Range-circle intersections keep edge-of-range groups usable.
        static IEnumerable<Vector2> CircleCenters(Vector2 a,float ar,Vector2 b,float br)
        {
            Vector2 offset=b-a;float distance=offset.magnitude;
            if(distance<.00001f||distance>ar+br||distance<Mathf.Abs(ar-br))yield break;
            float along=(ar*ar-br*br+distance*distance)/(2*distance);
            Vector2 unit=offset/distance,center=a+unit*along;
            float height=Mathf.Sqrt(Mathf.Max(0,ar*ar-along*along));
            Vector2 normal=new Vector2(-unit.y,unit.x)*height;
            yield return center+normal;yield return center-normal;
        }
        IEnumerable<Vector2> BlizzardCenters(EnemyState[] seen)
        {
            yield return State.position;
            for(int i=0;i<seen.Length;i++)
            {
                Vector2 a=seen[i].position;yield return a;
                yield return Vector2.MoveTowards(State.position,a,10);
                // A target can stand on landing-only terrain. Keep a near-side alternative
                // even when there is no second enemy from which to construct a midpoint.
                yield return Vector2.MoveTowards(a,State.position,2.9999f);
                foreach(var p in CircleCenters(a,2.9999f,State.position,9.9999f))yield return p;
                for(int j=i+1;j<seen.Length;j++)
                {
                    Vector2 b=seen[j].position;if(Vector2.Distance(a,b)>6)continue;
                    yield return (a+b)*.5f;
                    foreach(var p in CircleCenters(a,2.9999f,b,2.9999f))yield return p;
                }
            }
        }
        EdictAimPlan PlanEdictBlizzard(HuntEdictV2Document document,EnemyState globalTarget,EnemyState[] perceived)
        {
            string V(int n)=>HuntEdictV2.Value(document,"M02",n);
            var seen=perceived.Where(EdictTargetEligible).ToArray();
            var target=seen.FirstOrDefault(e=>e==globalTarget)??seen.OrderBy(e=>(e.position-State.position).sqrMagnitude).ThenBy(e=>e.id).FirstOrDefault();
            EdictAimPlan No(string reason,string code="EDICT_AIM")=>new EdictAimPlan(true,false,reason,null,target?.id??-1,code);
            if(target==null)return No("현재 감지한 대상이 없습니다.","NO_TARGET");
            var fields=State.effects.Where(LiveOwnBlizzard).ToArray();
            if(V(4)=="KEEP"&&fields.Length>=2)return No("유효한 자기 눈보라 두 개를 보존합니다.");
            var covered=new HashSet<int>(seen.Where(e=>fields.Any(f=>BlizzardCovers(f,e))).Select(e=>e.id));
            float remaining=fields.Where(f=>BlizzardCovers(f,target)).Select(f=>f.duration).DefaultIfEmpty(0).Max();
            var rule=EdictRuleOrder.BlizzardRule(document);
            var points=(V(3)=="DENSE"?BlizzardCenters(seen):new[]{GroundAim(rule,target,seen)}).Distinct().ToArray();
            var inRange=points.Where(p=>Finite(p)&&Vector2.Distance(State.position,p)<=10+.0001f).ToArray();
            if(inRange.Length==0)return No(Loc.F("스킬 사거리 {0}m 밖",10),"RANGE");
            var legal=inRange.Where(p=>Map.CanLand(p,.1f)&&Map.LineClear(State.position,p)).ToArray();
            if(legal.Length==0)return No("장판을 설치할 수 없는 위치","LANDING");
            var candidates=legal.Select(p=>new AttackForecast(State.position,p,p,
                seen.Where(e=>Vector2.Distance(p,e.position)<=3&&Map.LineClear(p,e.position)).Select(e=>e.id)));
            bool MeetsPurpose(AttackForecast forecast)
            {
                if(V(2)=="KEEP_TARGET")return forecast.HitsOn(target.id)>0&&remaining<=1+.00001f;
                return forecast.uniqueTargets>=(V(2)=="GROUP"?3:1)&&forecast.hits.Any(id=>!covered.Contains(id));
            }
            var chosen=candidates.Where(MeetsPurpose).OrderByDescending(f=>f.uniqueTargets)
                .ThenBy(f=>(f.aim-target.position).sqrMagnitude).ThenBy(f=>(f.aim-State.position).sqrMagnitude)
                .ThenBy(f=>f.aim.x).ThenBy(f=>f.aim.y).FirstOrDefault();
            if(chosen==null)return No(V(2)=="KEEP_TARGET"?"현재 대상을 덮는 설치 위치가 없거나 기존 눈보라가 1초 넘게 남아 있습니다.":
                V(2)=="GROUP"?"예상 대상 3명과 기존 눈보라 밖의 대상이 필요합니다.":"기존 눈보라 밖의 적을 덮는 설치 위치가 없습니다.");
            string reason=V(5)=="FOLLOW"&&!Stats.specials.Contains("LM01")?"LM01이 없어 새 눈보라를 위치 고정으로 설치합니다.":"눈보라의 설치 목적과 기존 영역을 확인했습니다.";
            return new EdictAimPlan(true,true,reason,chosen,target.id);
        }
    }
}
