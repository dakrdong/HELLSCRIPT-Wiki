using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace Hellscript.Editor
{
    // Observes the production generator. The independent probability model enumerates
    // weighted group selections, without calling the generator's allocation/pick helpers.
    public static class AffixDistributionValidation
    {
        [Serializable] public sealed class ProbabilityCheck
        {
            public string id;
            public int observed,trials;
            public double probability,expected,residual,limit;
            public bool passed;
        }
        [Serializable] public sealed class Cell
        {
            public int heroClass,slot,rarity,samples,rolls,newRolls,itemsWithNewAffixes;
            public uint seed,finalRng;
            public double wallSeconds;
            public List<ProbabilityCheck> affixes=new List<ProbabilityCheck>();
            public List<ProbabilityCheck> allocations=new List<ProbabilityCheck>();
            public List<ProbabilityCheck> tiers=new List<ProbabilityCheck>();
        }
        [Serializable] public sealed class Header
        {
            public int schema=1,itemLevel=30,samplesPerCell,expectedCells=96,completedCells,failedChecks;
            public long completedItems;
            public string profile,status="running",createdUtc;
            public double wallSeconds;
            public string scope="Actual ItemGenerator.Create, all 3 classes x 8 slots x 4 rarities at item level 30. Each affix/side allocation is an item-level inclusion probability, not a share of rolls. Tier probabilities are per roll. Independent weighted-group model; no player saves or runtime overrides. Fixed pseudorandom samples are diagnostics, not a proof of RNG independence.";
            public string tolerance="Two-sided Bernstein bound with per-check alpha 1e-8; exact zero/one probabilities are checked exactly. Unexpected or missing affixes and illegal items fail immediately.";
        }
        public sealed class Theory
        {
            public Dictionary<string,double> affixes=new Dictionary<string,double>();
            public double[] allocations=new double[25];
        }
        sealed class Group
        {
            public AffixDefinition[] entries;
            public double weight;
        }
        // Weighted sampling without replacement acts on whole groups. Within a chosen
        // group an affix receives its share of that group's weight.
        public static Dictionary<string,double> Inclusion(IReadOnlyList<AffixDefinition> pool,HeroClass heroClass,int draws)
        {
            var result=pool.ToDictionary(a=>a.id,_=>0d);
            var groups=pool.GroupBy(a=>a.group).Select(g=>new Group
            {entries=g.ToArray(),weight=g.Sum(a=>(double)a.Weight(heroClass))}).ToArray();
            if(draws<0||draws>groups.Length||groups.Any(g=>g.weight<=0))throw new ArgumentOutOfRangeException(nameof(draws));
            var used=new bool[groups.Length];
            void Visit(int remaining,double probability,double total)
            {
                if(remaining==0)return;
                for(int i=0;i<groups.Length;i++)
                {
                    if(used[i])continue;
                    var group=groups[i];double branch=probability*group.weight/total;
                    foreach(var affix in group.entries)result[affix.id]+=branch*affix.Weight(heroClass)/group.weight;
                    used[i]=true;Visit(remaining-1,branch,total-group.weight);used[i]=false;
                }
            }
            Visit(draws,1,groups.Sum(g=>g.weight));return result;
        }
        public static Theory Expected(IReadOnlyList<AffixDefinition> catalogue,HeroClass heroClass,int slot,int rarity)
        {
            if(slot<0||slot>7||rarity<0||rarity>3||(int)heroClass<0||(int)heroClass>2)throw new ArgumentOutOfRangeException();
            if(catalogue.GroupBy(a=>a.group).Any(g=>g.Select(a=>a.side).Distinct().Count()!=1))
                throw new InvalidOperationException("A group spans both affix sides.");
            var theory=new Theory();foreach(var a in catalogue)theory.affixes.Add(a.id,0);
            var prefixes=catalogue.Where(a=>a.Allows(slot)&&a.side==AffixSide.Prefix).ToArray();
            var suffixes=catalogue.Where(a=>a.Allows(slot)&&a.side==AffixSide.Suffix).ToArray();
            int prefixGroups=prefixes.Select(a=>a.group).Distinct().Count(),suffixGroups=suffixes.Select(a=>a.group).Distinct().Count();
            var possibilities=new List<(int p,int s,double weight)>();
            if(rarity==0)possibilities.Add((0,0,1));
            if(rarity==1){possibilities.Add((1,0,.25));possibilities.Add((0,1,.25));possibilities.Add((1,1,.5));}
            if(rarity==2){possibilities.Add((2,1,.5));possibilities.Add((1,2,.5));}
            if(rarity==3){possibilities.Add((2,2,.6));possibilities.Add((3,1,.2));possibilities.Add((1,3,.2));}
            // Normalize within each total-count branch; magic's count roll remains 50:50.
            foreach(var countGroup in possibilities.GroupBy(a=>a.p+a.s))
            {
                var valid=countGroup.Where(a=>a.p<=prefixGroups&&a.s<=suffixGroups).ToArray();
                double mass=countGroup.Sum(a=>a.weight),validMass=valid.Sum(a=>a.weight);
                if(validMass<=0)throw new InvalidOperationException("No feasible allocation.");
                foreach(var a in valid)
                {
                    double chance=mass*a.weight/validMass;theory.allocations[a.p*5+a.s]+=chance;
                    foreach(var pair in Inclusion(prefixes,heroClass,a.p))theory.affixes[pair.Key]+=chance*pair.Value;
                    foreach(var pair in Inclusion(suffixes,heroClass,a.s))theory.affixes[pair.Key]+=chance*pair.Value;
                }
            }
            return theory;
        }
        public static ProbabilityCheck Check(string id,int observed,int trials,double probability)
        {
            if(trials<0||observed<0||observed>trials||probability< -1e-12||probability>1+1e-12)throw new ArgumentOutOfRangeException();
            probability=Math.Max(0,Math.Min(1,probability));
            if(probability<1e-12)probability=0;if(probability>1-1e-12)probability=1;
            double expected=trials*probability,variance=expected*(1-probability),log=Math.Log(2e8);
            double limit=probability==0||probability==1?0:Math.Sqrt(2*variance*log)+2*log/3;
            return new ProbabilityCheck{id=id,observed=observed,trials=trials,probability=probability,expected=expected,
                residual=observed-expected,limit=limit,passed=Math.Abs(observed-expected)<=limit};
        }
        public static Cell Sample(HeroClass heroClass,int slot,int rarity,int samples)
        {
            if(samples<1)throw new ArgumentOutOfRangeException(nameof(samples));
            var theory=Expected(ItemCatalog.Affixes,heroClass,slot,rarity);
            uint seed=unchecked(0x714DA32Fu+(uint)((int)heroClass*32+slot*4+rarity)*0x9E3779B9u),rng=seed;
            var row=new Cell{heroClass=(int)heroClass,slot=slot,rarity=rarity,samples=samples,seed=seed};
            var counts=ItemCatalog.Affixes.ToDictionary(a=>a.id,_=>0);var allocations=new int[25];var tiers=new int[3];
            var clock=System.Diagnostics.Stopwatch.StartNew();
            for(int n=0;n<samples;n++)
            {
                var item=ItemGenerator.Create(heroClass,slot,rarity,30,ref rng,id:"distribution");
                int prefixes=0;bool hasNew=false;
                foreach(var roll in item.rolls)
                {
                    counts[roll.affixId]++;row.rolls++;
                    if(roll.side==AffixSide.Prefix)prefixes++;
                    if(int.Parse(roll.affixId.Substring(2))>=25){row.newRolls++;hasNew=true;}
                    int tier=roll.tierId=="T3"?0:roll.tierId=="T2"?1:roll.tierId=="T1"?2:-1;
                    if(tier<0)throw new InvalidOperationException("Unknown tier: "+roll.tierId);tiers[tier]++;
                }
                allocations[prefixes*5+item.rolls.Count-prefixes]++;
                if(hasNew)row.itemsWithNewAffixes++;
            }
            foreach(var pair in theory.affixes)row.affixes.Add(Check(pair.Key,counts[pair.Key],samples,pair.Value));
            for(int p=0;p<=4;p++)for(int s=0;s<=4;s++)row.allocations.Add(Check($"P{p}S{s}",allocations[p*5+s],samples,theory.allocations[p*5+s]));
            row.tiers.Add(Check("T3",tiers[0],row.rolls,.45));row.tiers.Add(Check("T2",tiers[1],row.rolls,.40));row.tiers.Add(Check("T1",tiers[2],row.rolls,.15));
            row.finalRng=rng;row.wallSeconds=clock.Elapsed.TotalSeconds;return row;
        }
        [MenuItem("HELLSCRIPT/접사 분포 검사")]
        public static void Run()
        {
            string profile=BuildIntegrationValidation.ValidateAffixProfile();
            string directory=Path.GetFullPath(BuildIntegrationValidation.AuditArgument("-hellscriptAuditOutput","Artifacts/Validation/AffixDistribution/"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmss")));
            int samples=BuildIntegrationValidation.AuditInteger("-hellscriptDistributionSamples",100000);
            Directory.CreateDirectory(directory);string headerPath=Path.Combine(directory,"distribution-header.json"),path=Path.Combine(directory,"cells.jsonl");
            if(File.Exists(headerPath)||File.Exists(path))throw new IOException("Use a new audit output directory.");
            var header=new Header{profile=profile,samplesPerCell=samples,createdUtc=DateTime.UtcNow.ToString("O")};
            var clock=System.Diagnostics.Stopwatch.StartNew();
            File.WriteAllText(headerPath,JsonUtility.ToJson(header,true));
            using(var output=new StreamWriter(new FileStream(path,FileMode.CreateNew,FileAccess.Write,FileShare.Read)))
            {
                output.AutoFlush=true;
                for(int c=0;c<3;c++)for(int slot=0;slot<8;slot++)for(int rarity=0;rarity<4;rarity++)
                {
                    var row=Sample((HeroClass)c,slot,rarity,samples);output.WriteLine(JsonUtility.ToJson(row));
                    header.completedCells++;header.completedItems+=samples;header.wallSeconds=clock.Elapsed.TotalSeconds;
                    header.failedChecks+=row.affixes.Concat(row.allocations).Concat(row.tiers).Count(check=>!check.passed);
                    File.WriteAllText(headerPath,JsonUtility.ToJson(header,true));
                    Debug.Log($"HELLSCRIPT_AFFIX_DISTRIBUTION_PROGRESS {profile} {header.completedCells}/96, failures={header.failedChecks}");
                }
            }
            header.status=header.failedChecks==0?"complete":"complete-with-deviations";header.wallSeconds=clock.Elapsed.TotalSeconds;
            File.WriteAllText(headerPath,JsonUtility.ToJson(header,true));
            if(header.failedChecks>0)throw new InvalidOperationException("Affix distribution deviated from the model. Inspect cells.jsonl.");
            Debug.Log($"HELLSCRIPT_AFFIX_DISTRIBUTION_COMPLETE {profile} {header.completedItems} items {header.wallSeconds:0.0}s");
        }
    }
}
