using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace Hellscript.Editor
{
    public static partial class BuildIntegrationValidation
    {
        [Serializable] public sealed class ChainTimeSample
        {
            public string phase;
            public float seconds,unseen,outsideFirstRange,chainAction,otherAction,cooldown,ready;
            public int chainReleases,chainHits,bossHits;
            public float chainHpDamage,bossHpDamage;
        }
        [Serializable] public sealed class ChainCastSample
        {
            public int root,firstTarget,firstKind,neighbors,reservedBonus,hits,uniqueHits;
            public bool firstBoss,firstElite,mp03,bossPhase;
            public float startedAt,releasedAt=-1,firstDistance,hpDamage;
            public string finish="pending";
            public string interruptionReason,replacementRule,replacementPhase,survivalRole;
            public string replacementDecision,replacementFinish="pending";
            public int replacementAction=-1,replacementHits;
            public float replacementDecisionAt=-1,replacementReleasedAt=-1;
            public List<int> replacementStatusTargets=new List<int>();
            public int replacementSkill=-2;
            public float interruptedAt=-1,hpPercentAtInterruption;
            public bool emergencyAtLastDecision,dodgeAtLastDecision,lowHpAtLastDecision,lethalAtLastDecision,heldAtLastDecision;
            public List<string> lastDodgeReasons=new List<string>();
            public List<int> hitIds=new List<int>();
        }
        [Serializable] public sealed class ChainDiagnosticRun
        {
            public string mode;
            public HuntEdictV2Document edict;
            public AuditedBalanceRun summary;
            public List<ChainTimeSample> phases=new List<ChainTimeSample>{new ChainTimeSample{phase="beforeBoss"},new ChainTimeSample{phase="boss"}};
            public List<ChainCastSample> casts=new List<ChainCastSample>();
        }
        [Serializable] sealed class ChainDiagnosticHeader
        {
            public int schema=4,stage,expectedRuns,completedRuns;
            public int[] seedIndices;
            public string[] modes;
            public string createdUtc,status="running",affixProfile,scope;
            public double wallSeconds;
        }
        public sealed class ChainObserver
        {
            public readonly ChainDiagnosticRun result=new ChainDiagnosticRun();
            readonly Dictionary<int,ChainCastSample> casts=new Dictionary<int,ChainCastSample>();
            readonly Dictionary<int,ChainCastSample> replacements=new Dictionary<int,ChainCastSample>();
            float actionThrough=-1,effectThrough=-1;
            int damageThrough=-1;
            public void Observe(CombatSimulation sim,float dt)
            {
                if(dt<=0){if(sim.EdictActive)result.edict=HuntEdictV2.Canonical(sim.Hero.edict);return;}
                var run=sim.State;bool bossPhase=run.bossId>=0;var phase=result.phases[bossPhase?1:0];phase.seconds+=dt;
                // Occupancy is sampled after each fixed step, not a causal attribution of idle time.
                var seen=run.enemies.Where(e=>!e.dead&&Vector2.Distance(run.position,e.position)<=12&&sim.Map.LineClear(run.position,e.position)).ToArray();
                if(sim.HeroActionBusy){if(run.heroAction.skill==14)phase.chainAction+=dt;else phase.otherAction+=dt;}
                else if(seen.Length==0)phase.unseen+=dt;
                else if(!seen.Any(e=>Vector2.Distance(run.position,e.position)<=10))phase.outsideFirstRange+=dt;
                else if(run.cooldowns[14]>0)phase.cooldown+=dt;
                else phase.ready+=dt;
                foreach(var action in run.actionEvents.Where(a=>a.time>actionThrough&&a.skill==14))
                {
                    if(action.kind=="ACTION_START")
                    {
                        var target=run.enemies.Find(e=>e.id==action.targetId);
                        var row=new ChainCastSample{root=action.actionId,firstTarget=action.targetId,startedAt=action.time,bossPhase=bossPhase,
                            reservedBonus=run.heroAction.chainBonus,mp03=sim.Stats.passives[2],firstKind=target?.kind??-1,firstBoss=target?.boss??false,firstElite=target?.elite>=0,
                            firstDistance=target==null?-1:Vector2.Distance(action.position,target.position),neighbors=target==null?0:seen.Count(e=>Vector2.Distance(target.position,e.position)<=4&&sim.Map.LineClear(target.position,e.position))};
                        casts.Add(row.root,row);result.casts.Add(row);
                    }
                    if(!casts.TryGetValue(action.actionId,out var cast))continue;
                    if(action.kind=="ACTION_RELEASE"){cast.releasedAt=action.time;cast.finish="released";phase.chainReleases++;}
                    if(action.kind=="ACTION_MISS")cast.finish="missed";
                    if(action.kind=="ACTION_INTERRUPTED")
                    {
                        cast.finish="interrupted";cast.interruptionReason=action.reason;cast.interruptedAt=action.time;
                        cast.hpPercentAtInterruption=100*run.health/sim.Stats.hp;
                        cast.replacementSkill=sim.HeroActionBusy?run.heroAction.skill:-2;
                        cast.replacementRule=run.heroAction.policy?.rule?.id??"";cast.replacementPhase=run.heroAction.phase.ToString();
                        if(cast.replacementRule=="edict:M06")
                        {
                            cast.replacementAction=run.heroAction.id;replacements[cast.replacementAction]=cast;
                            var decision=run.decisions.LastOrDefault(d=>d.ruleId==cast.replacementRule&&d.code=="SELECTED"&&Mathf.Abs(d.lastTime-action.time)<.00001f);
                            cast.replacementDecision=decision?.detail??"";cast.replacementDecisionAt=decision?.lastTime??-1;
                        }
                        // This is the last decision snapshot, not necessarily the exact cause of an
                        // interruption later in the tick. The action event retains the actual reason.
                        var plan=sim.LastEdictPlan;
                        if(plan!=null)
                        {
                            cast.emergencyAtLastDecision=plan.assessment.emergency;cast.dodgeAtLastDecision=plan.assessment.DodgeRequested;
                            cast.lowHpAtLastDecision=plan.assessment.lowHp;cast.lethalAtLastDecision=plan.assessment.lethal;cast.heldAtLastDecision=plan.assessment.heldForRecovery;
                            cast.survivalRole=plan.selected?.role??"";cast.lastDodgeReasons=plan.assessment.dodgeReasons.Select(r=>r.sourceKey+":"+r.code).ToList();
                        }
                    }
                }
                foreach(var action in run.actionEvents.Where(a=>a.time>actionThrough&&a.skill==17))
                    if(replacements.TryGetValue(action.actionId,out var replacement))
                    {
                        if(action.kind=="ACTION_RELEASE"){replacement.replacementReleasedAt=action.time;replacement.replacementFinish="released";}
                        if(action.kind=="ACTION_INTERRUPTED")replacement.replacementFinish="interrupted";
                        if(action.kind=="ACTION_MISS")replacement.replacementFinish="missed";
                    }
                actionThrough=run.time;
                foreach(var hit in run.damageEvents.Where(h=>h.id>damageThrough&&h.definitionId=="M03"&&!h.incoming))
                {
                    phase.chainHits++;phase.chainHpDamage+=hit.hpLoss;
                    if(run.enemies.Any(e=>e.id==hit.targetId&&e.boss)){phase.bossHits++;phase.bossHpDamage+=hit.hpLoss;}
                    if(casts.TryGetValue(hit.rootCastId,out var cast))
                    {cast.hits++;cast.hpDamage+=hit.hpLoss;if(!cast.hitIds.Contains(hit.targetId))cast.uniqueHits++;cast.hitIds.Add(hit.targetId);}
                }
                foreach(var hit in run.damageEvents.Where(h=>h.id>damageThrough&&h.definitionId=="M06"&&!h.incoming))
                    if(replacements.TryGetValue(hit.rootCastId,out var replacement))replacement.replacementHits++;
                // STATUS includes refreshes. These are applied freeze/stagger targets, not a
                // count of dangerous enemy casts prevented or a causal damage-saved estimate.
                foreach(var effect in run.effectEvents.Where(e=>e.time>effectThrough&&e.definitionId=="M06"&&(e.kind=="STATUS"||e.kind=="BOSS_STAGGER")))
                    if(replacements.TryGetValue(effect.rootCastId,out var replacement)&&!replacement.replacementStatusTargets.Contains(effect.targetId))replacement.replacementStatusTargets.Add(effect.targetId);
                effectThrough=run.time;
                if(run.damageEvents.Count>0)damageThrough=run.damageEvents[run.damageEvents.Count-1].id;
            }
        }
        // Explicit laboratory configuration, not a default or an automatically applied player preset.
        // Keep it fixed across code versions and preserve the whole document in each result.
        public static HuntEdictV2Document ConfigureChainSurvival(HuntEdictV2Document source)
        {
            var d=HuntEdictV2.Canonical(source);
            if(d.heroClass!="MAGE"||!d.slots.Contains("M04")||!d.slots.Contains("M05"))throw new ArgumentException("The survival comparison requires equipped Mage M04 and M05.");
            foreach(var pair in new[]{("survival.lowHp","ON"),("survival.lowHpPercent","30"),("survival.lethal","ON"),("survival.returnHpPercent","50"),
                ("survival.defenseSkill","M05"),("survival.escapeSkill","M04"),("survival.order","DEFENSE,ESCAPE,WALK"),("survival.fallback","OTHER_SKILL"),("survival.fallbackSkill","M05"),
                ("dodge.ground.policy","DAMAGE"),("dodge.ground.hpPercent","15"),("dodge.area.policy","DAMAGE"),("dodge.area.hpPercent","15"),("dodge.direct.policy","DAMAGE"),("dodge.direct.hpPercent","15"),("dodge.interrupt","CANCEL_ALLOWED")})
                d=HuntEdictV2Editing.WithGlobal(d,pair.Item1,pair.Item2);
            return d;
        }
        public static void RunChainDiagnostics()
        {
            string profile=ValidateAffixProfile();
            int stage=AuditInteger("-hellscriptAuditStage",20);
            string requested=AuditArgument("-hellscriptChainSeeds","0,1,2,3,4,5,9,14");
            var indices=requested.Split(',').Select(s=>int.TryParse(s,out int n)&&n>=0?n:throw new ArgumentException("Use nonnegative, comma-separated seed indices.")).ToArray();
            if(indices.Length==0||indices.Distinct().Count()!=indices.Length)throw new ArgumentException("Seed indices must be distinct.");
            var modes=Environment.GetCommandLineArgs().Contains("-hellscriptChainConfiguredSurvival")?new[]{"legacy","edict","survival-configured"}:new[]{"legacy","edict"};
            string directory=Path.GetFullPath(AuditArgument("-hellscriptAuditOutput","Artifacts/Validation/ChainDiagnostics/"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmss")));
            Directory.CreateDirectory(directory);string path=Path.Combine(directory,"runs.jsonl"),headerPath=Path.Combine(directory,"header.json");
            if(File.Exists(path)||File.Exists(headerPath))throw new IOException("Use a new diagnostic output directory.");
            var header=new ChainDiagnosticHeader{stage=stage,seedIndices=indices,modes=modes,expectedRuns=checked(indices.Length*modes.Length),createdUtc=DateTime.UtcNow.ToString("O"),affixProfile=profile,
                scope="Level-30 Chain Control with eight legal level-30 items, matched seeds and gear. Legacy rules, fresh default edicts with survival disabled, and optionally a separately specified survival configuration. Default documents do not translate legacy HP/danger conditions. Each active edict is saved in the result. Outcome-selected cases, not population win rates or isolated skill effects. End-of-50-ms occupancy samples and actual cast/damage events; no player-save or combat-stat overrides."};
            var clock=System.Diagnostics.Stopwatch.StartNew();var catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();
            try
            {
                File.WriteAllText(headerPath,JsonUtility.ToJson(header,true));
                using(var output=new StreamWriter(new FileStream(path,FileMode.CreateNew,FileAccess.Write,FileShare.Read)))
                {
                    output.AutoFlush=true;
                    foreach(int index in indices)foreach(string mode in modes)
                    {
                        var observer=new ChainObserver();observer.result.mode=mode;
                        observer.result.summary=AuditRun(catalog,HeroClass.Mage,1,stage,index,observer.Observe,mode!="legacy",mode=="survival-configured"?ConfigureChainSurvival:(Func<HuntEdictV2Document,HuntEdictV2Document>)null);
                        output.WriteLine(JsonUtility.ToJson(observer.result));header.completedRuns++;header.wallSeconds=clock.Elapsed.TotalSeconds;
                        File.WriteAllText(headerPath,JsonUtility.ToJson(header,true));Debug.Log($"HELLSCRIPT_CHAIN_DIAGNOSTIC {header.completedRuns}/{header.expectedRuns}");
                    }
                }
                header.status="complete";header.wallSeconds=clock.Elapsed.TotalSeconds;File.WriteAllText(headerPath,JsonUtility.ToJson(header,true));
                Debug.Log($"HELLSCRIPT_CHAIN_DIAGNOSTICS_COMPLETE {header.completedRuns} runs");
            }
            finally{UnityEngine.Object.DestroyImmediate(catalog);}
        }
    }
}
