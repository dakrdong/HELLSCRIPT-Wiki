using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace Hellscript.Editor
{
    public static partial class BuildIntegrationValidation
    {
        [Serializable] public sealed class AuditedBalanceRun
        {
            public int heroClass,variant,stage,seedIndex,ticks,kills,visited,chests,repaths,resourceChecks;
            public uint seed;
            public string outcome,finish,map,encounter,navigationError,objective;
            public float time,damage,hp,maxHp,baseDamage,bossSpawnTime=-1,bossRemainingHp,maxStationaryApproach;
            public bool bossSpawned,bossRewarded,gateOpen,gateOpenedByMeter;
            public float[] sheet;
            public List<Item> equipment=new List<Item>();
            public List<SkillStatistics> skills=new List<SkillStatistics>();
            public List<string> lastLogs=new List<string>();
        }
        [Serializable] public sealed class AuditHeader
        {
            public int schema=1,affixes,level=30,itemLevel=30,stage,seeds,expectedRuns,completedRuns;
            public string profile,status="running",createdUtc,scope;
            public double wallSeconds;
            public string[] affixIds;
            public string[] statIds=Enum.GetNames(typeof(StatId));
        }
        [Serializable] sealed class EncounterSnapshot
        {
            public uint combatSeed;
            public int bossKind;
            public List<EnemyState> enemies;
        }
        static string EncounterFingerprint(RunState run)
        {
            var snapshot=new EncounterSnapshot{combatSeed=run.rng,bossKind=run.layout.bossKind,enemies=run.enemies};
            using(var hash=SHA256.Create())return BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(JsonUtility.ToJson(snapshot)))).Replace("-","").ToLowerInvariant();
        }
        public static string AuditOutcome(RunState run,float limit,int ticks,int tickLimit)
        {
            if(run.phase==RunPhase.Cleared)return "Cleared";
            if(run.phase==RunPhase.Failed)
            {
                if(run.statistics?.finish==CombatFinish.HeroDeath||run.health<=0)return "HeroDeath";
                if(run.statistics?.finish==CombatFinish.Abandoned)return "Abandoned";
                if(run.time>=limit)return "TimeLimit";
                return "OtherFailure";
            }
            if(!string.IsNullOrEmpty(run.navigationError))return "NavigationBlocked";
            if(run.portal)return "PortalBlocked";
            if(run.paused)return "Paused";
            return ticks>=tickLimit?"TickLimit":"Incomplete";
        }
        // Slot-local streams keep bases and unique identities matched even if an affix pool
        // changes the number of random draws used by an earlier equipment slot.
        public static AccountSave AuditAccount(HeroClass heroClass,int variant,uint seed)
        {
            if((int)heroClass<0||(int)heroClass>2||variant<0||variant>1)throw new ArgumentOutOfRangeException();
            var account=GameStore.NewAccount();account.selectedHero=(int)heroClass;
            var hero=account.Hero;hero.level=30;hero.capacity=100;hero.inventory.Clear();
            hero.build=GameCatalog.Preset(heroClass,variant);
            for(int slot=0;slot<8;slot++)
            {
                uint rng=seed^unchecked((uint)(slot+1)*0x9E3779B9u);
                string unique=Sets[(int)heroClass*2+variant][slot];
                var item=ItemGenerator.Create(heroClass,slot,unique==null?2:3,30,ref rng,
                    id:$"audit-{(int)heroClass}-{variant}-{seed}-{slot}",uniqueId:unique);
                hero.inventory.Add(item);
                if(!Economy.Equip(hero,item))throw new InvalidOperationException("Illegal audit equipment: "+item.id);
            }
            if(hero.inventory.Count(i=>i.equipped)!=8||hero.inventory.Select(i=>i.slot).Distinct().Count()!=8)
                throw new InvalidOperationException("The audit requires eight legal occupied slots.");
            return account;
        }
        public static AuditedBalanceRun AuditRun(GameCatalog catalog,HeroClass heroClass,int variant,int stage,int seedIndex,Action<CombatSimulation,float> observer=null,bool useEdict=false,Func<HuntEdictV2Document,HuntEdictV2Document> edictSetup=null)
        {
            if(seedIndex<0||stage<1)throw new ArgumentOutOfRangeException();
            uint seed=unchecked((uint)(54321+seedIndex*1337+(int)heroClass*97+variant*31));
            var account=AuditAccount(heroClass,variant,seed);
            if(edictSetup!=null&&!useEdict)throw new ArgumentException("An explicit edict setup requires edict mode.");
            if(useEdict){var source=HuntEdictV2Storage.CreateForHero(account.Hero);account.Hero.edict=edictSetup==null?source:edictSetup(source);account.Hero.useEdict=true;}
            var sim=new CombatSimulation(account,catalog,stage,seed:seed);var run=sim.State;
            var row=new AuditedBalanceRun
            {
                heroClass=(int)heroClass,variant=variant,stage=stage,seedIndex=seedIndex,seed=seed,
                map=run.layout.fingerprint,encounter=EncounterFingerprint(run),objective=run.layout.objective.ToString(),
                maxHp=sim.Stats.hp,baseDamage=sim.Stats.damage,equipment=new List<Item>(account.Hero.inventory),
                sheet=Enumerable.Range(0,StatCatalog.Count).Select(i=>sim.Stats.Sheet((StatId)i)).ToArray()
            };
            int stationary=0;
            observer?.Invoke(sim,0);
            while(run.phase!=RunPhase.Cleared&&run.phase!=RunPhase.Failed&&row.ticks<10000)
            {
                if(run.portal||run.paused||!string.IsNullOrEmpty(run.navigationError))break;
                Vector2 before=run.position;sim.Tick(CombatSimulation.Step);row.ticks++;
                observer?.Invoke(sim,CombatSimulation.Step);
                if(run.bossId>=0&&!row.bossSpawned){row.bossSpawned=true;row.bossSpawnTime=run.time;}
                bool approaching=run.targetId>=0&&!sim.HeroActionBusy&&run.actionCd<=0&&Vector2.Distance(run.position,run.destination)>.75f;
                stationary=approaching&&Vector2.Distance(before,run.position)<.001f?stationary+1:0;
                row.maxStationaryApproach=Mathf.Max(row.maxStationaryApproach,stationary*CombatSimulation.Step);
            }
            row.outcome=AuditOutcome(run,sim.TimeLimit,row.ticks,10000);
            row.finish=run.statistics.finish.ToString();row.time=run.time;row.damage=run.dealt;row.hp=run.health;
            row.kills=run.kills;row.visited=run.visited.Count;row.chests=run.layout.chests.Count(c=>c.phase==ChestPhase.Opened);
            row.repaths=run.exploration.repaths;row.navigationError=run.navigationError;
            row.resourceChecks=run.statistics.resourceChecks;row.skills=new List<SkillStatistics>(run.statistics.skills);
            row.bossRewarded=run.bossRewarded;row.bossRemainingHp=run.enemies.Find(e=>e.boss&&e.id==run.bossId)?.health??0;
            row.gateOpen=run.layout.gateOpen;row.gateOpenedByMeter=run.layout.gateOpenedByMeter;
            row.lastLogs=run.logs.AsEnumerable().Reverse().Take(12).Reverse().ToList();
            return row;
        }
        internal static string AuditArgument(string key,string fallback)
        {
            var args=Environment.GetCommandLineArgs();int index=Array.IndexOf(args,key);
            if(index<0)return fallback;
            if(index+1>=args.Length||args[index+1].StartsWith("-",StringComparison.Ordinal))
                throw new ArgumentException(key+" requires a value.");
            return args[index+1];
        }
        internal static int AuditInteger(string key,int fallback)
        {
            if(!int.TryParse(AuditArgument(key,fallback.ToString()),out int value)||value<1)
                throw new ArgumentException(key+" requires a positive integer.");
            return value;
        }
        internal static string ValidateAffixProfile()
        {
            string profile=AuditArgument("-hellscriptAffixProfile","current54");
            int expected=profile=="current54"?54:profile=="legacy24"?24:0;
            if(expected==0||ItemCatalog.Affixes.Count!=expected||
                !Enumerable.Range(1,expected).Select(i=>"AF"+i.ToString("00")).SequenceEqual(ItemCatalog.Affixes.Select(a=>a.id)))
                throw new InvalidOperationException("The requested affix profile does not match the compiled catalogue.");
            return profile;
        }
        [MenuItem("HELLSCRIPT/접사 비교용 균열 기록")]
        public static void RunAffixBalanceAudit()
        {
            string profile=ValidateAffixProfile();
            string directory=Path.GetFullPath(AuditArgument("-hellscriptAuditOutput","Artifacts/Validation/AffixBalance/"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmss")));
            int stage=AuditInteger("-hellscriptAuditStage",20),seeds=AuditInteger("-hellscriptAuditSeeds",100);
            Directory.CreateDirectory(directory);
            string path=Path.Combine(directory,"runs.jsonl"),headerPath=Path.Combine(directory,"balance-header.json");
            if(File.Exists(path)||File.Exists(headerPath))throw new IOException("Use a new audit output directory.");
            var header=new AuditHeader
            {
                profile=profile,affixes=ItemCatalog.Affixes.Count,affixIds=ItemCatalog.Affixes.Select(a=>a.id).ToArray(),
                createdUtc=DateTime.UtcNow.ToString("O"),stage=stage,seeds=seeds,expectedRuns=checked(seeds*6),
                scope="Fresh level-30 fixtures, eight legal item-level-30 pieces, unchanged recommended builds. Slot-local gear seeds and separate encounter seeds permit paired affix-pool comparisons. No runtime combat overrides; no player saves; not natural progression or a win-rate acceptance gate."
            };
            var clock=System.Diagnostics.Stopwatch.StartNew();var catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();
            try
            {
                File.WriteAllText(headerPath,JsonUtility.ToJson(header,true));
                using(var output=new StreamWriter(new FileStream(path,FileMode.CreateNew,FileAccess.Write,FileShare.Read)))
                {
                    output.AutoFlush=true;
                    for(int c=0;c<3;c++)for(int variant=0;variant<2;variant++)for(int index=0;index<seeds;index++)
                    {
                        output.WriteLine(JsonUtility.ToJson(AuditRun(catalog,(HeroClass)c,variant,stage,index)));
                        header.completedRuns++;header.wallSeconds=clock.Elapsed.TotalSeconds;
                        File.WriteAllText(headerPath,JsonUtility.ToJson(header,true));
                        if(header.completedRuns%10==0)Debug.Log($"HELLSCRIPT_AFFIX_BALANCE_PROGRESS {profile} {header.completedRuns}/{header.expectedRuns}");
                    }
                }
                header.status="complete";header.wallSeconds=clock.Elapsed.TotalSeconds;
                File.WriteAllText(headerPath,JsonUtility.ToJson(header,true));
                Debug.Log($"HELLSCRIPT_AFFIX_BALANCE_COMPLETE {profile} {header.completedRuns} runs {header.wallSeconds:0.0}s");
            }
            finally{UnityEngine.Object.DestroyImmediate(catalog);}
        }
        public static void RunAffixAuditSuite()
        {
            AffixDistributionValidation.Run();
            RunAffixBalanceAudit();
        }
    }
}
