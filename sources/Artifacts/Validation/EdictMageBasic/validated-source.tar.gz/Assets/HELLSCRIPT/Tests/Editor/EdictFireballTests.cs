using System;
using System.Collections.Generic;
using System.Linq;
using Hellscript;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class EdictFireballTests
    {
        GameCatalog catalog;
        [SetUp] public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown] public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        CombatSimulation Fixture(bool enabled=true,bool legacyRow=true,params string[] gear)
        {
            var a=GameStore.NewAccount();a.selectedHero=2;var hero=a.Hero;hero.level=30;hero.inventory.Clear();
            hero.build.activeSkills=new List<int>{12};hero.build.passives=Array.Empty<int>();hero.build.potionThreshold=0;
            hero.build.rules=legacyRow?new List<Rule>{BehaviorRules.Make(12,BehaviorRules.C("SC06",Comparison.AtLeast,99,predicted:true))}:new List<Rule>();
            foreach(string id in gear)
            {
                uint rng=91367;var definition=ItemCatalog.Unique(id);var item=ItemGenerator.Create(HeroClass.Mage,definition.slot,3,30,ref rng,uniqueId:id);
                hero.inventory.Add(item);Assert.IsTrue(Economy.Equip(hero,item));
            }
            hero.edict=HuntEdictV2.WithOption(HuntEdictV2Storage.CreateForHero(hero),"BASIC",1,"OFF");hero.edict=HuntEdictV2.WithOption(hero.edict,"M01",1,"ON");
            hero.edict=HuntEdictV2Editing.WithGlobal(hero.edict,"position.mode","STAND");hero.useEdict=enabled;
            var sim=new CombatSimulation(a,catalog,1,1,seed:43177);sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();
            sim.State.exploration.enemies.Clear();sim.Stats.crit=0;sim.Stats.regen=0;
            return sim;
        }
        static EnemyState Enemy(CombatSimulation sim,float x,float y,int kind=0,int elite=-1)
        {
            var e=new EnemyState{id=900+sim.State.enemies.Count,kind=kind,elite=elite,position=sim.State.position+new Vector2(x,y),
                health=1000000,maxHealth=1000000,speed=0,attack=0,cooldown=1000};sim.State.enemies.Add(e);return e;
        }
        static void Option(CombatSimulation sim,int n,string value)
        {sim.Hero.edict=HuntEdictV2.WithOption(sim.Hero.edict,"M01",n,value);sim.RefreshEdict();}
        static void Advance(CombatSimulation sim,int ticks=60){for(int i=0;i<ticks;i++)sim.Tick(CombatSimulation.Step);}
        static int Starts(CombatSimulation sim)=>sim.State.statistics.skills.FirstOrDefault(s=>s.definitionId=="M01")?.starts??0;
        static EdictAimPlan Plan(CombatSimulation sim,EnemyState target)=>sim.PlanEdictAim(sim.Hero.edict,"M01",target);

        [TestCase(true)] [TestCase(false)]
        public void CorePolicyFiresWithoutDependingOnALegacyConditionOrRow(bool legacyRow)
        {
            var sim=Fixture(legacyRow:legacyRow);Enemy(sim,0,4);string rules=JsonUtility.ToJson(sim.State.build);
            Advance(sim);Assert.Greater(Starts(sim),0);Assert.Greater(sim.EdictAimedCasts,0);
            Assert.AreEqual(rules,JsonUtility.ToJson(sim.State.build));
            Assert.IsTrue(sim.State.decisions.Any(d=>d.ruleId=="edict:M01"&&d.code=="SELECTED"));
            Assert.IsTrue(sim.State.damageEvents.Any(d=>d.definitionId=="M01"&&!d.incoming));
        }
        [Test]
        public void OptingOutPreservesTheOldBlockingCondition()
        {
            var sim=Fixture(false);Enemy(sim,0,4);Advance(sim);Assert.AreEqual(0,Starts(sim));Assert.AreEqual(0,sim.EdictAimedCasts);
            Assert.IsFalse(sim.State.decisions.Any(d=>d.ruleId=="edict:M01"));
        }
        [Test]
        public void DisabledLegacyDuplicatesDoNotDisableOrDuplicateTheCorePolicy()
        {
            var sim=Fixture();sim.State.build.rules[0].enabled=false;sim.State.build.rules.Add(BehaviorRules.Make(12));
            string before=JsonUtility.ToJson(sim.State.build);var rows=EdictRuleOrder.ForSimulation(sim.State.build.rules,sim.Hero.edict).Where(o=>o.rule.action==RuleAction.Skill).ToList();
            Assert.AreEqual(1,rows.Count(r=>r.rule.skill==12));Assert.IsTrue(rows.Single().rule.enabled);Assert.IsTrue(rows.Single().rule.always);
            Assert.AreEqual(before,JsonUtility.ToJson(sim.State.build));Enemy(sim,0,4);Advance(sim);Assert.Greater(Starts(sim),0);
        }
        [TestCase(1,false)] [TestCase(2,false)] [TestCase(3,true)]
        public void GroupPurposeCountsOnlyThePrimaryExplosion(int count,bool available)
        {
            var sim=Fixture();var target=Enemy(sim,0,4);for(int i=1;i<count;i++)Enemy(sim,i%2==0?-.7f:.7f,4);
            Option(sim,2,"GROUP");Assert.AreEqual(available,Plan(sim,target).available);Advance(sim);
            Assert.AreEqual(available,Starts(sim)>0);
            if(!available)Assert.IsTrue(sim.State.decisions.Any(d=>d.code=="EDICT_AIM"));
        }
        [Test]
        public void EchoOnlyTargetsDoNotSatisfyTheGroupThreshold()
        {
            var sim=Fixture(gear:new[]{"LM02"});var target=Enemy(sim,0,4);Enemy(sim,3.1f,4);Enemy(sim,-3.1f,4);
            Option(sim,2,"GROUP");Assert.IsFalse(Plan(sim,target).available);Advance(sim);Assert.AreEqual(0,Starts(sim));
        }
        [TestCase("GLOBAL",0)] [TestCase("ELITE",1)] [TestCase("SUPPORT",2)]
        public void PriorityChoosesTheRequestedValidTargetCategory(string mode,int expected)
        {
            var sim=Fixture();var global=Enemy(sim,0,4);var elite=Enemy(sim,4,4,elite:0);var support=Enemy(sim,-4,4,kind:4);
            Option(sim,3,mode);var p=Plan(sim,global);Assert.IsTrue(p.available,p.reason);
            Assert.AreEqual(new[]{global.id,elite.id,support.id}[expected],p.targetId);
        }
        [TestCase("ELITE")] [TestCase("SUPPORT")]
        public void MissingPreferredCategoryFallsBackToGlobal(string mode)
        {
            var sim=Fixture();var global=Enemy(sim,0,4);Enemy(sim,4,4);Option(sim,3,mode);Assert.AreEqual(global.id,Plan(sim,global).targetId);
        }
        [Test]
        public void DensityUsesTheActualFirstCollisionRatherThanTheRemoteAimPoint()
        {
            var sim=Fixture();var global=Enemy(sim,0,8);Enemy(sim,0,2);Enemy(sim,.7f,8);Enemy(sim,-.7f,8);
            var alternative=Enemy(sim,4,4);Enemy(sim,4.7f,4);Enemy(sim,4,4.7f);Option(sim,3,"DENSE");
            var p=Plan(sim,global);Assert.IsTrue(p.available,p.reason);Assert.AreNotEqual(global.id,p.targetId);
            Assert.GreaterOrEqual(p.forecast.uniqueTargets,3);Assert.Contains(alternative.id,p.forecast.hits.ToArray());
        }
        [Test]
        public void HiddenAndExcludedEnemiesCannotBecomePreferredTargets()
        {
            var sim=Fixture();var global=Enemy(sim,0,4);Enemy(sim,0,40,elite:0);var excluded=Enemy(sim,4,4,elite:0);
            sim.State.edictTarget=new EdictTargetState();sim.State.edictTarget.excluded.Add(excluded.id);Option(sim,3,"ELITE");
            Assert.AreEqual(global.id,Plan(sim,global).targetId);
        }
        [TestCase("own",3f,true)] [TestCase("own",.01f,false)] [TestCase("foreign",3f,false)] [TestCase("none",0f,false)]
        public void ExposureMustBelongToThisHeroAndOutlastExpectedImpact(string owner,float remaining,bool preferred)
        {
            var sim=Fixture(gear:new[]{"SM1","SM2","SM3","SM4"});var global=Enemy(sim,0,4);var marked=Enemy(sim,4,4);
            marked.frostCasterId=owner=="own"?sim.State.heroId:owner;marked.frostMarkTime=remaining;marked.frostMarkId=567;
            Option(sim,2,"EXPOSURE");var p=Plan(sim,global);Assert.IsTrue(p.available,p.reason);
            Assert.AreEqual(preferred?marked.id:global.id,p.targetId);Assert.AreEqual(remaining,marked.frostMarkTime);
        }
        [Test]
        public void ExposureWithoutTheSetFallsBackWithoutChangingTheSavedChoice()
        {
            var sim=Fixture();var global=Enemy(sim,0,4);Option(sim,2,"EXPOSURE");var p=Plan(sim,global);
            Assert.IsTrue(p.available,p.reason);Assert.AreEqual("EXPOSURE",HuntEdictV2.Value(sim.Hero.edict,"M01",2));
            Assert.That(p.reason,Does.Contain("꾸준히"));
        }
        [TestCase("CURRENT",false)] [TestCase("PREDICTED",true)]
        public void ObservedMotionLeadsARealMovingTargetWithoutHoming(string mode,bool hit)
        {
            var sim=Fixture();var target=Enemy(sim,0,6);Vector2 velocity=Vector2.right*5;sim.State.time=2;
            sim.State.exploration.enemies.Add(new EnemyObservation{id=target.id,position=target.position-velocity*.2f,seenAt=1.8f,motionSampled=true,velocity=velocity});
            Option(sim,4,mode);target.position+=velocity*CombatSimulation.Step;Vector2 sampled=target.position;
            // Permit this observed speed through the anti-teleport sample check, then drive a
            // controlled straight path ourselves so the fixture never relies on enemy intent.
            target.speed=5;Advance(sim,1);target.speed=0;target.position=sampled;
            var action=sim.State.heroAction;Assert.AreEqual(12,action.skill);Vector2 aim=action.aim;
            Assert.AreEqual(hit,aim.x>target.position.x+1);sim.State.decisionTime=100;
            for(int i=0;i<30;i++){target.position+=velocity*CombatSimulation.Step;Advance(sim,1);Assert.AreEqual(aim,action.aim);}
            Assert.AreEqual(hit,sim.State.damageEvents.Any(e=>e.rootCastId==action.id&&e.definitionId=="M01"));
        }
        [TestCase("missing")] [TestCase("stale")] [TestCase("future")] [TestCase("invalid")]
        public void UnreliableMotionFallsBackAndPredictionDoesNotMutateState(string reason)
        {
            var sim=Fixture();var target=Enemy(sim,0,5);sim.State.time=2;
            if(reason!="missing")sim.State.exploration.enemies.Add(new EnemyObservation{id=target.id,position=target.position,seenAt=reason=="stale"?1.5f:reason=="future"?3:2,motionSampled=true,velocity=reason=="invalid"?new Vector2(float.NaN,0):Vector2.right*5});
            string before=JsonUtility.ToJson(sim.State);var p=Plan(sim,target);Assert.IsTrue(p.available,p.reason);
            Assert.AreEqual(target.position,p.forecast.aim);Assert.AreEqual(before,JsonUtility.ToJson(sim.State));
        }
        [Test]
        public void EchoBreaksAPrimaryTieButNeverOutvotesALargerPrimaryExplosion()
        {
            var sim=Fixture(gear:new[]{"LM02"});var global=Enemy(sim,-4,3);var other=Enemy(sim,0,9);Enemy(sim,0,11.3f);
            Option(sim,3,"DENSE");var tie=Plan(sim,global);Assert.IsTrue(tie.available,tie.reason);
            Assert.AreEqual(1,tie.forecast.uniqueTargets);Assert.AreEqual(other.id,tie.targetId);
            Enemy(sim,-4,3.5f);Enemy(sim,-4,2.5f);Enemy(sim,.6f,11.3f);Enemy(sim,-.6f,11.3f);
            var primary=Plan(sim,global);Assert.Contains(global.id,primary.forecast.hits.ToArray());Assert.AreEqual(3,primary.forecast.uniqueTargets);
        }
        [Test]
        public void ThePredictedPrimaryGroupIsTheActualDamageGroupForStationaryEnemies()
        {
            var sim=Fixture();var target=Enemy(sim,0,4);Enemy(sim,.7f,4);Enemy(sim,-.7f,4);Option(sim,2,"GROUP");
            var expected=Plan(sim,target).forecast;Advance(sim,1);int root=sim.State.heroAction.id;sim.State.decisionTime=100;Advance(sim,35);
            CollectionAssert.AreEquivalent(expected.hits,sim.State.damageEvents.Where(e=>e.rootCastId==root&&e.definitionId=="M01").Select(e=>e.targetId));
        }
        [Test]
        public void SwitchingAutomaticUseOffKeepsAlreadyLaunchedFireballs()
        {
            var sim=Fixture();Enemy(sim,0,8);for(int n=0;n<40&&!sim.State.projectiles.Any(p=>p.skill==12);n++)Advance(sim,1);
            Assert.IsTrue(sim.State.projectiles.Any(p=>p.skill==12));string before=JsonUtility.ToJson(sim.State.projectiles[0]);
            Option(sim,1,"OFF");Assert.AreEqual(before,JsonUtility.ToJson(sim.State.projectiles[0]));Advance(sim,160);
            Assert.AreEqual(1,Starts(sim));Assert.IsTrue(sim.State.damageEvents.Any(e=>e.definitionId=="M01"));Assert.IsTrue(sim.State.decisions.Any(e=>e.code=="EDICT_OFF"));
        }
        [Test]
        public void ACompiledCastRetainsItsAimAndPolicyThroughSaveRestoration()
        {
            var sim=Fixture(legacyRow:false);Enemy(sim,0,6);Advance(sim,2);var action=sim.State.heroAction;
            Assert.AreEqual("edict:M01",action.policy.rule.id);Assert.IsFalse(action.released);Option(sim,1,"OFF");
            var account=GameStore.NewAccount();account.selectedHero=2;account.heroes[2]=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(sim.Hero));
            var restored=new CombatSimulation(account,catalog,1,restore:JsonUtility.FromJson<RunState>(JsonUtility.ToJson(sim.State)));restored.Stats.crit=0;restored.Stats.regen=0;
            for(int i=0;i<50;i++){Advance(sim,1);Advance(restored,1);Assert.AreEqual(JsonUtility.ToJson(sim.State),JsonUtility.ToJson(restored.State),"replay tick "+i);}
            Assert.AreEqual(1,sim.State.actionEvents.Count(e=>e.actionId==action.id&&e.kind=="ACTION_RELEASE"));Assert.AreEqual(1,Starts(sim));
        }
        [TestCase("RESOURCE")] [TestCase("COOLDOWN")]
        public void TheCorePolicyStillRespectsActualCostAndCooldown(string block)
        {
            var sim=Fixture();Enemy(sim,0,4);if(block=="RESOURCE")sim.State.resource=0;else sim.State.cooldowns[12]=100;
            Advance(sim,10);Assert.AreEqual(0,Starts(sim));Assert.IsTrue(sim.State.decisions.Any(d=>d.ruleId=="edict:M01"&&d.code==block));
        }
        [Test]
        public void AFireballWithoutALegacyRowCanApproachAnOutOfRangeTarget()
        {
            var sim=Fixture(legacyRow:false);Enemy(sim,0,11);Vector2 start=sim.State.position;Advance(sim,80);
            Assert.Greater(Vector2.Distance(start,sim.State.position),.1f);Assert.Greater(Starts(sim),0);
            Assert.IsTrue(sim.State.decisions.Any(d=>d.ruleId=="edict:M01"&&d.code=="RANGE"));
        }
        [Test]
        public void DisablingTheOnlySkillDoesNotReuseItsPreviousApproachRule()
        {
            var sim=Fixture(legacyRow:false);Enemy(sim,0,11);Vector2 start=sim.State.position;Advance(sim,1);
            Assert.AreNotEqual(start,sim.State.position);Option(sim,1,"OFF");sim.State.decisionTime=0;start=sim.State.position;Advance(sim,12);
            Assert.AreEqual(-1,sim.State.movementRule);Assert.AreEqual(start,sim.State.position);Assert.AreEqual(0,Starts(sim));
        }
        [Test]
        public void AnUnreachableGlobalTargetDoesNotBlockAnAvailableAlternative()
        {
            var sim=Fixture();var global=Enemy(sim,0,11);var reachable=Enemy(sim,4,4);var p=Plan(sim,global);
            Assert.IsTrue(p.available,p.reason);Assert.AreEqual(reachable.id,p.targetId);
        }
        [TestCase("HIGH_HP")] [TestCase("LOW_HP")]
        public void TheGlobalPriorityUsesTheExactGlobalSelectorForReachableTargets(string mode)
        {
            var sim=Fixture(legacyRow:false);var a=Enemy(sim,-3,3);var b=Enemy(sim,4,3);a.health=a.maxHealth*.5f;b.health=b.maxHealth*(mode=="HIGH_HP"?.9f:.1f);
            sim.Hero.edict=HuntEdictV2Editing.WithGlobal(sim.Hero.edict,"target.default",mode);sim.RefreshEdict();Advance(sim,1);
            Assert.AreEqual(12,sim.State.heroAction.skill);Assert.AreEqual(b.id,sim.State.heroAction.targetId);
        }
        [TestCase(false)] [TestCase(true)]
        public void ReservingTheFreeMageEscapeDoesNotAddCostOrConsumeDiscountsOnBlockedFireballs(bool discount)
        {
            var sim=discount?Fixture(gear:new[]{"LC02"}):Fixture();Enemy(sim,0,4);
            sim.Hero.build.activeSkills.Add(15);sim.State.build.activeSkills.Add(15);
            sim.Hero.edict=HuntEdictV2.WithOption(HuntEdictV2Storage.CreateForHero(sim.Hero),"BASIC",1,"OFF");
            sim.Hero.edict=HuntEdictV2Editing.WithGlobal(sim.Hero.edict,"survival.escapeSkill","M04");
            sim.Hero.edict=HuntEdictV2Editing.WithGlobal(sim.Hero.edict,"survival.reserveResource","ON");sim.RefreshEdict();
            Assert.IsTrue(sim.EdictActive,sim.EdictInactiveReason);
            sim.Stats.costReduction=0;sim.State.itemEffects.reducedNext=discount;sim.State.itemEffects.lc02Charge=discount?6:0;
            float fire=catalog.skills[12].cost*(discount?.5f:1),escape=catalog.skills[15].cost;
            Assert.AreEqual(0,escape,"M04 has no resource cost in the current catalog.");
            sim.State.resource=fire+escape-.1f;Advance(sim,1);Assert.AreEqual(0,Starts(sim));Assert.AreEqual(discount,sim.State.itemEffects.reducedNext);
            Assert.IsTrue(sim.State.decisions.Any(d=>d.code=="RESOURCE"));
            sim.State.resource=fire+escape;sim.State.decisionTime=0;Advance(sim,1);Assert.AreEqual(1,Starts(sim));Assert.AreEqual(escape,sim.State.resource,.0001f);
            Assert.IsFalse(sim.State.itemEffects.reducedNext);Assert.AreEqual(0,sim.LastEdictPlan.assessment.escapeResource);
        }
    }
}
