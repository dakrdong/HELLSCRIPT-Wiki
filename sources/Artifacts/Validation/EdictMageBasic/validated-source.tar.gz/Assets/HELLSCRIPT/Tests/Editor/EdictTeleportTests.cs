using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class EdictTeleportTests
    {
        GameCatalog catalog;
        [SetUp] public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown] public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        CombatSimulation Fixture(bool enabled=true,string row="BLOCKED")
        {
            var account=ContentTestAccounts.Training();account.selectedHero=2;var h=account.Hero;h.level=30;h.inventory.Clear();
            h.build.activeSkills=new List<int>{15};h.build.passives=Array.Empty<int>();h.build.potionThreshold=0;h.build.movement=MovementMode.Stand;
            var old=BehaviorRules.Make(15,BehaviorRules.C("SC06",Comparison.AtLeast,99,predicted:true));old.escape=true;old.overrideMovement=true;old.movement=MovementMode.Stand;
            if(row=="ENABLED"||row=="DUPLICATE")old=BehaviorRules.Make(15);if(row=="DISABLED")old.enabled=false;
            h.build.rules=row=="MISSING"?new List<Rule>():new List<Rule>{old};if(row=="DUPLICATE")h.build.rules.Add(BehaviorRules.Make(15));
            h.edict=HuntEdictV2.WithOption(HuntEdictV2Storage.CreateForHero(h),"BASIC",1,"OFF");h.useEdict=enabled;
            foreach(var pair in new[]{("position.mode","STAND"),("position.distanceSource","EXPLICIT"),("position.distance","8"),("survival.potion","OFF"),("survival.lowHp","OFF"),("survival.lethal","OFF")})
                h.edict=HuntEdictV2Editing.WithGlobal(h.edict,pair.Item1,pair.Item2);
            var sim=new CombatSimulation(account,catalog,1,1,seed:83741,ownedTraining:true);sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();sim.State.exploration.enemies.Clear();
            Controlled(sim);Enemy(sim,0,2);return sim;
        }
        static void Controlled(CombatSimulation sim){sim.Stats.hp=100;sim.State.health=100;sim.Stats.regen=0;sim.Stats.crit=0;sim.Stats.armor=0;sim.Stats.resistance=0;sim.Stats.costReduction=0;}
        static EnemyState Enemy(CombatSimulation sim,float x,float y)
        {var e=new EnemyState{id=900+sim.State.enemies.Count,position=sim.State.position+new Vector2(x,y),health=1000000,maxHealth=1000000,speed=0,attack=0,cooldown=1000,brain=new EnemyBrain{initialized=true}};sim.State.enemies.Add(e);return e;}
        static void Option(CombatSimulation sim,int n,string value){sim.Hero.edict=HuntEdictV2.WithOption(sim.Hero.edict,"M04",n,value);sim.RefreshEdict();}
        static void Global(CombatSimulation sim,string id,string value){sim.Hero.edict=HuntEdictV2Editing.WithGlobal(sim.Hero.edict,id,value);sim.RefreshEdict();}
        static void Advance(CombatSimulation sim,int n=10){for(int i=0;i<n;i++)sim.Tick(CombatSimulation.Step);}
        static int Starts(CombatSimulation sim,int skill=15)=>sim.State.actionEvents.Count(e=>e.kind=="ACTION_START"&&e.skill==skill);
        static EdictResponseCandidate Plan(CombatSimulation sim)=>sim.PlanEdictTeleport(sim.Hero.edict,sim.State.enemies[0]);
        static EnemyHazard Danger(CombatSimulation sim,float radius=2,float damage=20,float delay=1)
        {var h=new EnemyHazard{id=800,actionId=800,enemyId=900,definitionId="TELEPORT_DANGER",position=sim.State.position,shape=AttackShape.Circle,radius=radius,damage=damage,delay=delay,createdAt=-1};sim.State.enemyHazards.Add(h);return h;}
        CombatSimulation Restore(CombatSimulation sim)
        {
            var a=ContentTestAccounts.Training();a.selectedHero=2;a.heroes[2]=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(sim.Hero));
            var copy=new CombatSimulation(a,catalog,1,restore:JsonUtility.FromJson<RunState>(JsonUtility.ToJson(sim.State)));Controlled(copy);return copy;
        }
        [TestCase("MISSING")][TestCase("DISABLED")][TestCase("BLOCKED")][TestCase("ENABLED")][TestCase("DUPLICATE")]
        public void DistancePolicyReplacesLegacyEligibilityWithoutMutatingRows(string row)
        {
            var sim=Fixture(row:row);Option(sim,2,"DISTANCE");Option(sim,3,"DISTANCE");string old=JsonUtility.ToJson(sim.State.build);var from=sim.State.position;
            Advance(sim,1);var action=sim.State.heroAction;Assert.AreEqual(15,action.skill);Assert.AreEqual("edict:M04",action.policy.rule.id);Assert.AreEqual(from,sim.State.position);
            Advance(sim,4);Assert.AreEqual(action.destination,sim.State.position);Assert.AreEqual(1,Starts(sim));Assert.AreEqual(old,JsonUtility.ToJson(sim.State.build));Assert.IsEmpty(sim.State.damageEvents.Where(d=>!d.incoming));
            Assert.IsTrue(sim.State.decisions.Any(d=>d.ruleId=="edict:M04"&&d.code=="SELECTED"));
        }
        [TestCase(true,0)][TestCase(false,1)]
        public void SurvivalOnlyDoesNotUseAnOrdinaryLegacyTeleportWhileOptOutPreservesIt(bool enabled,int casts)
        {var sim=Fixture(enabled,"ENABLED");Advance(sim);Assert.AreEqual(casts,Starts(sim));}
        [TestCase(6f,true)][TestCase(6.01f,false)][TestCase(8f,false)]
        public void DistanceAdjustmentRequiresAtLeastTwoMetersOfImprovement(float enemyDistance,bool ready)
        {
            var sim=Fixture();sim.State.enemies[0].position=sim.State.position+Vector2.up*enemyDistance;Option(sim,2,"DISTANCE");Option(sim,3,"DISTANCE");
            var plan=Plan(sim);Assert.AreEqual(ready,plan.ready);if(ready)Assert.GreaterOrEqual(Mathf.Abs(enemyDistance-8)-Mathf.Abs(Vector2.Distance(plan.destination,sim.State.enemies[0].position)-8),2-.0001f);
            Advance(sim);Assert.AreEqual(ready?1:0,Starts(sim));
        }
        [Test] public void BasicRangeUsesTenMetersInsteadOfTheSavedExplicitDistance()
        {
            var sim=Fixture();Global(sim,"position.distance","2");Option(sim,2,"DISTANCE");Option(sim,3,"DISTANCE");Assert.IsFalse(Plan(sim).ready);
            Global(sim,"position.distanceSource","BASIC_RANGE");var p=Plan(sim);Assert.IsTrue(p.ready);Assert.AreEqual(10,Vector2.Distance(p.destination,sim.State.enemies[0].position),.25f,"The room boundary prevents an exact 10 m landing.");
        }
        [Test] public void DistancePreferenceRestoresDesiredRangeInsteadOfMaximizingSeparation()
        {
            var sim=Fixture();Option(sim,2,"DISTANCE");var safe=Plan(sim);Option(sim,3,"DISTANCE");var distance=Plan(sim);Assert.IsTrue(safe.ready&&distance.ready);
            var target=sim.State.enemies[0];Assert.AreEqual(8,Vector2.Distance(distance.destination,target.position),.01f);Assert.Greater(Mathf.Abs(Vector2.Distance(safe.destination,target.position)-8),1.5f);
        }
        [TestCase("GLOBAL",true)][TestCase("NO_DAMAGE",false)]
        public void NoDamageRejectsAnAllowedSmallHitAcrossAllLandingPoints(string criterion,bool ready)
        {
            var sim=Fixture();Option(sim,2,"DISTANCE");Option(sim,4,criterion);Global(sim,"dodge.area.policy","DAMAGE");Global(sim,"dodge.area.hpPercent","100");Danger(sim,30,1);
            string before=JsonUtility.ToJson(sim.State);Assert.AreEqual(ready,Plan(sim).ready);Assert.AreEqual(before,JsonUtility.ToJson(sim.State));
        }
        [Test] public void EmergencyReservationBlocksDistanceButAllowsTheRequestedSurvivalEscape()
        {
            var sim=Fixture();Option(sim,2,"DISTANCE");Global(sim,"survival.escapeSkill","M04");Global(sim,"survival.reserveSkill","ON");Assert.AreEqual("RESERVED",Plan(sim).code);Advance(sim);Assert.AreEqual(0,Starts(sim));
            Global(sim,"survival.lowHp","ON");sim.State.health=20;sim.State.decisionTime=0;Advance(sim,1);Assert.AreEqual(1,Starts(sim));Assert.AreEqual("HED2:SURVIVAL:M04",sim.State.heroAction.policy.rule.id);
        }
        [TestCase("OFF")][TestCase("COOLDOWN")][TestCase("LEVEL")][TestCase("HIDDEN")][TestCase("EXCLUDED")]
        public void UnavailableDistanceCastsCannotPayOrMove(string gate)
        {
            var sim=Fixture();Option(sim,2,"DISTANCE");if(gate=="OFF")Option(sim,1,"OFF");if(gate=="COOLDOWN")sim.State.cooldowns[15]=100;
            if(gate=="LEVEL")sim.Hero.level=1;
            if(gate=="HIDDEN")sim.State.enemies[0].position+=Vector2.up*40;if(gate=="EXCLUDED"){sim.State.enemies[0].position=sim.State.position+Vector2.up*11;sim.State.edictTarget=new EdictTargetState();sim.State.edictTarget.excluded.Add(900);}
            var before=sim.State.position;float resource=sim.State.resource;Advance(sim,1);Assert.AreEqual(0,Starts(sim));Assert.AreEqual(before,sim.State.position);Assert.AreEqual(resource,sim.State.resource);
        }
        [Test] public void OrdinaryTeleportCannotInterruptAPaidChainEvenWhenItsLegacyRowHasPriority()
        {
            var sim=Fixture(row:"MISSING");sim.Hero.build.activeSkills.Add(14);sim.State.build.activeSkills.Add(14);sim.State.build.rules.Add(BehaviorRules.Make(14));sim.Hero.edict=HuntEdictV2.WithOption(HuntEdictV2Storage.CreateForHero(sim.Hero),"BASIC",1,"OFF");
            Global(sim,"position.mode","STAND");Global(sim,"position.distance","8");Option(sim,1,"OFF");Advance(sim,1);int root=sim.State.heroAction.id;Assert.AreEqual(14,sim.State.heroAction.skill);
            Option(sim,1,"ON");Option(sim,2,"DISTANCE");while(Array.IndexOf(sim.Hero.edict.skillOrder,"M04")>0)sim.Hero.edict=HuntEdictV2Editing.WithSkillOrderMoved(sim.Hero.edict,"M04",-1);sim.RefreshEdict();sim.State.decisionTime=0;
            Advance(sim,1);Assert.AreEqual("ACTION_LOCK",sim.State.decisions.Last(d=>d.ruleId=="edict:M04").code);Assert.AreEqual(root,sim.State.heroAction.id);
            Advance(sim,12);Assert.IsTrue(sim.State.actionEvents.Any(e=>e.actionId==root&&e.kind=="ACTION_RELEASE"));Assert.IsFalse(sim.State.actionEvents.Any(e=>e.actionId==root&&e.kind=="ACTION_INTERRUPTED"));
        }
        [TestCase("SAFE")][TestCase("SPARSE")][TestCase("DISTANCE")]
        public void TargetlessEnvironmentEscapeUsesGlobalPolicyAndNeverQueuesAnAttack(string preference)
        {
            var sim=Fixture(row:"MISSING");sim.State.enemies[0].position+=Vector2.up*40;Option(sim,3,preference);Global(sim,"survival.escapeSkill","M04");Global(sim,"dodge.area.policy","ALWAYS");Global(sim,"dodge.method","SKILL_FIRST");Danger(sim);
            Advance(sim,1);var a=sim.State.heroAction;Assert.AreEqual(15,a.skill);Assert.AreEqual(-1,a.targetId);Assert.AreEqual("HED2:SURVIVAL:M04",a.policy.rule.id);
            Option(sim,1,"OFF");Advance(sim,6);Assert.AreEqual(a.destination,sim.State.position);Assert.AreEqual(1,Starts(sim));Assert.IsEmpty(sim.State.damageEvents.Where(d=>!d.incoming));
        }
        [Test] public void PaidDestinationSurvivesOptionEditsTargetLossAndIndependentRestoration()
        {
            var sim=Fixture();Option(sim,2,"DISTANCE");Option(sim,3,"DISTANCE");Advance(sim,1);var a=sim.State.heroAction;
            Option(sim,2,"SURVIVAL");Option(sim,3,"SAFE");Option(sim,1,"OFF");Global(sim,"position.distance","2");sim.State.enemies[0].position+=Vector2.up*40;
            var restored=Restore(sim);for(int i=0;i<40;i++){Advance(sim,1);Advance(restored,1);Assert.AreEqual(JsonUtility.ToJson(sim.State),JsonUtility.ToJson(restored.State),"tick "+i);}
            Assert.AreEqual(a.destination,sim.State.actionEvents.Single(e=>e.actionId==a.id&&e.kind=="ACTION_END").position);Assert.AreEqual(1,Starts(sim));Assert.AreEqual(1,sim.State.actionEvents.Count(e=>e.kind=="ACTION_RELEASE"&&e.skill==15));
        }
        [Test] public void TeleportHasNoResourceCostAndPreservesAnUnusedNextSkillDiscount()
        {
            var sim=Fixture();Option(sim,2,"DISTANCE");sim.State.resource=0;sim.State.itemEffects.reducedNext=true;sim.State.itemEffects.lc02Charge=5;
            Advance(sim,1);Assert.AreEqual(1,Starts(sim));Assert.AreEqual(0,sim.State.heroAction.cost);Assert.AreEqual(0,sim.State.resource);Assert.IsTrue(sim.State.itemEffects.reducedNext);
        }
        [Test] public void LegacyTargetPointChoosesALegalNearbyLandingBeforeStarting()
        {
            var sim=Fixture(false,"ENABLED");sim.State.enemies[0].position=sim.State.position+Vector2.up*6;Advance(sim,1);var a=sim.State.heroAction;
            Assert.AreEqual(15,a.skill);Assert.GreaterOrEqual(Vector2.Distance(a.destination,sim.State.enemies[0].position),.85f);Advance(sim,4);
            Assert.AreEqual(a.destination,sim.State.position);Assert.IsTrue(a.released);
        }
        [TestCase("HIGH_HP")][TestCase("LOW_HP")]
        public void DistanceRestorationUsesTheExactGlobalTarget(string mode)
        {
            var sim=Fixture();var a=sim.State.enemies[0];a.position=sim.State.position+Vector2.left*4;a.health=a.maxHealth*.5f;
            var b=Enemy(sim,4,0);b.health=b.maxHealth*(mode=="HIGH_HP"?.9f:.1f);Global(sim,"target.default",mode);Option(sim,2,"DISTANCE");Option(sim,3,"DISTANCE");
            Advance(sim,1);Assert.AreEqual(b.id,sim.State.heroAction.targetId);Assert.AreEqual(8,Vector2.Distance(sim.State.heroAction.destination,b.position),.25f);
        }
        [Test] public void FailedGlobalEscapeCannotFallThroughIntoAnOrdinaryLegacyTeleport()
        {
            var sim=Fixture(row:"ENABLED");Global(sim,"survival.lowHp","ON");Global(sim,"survival.escapeSkill","M04");Global(sim,"survival.order","ESCAPE,WALK,DEFENSE");Global(sim,"survival.fallback","KEEP_FIGHTING");sim.State.health=20;
            sim.State.layout.obstacles.Add(new RiftObstacle{id="blocked",position=sim.State.position,halfSize=Vector2.one*30,blocksLanding=true,blocksWalk=false,blocksSight=false});
            Advance(sim,1);Assert.AreEqual("KEEP_FIGHTING",sim.LastEdictPlan.selected.role);Assert.AreEqual(0,Starts(sim));Assert.AreEqual(0,sim.State.cooldowns[15]);
        }
        [Test] public void PreparationHasNoInvulnerabilityAndDoesNotCancelAReleasedEnvironmentalHit()
        {
            var sim=Fixture();Global(sim,"survival.escapeSkill","M04");Global(sim,"dodge.area.policy","ALWAYS");Global(sim,"dodge.method","SKILL_FIRST");Danger(sim,2,20,.1f);
            Advance(sim,1);var action=sim.State.heroAction;Assert.AreEqual(15,action.skill);Advance(sim,1);
            Assert.Less(sim.State.health,100);Assert.AreEqual(action.origin,sim.State.position);Advance(sim,3);Assert.IsTrue(action.released);Assert.AreEqual(action.destination,sim.State.position);
        }
        [TestCase("LANDING")][TestCase("SIGHT")][TestCase("BODY")][TestCase("RANGE")]
        public void AnInvalidatedPaidLandingInterruptsWithoutMovingRefundingOrRecordingAnEvasion(string failure)
        {
            var sim=Fixture();Option(sim,2,"DISTANCE");Advance(sim,1);var a=sim.State.heroAction;var before=sim.State.position;float paid=sim.State.resource;
            if(failure=="LANDING")sim.State.layout.obstacles.Add(new RiftObstacle{id="blocked",position=a.destination,halfSize=Vector2.one,blocksLanding=true,blocksWalk=false,blocksSight=false});
            if(failure=="BODY")sim.State.enemies[0].position=a.destination;
            if(failure=="SIGHT")
            {sim.State.layout.legacy=false;sim.State.layout.corridors.Clear();sim.State.layout.obstacles.Add(new RiftObstacle{id="wall",position=(a.origin+a.destination)/2,halfSize=Vector2.one,blocksSight=true,blocksWalk=false});}
            if(failure=="RANGE")a.destination=a.origin+Vector2.up*9;
            Option(sim,1,"OFF");Advance(sim,4);Assert.AreEqual(before,sim.State.position);Assert.AreEqual(paid,sim.State.resource);Assert.Greater(sim.State.cooldowns[15],0);
            Assert.IsTrue(sim.State.actionEvents.Any(e=>e.actionId==a.id&&e.kind=="ACTION_INTERRUPTED"));Assert.IsFalse(sim.State.actionEvents.Any(e=>e.actionId==a.id&&e.kind=="ACTION_RELEASE"));
        }
    }
}
