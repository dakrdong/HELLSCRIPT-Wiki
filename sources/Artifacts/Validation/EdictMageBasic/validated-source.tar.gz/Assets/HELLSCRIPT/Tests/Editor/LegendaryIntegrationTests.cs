using System;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class LegendaryIntegrationTests
    {
        GameCatalog catalog;
        [SetUp]public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown]public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        static object Call(CombatSimulation s,string name,params object[] args)
        {
            var method=typeof(CombatSimulation).GetMethod(name,BindingFlags.Instance|BindingFlags.NonPublic);var parameters=method.GetParameters();var values=new object[parameters.Length];
            for(int i=0;i<values.Length;i++)values[i]=i<args.Length?args[i]:parameters[i].DefaultValue;return method.Invoke(s,values);
        }
        CombatSimulation Fixture(bool weapon=true)
        {
            var a=GameStore.NewAccount();var h=a.Hero;h.level=30;h.inventory.Clear();h.build=GameCatalog.Preset(HeroClass.Warrior,0);
            h.build.passives=Array.Empty<int>();h.build.rules.Clear();h.build.activeSkills=new[]{0,1,2,4}.ToList();h.build.movement=MovementMode.Stand;h.build.potionThreshold=0;
            var gear=new[]{weapon?"LW01":null,"SW1","SW2","LW03","LW02","LC03","LW04","LC01"};uint rng=71711;
            for(int slot=0;slot<8;slot++)
            {var item=ItemGenerator.Create(h.heroClass,slot,gear[slot]==null?2:3,30,ref rng,uniqueId:gear[slot]);h.inventory.Add(item);Assert.IsTrue(Economy.Equip(h,item));}
            Assert.AreEqual(8,h.inventory.Count(i=>i.equipped));Assert.AreEqual(8,h.inventory.Where(i=>i.equipped).Select(i=>i.slot).Distinct().Count());Assert.IsEmpty(BehaviorRules.Validate(h.build,h.heroClass));
            var s=new CombatSimulation(a,catalog,1,1,seed:71711);s.State.position=RiftMap.Rooms[0];s.State.enemies.Clear();s.State.decisionTime=10000;
            // These tests measure the legendary effects, not the character sheet. The gear here is
            // randomly rolled, so a conditional damage line or an overpower would otherwise move
            // the exact numbers they assert.
            SheetFixture.Neutral(s.Stats);
            Enemy(s,902,Vector2.up*2.2f);return s;
        }
        static EnemyState Enemy(CombatSimulation s,int id,Vector2 offset)
        {var e=new EnemyState{id=id,position=s.State.position+offset,health=100000,maxHealth=100000,cooldown=1000};s.State.enemies.Add(e);return e;}
        static void Start(CombatSimulation s)
        {var e=s.State.enemies[0];s.State.targetId=e.id;Call(s,"StartHeroAction",0,e,e.position,0f,-1,false);}
        static void Advance(CombatSimulation s,int ticks){for(int i=0;i<ticks;i++)s.Tick(CombatSimulation.Step);}
        CombatSimulation Restore(CombatSimulation s)
        {
            var a=GameStore.NewAccount();a.heroes[0]=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(s.Hero));
            var run=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(s.State));GameStore.NormalizeRun(run);return new CombatSimulation(a,catalog,1,1,run);
        }
        [Test]
        public void PaidWhirlwindStopsBeforeHeroAndOtherBodiesWithoutAnExtraHit()
        {
            var s=Fixture();var near=s.State.enemies[0];var far=Enemy(s,900,Vector2.up*3.1f);Start(s);Advance(s,19);
            Assert.AreEqual(s.State.position+Vector2.up*2.2f,near.position);Assert.AreEqual(100000,far.health);
            Advance(s,1);
            Assert.GreaterOrEqual(Vector2.Distance(s.State.position,near.position),.85f-.0001f);
            Assert.GreaterOrEqual(Vector2.Distance(near.position,far.position),.8f-.0001f);
            Assert.Less(Vector2.Distance(s.State.position,far.position),3.1f);
            Assert.AreEqual(4,s.State.damageEvents.Count(d=>d.definitionId=="W01"));Assert.AreEqual(100000,far.health,"Pulling into range must not invent an extra hit.");
            Assert.IsFalse(s.State.damageEvents.Any(d=>d.definitionId=="LW01"));
        }
        [TestCase(0f)][TestCase(128f)][TestCase(256f)]
        public void PaidPullIntervalsRemainOneSecondAcrossSaveAndLateCombatTime(float time)
        {
            var s=Fixture();s.State.time=time;Start(s);Advance(s,20);float first=s.State.itemEffects.lastPull;
            s.State.enemies[0].position=s.State.position+Vector2.up*2.2f;Advance(s,19);Assert.AreEqual(first,s.State.itemEffects.lastPull);
            var restored=Restore(s);Advance(s,1);Advance(restored,1);
            Assert.AreEqual(20,Mathf.RoundToInt(s.State.itemEffects.lastPull/CombatSimulation.Step)-Mathf.RoundToInt(first/CombatSimulation.Step));
            Assert.AreEqual(s.State.itemEffects.lastPull,restored.State.itemEffects.lastPull);Assert.AreEqual(s.State.enemies[0].position,restored.State.enemies[0].position);
        }
        [TestCase("root")][TestCase("stun")][TestCase("freeze")][TestCase("boss")][TestCase("dead")][TestCase("range")][TestCase("sight")]
        public void PullExcludesIneligibleTargets(string reason)
        {
            var s=Fixture();var target=Enemy(s,950,Vector2.right*(reason=="range"?3.51f:3.2f));Vector2 before=target.position;
            if(reason=="root")target.root=10;if(reason=="stun")target.stun=10;if(reason=="freeze")target.freeze=10;if(reason=="boss")target.boss=true;if(reason=="dead")target.dead=true;
            if(reason=="sight")
            {s.State.layout.legacy=false;s.State.layout.obstacles.Add(new RiftObstacle{id="pull-sight",position=s.State.position+Vector2.right*1.5f,halfSize=new Vector2(.1f,.5f),blocksWalk=false,blocksSight=true});}
            Start(s);Advance(s,20);Assert.AreEqual(before,target.position,reason);Assert.IsFalse(s.State.effectEvents.Any(e=>e.definitionId=="LW01"&&e.targetId==target.id));
        }
        [Test]
        public void PullStopsAtWalkBarrierEvenWhenTheEnemyIsVisible()
        {
            var s=Fixture();s.State.layout.legacy=false;var target=Enemy(s,950,Vector2.right*3.2f);Vector2 from=target.position;
            s.State.layout.obstacles.Add(new RiftObstacle{id="pull-low-wall",position=s.State.position+Vector2.right*1.8f,halfSize=new Vector2(.2f,.5f),blocksSight=false});
            Assert.IsTrue(s.Map.LineClear(s.State.position,target.position));Start(s);Advance(s,20);
            Assert.Less(target.position.x,from.x);Assert.GreaterOrEqual(target.position.x-s.State.position.x,2.4f-.001f);
            Assert.IsTrue(s.Map.Walkable(target.position,.4f));Assert.IsTrue(s.Map.TravelClear(from,target.position,.4f));
        }
        [Test]
        public void ActualPullInterruptsEnemyPreparationAndPreservesItsCooldown()
        {
            var s=Fixture();var target=s.State.enemies[0];target.kind=8;target.cooldown=0;Start(s);Advance(s,19);
            Assert.AreEqual(EnemyActionPhase.Preparing,target.brain.action.phase);int action=target.brain.action.id;float cooldown=target.cooldown;
            Advance(s,1);Assert.AreEqual(EnemyActionPhase.Idle,target.brain.action.phase);Assert.AreEqual(cooldown-CombatSimulation.Step,target.cooldown,.0001f);
            Assert.AreEqual(1,s.State.enemyEvents.Count(e=>e.actionId==action&&e.kind=="INTERRUPTED:회오리에 끌림"));
            Assert.IsFalse(s.State.enemyEvents.Any(e=>e.actionId==action&&e.kind=="RELEASE"));Assert.IsTrue(s.State.effectEvents.Any(e=>e.definitionId=="LW01"&&e.targetId==target.id&&e.value>0));
        }
        [TestCase(false)][TestCase(true)]
        public void PullNeedsBothTheWeaponAndASuccessfulPaidTick(bool insufficientResource)
        {
            var s=Fixture(insufficientResource);Start(s);Advance(s,19);if(insufficientResource)s.State.resource=0;
            Vector2 before=s.State.enemies[0].position;Advance(s,1);Assert.AreEqual(before,s.State.enemies[0].position);Assert.IsFalse(s.State.effectEvents.Any(e=>e.definitionId=="LW01"));
            if(insufficientResource)Assert.IsFalse(s.HeroActionBusy);
        }
        [Test]
        public void RestartingWhirlwindKeepsLastPullAndRequiresNewChannelMaintenance()
        {
            var s=Fixture();Start(s);Advance(s,20);float last=s.State.itemEffects.lastPull;s.State.enemies[0].position=s.State.position+Vector2.up*2.2f;
            Call(s,"InterruptHeroAction","channel restart");var restored=Restore(s);Start(restored);Advance(restored,19);Assert.AreEqual(last,restored.State.itemEffects.lastPull);
            Advance(restored,1);Assert.AreEqual(20,Mathf.RoundToInt(restored.State.itemEffects.lastPull/CombatSimulation.Step)-Mathf.RoundToInt(last/CombatSimulation.Step));
        }
        [Test]
        public void ExistingOverlappingCrowdCanSeparateButCannotBePulledDeeperIntoOtherBodies()
        {
            var s=Fixture();var inner=s.State.enemies[0];var outer=Enemy(s,950,Vector2.up*2.3f);float before=Vector2.Distance(inner.position,outer.position);
            Start(s);Advance(s,20);Assert.Greater(Vector2.Distance(inner.position,outer.position),before);Assert.GreaterOrEqual(Vector2.Distance(inner.position,outer.position),.8f-.0001f);
            Assert.GreaterOrEqual(Vector2.Distance(s.State.position,inner.position),.85f-.0001f);
        }
        [TestCase(false)][TestCase(true)]
        public void EquippedLandingLegendAddsOneIndependentShockwaveOnlyAfterSuccessfulLanding(bool cancel)
        {
            var s=Fixture();var target=s.State.enemies[0];target.position=s.State.position+Vector2.up*4;
            var edge=Enemy(s,950,new Vector2(3.5f,4));s.State.targetId=target.id;
            Call(s,"StartHeroAction",1,target,target.position,(float)Call(s,"Cost",catalog.skills[1]),-1,false);int root=s.State.heroAction.id;
            if(cancel)Call(s,"InterruptHeroAction","cancel leap preparation");Advance(s,40);
            var landing=s.State.damageEvents.Where(d=>d.definitionId=="W02").ToArray();var shock=s.State.damageEvents.Where(d=>d.definitionId=="LW02").ToArray();
            Assert.AreEqual(cancel?0:1,landing.Length);Assert.AreEqual(cancel?0:2,shock.Length);
            if(!cancel)
            {Assert.IsFalse(landing.Any(d=>d.targetId==edge.id));Assert.IsTrue(shock.All(d=>d.rootCastId==root&&d.kind==DamageKind.Legendary));Assert.IsTrue(shock.All(d=>Mathf.Abs(d.baseAttack-s.Stats.damage*.9f)<.001f));}
        }
        [TestCase(0,false)][TestCase(1,false)][TestCase(2,false)][TestCase(2,true)]
        public void EquippedCrushLegendCountsTheWholeImpactListBeforeAnyVictimDies(int count,bool firstDies)
        {
            var s=Fixture();var target=s.State.enemies[0];if(firstDies)target.health=1;
            if(count==2)Enemy(s,950,new Vector2(.4f,2.2f));s.State.targetId=target.id;
            Call(s,"StartHeroAction",2,target,target.position,(float)Call(s,"Cost",catalog.skills[2]),-1,false);
            if(count==0)target.position=s.State.position+Vector2.up*3.01f;
            Advance(s,30);var hits=s.State.damageEvents.Where(d=>d.definitionId=="W03").ToArray();Assert.AreEqual(count,hits.Length);
            foreach(var hit in hits)Assert.AreEqual(s.Stats.bonuses[4]/100+(count==1?.5f:0),hit.additive,.0001f);
            Assert.IsFalse(s.State.damageEvents.Any(d=>d.definitionId=="LW03"),"The single-target bonus is part of the hit, not a second attack.");
        }
    }
}
