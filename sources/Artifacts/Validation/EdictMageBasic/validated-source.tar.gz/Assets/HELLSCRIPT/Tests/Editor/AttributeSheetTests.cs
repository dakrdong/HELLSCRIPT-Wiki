using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class AttributeSheetTests
    {
        GameCatalog catalog;
        [SetUp]public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown]public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);

        static object Call(CombatSimulation sim,string name,params object[] arguments)
        {
            var method=typeof(CombatSimulation).GetMethod(name,BindingFlags.Instance|BindingFlags.NonPublic);
            var parameters=method.GetParameters();var filled=new object[parameters.Length];
            for(int i=0;i<filled.Length;i++)filled[i]=i<arguments.Length?arguments[i]:parameters[i].DefaultValue;
            return method.Invoke(sim,filled);
        }
        // A hero with nothing rolled, one motionless enemy in reach and a sheet pinned to
        // controlled numbers, so a test measures only the line it changes.
        CombatSimulation Fixture(HeroClass hero=HeroClass.Mage)
        {
            var account=GameStore.NewAccount();account.selectedHero=(int)hero;account.Hero.level=30;
            account.Hero.build.passives=Array.Empty<int>();account.Hero.build.potionThreshold=0;
            var sim=new CombatSimulation(account,catalog,1,1,seed:92);
            sim.State.build.rules.Clear();sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();sim.State.decisionTime=100;
            sim.State.enemies.Add(new EnemyState{id=900,position=sim.State.position+Vector2.up*2,health=10000,maxHealth=10000,cooldown=1000,speed=0});
            sim.Stats.hp=1000;sim.Stats.damage=100;sim.Stats.armor=sim.Stats.resistance=sim.Stats.regen=sim.Stats.crit=0;
            sim.Stats.shieldMultiplier=sim.Stats.healing=1;SheetFixture.Neutral(sim.Stats);
            sim.State.health=1000;return sim;
        }
        static DamageSnapshot Snapshot(float damage=100)
            =>new DamageSnapshot{damage=damage,level=30,critDamage=1.5f,elements=new float[Element.Count],passives=new bool[6]};

        // Existing saves address an affix by number. Renumbering any of the first twenty-four would
        // silently turn one stat into another on every character already created.
        [Test]
        public void TheFirstTwentyFourNumbersKeepWhatSavesWereWrittenWith()
        {
            var settled=new[]
            {
                StatId.MaximumLife,StatId.MaximumLifePercent,StatId.Armor,StatId.AllResistance,
                StatId.PhysicalDamage,StatId.FireDamage,StatId.ColdDamage,StatId.LightningDamage,
                StatId.PoisonDamage,StatId.ShadowDamage,StatId.Strength,StatId.Dexterity,
                StatId.Intelligence,StatId.Willpower,StatId.AllStats,StatId.CriticalStrikeChance,
                StatId.CriticalStrikeDamage,StatId.AttackSpeed,StatId.CooldownReduction,
                StatId.ResourceCostReduction,StatId.ResourceGeneration,StatId.MovementSpeed,
                StatId.PickupRadius,StatId.HealingReceived,
            };
            for(int i=0;i<settled.Length;i++)Assert.AreEqual(i,(int)settled[i],settled[i]+" moved off its saved number.");
        }

        [Test]
        public void EveryStatNumberCarriesExactlyOneDefinition()
        {
            Assert.AreEqual(Enum.GetValues(typeof(StatId)).Length,StatCatalog.All.Count);
            Assert.AreEqual(StatCatalog.All.Count,StatCatalog.Count);
            for(int i=0;i<StatCatalog.Count;i++)Assert.AreEqual(i,StatCatalog.Get(i).Index);
            CollectionAssert.AllItemsAreUnique(StatCatalog.All.Select(d=>d.id).ToList());
            Assert.IsTrue(StatCatalog.All.All(d=>!string.IsNullOrWhiteSpace(d.name)),"A stat reached the screen without a name.");
            Assert.Throws<ArgumentOutOfRangeException>(()=>StatCatalog.Get(StatCatalog.Count));
        }

        // The three lines below have nothing in this game to act on: the hero is never crowd
        // controlled and never spends stamina. They stay off the loot table rather than becoming
        // an affix that reads well and does nothing.
        static readonly StatId[] WithoutEffect={StatId.CrowdControlDuration,StatId.MaximumStamina,StatId.StaminaRegeneration};

        [Test]
        public void EveryStatThatDoesSomethingCanBeRolledOnGear()
        {
            var rolled=new HashSet<int>(ItemCatalog.Affixes.Select(a=>a.stat));
            var missing=StatCatalog.All.Where(d=>!WithoutEffect.Contains(d.id)&&!rolled.Contains(d.Index)).Select(d=>d.id.ToString()).ToList();
            Assert.IsEmpty(missing,"no affix rolls: "+string.Join(", ",missing));
            var stray=WithoutEffect.Where(id=>rolled.Contains((int)id)).Select(id=>id.ToString()).ToList();
            Assert.IsEmpty(stray,"rolled but does nothing: "+string.Join(", ",stray));
        }

        [Test]
        public void EveryAffixNamesAKnownStatAndFitsAtLeastOneSlot()
        {
            foreach(var affix in ItemCatalog.Affixes)
            {
                Assert.IsTrue(StatCatalog.Known(affix.stat),affix.id+" names an unknown stat.");
                Assert.IsTrue(Enumerable.Range(0,8).Any(affix.Allows),affix.id+" fits no slot.");
                Assert.Less(affix.min,affix.max,affix.id+" cannot roll a range.");
                Assert.Greater(affix.weight,0,affix.id+" can never be drawn.");
            }
            CollectionAssert.AllItemsAreUnique(ItemCatalog.Affixes.Select(a=>a.id).ToList());
        }

        // Generation picks how many prefixes and suffixes an item gets before it picks which ones,
        // so a slot has to hold enough distinct groups on each side to fill any legal split.
        [Test]
        public void EverySlotCanFillTheWidestLegalSplit()
        {
            for(int slot=0;slot<8;slot++)
            {
                var available=ItemCatalog.Affixes.Where(a=>a.Allows(slot)).ToList();
                int prefixes=available.Where(a=>a.side==AffixSide.Prefix).Select(a=>a.group).Distinct().Count();
                int suffixes=available.Where(a=>a.side==AffixSide.Suffix).Select(a=>a.group).Distinct().Count();
                Assert.GreaterOrEqual(prefixes,3,"slot "+slot+" cannot fill three prefixes.");
                Assert.GreaterOrEqual(suffixes,3,"slot "+slot+" cannot fill three suffixes.");
            }
        }

        static HeroSave Bare(HeroClass hero=HeroClass.Warrior,int level=30)
        {
            var account=GameStore.NewAccount();account.selectedHero=(int)hero;
            var save=account.Hero;save.level=level;save.inventory.Clear();save.build.passives=Array.Empty<int>();return save;
        }
        // Puts one rolled line on an equipped ring, the cheapest way to move a single stat.
        static HeroStats WithRoll(StatId stat,float value,HeroClass hero=HeroClass.Warrior)
        {
            var save=Bare(hero);
            var item=new Item{id="ring",baseId="B23",baseIndex=22,slot=7,rarity=1,level=1,equipped=true,contentVersion=ItemCatalog.Version};
            item.rolls.Add(new AffixRoll{slotId="ring:a0",affixId=ItemCatalog.Affixes.First(a=>a.stat==(int)stat).id,
                side=ItemCatalog.Affixes.First(a=>a.stat==(int)stat).side,tierId="T1",rollBasisPoints=10000,value=value});
            save.inventory.Add(item);return new HeroStats(save);
        }

        [TestCase(HeroClass.Warrior,0,4)]
        [TestCase(HeroClass.Ranger,0,4.4f)]
        [TestCase(HeroClass.Mage,0,4)]
        [TestCase(HeroClass.Warrior,25,5)]
        [TestCase(HeroClass.Ranger,25,5.5f)]
        [TestCase(HeroClass.Mage,80,6)]
        public void MovementSheetUsesActualSpeedWhileGearRetainsItsPercentage(HeroClass hero,float bonus,float expected)
        {
            var stats=WithRoll(StatId.MovementSpeed,bonus,hero);var definition=StatCatalog.Get(StatId.MovementSpeed);
            Assert.AreEqual(expected,stats.speed,.0001f);
            Assert.AreEqual(expected,stats.Sheet(StatId.MovementSpeed),.0001f);
            StringAssert.EndsWith("m/s",definition.FormatSheet(stats.Sheet(StatId.MovementSpeed)));
            StringAssert.DoesNotContain("%",definition.FormatSheet(stats.Sheet(StatId.MovementSpeed)));
            StringAssert.EndsWith("%",definition.Format(bonus));
            StringAssert.EndsWith("%",definition.Signed(bonus));
        }

        [Test]
        public void ARolledLineReachesTheSheetItBelongsTo()
        {
            Assert.AreEqual(.2f,WithRoll(StatId.DodgeChance,20).dodge-new HeroStats(Bare()).dodge,.0001f);
            Assert.AreEqual(.25f,WithRoll(StatId.BlockChance,25).blockChance,.0001f);
            Assert.AreEqual(.3f,WithRoll(StatId.BlockedDamageReduction,30).blockedReduction,.0001f);
            Assert.AreEqual(40,WithRoll(StatId.Thorns,40).thorns,.0001f);
            Assert.AreEqual(.05f,WithRoll(StatId.LifeSteal,5).lifeSteal,.0001f);
            Assert.AreEqual(.1f,WithRoll(StatId.DamageReduction,10).damageReduction,.0001f);
            Assert.AreEqual(12,WithRoll(StatId.LifeRegeneration,12).lifeRegen,.0001f);
            Assert.AreEqual(1.3f,WithRoll(StatId.PotionHealing,30).potionHealing,.0001f);
            Assert.AreEqual(1.25f,WithRoll(StatId.ExperienceGain,25).experienceGain,.0001f);
            Assert.AreEqual(1.5f,WithRoll(StatId.GoldFind,50).goldFind,.0001f);
            Assert.AreEqual(130,WithRoll(StatId.MaximumResource,30).maxResource,.0001f);
            Assert.AreEqual(.15f,WithRoll(StatId.CloseDamage,15).Conditional(DamageCondition.Close),.0001f);
        }

        // A ceiling belongs to the finished number, not to the roll: two pieces of gear that each
        // roll under the cap must not add up past it.
        [Test]
        public void TheSheetHoldsItsCeilings()
        {
            Assert.AreEqual(StatCatalog.Get(StatId.DodgeChance).cap/100,WithRoll(StatId.DodgeChance,500).dodge,.0001f);
            Assert.AreEqual(StatCatalog.Get(StatId.BlockChance).cap/100,WithRoll(StatId.BlockChance,500).blockChance,.0001f);
            Assert.AreEqual(StatCatalog.Get(StatId.DamageReduction).cap/100,WithRoll(StatId.DamageReduction,500).damageReduction,.0001f);
            Assert.AreEqual(60,StatCatalog.Cap(StatId.DodgeChance,999));
            Assert.AreEqual(999,StatCatalog.Cap(StatId.Thorns,999),"A stat without a ceiling keeps its value.");
        }

        // Diablo IV never adds two reductions together; it takes what is left after each one.
        [Test]
        public void ReductionsStackTheWayTheSheetStacksThem()
        {
            Assert.AreEqual(0,StatCatalog.Combine(),.0001f);
            Assert.AreEqual(.3f,StatCatalog.Combine(.3f),.0001f);
            Assert.AreEqual(.51f,StatCatalog.Combine(.3f,.3f),.0001f);
            Assert.AreEqual(.657f,StatCatalog.Combine(.3f,.3f,.3f),.0001f);
            Assert.AreEqual(1,StatCatalog.Combine(1,.5f),.0001f,"Nothing survives a full reduction.");
            Assert.AreEqual(.3f,StatCatalog.Combine(.3f,-.5f),.0001f,"A negative source cannot add damage back.");
        }

        [Test]
        public void ArmourAnswersPhysicalAndEachElementAnswersWithItsOwnResistance()
        {
            var save=Bare();
            var item=new Item{id="amulet",baseId="B20",baseIndex=19,slot=6,rarity=1,level=1,equipped=true,contentVersion=ItemCatalog.Version};
            item.rolls.Add(new AffixRoll{slotId="amulet:a0",affixId="AF38",side=AffixSide.Prefix,tierId="T1",rollBasisPoints=10000,value=40});
            save.inventory.Add(item);
            var stats=new HeroStats(save);
            Assert.AreEqual(stats.armor,stats.Resistance(Element.Physical),.0001f);
            Assert.AreEqual(stats.resistance+40,stats.Resistance(Element.Fire),.0001f);
            Assert.AreEqual(stats.resistance,stats.Resistance(Element.Cold),.0001f);
            Assert.AreEqual(stats.resistance,stats.Resistance(Element.Shadow),.0001f);
        }

        // Overwriting armour has to move what depends on it, or a test that pins the sheet would
        // still be measuring the resistance the constructor happened to compute.
        [Test]
        public void OverwritingArmourMovesThePhysicalRating()
        {
            var stats=new HeroStats(Bare());
            stats.armor=0;stats.resistance=0;
            Assert.AreEqual(0,stats.Resistance(Element.Physical),.0001f);
            Assert.AreEqual(0,stats.Resistance(Element.Fire),.0001f);
        }

        [Test]
        public void DodgeTurnsAHitIntoNothing()
        {
            var sim=Fixture();sim.Stats.dodge=1;
            Call(sim,"Hurt",500f);
            Assert.AreEqual(1000,sim.State.health,"A dodged hit costs no life.");
            Assert.IsTrue(sim.State.effectEvents.Any(e=>e.kind=="DODGED"));
            Assert.IsEmpty(sim.State.damageEvents.Where(d=>d.incoming),"A dodged hit is not a damage event.");
            sim.Stats.dodge=0;Call(sim,"Hurt",500f);
            Assert.AreEqual(500,sim.State.health,.001f);
        }

        [Test]
        public void ANeutralSheetNeverDrawsFromItsOwnStream()
        {
            var sim=Fixture();uint before=sim.State.sheetRng;
            Call(sim,"Hurt",100f);
            Assert.AreEqual(before,sim.State.sheetRng,"A sheet with nothing on it rolls nothing.");
        }

        // The sheet's rolls must not move the stream every saved run replays from, or adding them
        // would have changed the outcome of runs recorded before they existed.
        [Test]
        public void TheSheetRollsLeaveTheMainStreamAlone()
        {
            var sim=Fixture();sim.Stats.dodge=.5f;sim.Stats.blockChance=.5f;
            uint main=sim.State.rng;
            for(int n=0;n<20;n++)Call(sim,"Hurt",10f);
            Assert.AreEqual(main,sim.State.rng,"Dodge and block spent the main stream.");
            Assert.AreNotEqual(0u,sim.State.sheetRng);
        }

        [Test]
        public void ARestoredRunKeepsTheStreamItWasSavedWith()
        {
            var sim=Fixture();sim.Stats.dodge=.5f;
            for(int n=0;n<5;n++)Call(sim,"Hurt",10f);
            uint saved=sim.State.sheetRng;
            var copy=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(sim.State));
            GameStore.NormalizeRun(copy);
            Assert.AreEqual(saved,copy.sheetRng,"Normalising a saved run must not reseed its stream.");
            var older=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(sim.State));older.sheetRng=0;
            GameStore.NormalizeRun(older);
            Assert.AreNotEqual(0u,older.sheetRng,"A run saved before the sheet existed is given a stream.");
        }

        [Test]
        public void BlockKeepsItsShareOfTheHitOff()
        {
            var sim=Fixture();sim.Stats.blockChance=1;sim.Stats.blockedReduction=.5f;
            Call(sim,"Hurt",400f);
            Assert.AreEqual(800,sim.State.health,.001f);
            Assert.IsTrue(sim.State.effectEvents.Any(e=>e.kind=="BLOCKED"));
        }

        [Test]
        public void ReductionFromCloseAndDistantFollowTheAttackersDistance()
        {
            var sim=Fixture();sim.Stats.closeReduction=.5f;
            Call(sim,"Hurt",200f,0,"900");
            Assert.AreEqual(900,sim.State.health,.001f,"The enemy stands two metres away, which is close.");
            sim.State.health=1000;sim.State.enemies[0].position=sim.State.position+Vector2.up*9;
            Call(sim,"Hurt",200f,0,"900");
            Assert.AreEqual(800,sim.State.health,.001f,"Nine metres is not close.");
            sim.State.health=1000;sim.Stats.closeReduction=0;sim.Stats.distantReduction=.5f;
            Call(sim,"Hurt",200f,0,"900");
            Assert.AreEqual(900,sim.State.health,.001f);
        }

        [Test]
        public void ThornsAnswerTheAttackerAndNothingElse()
        {
            var sim=Fixture();sim.Stats.thorns=60;
            float before=sim.State.enemies[0].health;
            Call(sim,"Hurt",100f,0,"900");
            Assert.Less(sim.State.enemies[0].health,before,"Thorns never reached the attacker.");
            Assert.IsTrue(sim.State.damageEvents.Any(d=>d.definitionId=="THORNS"&&!d.incoming));
            float unanswered=sim.State.enemies[0].health;
            Call(sim,"Hurt",100f,0,"ENEMY");
            Assert.AreEqual(unanswered,sim.State.enemies[0].health,.001f,"An attacker this run cannot name takes nothing.");
        }

        [Test]
        public void LifeStealReturnsAShareOfTheDamageAndStopsAtFullLife()
        {
            var sim=Fixture();sim.Stats.lifeSteal=.1f;sim.State.health=500;
            var hit=(DamageEvent)Call(sim,"Hit",sim.State.enemies[0],1f,0,false,0f,Snapshot());
            Assert.AreEqual(500+hit.hpLoss*.1f,sim.State.health,.001f);
            sim.State.health=1000;
            Call(sim,"Hit",sim.State.enemies[0],1f,0,false,0f,Snapshot());
            Assert.AreEqual(1000,sim.State.health,.001f,"Life steal cannot overheal.");
        }

        [Test]
        public void ConditionalDamageFollowsTheTargetsCondition()
        {
            var sim=Fixture();var enemy=sim.State.enemies[0];
            float plain=((DamageEvent)Call(sim,"Hit",enemy,1f,0,false,0f,Snapshot())).finalDamage;
            sim.Stats.bonuses[(int)StatId.CloseDamage]=50;
            float close=((DamageEvent)Call(sim,"Hit",enemy,1f,0,false,0f,Snapshot())).finalDamage;
            Assert.AreEqual(plain*1.5f,close,.01f,"Close damage did not apply at two metres.");
            sim.Stats.bonuses[(int)StatId.CloseDamage]=0;
            sim.Stats.bonuses[(int)StatId.DamageToHealthy]=50;
            float healthy=((DamageEvent)Call(sim,"Hit",enemy,1f,0,false,0f,Snapshot())).finalDamage;
            Assert.AreEqual(plain*1.5f,healthy,.01f,"A full-life enemy is a healthy one.");
            sim.Stats.bonuses[(int)StatId.DamageToHealthy]=0;
            sim.Stats.bonuses[(int)StatId.DamageToInjured]=50;
            Assert.AreEqual(plain,((DamageEvent)Call(sim,"Hit",enemy,1f,0,false,0f,Snapshot())).finalDamage,.01f,
                "A full-life enemy is not an injured one.");
        }

        [Test]
        public void RegenerationOnlyReturnsWhatTheGearRolled()
        {
            var sim=Fixture();sim.State.health=500;
            Call(sim,"RegenerateLife",1f);
            Assert.AreEqual(500,sim.State.health,.001f,"A sheet without the roll regenerates nothing.");
            sim.Stats.lifeRegen=20;
            Call(sim,"RegenerateLife",1f);
            Assert.AreEqual(520,sim.State.health,.001f);
            sim.State.health=995;Call(sim,"RegenerateLife",1f);
            Assert.AreEqual(1000,sim.State.health,.001f,"Regeneration stops at full life.");
            sim.State.health=0;Call(sim,"RegenerateLife",1f);
            Assert.AreEqual(0,sim.State.health,.001f,"A dead hero does not regenerate.");
        }

        [Test]
        public void GoldFindNeverPaysLessThanThePayoutItScales()
        {
            var sim=Fixture();
            Assert.AreEqual(100,(int)Call(sim,"Gold",100));
            sim.Stats.goldFind=1.5f;
            Assert.AreEqual(150,(int)Call(sim,"Gold",100));
            sim.Stats.goldFind=1.004f;
            Assert.AreEqual(1,(int)Call(sim,"Gold",1),"Rounding may not turn a bonus into a loss.");
            sim.Stats.goldFind=0;
            Assert.AreEqual(7,(int)Call(sim,"Gold",7),"A cleared multiplier still pays the written amount.");
        }

        [Test]
        public void EveryStatNameAndUnitReachesTheScreen()
        {
            foreach(var definition in StatCatalog.All)
            {
                Assert.IsNotEmpty(definition.Name,definition.id+" has no name on screen.");
                Assert.IsNotEmpty(definition.Format(12.5f));
                StringAssert.StartsWith("+",definition.Signed(3));
                StringAssert.StartsWith("-",definition.Signed(-3));
            }
            StringAssert.Contains("%",StatCatalog.Get(StatId.CriticalStrikeChance).Format(5));
            StringAssert.Contains("m",StatCatalog.Get(StatId.PickupRadius).Format(2));
        }

        [Test]
        public void EveryPageOfTheSheetHoldsSomething()
        {
            foreach(StatPage page in Enum.GetValues(typeof(StatPage)))
                Assert.IsNotEmpty(StatCatalog.Page(page).ToList(),page+" is an empty page.");
            Assert.AreEqual(StatCatalog.All.Count,Enum.GetValues(typeof(StatPage)).Cast<StatPage>().Sum(p=>StatCatalog.Page(p).Count()));
        }
    }
}
