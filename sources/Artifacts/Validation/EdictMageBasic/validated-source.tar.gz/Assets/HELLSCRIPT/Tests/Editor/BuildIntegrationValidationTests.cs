using System.Linq;
using NUnit.Framework;
using Hellscript.Editor;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class BuildIntegrationValidationTests
    {
        [Test]
        public void ArchetypeBalanceSimulationRunnerRunsAcrossAll6ArchetypesWithoutExceptions()
        {
            // Run a targeted simulation (2 seeds per archetype) to verify deterministic stability and zero runtime exceptions
            var summaries = BuildIntegrationValidation.RunMultiSeedBalanceSimulation(seedCount: 2, stage: 1);
            Assert.AreEqual(6, summaries.Count, "Should produce summaries for all 6 core archetype builds");
            foreach (var s in summaries)
            {
                Assert.AreEqual(2, s.totalRuns);
                Assert.AreEqual(2,s.wins+s.defeats+s.incomplete);
                Assert.AreEqual(0,s.incomplete,$"Archetype {s.archetypeName} did not reach a terminal outcome");
                Assert.IsFalse(s.deathCauses.ContainsKey("NavigationBlocked"), $"Archetype {s.archetypeName} encountered navigation errors");
            }
        }
        [TestCase(RunPhase.Cleared,CombatFinish.HeroDeath,0,300,"Cleared")]
        [TestCase(RunPhase.Failed,CombatFinish.HeroDeath,0,300,"HeroDeath")]
        [TestCase(RunPhase.Failed,CombatFinish.Other,0,50,"HeroDeath")]
        [TestCase(RunPhase.Failed,CombatFinish.Other,100,300,"TimeLimit")]
        [TestCase(RunPhase.Failed,CombatFinish.Abandoned,100,300,"Abandoned")]
        [TestCase(RunPhase.Failed,CombatFinish.Other,100,20,"OtherFailure")]
        public void AuditSeparatesTerminalOutcomes(RunPhase phase,CombatFinish finish,float health,float time,string expected)
        {
            var run=new RunState{phase=phase,health=health,time=time,statistics=new CombatStatistics{finish=finish}};
            Assert.AreEqual(expected,BuildIntegrationValidation.AuditOutcome(run,300,6000,10000));
        }
        [TestCase(false,false,null,10,"Incomplete")]
        [TestCase(false,false,null,10000,"TickLimit")]
        [TestCase(true,false,null,10000,"PortalBlocked")]
        [TestCase(false,true,null,10000,"Paused")]
        [TestCase(false,false,"blocked",10000,"NavigationBlocked")]
        public void AuditDoesNotCallAnUnfinishedRunATimeLimit(bool portal,bool paused,string error,int ticks,string expected)
        {
            var run=new RunState{phase=RunPhase.Exploring,health=100,time=300,portal=portal,paused=paused,navigationError=error};
            Assert.AreEqual(expected,BuildIntegrationValidation.AuditOutcome(run,300,ticks,10000));
        }
        [TestCase(HeroClass.Warrior,0)] [TestCase(HeroClass.Warrior,1)]
        [TestCase(HeroClass.Ranger,0)] [TestCase(HeroClass.Ranger,1)]
        [TestCase(HeroClass.Mage,0)] [TestCase(HeroClass.Mage,1)]
        public void AuditUsesReproducibleLegalEightSlotEquipment(HeroClass heroClass,int variant)
        {
            var first=BuildIntegrationValidation.AuditAccount(heroClass,variant,54321).Hero;
            var second=BuildIntegrationValidation.AuditAccount(heroClass,variant,54321).Hero;
            Assert.AreEqual(8,first.inventory.Count(i=>i.equipped));
            CollectionAssert.AreEquivalent(Enumerable.Range(0,8),first.inventory.Select(i=>i.slot));
            Assert.AreEqual(JsonUtility.ToJson(first.build),JsonUtility.ToJson(second.build));
            for(int slot=0;slot<8;slot++)
            {
                var item=first.inventory[slot];ItemCatalog.Validate(item);
                Assert.AreEqual(JsonUtility.ToJson(item),JsonUtility.ToJson(second.inventory[slot]));
                Assert.AreEqual(30,item.level);Assert.AreEqual(0,item.enhancement);
                Assert.IsTrue(ItemCatalog.Bases.Single(b=>b.id==item.baseId).Fits(heroClass,slot));
            }
        }
    }
}
