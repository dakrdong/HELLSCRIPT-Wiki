namespace Hellscript.Tests
{
    // The sheet lines this project gained when it took on Diablo IV's stats. A test that pins the
    // older lines to controlled values pins these as well, so that a dodge, a block or an overpower
    // the test never asked about cannot move the number it is actually measuring.
    //
    // Vulnerable is deliberately left alone: its baseline is the same share a marked target always
    // added, so a test written before the sheet existed still measures what it did then.
    static class SheetFixture
    {
        public static void Neutral(HeroStats stats)
        {
            // Clearing the rolls as well as the derived lines, so that a conditional damage line
            // the gear happened to roll cannot change a number the test asserts exactly.
            for(int i=(int)StatId.VulnerableDamage;i<StatCatalog.Count;i++)stats.bonuses[i]=0;
            stats.dodge=stats.blockChance=stats.blockedReduction=stats.overpower=stats.luckyHit=0;
            stats.thorns=stats.lifeSteal=stats.lifeRegen=0;
            stats.damageReduction=stats.closeReduction=stats.distantReduction=0;
            stats.injuredReduction=stats.physicalReduction=0;
            stats.potionHealing=stats.experienceGain=stats.goldFind=1;
            stats.maxResource=100;
        }
    }
}
