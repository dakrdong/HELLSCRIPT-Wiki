using System.Linq;
using Hellscript.Editor;
using NUnit.Framework;

namespace Hellscript.Tests
{
    public sealed class AffixDistributionValidationTests
    {
        static AffixDefinition A(string id,string group,int weight)=>new AffixDefinition(id,0,AffixSide.Prefix,id,group,weight,1,2,false,0);
        [Test]
        public void RemovingAGroupSharesItsProbabilityBetweenItsAffixes()
        {
            var result=AffixDistributionValidation.Inclusion(new[]{A("a","shared",1),A("b","shared",1),A("c","solo",1)},HeroClass.Warrior,2);
            Assert.AreEqual(.5,result["a"],1e-12);Assert.AreEqual(.5,result["b"],1e-12);Assert.AreEqual(1,result["c"],1e-12);
        }
        [Test]
        public void WeightedGroupSelectionHasKnownTwoDrawMarginals()
        {
            var result=AffixDistributionValidation.Inclusion(new[]{A("a","a",1),A("b","b",1),A("c","c",2)},HeroClass.Warrior,2);
            Assert.AreEqual(7d/12,result["a"],1e-12);Assert.AreEqual(7d/12,result["b"],1e-12);Assert.AreEqual(5d/6,result["c"],1e-12);
        }
        [Test]
        public void BootsNormalizeOnlyFeasibleAllocationsForEachCatalogue()
        {
            var old=AffixDistributionValidation.Expected(ItemCatalog.Affixes.Take(24).ToArray(),HeroClass.Warrior,4,3);
            Assert.AreEqual(.75,old.allocations[2*5+2],1e-12);Assert.AreEqual(.25,old.allocations[1*5+3],1e-12);
            Assert.AreEqual(0,old.allocations[3*5+1]);Assert.AreEqual(4,old.affixes.Values.Sum(),1e-12);
            var current=AffixDistributionValidation.Expected(ItemCatalog.Affixes,HeroClass.Warrior,4,3);
            Assert.AreEqual(.6,current.allocations[2*5+2],1e-12);Assert.AreEqual(.2,current.allocations[1*5+3],1e-12);
            Assert.AreEqual(.2,current.allocations[3*5+1],1e-12);Assert.AreEqual(4,current.affixes.Values.Sum(),1e-12);
        }
        [TestCase(0,0)] [TestCase(1,1.5)] [TestCase(2,3)] [TestCase(3,4)]
        public void TheoryConservesProbabilityAndExpectedAffixCount(int rarity,double count)
        {
            for(int c=0;c<3;c++)for(int slot=0;slot<8;slot++)
            {
                var theory=AffixDistributionValidation.Expected(ItemCatalog.Affixes,(HeroClass)c,slot,rarity);
                Assert.AreEqual(1,theory.allocations.Sum(),1e-12);Assert.AreEqual(count,theory.affixes.Values.Sum(),1e-10);
                foreach(var affix in ItemCatalog.Affixes)
                {
                    Assert.That(theory.affixes[affix.id],Is.InRange(-1e-12,1+1e-12));
                    if(!affix.Allows(slot))Assert.AreEqual(0,theory.affixes[affix.id]);
                }
            }
        }
        [TestCase(0,0,100,true)] [TestCase(0,1,100,false)]
        [TestCase(1,100,100,true)] [TestCase(1,99,100,false)]
        [TestCase(.5,50000,100000,true)] [TestCase(.5,55000,100000,false)]
        public void StatisticalGateRejectsImpossibleAndMateriallyBiasedCounts(double p,int observed,int trials,bool expected)
        {Assert.AreEqual(expected,AffixDistributionValidation.Check("sample",observed,trials,p).passed);}
        [Test]
        public void CommonItemSampleReportsNoAffixesAndIsReproducible()
        {
            var first=AffixDistributionValidation.Sample(HeroClass.Mage,0,0,100);
            var second=AffixDistributionValidation.Sample(HeroClass.Mage,0,0,100);
            Assert.AreEqual(0,first.rolls);Assert.AreEqual(0,first.newRolls);Assert.AreEqual(first.finalRng,second.finalRng);
            Assert.AreEqual(100,first.allocations.Single(a=>a.id=="P0S0").observed);
            Assert.IsTrue(first.affixes.Concat(first.allocations).Concat(first.tiers).All(c=>c.passed));
        }
    }
}
