using System;
using System.Collections.Generic;
using System.IO;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class StoredLocalizationTests
    {
        static Dictionary<string,string> Table()=>LocalizationTable.Parse(File.ReadAllText(Path.Combine(Application.dataPath,"HELLSCRIPT/Resources/Localization/en.txt"))).Entries;
        [TearDown] public void Cleanup()=>Loc.UseSource();

        [TestCase("000.0s [RUN_START] 균열 10단계 진입","000.0s [RUN_START] Entered rift stage 10")]
        [TestCase("000.0s [RUN_END] 마을로 귀환","000.0s [RUN_END] Returning to town")]
        [TestCase("300,0s [RUN_END] 제한시간 초과","300,0s [RUN_END] Out of time")]
        public void SavedMessagesKeepTheirTimestampAndEventIdentifier(string saved,string expected)
        {
            Loc.Use("en",Table());Assert.AreEqual(expected,Loc.LogLine(saved));Assert.AreEqual(0,Loc.MissingCount);
            Loc.UseSource();Assert.AreEqual(saved,Loc.LogLine(saved));
        }
        [Test] public void ShippedDeathMessageTranslatesNestedNamesAndKeepsTheSavedNumber()
        {
            Loc.Use("en",Table());string expected=Loc.F("{0} #{1} 사망","보스",119);
            Assert.AreEqual("012.5s [ENEMY_DEATH] "+expected,Loc.LogLine("012.5s [ENEMY_DEATH] 보스 #119 사망"));
            Assert.AreEqual(0,Loc.MissingCount);
        }
        [Test] public void FormattedValuesKeepPrecisionWhenTheTranslationReordersArguments()
        {
            Loc.Use("en",new Dictionary<string,string>{{"받은 피해 {0:0.0} / HP {1:N0}","HP {1:N0}; damage {0:0.0}"}});
            Assert.AreEqual("HP 1,234; damage 12.7",Loc.StoredText("받은 피해 12.7 / HP 1,234"));Assert.AreEqual(0,Loc.MissingCount);
        }
        [Test] public void ExactEntriesAndSpecificTemplatesWinOverGeneralTemplates()
        {
            Loc.Use("en",new Dictionary<string,string>{{"목표 {0}","Goal {0}"},{"목표 정수 {0}명","Carriers {0}"},{"목표 정수 3명","All carriers"}});
            Assert.AreEqual("All carriers",Loc.StoredText("목표 정수 3명"));
            Assert.AreEqual("Carriers 2",Loc.StoredText("목표 정수 2명"));Assert.AreEqual(0,Loc.MissingCount);
        }
        [Test] public void EscapedBracesAndRepeatedArgumentsRemainLiteral()
        {
            Loc.Use("en",new Dictionary<string,string>{{"{{대상}} {0} / {0}","{{target}} {0} / {0}"}});
            Assert.AreEqual("{target} 12 / 12",Loc.StoredText("{대상} 12 / 12"));Assert.AreEqual(0,Loc.MissingCount);
        }
        [Test] public void ReapplyingTheLanguageClearsCachedTemplatesAndTranslations()
        {
            Loc.Use("en",new Dictionary<string,string>{{"목표 {0}","Goal {0}"}});Assert.AreEqual("Goal 3",Loc.StoredText("목표 3"));
            Loc.Use("en",new Dictionary<string,string>{{"목표 {0}","Objective {0}"}});Assert.AreEqual("Objective 3",Loc.StoredText("목표 3"));
            Loc.UseSource();Assert.AreEqual("목표 3",Loc.StoredText("목표 3"));
        }
        [Test] public void UnknownAndDamagedMessagesRemainReadableAndAreReported()
        {
            Loc.Use("en",new Dictionary<string,string>{{"목표 {0}","Goal {2}"},{"성소","Sanctuary"}});
            Assert.AreEqual("목표 3",Loc.StoredText("목표 3"));
            Assert.AreEqual("004.0s [UNKNOWN] 알 수 없는 기록",Loc.LogLine("004.0s [UNKNOWN] 알 수 없는 기록"));
            CollectionAssert.AreEquivalent(new[]{"목표 3","알 수 없는 기록"},Loc.Missing);
            Assert.AreEqual("raw 003.0s [TAG] alpha_42",Loc.LogLine("raw 003.0s [TAG] alpha_42"));
        }
        [Test] public void GenericJoinsTranslateKnownPartsWithoutChangingTheOriginalSave()
        {
            Loc.Use("en",Table());var record=new RunRecord{logs=new List<string>{"001.0s [TARGET_SELECTED] 쇠사슬 시체 · 영웅 사망"}};
            string saved=JsonUtility.ToJson(record);
            Assert.AreEqual("001.0s [TARGET_SELECTED] "+Loc.T("쇠사슬 시체")+" · "+Loc.T("영웅 사망"),Loc.LogLine(record.logs[0]));
            Assert.AreEqual(saved,JsonUtility.ToJson(record));Assert.AreEqual(0,Loc.MissingCount);
        }
        [TestCase("연쇄 번개 · 준비","Chain Lightning · preparing")]
        [TestCase("서리 폭발 · 준비 0.35초","Frost Nova · preparing 0.35s")]
        public void ACommittedActionCanChangeDisplayLanguageWithoutChangingTheRun(string action,string expected)
        {
            var run=new RunState{action=action};string saved=JsonUtility.ToJson(run);
            Loc.Use("en",Table());
            Assert.AreEqual(expected+"   |   1×",Loc.F("{0}   |   {1:0.#}×",Loc.StoredText(run.action),1));
            Assert.AreEqual(0,Loc.MissingCount);Assert.AreEqual(saved,JsonUtility.ToJson(run));
            Loc.UseSource();Assert.AreEqual(action,Loc.StoredText(run.action));
        }
    }
}
