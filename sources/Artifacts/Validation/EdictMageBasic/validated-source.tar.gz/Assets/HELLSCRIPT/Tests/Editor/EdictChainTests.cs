using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class EdictChainTests
    {
        GameCatalog catalog;
        [SetUp] public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown] public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        static readonly string[] Set={"SMB1","SMB2","SMB3","SMB4"};
        CombatSimulation Fixture(bool enabled=true,bool legacyRow=true,bool passive=false,params string[] gear)
        {
            var account=GameStore.NewAccount();account.selectedHero=2;var hero=account.Hero;hero.level=30;hero.inventory.Clear();
            hero.build.activeSkills=new List<int>{14};hero.build.passives=passive?new[]{2}:Array.Empty<int>();hero.build.potionThreshold=0;hero.build.movement=MovementMode.Stand;
            hero.build.rules=legacyRow?new List<Rule>{BehaviorRules.Make(14,BehaviorRules.C("SC06",Comparison.AtLeast,99,predicted:true))}:new List<Rule>();
            uint rng=91367;
            foreach(string id in gear)
            {
                var item=ItemGenerator.Create(HeroClass.Mage,ItemCatalog.Unique(id).slot,3,30,ref rng,uniqueId:id);
                hero.inventory.Add(item);Assert.IsTrue(Economy.Equip(hero,item));
            }
            hero.edict=HuntEdictV2.WithOption(HuntEdictV2Storage.CreateForHero(hero),"BASIC",1,"OFF");hero.edict=HuntEdictV2.WithOption(hero.edict,"M03",1,"ON");
            hero.edict=HuntEdictV2Editing.WithGlobal(hero.edict,"position.mode","STAND");hero.useEdict=enabled;
            var sim=new CombatSimulation(account,catalog,1,1,seed:43177);sim.State.position=RiftMap.Rooms[0];
            sim.State.enemies.Clear();sim.State.exploration.enemies.Clear();Controlled(sim);return sim;
        }
        static void Controlled(CombatSimulation sim){sim.Stats.crit=0;sim.Stats.regen=0;sim.Stats.costReduction=0;sim.Stats.luckyHit=0;}
        static EnemyState Enemy(CombatSimulation sim,float x,float y,int kind=0,int elite=-1,bool boss=false)
        {
            var enemy=new EnemyState{id=900+sim.State.enemies.Count,kind=kind,elite=elite,boss=boss,position=sim.State.position+new Vector2(x,y),
                health=1000000,maxHealth=1000000,speed=0,attack=0,cooldown=1000};sim.State.enemies.Add(enemy);return enemy;
        }
        static void Option(CombatSimulation sim,int n,string value)
        {sim.Hero.edict=HuntEdictV2.WithOption(sim.Hero.edict,"M03",n,value);sim.RefreshEdict();}
        static void Advance(CombatSimulation sim,int ticks=25){for(int i=0;i<ticks;i++)sim.Tick(CombatSimulation.Step);}
        static int Starts(CombatSimulation sim)=>sim.State.statistics.skills.FirstOrDefault(s=>s.definitionId=="M03")?.starts??0;
        static DamageEvent[] Hits(CombatSimulation sim,int root)=>sim.State.damageEvents.Where(e=>e.definitionId=="M03"&&e.rootCastId==root&&!e.incoming).ToArray();
        static EdictAimPlan Plan(CombatSimulation sim,EnemyState target)=>sim.PlanEdictAim(sim.Hero.edict,"M03",target);
        CombatSimulation Restore(CombatSimulation sim)
        {
            var account=GameStore.NewAccount();account.selectedHero=2;account.heroes[2]=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(sim.Hero));
            var restored=new CombatSimulation(account,catalog,1,restore:JsonUtility.FromJson<RunState>(JsonUtility.ToJson(sim.State)));Controlled(restored);return restored;
        }

        [TestCase(true)] [TestCase(false)]
        public void CorePolicyFiresWithoutALegacyConditionOrRow(bool legacyRow)
        {
            var sim=Fixture(legacyRow:legacyRow);Enemy(sim,0,4);string before=JsonUtility.ToJson(sim.State.build);Advance(sim);
            Assert.AreEqual(1,Starts(sim));Assert.AreEqual(before,JsonUtility.ToJson(sim.State.build));
            Assert.IsTrue(sim.State.decisions.Any(d=>d.ruleId=="edict:M03"&&d.code=="SELECTED"));Assert.IsTrue(sim.State.damageEvents.Any(d=>d.definitionId=="M03"));
        }
        [Test] public void OptingOutPreservesTheOldBlockingCondition()
        {var sim=Fixture(false);Enemy(sim,0,4);Advance(sim);Assert.AreEqual(0,Starts(sim));Assert.IsFalse(sim.State.decisions.Any(d=>d.ruleId=="edict:M03"));}
        [Test] public void DisabledDuplicatesProduceOneEnabledDerivedCandidate()
        {
            var sim=Fixture();sim.State.build.rules[0].enabled=false;sim.State.build.rules.Add(BehaviorRules.Make(14));
            string before=JsonUtility.ToJson(sim.State.build);var rows=EdictRuleOrder.ForSimulation(sim.State.build.rules,sim.Hero.edict).Where(o=>o.rule.action==RuleAction.Skill).ToList();
            Assert.AreEqual(1,rows.Count);Assert.IsTrue(rows.Single().rule.enabled&&rows.Single().rule.always);Assert.AreEqual(before,JsonUtility.ToJson(sim.State.build));
        }
        [TestCase("SINGLE",1,true)] [TestCase("LINKED",1,false)] [TestCase("LINKED",2,true)]
        [TestCase("SAVE_CHARGE",1,false)] [TestCase("SAVE_CHARGE",2,true)]
        public void PurposeUsesTheFixedDistinctTargetThreshold(string purpose,int count,bool allowed)
        {
            var sim=Fixture();var target=Enemy(sim,0,4);if(count>1)Enemy(sim,1,4);Option(sim,2,purpose);
            Assert.AreEqual(allowed,Plan(sim,target).available);Advance(sim);Assert.AreEqual(allowed,Starts(sim)>0);
            Assert.AreEqual(purpose,HuntEdictV2.Value(sim.Hero.edict,"M03",2));
        }
        [Test] public void TwoDisconnectedEnemiesDoNotSatisfyLinkedPurpose()
        {var sim=Fixture();var a=Enemy(sim,-4,2);Enemy(sim,4,2);Option(sim,2,"LINKED");Assert.IsFalse(Plan(sim,a).available);Advance(sim);Assert.AreEqual(0,Starts(sim));}
        [TestCase(.01f,1,true)] [TestCase(1f,1,true)] [TestCase(1.01f,1,false)] [TestCase(0f,1,false)] [TestCase(.5f,0,false)]
        public void SaveChargeAllowsASingleTargetOnlyWithALiveChargeExpiringWithinOneSecond(float remaining,int charges,bool allowed)
        {
            var sim=Fixture(gear:Set);var target=Enemy(sim,0,4);Option(sim,2,"SAVE_CHARGE");sim.State.itemEffects.chainCharge=remaining;sim.State.itemEffects.chainCharges=charges;
            string before=JsonUtility.ToJson(sim.State);Assert.AreEqual(allowed,Plan(sim,target).available);Assert.AreEqual(before,JsonUtility.ToJson(sim.State));
        }
        [Test] public void SaveChargeWithoutTheSetFallsBackToLinkedWithoutWaitingForNova()
        {
            var sim=Fixture();var a=Enemy(sim,0,4);Enemy(sim,1,4);Option(sim,2,"SAVE_CHARGE");var plan=Plan(sim,a);
            Assert.IsTrue(plan.available);Assert.That(plan.reason,Does.Contain("SMB 4세트"));Advance(sim);Assert.AreEqual(1,Starts(sim));
            Assert.AreEqual("SAVE_CHARGE",HuntEdictV2.Value(sim.Hero.edict,"M03",2));Assert.IsFalse(sim.State.build.activeSkills.Contains(17));
        }
        [TestCase("ALL",0)] [TestCase("ELITE",1)] [TestCase("SUPPORT",2)]
        public void FirstTargetPreferenceFiltersBeforeComparingConnections(string preference,int expected)
        {
            var sim=Fixture();var global=Enemy(sim,-4,2);var elite=Enemy(sim,4,2,elite:0);var support=Enemy(sim,0,8,kind:10);
            Option(sim,3,preference);Assert.AreEqual(new[]{global.id,elite.id,support.id}[expected],Plan(sim,global).targetId);
        }
        [TestCase("ELITE")] [TestCase("SUPPORT")]
        public void MissingOrOutOfRangePreferredTypesFallBackToOtherValidFirstTargets(string preference)
        {
            var sim=Fixture();var global=Enemy(sim,0,4);Enemy(sim,0,11,kind:preference=="SUPPORT"?4:0,elite:preference=="ELITE"?0:-1);
            Option(sim,3,preference);Assert.AreEqual(global.id,Plan(sim,global).targetId);
        }
        [Test] public void PreferredFirstTargetCannotBorrowASeparateGroupsHits()
        {
            var sim=Fixture();var elite=Enemy(sim,-4,2,elite:0);Enemy(sim,4,2);Enemy(sim,4,3);
            Option(sim,3,"ELITE");Option(sim,2,"LINKED");Assert.IsFalse(Plan(sim,elite).available);Advance(sim);Assert.AreEqual(0,Starts(sim));
        }
        [TestCase("UNIQUE",false)] [TestCase("TOTAL_HITS",true)]
        public void UniqueAndTotalCriteriaChooseDifferentLegalChains(string mode,bool choosePair)
        {
            var sim=Fixture(gear:new[]{"LM04"});var global=Enemy(sim,-5,0);Enemy(sim,-5,1);Enemy(sim,3,0);Enemy(sim,4,0);Enemy(sim,5,0);Enemy(sim,6,0);
            Option(sim,4,mode);var plan=Plan(sim,global);Assert.IsTrue(plan.available);Assert.AreEqual(choosePair,plan.targetId==global.id);
            Assert.AreEqual(4,plan.forecast.TotalHits);Assert.AreEqual(choosePair?2:4,plan.forecast.uniqueTargets);
        }
        [Test] public void TotalWithoutLm04FallsBackWithoutEditingTheSavedChoice()
        {
            var sim=Fixture();var a=Enemy(sim,0,4);Option(sim,4,"TOTAL_HITS");var plan=Plan(sim,a);Assert.IsTrue(plan.available);
            Assert.That(plan.reason,Does.Contain("고유 대상"));Assert.AreEqual("TOTAL_HITS",HuntEdictV2.Value(sim.Hero.edict,"M03",4));Advance(sim);Assert.AreEqual(1,Starts(sim));
        }
        [TestCase("HIGH_HP")] [TestCase("LOW_HP")]
        public void TiedChainsRespectTheExactGlobalTarget(string mode)
        {
            var sim=Fixture(legacyRow:false);var a=Enemy(sim,-4,2);var b=Enemy(sim,4,2);a.health=a.maxHealth*.5f;b.health=b.maxHealth*(mode=="HIGH_HP"?.9f:.1f);
            sim.Hero.edict=HuntEdictV2Editing.WithGlobal(sim.Hero.edict,"target.default",mode);sim.RefreshEdict();Advance(sim,1);Assert.AreEqual(b.id,sim.State.heroAction.targetId);
        }
        [Test] public void ExcludedOrHiddenPreferredEnemiesCannotBecomeFirstTargets()
        {
            var sim=Fixture();var a=Enemy(sim,0,4);var excluded=Enemy(sim,4,4,elite:0);Enemy(sim,0,40,elite:0);Enemy(sim,-4,4,elite:0).dead=true;
            sim.State.edictTarget=new EdictTargetState();sim.State.edictTarget.excluded.Add(excluded.id);Option(sim,3,"ELITE");Assert.AreEqual(a.id,Plan(sim,a).targetId);
        }
        [TestCase(false,false,4)] [TestCase(true,false,5)] [TestCase(false,true,6)] [TestCase(true,true,7)]
        public void ActualLimitsAndVisitOrderMatchTheForecast(bool passive,bool charged,int maximum)
        {
            var sim=Fixture(passive:passive,gear:Set.Concat(new[]{"LM04"}).ToArray());for(int i=0;i<7;i++)Enemy(sim,i*.8f,2);
            if(charged){sim.State.itemEffects.chainCharge=6;sim.State.itemEffects.chainCharges=2;}
            var plan=Plan(sim,sim.State.enemies[0]);Assert.AreEqual(maximum,plan.forecast.TotalHits);Advance(sim,1);int root=sim.State.heroAction.id;
            Assert.AreEqual(charged?1:0,sim.State.itemEffects.chainCharges);Option(sim,1,"OFF");Advance(sim);
            CollectionAssert.AreEqual(plan.forecast.hits,Hits(sim,root).Select(h=>h.targetId));Assert.AreEqual(1,Starts(sim));
        }
        [Test] public void Lm04RevisitsApplyDecayAndHalfDamageWithoutIncreasingTheHitCap()
        {
            var sim=Fixture(gear:new[]{"LM04"});var a=Enemy(sim,0,2);var b=Enemy(sim,1,2);Advance(sim,1);int root=sim.State.heroAction.id;Option(sim,1,"OFF");Advance(sim);
            var hits=Hits(sim,root);CollectionAssert.AreEqual(new[]{a.id,b.id,a.id,b.id},hits.Select(h=>h.targetId));
            for(int i=0;i<4;i++)Assert.AreEqual(hits[0].baseAttack*Mathf.Pow(.8f,i)*(i>=2?.5f:1),hits[i].baseAttack,.0001f);
        }
        [Test] public void AChargedLm04CastStillHitsASingleBossOnlyOnce()
        {
            var sim=Fixture(passive:true,gear:Set.Concat(new[]{"LM04"}).ToArray());var boss=Enemy(sim,0,4,boss:true);sim.State.itemEffects.chainCharge=6;sim.State.itemEffects.chainCharges=2;
            var plan=Plan(sim,boss);Assert.AreEqual(1,plan.forecast.TotalHits);Advance(sim,1);int root=sim.State.heroAction.id;Option(sim,1,"OFF");Advance(sim);Assert.AreEqual(1,Hits(sim,root).Length);
        }
        [TestCase("RESOURCE")] [TestCase("COOLDOWN")] [TestCase("LEVEL_LOCK")] [TestCase("EDICT_OFF")]
        public void ExecutionGatesDoNotConsumeChargesOrResource(string gate)
        {
            var sim=Fixture(gear:Set);Enemy(sim,0,4);sim.State.itemEffects.chainCharge=6;sim.State.itemEffects.chainCharges=2;
            if(gate=="RESOURCE")sim.State.resource=0;if(gate=="COOLDOWN")sim.State.cooldowns[14]=100;
            if(gate=="LEVEL_LOCK"){sim.Hero.level=1;sim.State.trainingUsesOwnedHero=true;}if(gate=="EDICT_OFF")Option(sim,1,"OFF");
            float resource=sim.State.resource;Advance(sim,1);Assert.AreEqual(0,Starts(sim));Assert.AreEqual(2,sim.State.itemEffects.chainCharges);Assert.AreEqual(resource,sim.State.resource);
            Assert.IsTrue(sim.State.decisions.Any(d=>d.ruleId=="edict:M03"&&d.code==gate));
        }
        [Test] public void MissingLegacyRowCanApproachAndTurningOffCancelsFurtherApproach()
        {
            var sim=Fixture(legacyRow:false);Enemy(sim,0,11);Vector2 before=sim.State.position;Advance(sim,1);
            Assert.AreNotEqual(before,sim.State.position);Assert.IsTrue(sim.State.decisions.Any(d=>d.ruleId=="edict:M03"&&d.code=="RANGE"));
            Option(sim,1,"OFF");sim.State.decisionTime=0;before=sim.State.position;Advance(sim,10);Assert.AreEqual(before,sim.State.position);Assert.AreEqual(-1,sim.State.movementRule);
            Option(sim,1,"ON");sim.State.decisionTime=0;Advance(sim,80);Assert.Greater(Starts(sim),0);
        }
        [Test] public void PaidCastKeepsItsFirstTargetAndReservedBonusAcrossEditingAndRestart()
        {
            var sim=Fixture(passive:true,gear:Set.Concat(new[]{"LM04"}).ToArray());for(int i=0;i<4;i++)Enemy(sim,i,2);
            sim.State.itemEffects.chainCharge=.2f;sim.State.itemEffects.chainCharges=1;Advance(sim,1);var action=sim.State.heroAction;
            Assert.AreEqual("edict:M03",action.policy.rule.id);Assert.AreEqual(2,action.chainBonus);Assert.AreEqual(0,sim.State.itemEffects.chainCharges);
            Option(sim,3,"SUPPORT");Option(sim,2,"LINKED");Option(sim,1,"OFF");var restored=Restore(sim);
            for(int i=0;i<60;i++){Advance(sim,1);Advance(restored,1);Assert.AreEqual(JsonUtility.ToJson(sim.State),JsonUtility.ToJson(restored.State),"replay tick "+i);}
            Assert.AreEqual(7,Hits(sim,action.id).Length);Assert.AreEqual(action.targetId,Hits(sim,action.id)[0].targetId);Assert.AreEqual(1,Starts(sim));
            Assert.AreEqual(1,sim.State.effectEvents.Count(e=>e.definitionId=="SMB4"&&e.kind=="RESERVED"));
        }
        [TestCase(true,"range")] [TestCase(false,"range")] [TestCase(true,"sight")] [TestCase(false,"sight")]
        [TestCase(true,"dead")] [TestCase(false,"dead")] [TestCase(true,"hidden")] [TestCase(false,"hidden")]
        public void AFirstTargetLostDuringPreparationCannotBeHitOrReplacedByAnotherEnemy(bool enabled,string loss)
        {
            var sim=Fixture(enabled,gear:Set);if(!enabled)sim.State.build.rules=new List<Rule>{BehaviorRules.Make(14)};
            var target=Enemy(sim,0,4);sim.State.itemEffects.chainCharge=6;sim.State.itemEffects.chainCharges=1;Advance(sim,1);
            var action=sim.State.heroAction;Assert.AreEqual(14,action.skill);Assert.AreEqual(target.id,action.targetId);float paid=sim.State.resource;Enemy(sim,0,2);
            if(loss=="range")target.position=action.origin+Vector2.up*11;
            if(loss=="hidden")target.position=action.origin+Vector2.up*30;
            if(loss=="dead")target.dead=true;
            if(loss=="sight")
            {
                // This synthetic room has no exits; legacy corridors have no procedural door indices.
                sim.State.layout.legacy=false;sim.State.layout.corridors.Clear();
                sim.State.layout.obstacles.Add(new RiftObstacle{id="screen",position=action.origin+Vector2.up*3,halfSize=new Vector2(8,.1f),blocksSight=true,blocksWalk=false,blocksProjectile=false});
            }
            sim.State.decisionTime=100;Advance(sim,15);Assert.IsEmpty(Hits(sim,action.id));Assert.AreEqual(paid,sim.State.resource);
            Assert.AreEqual(0,sim.State.itemEffects.chainCharges);Assert.AreEqual(1,sim.State.actionEvents.Count(e=>e.actionId==action.id&&e.kind=="ACTION_MISS"));
        }
        [Test] public void MovedSecondaryTargetsAreReevaluatedAtRelease()
        {
            var sim=Fixture(gear:new[]{"LM04"});var a=Enemy(sim,0,2);var b=Enemy(sim,1,2);var plan=Plan(sim,a);Assert.AreEqual(4,plan.forecast.TotalHits);
            Advance(sim,1);int root=sim.State.heroAction.id;b.position=sim.State.position+Vector2.right*9;Option(sim,1,"OFF");Advance(sim);
            CollectionAssert.AreEqual(new[]{a.id},Hits(sim,root).Select(h=>h.targetId));
        }
        [Test] public void SetAndLc02CostReductionsAreConsumedOnlyOnThePaidCast()
        {
            var sim=Fixture(gear:new[]{"SMB1","SMB2","LC02"});Enemy(sim,0,4);sim.State.itemEffects.reducedNext=true;sim.State.itemEffects.lc02Charge=5;
            Option(sim,2,"LINKED");float before=sim.State.resource;Advance(sim,1);Assert.AreEqual(before,sim.State.resource);Assert.IsTrue(sim.State.itemEffects.reducedNext);
            Option(sim,2,"SINGLE");sim.State.decisionTime=0;Advance(sim,1);Assert.AreEqual(12.5f,sim.State.heroAction.cost,.001f);Assert.AreEqual(before-12.5f,sim.State.resource,.001f);
            Assert.IsFalse(sim.State.itemEffects.reducedNext);Option(sim,1,"OFF");Advance(sim);Assert.AreEqual(1,Starts(sim));
        }
        [Test] public void ARealNovaGrantsTwoChargesAndTwoChainCastsConsumeOneEach()
        {
            var sim=Fixture(passive:true,gear:Set.Concat(new[]{"LM04"}).ToArray());
            sim.Hero.build.activeSkills.Add(17);sim.State.build.activeSkills.Add(17);sim.State.build.rules.Add(BehaviorRules.Make(17));
            sim.Hero.edict=HuntEdictV2.WithOption(HuntEdictV2.WithOption(HuntEdictV2Storage.CreateForHero(sim.Hero),"BASIC",1,"OFF"),"M06",2,"GROUP");Option(sim,1,"OFF");
            Enemy(sim,0,1);Enemy(sim,1,1);Enemy(sim,-1,1);Enemy(sim,0,2.2f);Advance(sim,9);
            Assert.AreEqual(0,Starts(sim));Assert.AreEqual(2,sim.State.itemEffects.chainCharges);
            Assert.IsTrue(sim.State.damageEvents.Any(d=>d.definitionId=="M06"));
            Option(sim,1,"ON");sim.State.decisionTime=0;Advance(sim,1);Assert.AreEqual(1,sim.State.itemEffects.chainCharges);
            for(int i=0;i<80&&Starts(sim)<2;i++)Advance(sim,1);
            Assert.AreEqual(2,Starts(sim));Assert.AreEqual(0,sim.State.itemEffects.chainCharges);Option(sim,1,"OFF");Advance(sim,20);
            var roots=sim.State.actionEvents.Where(e=>e.skill==14&&e.kind=="ACTION_START").Select(e=>e.actionId).ToArray();
            Assert.IsTrue(roots.All(root=>Hits(sim,root).Length==7));
            Assert.AreEqual(2,sim.State.effectEvents.Count(e=>e.definitionId=="SMB4"&&e.kind=="RESERVED"));
        }
    }
}
