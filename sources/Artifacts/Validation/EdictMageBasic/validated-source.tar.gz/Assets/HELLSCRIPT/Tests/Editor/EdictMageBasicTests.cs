using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class EdictMageBasicTests
    {
        GameCatalog catalog;
        [SetUp] public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown] public void Cleanup()=>UnityEngine.Object.DestroyImmediate(catalog);
        CombatSimulation Fixture(string rows="BLOCKED",bool enabled=true,bool necklace=false,int passive=-1)
        {
            var a=ContentTestAccounts.Training(catalog);a.selectedHero=2;var h=a.Hero;h.level=30;h.inventory.Clear();h.build.activeSkills=new List<int>{12,13,14,17};h.build.passives=passive<0?Array.Empty<int>():new[]{passive};
            h.build.rules=new List<Rule>();
            if(rows!="MISSING")h.build.rules.Add(rows=="BLOCKED"?BehaviorRules.Utility(RuleAction.Basic,BehaviorRules.C("SC01",Comparison.AtMost,0)):BehaviorRules.Utility(RuleAction.Basic));
            if(rows=="DISABLED")h.build.rules[0].enabled=false;if(rows=="DUPLICATE")h.build.rules.Add(BehaviorRules.Utility(RuleAction.Basic));
            if(necklace){uint rng=176109;var item=ItemGenerator.Create(HeroClass.Mage,ItemCatalog.Unique("LC02").slot,3,30,ref rng,uniqueId:"LC02");h.inventory.Add(item);Assert.IsTrue(Economy.Equip(h,item));}
            h.edict=HuntEdictV2Storage.CreateForHero(h);h.useEdict=enabled;
            foreach(var p in new[]{("position.mode","STAND"),("survival.potion","OFF"),("survival.lowHp","OFF"),("survival.lethal","OFF")})h.edict=HuntEdictV2Editing.WithGlobal(h.edict,p.Item1,p.Item2);
            var s=new CombatSimulation(a,catalog,1,1,ownedTraining:true);s.State.enemies.Clear();s.State.exploration.enemies.Clear();s.State.position=RiftMap.Rooms[0];Controlled(s);s.State.health=1000;s.State.resource=10;
            foreach(int i in h.build.activeSkills)s.State.cooldowns[i]=1000;return s;
        }
        static void Controlled(CombatSimulation s)
        {s.Stats.hp=1000;s.Stats.maxResource=100;s.Stats.attackSpeed=1;s.Stats.regen=s.Stats.crit=s.Stats.costReduction=s.Stats.cdr=0;SheetFixture.Neutral(s.Stats);}
        static EnemyState Enemy(CombatSimulation s,float x,float y=0)
        {var e=new EnemyState{id=900+s.State.enemies.Count,kind=0,position=s.State.position+new Vector2(x,y),health=1000000,maxHealth=1000000,speed=0,attack=0,cooldown=1000};e.brain.initialized=true;s.State.enemies.Add(e);return e;}
        static void Option(CombatSimulation s,int n,string value,string skill="BASIC")
        {s.Hero.edict=HuntEdictV2.WithOption(s.Hero.edict,skill,n,value);s.RefreshEdict();}
        static void Global(CombatSimulation s,string id,string value)
        {s.Hero.edict=HuntEdictV2Editing.WithGlobal(s.Hero.edict,id,value);s.RefreshEdict();}
        static EdictAimPlan Plan(CombatSimulation s,EnemyState target=null)=>s.PlanEdictAim(s.Hero.edict,"BASIC",target);
        static void Advance(CombatSimulation s,int n=1){for(int i=0;i<n;i++)s.Tick(CombatSimulation.Step);}
        static int Starts(CombatSimulation s)=>s.State.actionEvents.Count(a=>a.skill<0&&a.kind=="ACTION_START");
        static int Hits(CombatSimulation s)=>s.State.damageEvents.Count(d=>!d.incoming&&d.definitionId=="BASIC");
        CombatSimulation Restore(CombatSimulation s)
        {
            var a=ContentTestAccounts.Training(catalog);a.selectedHero=2;a.heroes[2]=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(s.Hero));
            var run=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(s.State));GameStore.NormalizeRun(run);
            var restored=new CombatSimulation(a,catalog,1,restore:run);Controlled(restored);return restored;
        }
        [TestCase("MISSING")][TestCase("BLOCKED")][TestCase("DISABLED")][TestCase("DUPLICATE")][TestCase("ENABLED")]
        public void OneIndependentBasicIgnoresLegacyConditions(string rows)
        {
            var s=Fixture(rows);Enemy(s,4);string build=JsonUtility.ToJson(s.State.build);Advance(s,14);
            Assert.AreEqual(1,Starts(s));Assert.AreEqual(1,Hits(s));Assert.AreEqual(15,s.State.resource,.001);Assert.AreEqual(build,JsonUtility.ToJson(s.State.build));
            Assert.IsTrue(s.State.decisions.Any(d=>d.ruleId=="edict:MAGE:BASIC"&&d.code=="SELECTED"));Assert.AreEqual("edict:MAGE:BASIC",s.State.heroAction.policy.rule.id);
        }
        [Test] public void BasicNeverUsesAnActiveSlotAndInvalidSkillRowsAreNotConverted()
        {
            var s=Fixture("MISSING");s.State.build.rules.Add(BehaviorRules.Make(-1));var order=EdictRuleOrder.ForSimulation(s.State.build.rules,s.Hero.edict);
            Assert.AreEqual(1,order.Count(o=>o.rule.id=="edict:MAGE:BASIC"));Assert.AreEqual(1,order.Count(o=>o.rule.action==RuleAction.Skill&&o.rule.skill==-1));Assert.IsFalse(s.Hero.edict.slots.Contains("BASIC"));
        }
        [Test] public void OptingOutKeepsTheOldBlockedBasic()
        {var s=Fixture(enabled:false);Enemy(s,4);Advance(s,20);Assert.AreEqual(0,Starts(s));Assert.AreEqual(0,s.EdictAimedCasts);}
        [Test] public void AutomaticOffStillKeepsTheBasicCandidateVisible()
        {var s=Fixture();Enemy(s,4);Option(s,1,"OFF");Assert.IsFalse(Plan(s).available);Advance(s,12);Assert.AreEqual(0,Starts(s));Assert.IsTrue(s.State.decisions.Any(d=>d.ruleId=="edict:MAGE:BASIC"&&d.code=="EDICT_OFF"));}
        [Test] public void FillFollowsTheActualCommonSkillOrder()
        {
            var s=Fixture();Enemy(s,4);s.State.cooldowns[12]=0;s.State.resource=100;Advance(s);Assert.AreEqual(12,s.State.heroAction.skill);
            var b=Fixture();Enemy(b,4);b.State.cooldowns[12]=0;b.State.resource=100;
            for(int i=0;i<6;i++)b.Hero.edict=HuntEdictV2Editing.WithSkillOrderMoved(b.Hero.edict,"BASIC",-1);b.RefreshEdict();Advance(b);Assert.AreEqual(-1,b.State.heroAction.skill);
        }
        [TestCase(12)][TestCase(13)][TestCase(14)][TestCase(17)]
        public void ResourceModeFindsAnOtherwiseEligibleUnfundedActive(int skill)
        {
            var s=Fixture();var e=Enemy(s,2);Enemy(s,-2);s.State.resource=0;s.State.cooldowns[skill]=0;Option(s,2,"RESOURCE");Option(s,2,"GROUP","M06");
            string before=JsonUtility.ToJson(s.State);Assert.IsTrue(Plan(s,e).available);Assert.AreEqual(before,JsonUtility.ToJson(s.State));Advance(s);Assert.AreEqual(-1,s.State.heroAction.skill);Assert.AreEqual(0,s.State.heroAction.cost);
        }
        [TestCase("COOLDOWN")][TestCase("OFF")][TestCase("LOCKED")][TestCase("PURPOSE")][TestCase("FUNDED")][TestCase("NO_TARGET")]
        public void ResourceModeDoesNotInventAnActiveOpportunity(string gate)
        {
            var s=Fixture();var e=Enemy(s,4);Option(s,2,"RESOURCE");s.State.resource=0;s.State.cooldowns[12]=0;
            if(gate=="COOLDOWN")s.State.cooldowns[12]=1;if(gate=="OFF")Option(s,1,"OFF","M01");if(gate=="LOCKED")s.Hero.level=1;
            if(gate=="PURPOSE")Option(s,2,"GROUP","M01");if(gate=="FUNDED")s.State.resource=100;if(gate=="NO_TARGET")e.dead=true;
            if(gate=="LOCKED"){s.State.cooldowns[12]=1000;s.State.cooldowns[17]=0;Option(s,2,"GROUP","M06");Enemy(s,-2);}
            Assert.IsFalse(Plan(s,e).available);Assert.AreEqual("RESOURCE_NOT_NEEDED",Plan(s,e).blockCode);
        }
        [Test] public void NovaResourceProbeStillRequiresItsActualPurposeAndHereRange()
        {
            var s=Fixture();var e=Enemy(s,6);Enemy(s,6,1);s.State.resource=0;s.State.cooldowns[17]=0;Option(s,2,"RESOURCE");Option(s,2,"GROUP","M06");Option(s,3,"APPROACH","M06");
            Assert.IsFalse(Plan(s,e).available);e.position=s.State.position+Vector2.up*2;s.State.enemies[1].position=s.State.position-Vector2.up*2;Assert.IsTrue(Plan(s,e).available);
            Option(s,2,"CONTROL","M06");Assert.IsFalse(Plan(s,e).available);Assert.AreEqual("RESOURCE",s.PlanEdictNova(s.Hero.edict).code);
        }
        [TestCase("GLOBAL")][TestCase("CURRENT")][TestCase("LOW_HP")]
        public void PreferenceChangesTheActualSelectedTarget(string preference)
        {
            var s=Fixture();var global=Enemy(s,2);var other=Enemy(s,4);other.health=1;Option(s,3,preference);s.State.targetId=other.id;
            Assert.AreEqual(preference=="GLOBAL"?global.id:other.id,Plan(s,global).targetId);
        }
        [Test] public void LowHpUsesTheRatioBeforeDistance()
        {var s=Fixture();var near=Enemy(s,1);var far=Enemy(s,8);near.health=20;near.maxHealth=100;far.health=30;far.maxHealth=1000;Option(s,3,"LOW_HP");Assert.AreEqual(far.id,Plan(s,near).targetId);}
        [Test] public void InvalidCurrentTargetFallsBackToTheGlobalTarget()
        {var s=Fixture();var e=Enemy(s,3);Option(s,3,"CURRENT");s.State.targetId=123456;Assert.AreEqual(e.id,Plan(s,e).targetId);}
        [Test] public void DiscountModeRequiresRealEquipment()
        {var s=Fixture();Enemy(s,4);Option(s,2,"DISCOUNT");Assert.AreEqual("REFERENCE",Plan(s).blockCode);Assert.AreEqual("DISCOUNT",HuntEdictV2.Value(s.Hero.edict,"BASIC",2));}
        [TestCase("READY",true)][TestCase("CHARGE",false)][TestCase("COOLDOWN",false)][TestCase("ZERO_HITS",false)][TestCase("EXCLUDED",false)]
        public void DiscountPreferenceUsesOnlyAValidUnfinishedHitSequence(string state,bool preferLast)
        {
            var s=Fixture(necklace:true);var global=Enemy(s,2);var last=Enemy(s,4);Option(s,2,"DISCOUNT");s.State.itemEffects.basicCount=2;s.State.itemEffects.lastBasic=last.id;
            if(state=="CHARGE"){s.State.itemEffects.lc02Charge=5;s.State.itemEffects.reducedNext=true;}if(state=="COOLDOWN")s.State.itemEffects.procCooldown=1;
            if(state=="ZERO_HITS")s.State.itemEffects.basicCount=0;if(state=="EXCLUDED"){s.State.edictTarget??=new EdictTargetState();s.State.edictTarget.excluded.Add(last.id);}
            Assert.AreEqual(preferLast?last.id:global.id,Plan(s,global).targetId);
        }
        [Test] public void FrontCollisionCreditsTheActualVictimAndFiveResource()
        {
            var s=Fixture(necklace:true);var near=Enemy(s,2);near.health=1000;var far=Enemy(s,5);Global(s,"target.default","HIGH_HP");
            var plan=Plan(s,far);Assert.AreEqual(far.id,plan.targetId);Assert.AreEqual(near.id,plan.forecast.hits.Single());Advance(s,12);
            Assert.AreEqual(near.id,s.State.damageEvents.Single(d=>!d.incoming).targetId);Assert.AreEqual(near.id,s.State.itemEffects.lastBasic);Assert.AreEqual(1,s.State.itemEffects.basicCount);Assert.AreEqual(15,s.State.resource,.001);
        }
        [TestCase(-1)][TestCase(4)]
        public void ThreeActualHitsEarnOneDiscountWithoutScalingTheHitRecovery(int passive)
        {
            var s=Fixture(necklace:true,passive:passive);Enemy(s,4);Option(s,2,"DISCOUNT");s.State.resource=0;
            for(int i=0;i<100&&!s.State.itemEffects.reducedNext;i++)Advance(s);
            Assert.AreEqual(3,Hits(s));Assert.AreEqual(15,s.State.resource,.001);Assert.Greater(s.State.itemEffects.lc02Charge,4.9f);Assert.AreEqual(1,s.State.effectEvents.Count(e=>e.definitionId=="LC02"&&e.kind=="CHARGE"));
            Assert.IsFalse(s.State.actionEvents.Any(a=>a.skill>=0&&a.kind=="ACTION_START"));
        }
        [Test] public void PreparingDoesNotGrantResourceAndOffEditsDoNotCancelTheCommittedAim()
        {
            var s=Fixture(necklace:true);var e=Enemy(s,4);Advance(s);Assert.AreEqual(0,Hits(s));Assert.AreEqual(10,s.State.resource);Assert.AreEqual(0,s.State.itemEffects.basicCount);
            Vector2 aim=s.State.heroAction.aim;int id=s.State.heroAction.id;Option(s,1,"OFF");Option(s,3,"LOW_HP");Option(s,4,"CURRENT");
            var restored=Restore(s);Assert.AreEqual(id,restored.State.heroAction.id);Assert.AreEqual(aim,restored.State.heroAction.aim);Advance(restored,30);
            Assert.AreEqual(1,Starts(restored));Assert.AreEqual(1,Hits(restored));Assert.AreEqual(15,restored.State.resource,.001);
        }
        [Test] public void AnInFlightBoltRestoresOnceWithItsOriginalDirection()
        {
            var s=Fixture(necklace:true);Enemy(s,7);Advance(s);Option(s,1,"OFF");for(int i=0;i<20&&s.State.projectiles.Count==0;i++)Advance(s);
            Assert.AreEqual(1,s.State.projectiles.Count);Assert.AreEqual(0,Hits(s));var shot=s.State.projectiles.Single();var restored=Restore(s);
            Assert.AreEqual(JsonUtility.ToJson(shot),JsonUtility.ToJson(restored.State.projectiles.Single()));Advance(restored,30);Assert.AreEqual(1,Hits(restored));Assert.AreEqual(1,Starts(restored));Assert.AreEqual(15,restored.State.resource,.001);
        }
        [Test] public void FillCannotInterruptTheCurrentMainAction()
        {var s=Fixture();Enemy(s,4);s.State.cooldowns[12]=0;s.State.resource=100;Advance(s);Assert.AreEqual(12,s.State.heroAction.skill);Assert.AreEqual("ACTION_LOCK",Plan(s).blockCode);}
        [Test] public void AimModesUseObservedMotionAndRemainReadOnly()
        {
            var s=Fixture();var e=Enemy(s,4);s.State.exploration.enemies.Add(new EnemyObservation{id=e.id,position=e.position,seenAt=s.State.time,motionSampled=true,velocity=Vector2.up*2});
            string before=JsonUtility.ToJson(s.State);var predicted=Plan(s,e);Assert.Greater(predicted.forecast.aim.y,e.position.y);Assert.AreEqual(before,JsonUtility.ToJson(s.State));
            Option(s,4,"CURRENT");Assert.AreEqual(e.position,Plan(s,e).forecast.aim);
            Option(s,4,"PREDICTED");s.State.exploration.enemies[0].seenAt=s.State.time-1;Assert.AreEqual(e.position,Plan(s,e).forecast.aim);
        }
        [TestCase("OWN",true)][TestCase("LEGACY_OWNER",true)][TestCase("FOREIGN",false)][TestCase("HOSTILE",false)]
        [TestCase("EXPIRED",false)][TestCase("DELAYED",false)][TestCase("FUTURE",false)][TestCase("OUTSIDE",false)]
        public void OwnBlizzardPreferenceRequiresActualActiveCoverage(string kind,bool preferCovered)
        {
            var s=Fixture();var global=Enemy(s,1);var covered=Enemy(s,6);Option(s,3,"OWN_BLIZZARD");
            var field=new GroundEffect{kind=13,definitionId="M02",casterId=s.State.heroId,position=covered.position,radius=2,duration=6,createdAt=s.State.time};s.State.effects.Add(field);
            if(kind=="LEGACY_OWNER")field.casterId="";if(kind=="FOREIGN")field.casterId="another-hero";if(kind=="HOSTILE")field.hostile=true;
            if(kind=="EXPIRED")field.duration=0;if(kind=="DELAYED")field.delay=.5f;if(kind=="FUTURE")field.createdAt=1;if(kind=="OUTSIDE")field.position+=Vector2.up*4;
            Assert.AreEqual(preferCovered?covered.id:global.id,Plan(s,global).targetId);
        }
        [TestCase(12.5f,false)][TestCase(12.49f,true)]
        public void ResourceModeUsesTheActualEarnedDiscountedCost(float resource,bool shouldFill)
        {
            var s=Fixture(necklace:true);var e=Enemy(s,4);Option(s,2,"RESOURCE");s.State.cooldowns[12]=0;s.State.resource=resource;
            s.State.itemEffects.lc02Charge=5;s.State.itemEffects.reducedNext=true;
            string before=JsonUtility.ToJson(s.State);Assert.AreEqual(shouldFill,Plan(s,e).available);Assert.AreEqual(before,JsonUtility.ToJson(s.State));
        }
        [TestCase(10f,true)][TestCase(10.001f,false)]
        public void BasicKeepsItsPhysicalTenMeterRange(float distance,bool available)
        {var s=Fixture();var e=Enemy(s,0,distance);Assert.AreEqual(available,Plan(s,e).available);}
        [TestCase("MISSING")][TestCase("ENABLED")]
        public void BasicApproachUsesGlobalMovementAndStopsAtThePursuitLimit(string rows)
        {
            var s=Fixture(rows);var e=Enemy(s,0,11.8f);
            foreach(string id in new[]{"M01","M02","M03","M06"})Option(s,1,"OFF",id);
            if(s.State.build.rules.Count>0){s.State.build.rules[0].overrideMovement=true;s.State.build.rules[0].movement=MovementMode.Retreat;}
            Global(s,"target.chaseDistance","1");Vector2 origin=s.State.position;Advance(s);
            Assert.AreEqual("edict:MAGE:BASIC",s.State.targetRuleId);Assert.Greater(s.State.position.y,origin.y);
            var restored=Restore(s);Advance(restored,30);
            Assert.LessOrEqual(Vector2.Distance(origin,restored.State.position),1.0001f);Assert.Contains(e.id,restored.State.edictTarget.excluded);Assert.AreEqual(0,Starts(restored));
        }
        [TestCase("MISSING")][TestCase("FUTURE")][TestCase("INVALID")][TestCase("FROZEN")]
        public void InvalidMotionFallsBackToTheCurrentPosition(string kind)
        {
            var s=Fixture();var e=Enemy(s,4);var motion=new EnemyObservation{id=e.id,position=e.position,seenAt=s.State.time,motionSampled=true,velocity=Vector2.up*2};
            if(kind!="MISSING")s.State.exploration.enemies.Add(motion);
            if(kind=="FUTURE")motion.seenAt=1;if(kind=="INVALID")motion.velocity=new Vector2(float.NaN,2);if(kind=="FROZEN")e.freeze=1;
            Assert.AreEqual(e.position,Plan(s,e).forecast.aim);
        }
        [TestCase("PREDICTED",1)][TestCase("CURRENT",0)]
        public void ActualBoltUsesTheCommittedAimAgainstObservedSidewaysMotion(string aim,int expectedHits)
        {
            var s=Fixture();var e=Enemy(s,0,6);Vector2 velocity=Vector2.right*3;Option(s,4,aim);
            s.State.exploration.enemies.Add(new EnemyObservation{id=e.id,position=e.position-velocity*CombatSimulation.Step,seenAt=s.State.time,motionSampled=true,velocity=velocity});
            // Keep the first motion sample physically plausible, then drive its straight path
            // explicitly so enemy steering cannot change the comparison.
            Vector2 sampled=e.position;e.speed=velocity.magnitude;Advance(s);e.speed=0;e.position=sampled;
            Assert.AreEqual(1,Starts(s));Assert.AreEqual(aim=="PREDICTED",s.State.heroAction.aim.x>sampled.x+.5f);Option(s,1,"OFF");
            for(int i=0;i<24;i++){e.position+=velocity*CombatSimulation.Step;Advance(s);}
            Assert.AreEqual(expectedHits,Hits(s));Assert.AreEqual(10+expectedHits*5,s.State.resource,.001);
        }
    }
}
