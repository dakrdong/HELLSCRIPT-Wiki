using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class EdictNovaTests
    {
        static readonly string[] Set={"SMB1","SMB2","SMB3","SMB4"};
        GameCatalog catalog;
        [SetUp] public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown] public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        CombatSimulation Fixture(string rows="BLOCKED",bool enabled=true,bool chain=false,bool basic=false,params string[] gear)
        {
            var a=ContentTestAccounts.Training(catalog);a.selectedHero=2;var h=a.Hero;h.level=30;h.inventory.Clear();h.build.activeSkills=new List<int>{17};h.build.passives=new[]{5};h.build.movement=MovementMode.Stand;h.build.potionThreshold=0;h.build.rules=new List<Rule>();
            if(rows!="MISSING")h.build.rules.Add(rows=="BLOCKED"?BehaviorRules.Make(17,BehaviorRules.C("SC06",Comparison.AtLeast,99,predicted:true)):BehaviorRules.Make(17));
            if(rows=="DISABLED")h.build.rules[0].enabled=false;if(rows=="DUPLICATE")h.build.rules.Add(BehaviorRules.Make(17));
            if(chain){h.build.activeSkills.Add(14);h.build.rules.Add(BehaviorRules.Make(14));}if(basic)h.build.rules.Add(BehaviorRules.Utility(RuleAction.Basic));
            uint rng=176013;foreach(string id in gear){var item=ItemGenerator.Create(HeroClass.Mage,ItemCatalog.Unique(id).slot,3,30,ref rng,uniqueId:id);h.inventory.Add(item);Assert.IsTrue(Economy.Equip(h,item),id);}
            h.edict=HuntEdictV2.WithOption(HuntEdictV2Storage.CreateForHero(h),"BASIC",1,basic?"ON":"OFF");h.useEdict=enabled;
            foreach(var p in new[]{("position.mode","STAND"),("survival.potion","OFF"),("survival.lowHp","OFF"),("survival.lethal","OFF")})h.edict=HuntEdictV2Editing.WithGlobal(h.edict,p.Item1,p.Item2);
            var s=new CombatSimulation(a,catalog,1,1,ownedTraining:true);s.State.enemies.Clear();s.State.exploration.enemies.Clear();s.State.position=RiftMap.Rooms[0];Controlled(s);s.State.health=1000;s.State.resource=100;s.State.cooldowns[14]=1000;return s;
        }
        static void Controlled(CombatSimulation s)
        {s.Stats.hp=1000;s.Stats.armor=s.Stats.resistance=s.Stats.regen=s.Stats.crit=s.Stats.costReduction=s.Stats.cdr=0;SheetFixture.Neutral(s.Stats);}
        static EnemyState Enemy(CombatSimulation s,float x,float y=0,bool boss=false)
        {
            var e=new EnemyState{id=900+s.State.enemies.Count,kind=0,position=s.State.position+new Vector2(x,y),boss=boss,health=1000000,maxHealth=1000000,attack=0,speed=0,cooldown=1000};
            e.brain.initialized=true;if(boss){e.brain.boss.initialized=true;e.brain.boss.cooldowns=new[]{1000f,1000f,1000f};}s.State.enemies.Add(e);return e;
        }
        static void Caster(CombatSimulation s,EnemyState e,float remaining=1)
        {e.kind=3;e.brain.action=new EnemyActionState{id=5000+e.id,phase=EnemyActionPhase.Preparing,kind=3,origin=e.position,aim=s.State.position,direction=(s.State.position-e.position).normalized,remaining=remaining,preparation=remaining,damage=20};}
        static void Option(CombatSimulation s,int n,string value){s.Hero.edict=HuntEdictV2.WithOption(s.Hero.edict,"M06",n,value);s.RefreshEdict();}
        static void Global(CombatSimulation s,string id,string value){s.Hero.edict=HuntEdictV2Editing.WithGlobal(s.Hero.edict,id,value);s.RefreshEdict();}
        static void Chain(CombatSimulation s,bool on){s.Hero.edict=HuntEdictV2.WithOption(s.Hero.edict,"M03",1,on?"ON":"OFF");s.RefreshEdict();}
        static void Advance(CombatSimulation s,int ticks=9){for(int i=0;i<ticks;i++)s.Tick(CombatSimulation.Step);}
        static int Starts(CombatSimulation s,int skill=17)=>s.State.actionEvents.Count(a=>a.kind=="ACTION_START"&&a.skill==skill);
        static EdictResponseCandidate Plan(CombatSimulation s,EnemyState target=null)=>s.PlanEdictNova(s.Hero.edict,target);
        static void Invoke(CombatSimulation s,string name,params object[] args)=>typeof(CombatSimulation).GetMethod(name,BindingFlags.NonPublic|BindingFlags.Instance).Invoke(s,args);
        CombatSimulation Restore(CombatSimulation s)
        {
            var a=ContentTestAccounts.Training(catalog);a.selectedHero=2;a.heroes[2]=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(s.Hero));var run=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(s.State));GameStore.NormalizeRun(run);
            var resumed=new CombatSimulation(a,catalog,1,restore:run);Controlled(resumed);return resumed;
        }
        [TestCase("MISSING")][TestCase("DISABLED")][TestCase("BLOCKED")][TestCase("ENABLED")][TestCase("DUPLICATE")]
        public void GroupPolicyDerivesOneCastWithoutLegacyConditions(string row)
        {
            var s=Fixture(row);Enemy(s,-1);Enemy(s,1);Option(s,2,"GROUP");string rules=JsonUtility.ToJson(s.State.build);Advance(s);
            Assert.AreEqual(1,Starts(s));Assert.AreEqual(80,s.State.resource,.001);Assert.AreEqual(10,s.State.actionEvents.Where(a=>a.kind=="ACTION_START").Select(a=>s.State.cooldowns[17]+s.State.time-a.time).Single(),.001);
            Assert.AreEqual(2,s.State.damageEvents.Count(d=>d.definitionId=="M06"&&!d.incoming));Assert.IsTrue(s.State.enemies.All(e=>CombatEffects.Has(e,StatusKind.Freeze)));Assert.AreEqual(rules,JsonUtility.ToJson(s.State.build));
        }
        [Test] public void DefaultControlDoesNotUseAnOldAlwaysRowWithoutRisk()
        {var s=Fixture("ENABLED");Enemy(s,1);Enemy(s,-1);Advance(s);Assert.AreEqual(0,Starts(s));Assert.AreEqual(100,s.State.resource);}
        [Test] public void OptOutRestoresLegacyUse()
        {var s=Fixture("ENABLED",false);Enemy(s,1);Advance(s);Assert.AreEqual(1,Starts(s));}
        [Test] public void SelfCenteredVictimsDoNotDependOnTheDistantGlobalTarget()
        {
            var s=Fixture();var near=Enemy(s,1);Enemy(s,-1);var far=Enemy(s,0,8);Option(s,2,"GROUP");Global(s,"target.default","HIGH_HP");far.maxHealth=100000;far.health=1000000;
            var plan=Plan(s,far);Assert.IsTrue(plan.ready);Assert.AreNotEqual(far.id,plan.targetId);Advance(s);
            Assert.IsTrue(s.State.damageEvents.Any(d=>d.definitionId=="M06"&&d.targetId==near.id));Assert.IsFalse(s.State.damageEvents.Any(d=>d.definitionId=="M06"&&d.targetId==far.id));
        }
        [TestCase(3f,true)][TestCase(3.001f,false)]
        public void GroupThresholdUsesTheActualThreeMeterRadius(float distance,bool ready)
        {var s=Fixture();Enemy(s,-1);Enemy(s,distance);Option(s,2,"GROUP");Assert.AreEqual(ready,Plan(s).ready);}
        [TestCase("OFF","EDICT_OFF")][TestCase("LEVEL","LEVEL_LOCK")][TestCase("RESOURCE","RESOURCE")][TestCase("COOLDOWN","COOLDOWN")]
        public void ExecutionGatesPreserveCostAndCooldown(string gate,string code)
        {
            var s=Fixture();Enemy(s,-1);Enemy(s,1);Option(s,2,"GROUP");if(gate=="OFF")Option(s,1,"OFF");if(gate=="LEVEL")s.Hero.level=19;if(gate=="RESOURCE")s.State.resource=19;if(gate=="COOLDOWN")s.State.cooldowns[17]=1;
            Assert.AreEqual(code,Plan(s).code);float resource=s.State.resource;Advance(s,1);Assert.AreEqual(0,Starts(s));Assert.AreEqual(resource,s.State.resource);
        }
        [TestCase(.35f,false)][TestCase(.36f,true)][TestCase(.1f,false)]
        public void DangerousCastRequiresEnoughTimeForPreparation(float remaining,bool ready)
        {var s=Fixture();var e=Enemy(s,2);Caster(s,e,remaining);Assert.AreEqual(ready,Plan(s).ready);}
        [Test] public void ARealDangerousCastIsInterruptedByActualFreeze()
        {var s=Fixture();var e=Enemy(s,2);Caster(s,e);Advance(s);Assert.AreEqual(1,Starts(s));Assert.IsTrue(CombatEffects.Has(e,StatusKind.Freeze));Assert.AreEqual(EnemyActionPhase.Idle,e.brain.action.phase);Assert.IsFalse(s.State.damageEvents.Any(d=>d.incoming));}
        [TestCase(.8f,false)][TestCase(.2f,true)]
        public void NewControlReadsRemainingFreezeAtArrival(float remaining,bool ready)
        {var s=Fixture();var e=Enemy(s,2);e.statuses.Add(new StatusEffect{kind=StatusKind.Freeze,remaining=remaining});Global(s,"survival.lowHp","ON");s.State.health=200;Assert.AreEqual(ready,Plan(s).ready);}
        [TestCase(84.9f,false)][TestCase(85f,true)]
        public void CrisisControlRequiresCompletingBossStagger(float meter,bool ready)
        {
            var s=Fixture();var e=Enemy(s,2,boss:true);e.bossControl.meter=meter;Global(s,"survival.lowHp","ON");s.State.health=200;Assert.AreEqual(ready,Plan(s).ready);Advance(s);
            Assert.AreEqual(ready?1:0,Starts(s));Assert.IsFalse(CombatEffects.Has(e,StatusKind.Freeze));if(ready){Assert.Greater(e.bossControl.staggered,0);Assert.AreEqual(0,e.bossControl.meter);}
        }
        [TestCase("PURPOSE",true)][TestCase("STAGGER_ONLY",false)][TestCase("HOLD_ALONE",true)]
        public void BossDecisionPolicyDoesNotRemoveOrdinaryTargets(string policy,bool ready)
        {var s=Fixture();Enemy(s,-1);var boss=Enemy(s,1,boss:true);boss.bossControl.immunity=2;Option(s,2,"GROUP");Option(s,4,policy);Assert.AreEqual(ready,Plan(s).ready);}
        [Test] public void HoldAloneDoesNotInventAControlExemptionForGlobalEmergency()
        {var s=Fixture();var boss=Enemy(s,2,boss:true);boss.bossControl.meter=90;Option(s,4,"HOLD_ALONE");Global(s,"survival.lowHp","ON");Global(s,"survival.defenseSkill","M06");s.State.health=200;Assert.AreEqual("NO_CONTROL",s.PlanEdictSurvival(s.Hero.edict).attempts[0].code);}
        [Test] public void DirectGlobalDefenseStillRequiresTheChosenGroupPurpose()
        {var s=Fixture();Enemy(s,2);Option(s,2,"GROUP");Global(s,"survival.lowHp","ON");Global(s,"survival.defenseSkill","M06");s.State.health=200;Assert.AreEqual("NO_CONTROL",s.PlanEdictSurvival(s.Hero.edict).attempts[0].code);Enemy(s,-2);Advance(s,1);Assert.AreEqual("HED2:SURVIVAL:M06",s.State.heroAction.policy.rule.id);}
        [TestCase(false)][TestCase(true)]
        public void ChargePurposeRequiresFourActuallyEquippedSetPieces(bool equipped)
        {var s=Fixture(chain:true,gear:equipped?Set:Set.Take(3).ToArray());Enemy(s,2);Option(s,2,"CHAIN_CHARGE");Assert.AreEqual(equipped,Plan(s).ready);if(!equipped)Assert.AreEqual("REFERENCE",Plan(s).code);}
        [TestCase(0,6f,true)][TestCase(2,1f,true)][TestCase(2,1.01f,false)]
        public void ChargeOpportunityIgnoresChainCooldownAndUsesCountOrLifetime(int charges,float life,bool ready)
        {var s=Fixture(chain:true,gear:Set);Enemy(s,2);Option(s,2,"CHAIN_CHARGE");s.State.itemEffects.chainCharges=charges;s.State.itemEffects.chainCharge=life;Assert.AreEqual(ready,Plan(s).ready);Assert.Greater(s.State.cooldowns[14],0);}
        [Test] public void DisabledChainFallsBackToControlWithoutRewritingItsPreset()
        {var s=Fixture(chain:true,gear:Set);var e=Enemy(s,2);Option(s,2,"CHAIN_CHARGE");Chain(s,false);Assert.IsFalse(Plan(s).ready);Caster(s,e);Assert.IsTrue(Plan(s).ready);Assert.AreEqual("CHAIN_CHARGE",HuntEdictV2.Value(s.Hero.edict,"M06",2));}
        [Test] public void RealNovaChargesTwoSubsequentChainsAndTriggersMp06FromColdThenLightning()
        {
            var s=Fixture(chain:true,gear:Set);Enemy(s,-1);Enemy(s,1);Option(s,2,"CHAIN_CHARGE");Advance(s);Assert.AreEqual(2,s.State.itemEffects.chainCharges);Assert.AreEqual(0,s.State.itemEffects.elementBuff);
            Option(s,1,"OFF");s.State.cooldowns[14]=0;s.State.decisionTime=0;
            for(int i=0;i<30&&!s.State.damageEvents.Any(d=>d.definitionId=="M03");i++)Advance(s,1);
            Assert.AreEqual(1,s.State.itemEffects.chainCharges);Assert.Greater(s.State.itemEffects.elementBuff,0);Assert.AreEqual(2,s.State.effectEvents.Single(e=>e.definitionId=="SMB4"&&e.kind=="RESERVED").value);
            for(int i=0;i<30&&s.HeroActionBusy;i++)Advance(s,1);Assert.IsFalse(s.HeroActionBusy);
            s.State.cooldowns[14]=0;s.State.decisionTime=0;Advance(s,12);Assert.AreEqual(0,s.State.itemEffects.chainCharges);Assert.AreEqual(2,s.State.effectEvents.Count(e=>e.definitionId=="SMB4"&&e.kind=="RESERVED"));
        }
        [Test] public void EmptyCommittedNovaDoesNotGenerateChargesOrReplayCost()
        {
            var s=Fixture(chain:true,gear:Set);var e=Enemy(s,2);Option(s,2,"CHAIN_CHARGE");Advance(s,1);e.position=s.State.position+Vector2.right*8;Option(s,1,"OFF");Advance(s);
            Assert.AreEqual(80,s.State.resource,.001);Assert.AreEqual(0,s.State.itemEffects.chainCharges);Assert.IsFalse(s.State.damageEvents.Any(d=>d.definitionId=="M06"));Assert.IsTrue(s.State.actionEvents.Any(a=>a.skill==17&&a.kind=="ACTION_MISS"));
        }
        [Test] public void DiscountedPreparationSurvivesOptionEditsAndRestartExactlyOnce()
        {
            var s=Fixture(chain:true,gear:Set.Concat(new[]{"LC02"}).ToArray());Enemy(s,2);Option(s,2,"CHAIN_CHARGE");s.State.itemEffects.lc02Charge=5;s.State.itemEffects.reducedNext=true;Advance(s,1);
            Assert.AreEqual(10,s.State.heroAction.cost,.001);Assert.AreEqual(90,s.State.resource,.001);Assert.IsFalse(s.State.itemEffects.reducedNext);
            Option(s,1,"OFF");Option(s,2,"CONTROL");Option(s,3,"APPROACH");Option(s,4,"HOLD_ALONE");Chain(s,false);var restored=Restore(s);Assert.AreEqual(s.State.heroAction.id,restored.State.heroAction.id);Assert.AreEqual(s.State.time,restored.State.time);
            Advance(restored);Assert.AreEqual(90,restored.State.resource,.001);Assert.AreEqual(1,Starts(restored));Assert.AreEqual(2,restored.State.itemEffects.chainCharges);Assert.AreEqual(1,restored.State.effectEvents.Count(e=>e.definitionId=="LC02"&&e.kind=="CONSUMED"));
        }
        [TestCase("FINISH",false)][TestCase("CANCEL_ALLOWED",true)]
        public void CrisisInterruptionUsesTheGlobalPermission(string permission,bool interrupted)
        {
            var s=Fixture(chain:true);var e=Enemy(s,2);Option(s,1,"OFF");s.State.cooldowns[14]=0;Advance(s,1);Assert.AreEqual(14,s.State.heroAction.skill);int id=s.State.heroAction.id;
            Global(s,"dodge.interrupt",permission);Option(s,1,"ON");Caster(s,e,2);s.State.decisionTime=0;Advance(s,1);Assert.AreEqual(interrupted?17:14,s.State.heroAction.skill);Assert.AreEqual(interrupted,s.State.actionEvents.Any(a=>a.actionId==id&&a.kind=="ACTION_INTERRUPTED"));
        }
        [Test] public void OrdinaryGroupCannotCancelAPreparingAttack()
        {var s=Fixture(chain:true);Enemy(s,-1);Enemy(s,1);Option(s,1,"OFF");s.State.cooldowns[14]=0;Advance(s,1);Global(s,"dodge.interrupt","CANCEL_ALLOWED");Option(s,1,"ON");Option(s,2,"GROUP");s.State.decisionTime=0;Advance(s,1);Assert.AreEqual(14,s.State.heroAction.skill);}
        [TestCase("HERE",false,"BLOCKED")][TestCase("APPROACH",true,"BLOCKED")][TestCase("APPROACH",true,"MISSING")]
        public void ApproachIsARealFiniteWalkBeforeCastingAndDoesNotSpendOnWalking(string placement,bool moves,string row)
        {
            var s=Fixture(row,basic:true);Enemy(s,0,5);Enemy(s,1,5);Option(s,2,"GROUP");Option(s,3,placement);Vector2 origin=s.State.position;Advance(s,1);
            Assert.AreEqual(moves,Vector2.Distance(origin,s.State.position)>0);Assert.AreEqual(0,Starts(s));Assert.AreEqual(100,s.State.resource);
            if(moves){for(int i=0;i<100&&Starts(s)==0;i++)Advance(s,1);Assert.AreEqual(1,Starts(s));Assert.IsTrue(s.State.enemies.All(e=>Vector2.Distance(e.position,s.State.position)<=3));Assert.AreEqual(80,s.State.resource,.001);}
        }
        [Test] public void ApproachRechecksDangerAndOptionChangesWithoutCharging()
        {
            var s=Fixture();Enemy(s,0,6);Enemy(s,1,6);Option(s,2,"GROUP");Option(s,3,"APPROACH");Advance(s,1);Assert.Greater(s.State.moveDistance,0);Vector2 p=s.State.position;
            Global(s,"dodge.area.policy","ALWAYS");s.State.enemyHazards.Add(new EnemyHazard{id=800,actionId=800,enemyId=900,position=p,shape=AttackShape.Circle,radius=30,damage=100,delay=1,createdAt=-1});
            Assert.AreEqual("DANGER",Plan(s).code);Advance(s,1);Assert.AreEqual(p,s.State.position);Option(s,1,"OFF");Advance(s,1);Assert.AreEqual(0,Starts(s));Assert.AreEqual(100,s.State.resource);
        }
        [TestCase("target.chaseDistance")][TestCase("target.chaseTime")]
        public void ApproachDoesNotPursueBeyondTheConfiguredLimit(string limit)
        {var s=Fixture();Enemy(s,0,8);Enemy(s,1,8);Option(s,2,"GROUP");Option(s,3,"APPROACH");Global(s,limit,"1");Assert.AreEqual("NO_PATH",Plan(s).code);Advance(s);Assert.AreEqual(0,s.State.moveDistance);}
        [Test] public void AWallOrAnExcludedEnemyCannotSupplyTheSecondGroupVictim()
        {
            var s=Fixture();Enemy(s,-2);var e=Enemy(s,2);Option(s,2,"GROUP");Assert.IsTrue(Plan(s).ready);
            s.State.edictTarget=new EdictTargetState();s.State.edictTarget.excluded.Add(e.id);Assert.IsFalse(Plan(s).ready);s.State.edictTarget.excluded.Clear();
            s.State.layout.legacy=false;s.State.layout.corridors.Clear();s.State.layout.obstacles.Add(new RiftObstacle{id="nova-wall",position=s.State.position+Vector2.right,halfSize=new Vector2(.1f,1),blocksSight=true,blocksWalk=false});
            Assert.IsFalse(s.Map.LineClear(s.State.position,e.position));Assert.IsFalse(Plan(s).ready);
        }
        [Test] public void BossPolicyFiltersTheDecisionWhileActualDamageStillUsesTheWholeArea()
        {
            var s=Fixture();Enemy(s,-1);Enemy(s,1);var boss=Enemy(s,0,2,true);boss.bossControl.immunity=3;boss.bossControl.meter=42;Option(s,2,"GROUP");Option(s,4,"STAGGER_ONLY");Advance(s);
            Assert.IsTrue(s.State.damageEvents.Any(d=>d.definitionId=="M06"&&d.targetId==boss.id));Assert.IsFalse(CombatEffects.Has(boss,StatusKind.Freeze));Assert.AreEqual(42,boss.bossControl.meter);
        }
        [Test] public void WalkingRestoresItsPositionAndPursuitBudgetBeforeOnePaidCast()
        {
            var s=Fixture();Enemy(s,0,6);Enemy(s,1,6);Option(s,2,"GROUP");Option(s,3,"APPROACH");Advance(s,2);Assert.Greater(s.State.edictTarget.pursuitSeconds,0);var resumed=Restore(s);
            Assert.AreEqual(s.State.position,resumed.State.position);Assert.AreEqual(s.State.edictTarget.pursuitSeconds,resumed.State.edictTarget.pursuitSeconds);Assert.AreEqual(s.State.edictTarget.origin,resumed.State.edictTarget.origin);
            for(int i=0;i<100&&Starts(resumed)==0;i++)Advance(resumed,1);Assert.AreEqual(1,Starts(resumed));Assert.AreEqual(80,resumed.State.resource,.001);
        }
        [Test] public void AdditionalEnemyPolicyUsesRememberedPositionsAlongTheApproach()
        {
            var s=Fixture();Enemy(s,0,6);Enemy(s,1,6);Option(s,2,"GROUP");Option(s,3,"APPROACH");Global(s,"position.addEnemies","ON");var allowed=Plan(s);Assert.AreEqual("APPROACH",allowed.code);
            Vector2? memory=null;
            for(float distance=14.1f;distance<=20&&!memory.HasValue;distance+=.5f)for(int n=0;n<72;n++)
            {
                Vector2 p=s.State.position+new Vector2(Mathf.Cos(n*Mathf.PI/36),Mathf.Sin(n*Mathf.PI/36))*distance;
                if(Vector2.Distance(allowed.destination,p)<13&&s.Map.LineClear(allowed.destination,p)){memory=p;break;}
            }
            Assert.IsTrue(memory.HasValue,"The fixture must contain a remembered group beyond current aggro reach.");
            s.State.exploration.enemies.Add(new EnemyObservation{id=4999,position=memory.Value,seenAt=s.State.time});Assert.AreEqual(allowed.destination,Plan(s).destination);
            Global(s,"position.addEnemies","OFF");var guarded=Plan(s);
            Assert.IsTrue(!guarded.ready||Vector2.Distance(guarded.destination,memory.Value)>14||!s.Map.LineClear(guarded.destination,memory.Value));
        }
        [Test] public void AStoppedNovaPursuitDoesNotRearmAtTheBasicAttackRangeAfterRestore()
        {
            var s=Fixture();var e=Enemy(s,0,6);Enemy(s,1,6);Option(s,2,"GROUP");Option(s,3,"APPROACH");Advance(s,1);Assert.AreEqual("edict:M06",s.State.targetRuleId);int target=s.State.targetId;
            Invoke(s,"EndEdictPursuit","추적 시간 한도에 도달했습니다.",true);var resumed=Restore(s);Invoke(resumed,"Sense");Assert.Contains(target,resumed.State.edictTarget.excluded);
            resumed.State.enemies.Find(x=>x.id==target).position=resumed.State.position+Vector2.up*2;Invoke(resumed,"Sense");Assert.IsFalse(resumed.State.edictTarget.excluded.Contains(target));
        }
        [Test] public void PlansRemainReadOnlyIncludingApproachSearch()
        {var s=Fixture();Enemy(s,0,5);Enemy(s,1,5);Option(s,2,"GROUP");Option(s,3,"APPROACH");string state=JsonUtility.ToJson(s.State),document=HuntEdictV2Codec.Encode(s.Hero.edict);Assert.IsTrue(Plan(s).ready);Assert.AreEqual(state,JsonUtility.ToJson(s.State));Assert.AreEqual(document,HuntEdictV2Codec.Encode(s.Hero.edict));}
    }
}
