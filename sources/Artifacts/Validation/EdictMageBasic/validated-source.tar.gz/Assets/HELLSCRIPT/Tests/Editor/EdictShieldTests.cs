using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class EdictShieldTests
    {
        GameCatalog catalog;
        [SetUp] public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown] public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        CombatSimulation Fixture(bool enabled=true,string row="BLOCKED",bool attack=false,string gear=null)
        {
            var a=ContentTestAccounts.Training(catalog);a.selectedHero=2;var hero=a.Hero;hero.level=30;hero.inventory.Clear();hero.build.activeSkills=new List<int>{16};hero.build.passives=Array.Empty<int>();
            hero.build.rules=new List<Rule>();hero.build.potionThreshold=0;hero.build.movement=MovementMode.Stand;
            if(row!="MISSING")hero.build.rules.Add(row=="BLOCKED"?BehaviorRules.Make(16,BehaviorRules.C("SC06",Comparison.AtLeast,99,predicted:true)):BehaviorRules.Make(16));
            if(row=="DISABLED")hero.build.rules[0].enabled=false;if(row=="DUPLICATE")hero.build.rules.Add(BehaviorRules.Make(16));
            if(attack){hero.build.activeSkills.Add(14);hero.build.rules.Add(BehaviorRules.Make(14));}
            if(gear!=null){uint rng=91273;var item=ItemGenerator.Create(HeroClass.Mage,ItemCatalog.Unique(gear).slot,3,30,ref rng,uniqueId:gear);hero.inventory.Add(item);Assert.IsTrue(Economy.Equip(hero,item));}
            hero.edict=HuntEdictV2.WithOption(HuntEdictV2Storage.CreateForHero(hero),"BASIC",1,"OFF");hero.useEdict=enabled;
            foreach(var pair in new[]{("position.mode","STAND"),("survival.potion","OFF"),("survival.lowHp","OFF"),("survival.lethal","OFF")})hero.edict=HuntEdictV2Editing.WithGlobal(hero.edict,pair.Item1,pair.Item2);
            var sim=new CombatSimulation(a,catalog,1,1,ownedTraining:true);sim.State.position=RiftMap.Rooms[0];sim.State.enemies.Clear();sim.State.exploration.enemies.Clear();Controlled(sim);sim.State.health=1000;
            Enemy(sim,0,2);return sim;
        }
        static void Controlled(CombatSimulation s)
        {s.Stats.hp=1000;s.Stats.shieldMultiplier=1;s.Stats.armor=s.Stats.resistance=s.Stats.regen=s.Stats.crit=s.Stats.costReduction=0;SheetFixture.Neutral(s.Stats);}
        static EnemyState Enemy(CombatSimulation s,float x,float y,int elite=-1,bool boss=false)
        {
            var e=new EnemyState{id=900+s.State.enemies.Count,position=s.State.position+new Vector2(x,y),elite=elite,boss=boss,health=1000000,maxHealth=1000000,speed=0,attack=0,cooldown=1000};
            if(boss){e.brain.initialized=true;e.brain.boss.initialized=true;e.brain.boss.cooldowns=new[]{1000f,1000f,1000f};}s.State.enemies.Add(e);return e;
        }
        static void Option(CombatSimulation s,int n,string value){s.Hero.edict=HuntEdictV2.WithOption(s.Hero.edict,"M05",n,value);s.RefreshEdict();}
        static void Global(CombatSimulation s,string id,string value){s.Hero.edict=HuntEdictV2Editing.WithGlobal(s.Hero.edict,id,value);s.RefreshEdict();}
        static EdictResponseCandidate Plan(CombatSimulation s)=>s.PlanEdictShield(s.Hero.edict,s.State.enemies.FirstOrDefault());
        static void Advance(CombatSimulation s,int ticks=5){for(int i=0;i<ticks;i++)s.Tick(CombatSimulation.Step);}
        static int Starts(CombatSimulation s,int skill=16)=>s.State.actionEvents.Count(e=>e.skill==skill&&e.kind=="ACTION_START");
        static void Other(CombatSimulation s,float amount=800,string id="OTHER",float duration=10)=>s.State.shields.Add(new ShieldEffect{id=s.State.nextId++,definitionId=id,amount=amount,remaining=duration,createdMaxHp=s.Stats.hp});
        static void Hurt(CombatSimulation s,float damage)
        {
            var m=typeof(CombatSimulation).GetMethod("Hurt",BindingFlags.Instance|BindingFlags.NonPublic);var ps=m.GetParameters();var args=ps.Select(p=>p.DefaultValue).ToArray();args[0]=damage;m.Invoke(s,args);
        }
        static void Danger(CombatSimulation s,float damage=100)
        {
            Global(s,"dodge.area.policy","ALWAYS");s.State.enemyHazards.Add(new EnemyHazard{id=800,actionId=800,enemyId=900,definitionId="SHIELD_DANGER",position=s.State.position,shape=AttackShape.Circle,radius=30,damage=damage,delay=1,createdAt=-1});
        }
        CombatSimulation Restore(CombatSimulation s)
        {
            var a=ContentTestAccounts.Training(catalog);a.selectedHero=2;a.heroes[2]=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(s.Hero));var run=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(s.State));GameStore.NormalizeRun(run);
            var restored=new CombatSimulation(a,catalog,1,restore:run);Controlled(restored);return restored;
        }

        [TestCase("MISSING")][TestCase("DISABLED")][TestCase("BLOCKED")][TestCase("ENABLED")][TestCase("DUPLICATE")]
        public void EngagingShieldReplacesLegacyRowsAndUsesCooldownOnce(string row)
        {
            var s=Fixture(row:row);Option(s,2,"ENGAGE");string original=JsonUtility.ToJson(s.State.build);var origin=s.State.position;Advance(s,1);
            Assert.AreEqual(1,Starts(s));Assert.AreEqual("edict:M05",s.State.heroAction.policy.rule.id);Assert.AreEqual(100,s.State.resource,.001);Assert.IsEmpty(s.State.shields);Assert.AreEqual(14,s.State.cooldowns[16],.001);
            Advance(s,4);Assert.AreEqual(350,s.State.shield,.001);Assert.AreEqual(origin,s.State.position);Assert.AreEqual(original,JsonUtility.ToJson(s.State.build));Assert.AreEqual(1,s.State.actionEvents.Count(e=>e.skill==16&&e.kind=="ACTION_RELEASE"));
        }
        [TestCase(true,0)][TestCase(false,1)]
        public void DefaultPreventDoesNotReuseAnUnconditionalLegacyShield(bool enabled,int starts)
        {var s=Fixture(enabled,"ENABLED");Advance(s);Assert.AreEqual(starts,Starts(s));}
        [TestCase("EMERGENCY",false)][TestCase("PREVENT",true)][TestCase("ENGAGE",true)]
        public void DetectedDamageUsesTheGlobalDodgePolicy(string moment,bool expected)
        {
            var s=Fixture();Option(s,2,moment);Danger(s);string before=JsonUtility.ToJson(s.State);Assert.AreEqual(expected,Plan(s).ready);Assert.AreEqual(before,JsonUtility.ToJson(s.State));Advance(s,1);Assert.AreEqual(expected?1:0,Starts(s));
        }
        [Test] public void AnAlwaysDodgeWithNoDamageDoesNotMakeAPreventiveShield()
        {var s=Fixture();Danger(s,0);Assert.IsFalse(Plan(s).ready);Advance(s,1);Assert.AreEqual(0,Starts(s));}
        [TestCase("EMERGENCY")][TestCase("PREVENT")][TestCase("ENGAGE")]
        public void EnabledGlobalEmergencyCanQualifyEveryMoment(string moment)
        {var s=Fixture();Option(s,2,moment);Global(s,"survival.lowHp","ON");s.State.health=200;Assert.IsTrue(Plan(s).ready);Advance(s,1);Assert.AreEqual(1,Starts(s));}
        [TestCase("AFTER",0)][TestCase("TOGETHER",1)]
        public void OtherShieldsCanDeferOrCapTheActualAdditionalAmount(string mode,int starts)
        {var s=Fixture();Option(s,2,"ENGAGE");Option(s,3,mode);Other(s);Advance(s);Assert.AreEqual(starts,Starts(s));if(starts>0){Assert.AreEqual(200,s.State.shields.Single(e=>e.definitionId=="M05").amount,.001);Assert.AreEqual(1000,s.State.shield,.001);}}
        [TestCase("OFF")][TestCase("COOLDOWN")][TestCase("OWN")][TestCase("CAP")][TestCase("NO_SCALE")][TestCase("LEVEL")]
        public void UnavailableOpeningDoesNotSpendOrWaitForASecondChance(string gate)
        {
            var s=Fixture();Option(s,2,"ENGAGE");if(gate=="OFF")Option(s,1,"OFF");if(gate=="COOLDOWN")s.State.cooldowns[16]=1;if(gate=="OWN")Other(s,1,"M05");if(gate=="CAP")Other(s,1000);if(gate=="NO_SCALE")s.Stats.shieldMultiplier=0;if(gate=="LEVEL")s.Hero.level=1;
            float resource=s.State.resource;Advance(s,1);Assert.AreEqual(0,Starts(s));Assert.AreEqual(resource,s.State.resource);
            s.State.cooldowns[16]=0;s.State.resource=100;s.State.shields.Clear();s.Stats.shieldMultiplier=1;s.Hero.level=30;Option(s,1,"ON");Advance(s);Assert.AreEqual(0,Starts(s),"The initial unavailable review must not turn into a delayed opening.");
        }
        [Test] public void ZeroResourceStillStartsAndPreservesTheNextCostDiscount()
        {var s=Fixture(gear:"LC02");Option(s,2,"ENGAGE");s.State.resource=0;s.State.itemEffects.reducedNext=true;s.State.itemEffects.lc02Charge=5;Advance(s);Assert.AreEqual(1,Starts(s));Assert.AreEqual(350,s.State.shield,.001);Assert.AreEqual(0,s.State.resource);Assert.IsTrue(s.State.itemEffects.reducedNext);}
        [Test] public void OpeningRunsBeforeAReadyAttackEvenWhenShieldIsOrderedLater()
        {
            var s=Fixture(attack:true);Option(s,2,"ENGAGE");Assert.Less(Array.IndexOf(s.Hero.edict.skillOrder,"M03"),Array.IndexOf(s.Hero.edict.skillOrder,"M05"));Advance(s,1);
            Assert.AreEqual(16,s.State.heroAction.skill);Advance(s,4);Assert.AreEqual(1,Starts(s,14));Assert.Less(s.State.actionEvents.FindIndex(e=>e.skill==16&&e.kind=="ACTION_END"),s.State.actionEvents.FindIndex(e=>e.skill==14&&e.kind=="ACTION_START"));
        }
        [Test] public void UnavailableOpeningContinuesTheReadyAttackImmediately()
        {var s=Fixture(attack:true);Option(s,2,"ENGAGE");s.State.cooldowns[16]=10;Advance(s,1);Assert.AreEqual(14,s.State.heroAction.skill);Assert.AreEqual(0,Starts(s));}
        [TestCase("FINISH",false)][TestCase("CANCEL_ALLOWED",true)]
        public void PreventiveShieldUsesGlobalInterruptionPermission(string policy,bool interrupts)
        {
            var s=Fixture(row:"ENABLED",attack:true);Advance(s,1);var original=s.State.heroAction;Assert.AreEqual(14,original.skill);
            Global(s,"dodge.interrupt",policy);Danger(s);s.State.decisionTime=0;Advance(s,1);Assert.AreEqual(interrupts?16:14,s.State.heroAction.skill);
            Assert.AreEqual(interrupts,s.State.actionEvents.Any(e=>e.actionId==original.id&&e.kind=="ACTION_INTERRUPTED"));
        }
        [TestCase("ALL",false,false,true)][TestCase("ELITE",false,false,false)][TestCase("ELITE",true,false,true)][TestCase("ELITE",false,true,true)][TestCase("BOSS",true,false,false)][TestCase("BOSS",false,true,true)]
        public void OrdinaryEncounterRestrictionsUseCurrentlyPerceivedEnemies(string group,bool elite,bool boss,bool ready)
        {
            var s=Fixture();Option(s,2,"ENGAGE");Option(s,4,group);s.State.enemies.Clear();Enemy(s,0,2,elite?0:-1,boss);Assert.AreEqual(ready,Plan(s).ready);Advance(s,1);Assert.AreEqual(ready?1:0,Starts(s));
        }
        [TestCase(false)][TestCase(true)]
        public void HiddenOrExcludedElitesCannotQualifyTheEncounter(bool excluded)
        {
            var s=Fixture();Option(s,2,"ENGAGE");Option(s,4,"ELITE");var elite=Enemy(s,0,excluded?11:40,0);if(excluded){s.State.edictTarget=new EdictTargetState();s.State.edictTarget.excluded.Add(elite.id);}
            Assert.IsFalse(Plan(s).ready);Advance(s,1);Assert.AreEqual(0,Starts(s));
        }
        [Test] public void DirectGlobalEmergencyOverridesOtherShieldAndEncounterRestrictions()
        {
            var s=Fixture();Option(s,3,"AFTER");Option(s,4,"BOSS");Other(s);Global(s,"survival.lowHp","ON");s.State.health=200;
            Assert.IsFalse(Plan(s).ready,"An ordinary candidate cannot invent a direct global selection.");Global(s,"survival.defenseSkill","M05");Advance(s,1);
            Assert.AreEqual("HED2:SURVIVAL:M05",s.State.heroAction.policy.rule.id);Advance(s,4);Assert.AreEqual(200,s.State.shields.Single(e=>e.definitionId=="M05").amount,.001);
        }
        [Test] public void EmergencyOnlyIgnoresTheStoredInactiveEncounterGroup()
        {var s=Fixture();Option(s,2,"EMERGENCY");Option(s,4,"BOSS");Global(s,"survival.lowHp","ON");s.State.health=200;Assert.IsTrue(Plan(s).ready);Assert.AreEqual("BOSS",HuntEdictV2.Value(s.Hero.edict,"M05",4));}
        [Test] public void PreventiveShieldCanProtectAgainstATargetlessVisibleHazard()
        {var s=Fixture();s.State.enemies[0].position+=Vector2.up*40;Danger(s);Advance(s,1);Assert.AreEqual(1,Starts(s));Assert.AreEqual(-1,s.State.heroAction.targetId);}
        [Test] public void PreparationAndConsumedOpeningSurviveEditsAndIndependentRestore()
        {
            var s=Fixture(gear:"LC02");Option(s,2,"ENGAGE");s.State.itemEffects.reducedNext=true;s.State.itemEffects.lc02Charge=5;Advance(s,1);var action=s.State.heroAction;string paid=JsonUtility.ToJson(action);Assert.AreEqual(0,action.cost,.001);Assert.IsTrue(s.State.itemEffects.reducedNext);
            Option(s,2,"EMERGENCY");Option(s,3,"AFTER");Option(s,4,"BOSS");Option(s,1,"OFF");Assert.AreEqual(paid,JsonUtility.ToJson(s.State.heroAction));
            var restored=Restore(s);Assert.AreEqual(paid,JsonUtility.ToJson(restored.State.heroAction));Advance(s,4);Advance(restored,4);Assert.AreEqual(350,restored.State.shield,.001);Assert.AreEqual(100,restored.State.resource,.001);
            Assert.AreEqual(1,Starts(restored));Assert.IsTrue(restored.State.edictEngagement.openingChecked);Assert.AreEqual(JsonUtility.ToJson(s.State),JsonUtility.ToJson(restored.State));
            Option(restored,1,"ON");Option(restored,2,"ENGAGE");Option(restored,3,"TOGETHER");Option(restored,4,"ALL");restored.State.cooldowns[16]=0;restored.State.shields.Clear();Advance(restored);Assert.AreEqual(1,Starts(restored));
        }
        [Test] public void ShortSightLossDoesNotRearmButAQuietThreeSecondExitDoes()
        {
            var s=Fixture();Option(s,2,"ENGAGE");Advance(s);var enemy=s.State.enemies[0];var at=enemy.position;enemy.position+=Vector2.up*40;s.State.cooldowns[16]=0;s.State.shields.Clear();Advance(s,20);enemy.position=at;s.State.decisionTime=0;Advance(s,1);Assert.AreEqual(1,Starts(s));
            enemy.position+=Vector2.up*40;Advance(s,65);Assert.IsFalse(s.State.edictEngagement.active);enemy.position=at;s.State.decisionTime=0;Advance(s,1);Assert.AreEqual(2,Starts(s));
        }
        [Test] public void LegacyMidCombatSaveCannotMintANewOpeningOnLoad()
        {var s=Fixture();Option(s,2,"ENGAGE");s.State.time=10;s.State.noEnemySince=10;s.State.edictEngagement=null;var restored=Restore(s);Assert.IsTrue(restored.State.edictEngagement.openingChecked);Advance(restored);Assert.AreEqual(0,Starts(restored));}
        [Test] public void NewerEngagementVersionsAreRejectedWithoutDiscardingTheRecord()
        {var s=Fixture();s.State.edictEngagement.version=99;Assert.Throws<NotSupportedException>(()=>GameStore.NormalizeRun(s.State));Assert.AreEqual(99,s.State.edictEngagement.version);}
        [TestCase(HeroClass.Warrior)][TestCase(HeroClass.Ranger)]
        public void OtherClassesDoNotAllocateMageOpeningState(HeroClass heroClass)
        {
            var a=ContentTestAccounts.Training(catalog);a.selectedHero=(int)heroClass;var sim=new CombatSimulation(a,catalog,1,1,ownedTraining:true);Advance(sim,1);Assert.IsNull(sim.State.edictEngagement);
            var run=JsonUtility.FromJson<RunState>(JsonUtility.ToJson(sim.State));GameStore.NormalizeRun(run);Assert.IsNull(run.edictEngagement);
        }
        [TestCase("OWN")][TestCase("CAP")]
        public void ReleaseRechecksOwnShieldAndTotalCapWithoutRefundingTheCast(string block)
        {
            var s=Fixture();Option(s,2,"ENGAGE");Advance(s,1);int id=s.State.heroAction.id;Other(s,block=="OWN"?1:1000,block=="OWN"?"M05":"OTHER");Advance(s,4);
            Assert.AreEqual(100,s.State.resource,.001);Assert.Greater(s.State.cooldowns[16],13);Assert.IsTrue(s.State.actionEvents.Any(e=>e.actionId==id&&e.kind=="ACTION_INTERRUPTED"));Assert.IsFalse(s.State.actionEvents.Any(e=>e.actionId==id&&e.kind=="ACTION_RELEASE"));
        }
        [Test] public void ActualWillpowerAndMp04ScaleTheNewShieldButHealingDoesNot()
        {
            var s=Fixture();s.Hero.build.passives=new[]{3};var sheet=new HeroStats(s.Hero);Assert.AreEqual(1.239f,sheet.shieldMultiplier,.0001);s.Stats.shieldMultiplier=sheet.shieldMultiplier;s.Stats.healing=99;Option(s,2,"ENGAGE");Advance(s);Assert.AreEqual(433.65f,s.State.shield,.001);
        }
        [Test] public void EquippedLm03RewardsOnlyTheCreatedShieldAfterRealAbsorptionAndRestore()
        {
            var s=Fixture(gear:"LM03");Assert.IsTrue(s.Stats.specials.Contains("LM03"));s.State.resource=50;Option(s,2,"ENGAGE");Advance(s);Other(s,100,"OTHER",3);Hurt(s,240);
            var shield=s.State.shields.Single(e=>e.definitionId=="M05");Assert.AreEqual(140,shield.absorbed,.001);Assert.IsFalse(shield.manaPaid);Assert.AreEqual(50,s.State.resource,.001);
            var restored=Restore(s);restored.Stats.hp=2000;Hurt(restored,10);Assert.AreEqual(70,restored.State.resource,.001);Assert.AreEqual(4,restored.State.itemEffects.lm03Cooldown,.001);Assert.IsTrue(restored.State.shields.Single(e=>e.definitionId=="M05").manaPaid);
            Hurt(restored,100);Assert.AreEqual(70,restored.State.resource,.001);Assert.AreEqual(1,restored.State.effectEvents.Count(e=>e.definitionId=="LM03"&&e.kind=="RESOURCE"));
        }
        [Test] public void ACapLimitedShieldBelowItsCreationThresholdCannotEarnLm03Mana()
        {var s=Fixture(gear:"LM03");s.State.resource=50;Other(s,900);Option(s,2,"ENGAGE");Advance(s);Assert.AreEqual(100,s.State.shields.Single(e=>e.definitionId=="M05").amount,.001);Hurt(s,100);Assert.AreEqual(50,s.State.resource,.001);Assert.IsFalse(s.State.shields.Any(e=>e.definitionId=="M05"));}
    }
}
