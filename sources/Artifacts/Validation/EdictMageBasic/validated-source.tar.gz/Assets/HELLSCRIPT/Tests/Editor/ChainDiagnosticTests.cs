using System.Linq;
using Hellscript.Editor;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class ChainDiagnosticTests
    {
        [Test] public void NovaReplacementRecordsTheSameDecisionAndActualReleasedControl()
        {
            var catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();
            try
            {
                var account=ContentTestAccounts.Training(catalog);account.selectedHero=2;var hero=account.Hero;hero.level=30;hero.inventory.Clear();
                hero.build.activeSkills=new System.Collections.Generic.List<int>{14,17};hero.build.passives=System.Array.Empty<int>();
                hero.build.rules=new System.Collections.Generic.List<Rule>{BehaviorRules.Make(14),BehaviorRules.Make(17)};
                hero.edict=HuntEdictV2.WithOption(HuntEdictV2.WithOption(HuntEdictV2Storage.CreateForHero(hero),"BASIC",1,"OFF"),"M06",1,"OFF");hero.useEdict=true;
                foreach(var pair in new[]{("position.mode","STAND"),("survival.potion","OFF"),("survival.lowHp","OFF"),("survival.lethal","OFF"),("dodge.interrupt","CANCEL_ALLOWED")})
                    hero.edict=HuntEdictV2Editing.WithGlobal(hero.edict,pair.Item1,pair.Item2);
                var sim=new CombatSimulation(account,catalog,1,1,ownedTraining:true);sim.State.enemies.Clear();sim.State.exploration.enemies.Clear();sim.State.position=RiftMap.Rooms[0];sim.State.resource=100;
                var enemy=new EnemyState{id=900,kind=0,position=sim.State.position+Vector2.up*2,health=1000000,maxHealth=1000000,speed=0,attack=0,cooldown=1000};enemy.brain.initialized=true;sim.State.enemies.Add(enemy);
                var observer=new BuildIntegrationValidation.ChainObserver();observer.Observe(sim,0);sim.Tick(CombatSimulation.Step);observer.Observe(sim,CombatSimulation.Step);
                Assert.AreEqual(14,sim.State.heroAction.skill);Assert.AreEqual(1,observer.result.casts.Count);
                sim.Hero.edict=HuntEdictV2.WithOption(sim.Hero.edict,"M06",1,"ON");sim.RefreshEdict();sim.State.decisionTime=0;
                enemy.kind=3;enemy.brain.action=new EnemyActionState{id=5900,phase=EnemyActionPhase.Preparing,kind=3,origin=enemy.position,aim=sim.State.position,direction=Vector2.down,remaining=2,preparation=2,damage=20};
                var plan=sim.PlanEdictNova(sim.Hero.edict);Assert.IsTrue(plan.ready,plan.code+": "+plan.detail);
                sim.Tick(CombatSimulation.Step);observer.Observe(sim,CombatSimulation.Step);
                var cast=observer.result.casts.Single();Assert.AreEqual("interrupted",cast.finish);Assert.AreEqual("edict:M06",cast.replacementRule);
                Assert.AreEqual(sim.State.heroAction.id,cast.replacementAction);Assert.AreEqual(cast.interruptedAt,cast.replacementDecisionAt);
                Assert.AreEqual("준비가 끝나기 전에 끊을 수 있는 위험 시전을 제어합니다.",cast.replacementDecision);
                for(int i=0;i<12;i++){sim.Tick(CombatSimulation.Step);observer.Observe(sim,CombatSimulation.Step);}
                Assert.AreEqual("released",cast.replacementFinish);Assert.Greater(cast.replacementReleasedAt,cast.interruptedAt);Assert.AreEqual(1,cast.replacementHits);
                CollectionAssert.AreEqual(new[]{enemy.id},cast.replacementStatusTargets);
            }
            finally{Object.DestroyImmediate(catalog);}
        }
        [Test] public void ConfiguredSurvivalIsExplicitAndDoesNotChangeFreshDefaults()
        {
            var d=HuntEdictV2.Create(HeroClass.Mage);d.slots=new[]{"M03","M04","M05","M06"};string before=JsonUtility.ToJson(d);
            var configured=BuildIntegrationValidation.ConfigureChainSurvival(d);Assert.AreEqual(before,JsonUtility.ToJson(d));
            string G(HuntEdictV2Document source,string id)=>source.global.Single(o=>o.id==id).value;
            Assert.AreEqual("OFF",G(d,"survival.lowHp"));Assert.AreEqual("",G(d,"survival.defenseSkill"));Assert.AreEqual("ON",G(configured,"survival.lowHp"));Assert.AreEqual("M05",G(configured,"survival.defenseSkill"));
            Assert.AreEqual("M04",G(configured,"survival.escapeSkill"));Assert.AreEqual("15",G(configured,"dodge.area.hpPercent"));Assert.AreEqual("CANCEL_ALLOWED",G(configured,"dodge.interrupt"));
            Assert.AreEqual(HuntEdictV2.Value(d,"M05",2),HuntEdictV2.Value(configured,"M05",2));
        }
        [Test] public void ConfiguredSurvivalObservationPreservesCombatAndRecordsItsActualDocument()
        {
            var catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();
            try
            {
                var plain=BuildIntegrationValidation.AuditRun(catalog,HeroClass.Mage,1,1,0,useEdict:true,edictSetup:BuildIntegrationValidation.ConfigureChainSurvival);
                var observer=new BuildIntegrationValidation.ChainObserver();var observed=BuildIntegrationValidation.AuditRun(catalog,HeroClass.Mage,1,1,0,observer.Observe,true,BuildIntegrationValidation.ConfigureChainSurvival);
                Assert.AreEqual(JsonUtility.ToJson(plain),JsonUtility.ToJson(observed));Assert.NotNull(observer.result.edict);
                Assert.AreEqual("M05",observer.result.edict.global.Single(o=>o.id=="survival.defenseSkill").value);
                Assert.AreEqual(observed.skills.Single(s=>s.definitionId=="M03").interruptions,observer.result.casts.Count(c=>c.finish=="interrupted"));
            }
            finally{Object.DestroyImmediate(catalog);}
        }
        [Test] public void ObservingAGeneratedRiftDoesNotChangeItsOutcomeOrRecordedCombat()
        {
            var catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();
            try
            {
                var plain=BuildIntegrationValidation.AuditRun(catalog,HeroClass.Mage,1,1,0);
                var observer=new BuildIntegrationValidation.ChainObserver();var observed=BuildIntegrationValidation.AuditRun(catalog,HeroClass.Mage,1,1,0,observer.Observe);
                Assert.AreEqual(JsonUtility.ToJson(plain),JsonUtility.ToJson(observed));
                var chain=observed.skills.Single(s=>s.definitionId=="M03");
                Assert.AreEqual(chain.starts,observer.result.casts.Count);Assert.AreEqual(chain.hits,observer.result.casts.Sum(c=>c.hits));
                Assert.AreEqual(chain.releases,observer.result.phases.Sum(p=>p.chainReleases));
                Assert.AreEqual(observed.ticks*CombatSimulation.Step,observer.result.phases.Sum(p=>p.seconds),.05f);
                foreach(var phase in observer.result.phases)
                    Assert.AreEqual(phase.seconds,phase.unseen+phase.outsideFirstRange+phase.chainAction+phase.otherAction+phase.cooldown+phase.ready,.05f);
            }
            finally{Object.DestroyImmediate(catalog);}
        }
    }
}
