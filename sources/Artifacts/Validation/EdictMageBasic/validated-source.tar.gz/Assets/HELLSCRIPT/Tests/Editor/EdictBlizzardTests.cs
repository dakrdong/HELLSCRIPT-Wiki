using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class EdictBlizzardTests
    {
        GameCatalog catalog;
        [SetUp] public void Setup(){catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();}
        [TearDown] public void Teardown()=>UnityEngine.Object.DestroyImmediate(catalog);
        CombatSimulation Fixture(bool enabled=true,bool legacyRow=true,params string[] gear)
        {
            var account=GameStore.NewAccount();account.selectedHero=2;var hero=account.Hero;hero.level=30;hero.inventory.Clear();
            hero.build.activeSkills=new List<int>{13};hero.build.passives=Array.Empty<int>();hero.build.potionThreshold=0;
            hero.build.rules=legacyRow?new List<Rule>{BehaviorRules.Make(13,BehaviorRules.C("SC06",Comparison.AtLeast,99,predicted:true))}:new List<Rule>();
            uint rng=91367;
            foreach(string id in gear)
            {
                var item=ItemGenerator.Create(HeroClass.Mage,ItemCatalog.Unique(id).slot,3,30,ref rng,uniqueId:id);
                hero.inventory.Add(item);Assert.IsTrue(Economy.Equip(hero,item));
            }
            hero.edict=HuntEdictV2.WithOption(HuntEdictV2Storage.CreateForHero(hero),"BASIC",1,"OFF");hero.edict=HuntEdictV2.WithOption(hero.edict,"M02",1,"ON");
            hero.edict=HuntEdictV2Editing.WithGlobal(hero.edict,"position.mode","STAND");hero.useEdict=enabled;
            var sim=new CombatSimulation(account,catalog,1,1,seed:43177);sim.State.position=RiftMap.Rooms[0];
            sim.State.enemies.Clear();sim.State.exploration.enemies.Clear();Controlled(sim);return sim;
        }
        static void Controlled(CombatSimulation sim){sim.Stats.crit=0;sim.Stats.regen=0;sim.Stats.costReduction=0;}
        static EnemyState Enemy(CombatSimulation sim,float x,float y)
        {
            var enemy=new EnemyState{id=900+sim.State.enemies.Count,position=sim.State.position+new Vector2(x,y),
                health=1000000,maxHealth=1000000,speed=0,attack=0,cooldown=1000};sim.State.enemies.Add(enemy);return enemy;
        }
        static GroundEffect Field(CombatSimulation sim,Vector2 position,float duration=6)
        {
            var field=new GroundEffect{id=sim.State.nextId++,rootCastId=sim.State.nextId++,kind=13,definitionId="M02",casterId=sim.State.heroId,
                position=position,radius=3,duration=duration,createdAt=sim.State.time,damage=65,
                snapshot=new DamageSnapshot{damage=100,level=30,critDamage=1,elements=new float[6],passives=new bool[6]}};
            sim.State.effects.Add(field);return field;
        }
        static void Option(CombatSimulation sim,int n,string value)
        {sim.Hero.edict=HuntEdictV2.WithOption(sim.Hero.edict,"M02",n,value);sim.RefreshEdict();}
        static void Advance(CombatSimulation sim,int ticks=30){for(int i=0;i<ticks;i++)sim.Tick(CombatSimulation.Step);}
        static int Starts(CombatSimulation sim)=>sim.State.statistics.skills.FirstOrDefault(s=>s.definitionId=="M02")?.starts??0;
        static EdictAimPlan Plan(CombatSimulation sim,EnemyState target)=>sim.PlanEdictAim(sim.Hero.edict,"M02",target);
        CombatSimulation Restore(CombatSimulation sim)
        {
            var account=GameStore.NewAccount();account.selectedHero=2;account.heroes[2]=JsonUtility.FromJson<HeroSave>(JsonUtility.ToJson(sim.Hero));
            var restored=new CombatSimulation(account,catalog,1,restore:JsonUtility.FromJson<RunState>(JsonUtility.ToJson(sim.State)));Controlled(restored);return restored;
        }

        [TestCase(true)] [TestCase(false)]
        public void CorePolicyInstallsWithoutDependingOnALegacyConditionOrRow(bool legacyRow)
        {
            var sim=Fixture(legacyRow:legacyRow);Enemy(sim,0,4);string before=JsonUtility.ToJson(sim.State.build);Advance(sim);
            Assert.AreEqual(1,Starts(sim));Assert.AreEqual(before,JsonUtility.ToJson(sim.State.build));
            Assert.IsTrue(sim.State.decisions.Any(d=>d.ruleId=="edict:M02"&&d.code=="SELECTED"));
            Assert.IsFalse(sim.State.effects.Single(f=>f.kind==13).followsTarget);
            Assert.IsTrue(sim.State.damageEvents.Any(d=>d.definitionId=="M02"));
        }
        [Test] public void OptingOutPreservesTheOldBlockingCondition()
        {var sim=Fixture(false);Enemy(sim,0,4);Advance(sim);Assert.AreEqual(0,Starts(sim));Assert.IsFalse(sim.State.decisions.Any(d=>d.ruleId=="edict:M02"));}
        [Test] public void DisabledDuplicatesBecomeOneEnabledCandidateWithoutMutatingTheBuild()
        {
            var sim=Fixture();sim.State.build.rules[0].enabled=false;sim.State.build.rules.Add(BehaviorRules.Make(13));
            string before=JsonUtility.ToJson(sim.State.build);var rows=EdictRuleOrder.ForSimulation(sim.State.build.rules,sim.Hero.edict).Where(o=>o.rule.action==RuleAction.Skill).ToList();
            Assert.AreEqual(1,rows.Count);Assert.IsTrue(rows.Single().rule.enabled&&rows.Single().rule.always);
            Assert.AreEqual(before,JsonUtility.ToJson(sim.State.build));Enemy(sim,0,4);Advance(sim);Assert.AreEqual(1,Starts(sim));
        }
        [TestCase("NEW_AREA",1,false,true)] [TestCase("NEW_AREA",1,true,false)]
        [TestCase("GROUP",2,false,false)] [TestCase("GROUP",3,false,true)] [TestCase("GROUP",3,true,false)]
        public void PurposeRequiresTheFixedPopulationAndAnUncoveredEnemy(string mode,int count,bool covered,bool expected)
        {
            var sim=Fixture();var target=Enemy(sim,0,4);for(int i=1;i<count;i++)Enemy(sim,i*.4f,4);
            if(covered)Field(sim,target.position);Option(sim,2,mode);var plan=Plan(sim,target);Assert.AreEqual(expected,plan.available,plan.reason);
            Advance(sim);Assert.AreEqual(expected,Starts(sim)>0);
        }
        [Test] public void DenseNewAreaChoosesAQualifyingSmallerGroupOverAnAlreadyCoveredLargerOne()
        {
            var sim=Fixture();var target=Enemy(sim,-3,2);Enemy(sim,-3.4f,2);Enemy(sim,-3,2.4f);Field(sim,target.position);
            var outside=Enemy(sim,4,4);var plan=Plan(sim,target);Assert.IsTrue(plan.available,plan.reason);Assert.Contains(outside.id,plan.forecast.hits.ToArray());
        }
        [TestCase(0f,0f,true)] [TestCase(.5f,1f,true)] [TestCase(.5f,1.01f,false)] [TestCase(4f,.1f,false)]
        public void KeepTargetUsesTheLongestRemainingCoveringLifetime(float first,float second,bool expected)
        {
            var sim=Fixture();var target=Enemy(sim,0,4);if(first>0)Field(sim,target.position,first);if(second>0)Field(sim,target.position,second);
            Option(sim,2,"KEEP_TARGET");Assert.AreEqual(expected,Plan(sim,target).available);
        }
        [Test] public void KeepTargetCannotInstallADenseGroupWhichDoesNotCoverTheCurrentTarget()
        {
            var sim=Fixture();var target=Enemy(sim,-4,2);Enemy(sim,4,4);Enemy(sim,4.4f,4);Enemy(sim,4,4.4f);Option(sim,2,"KEEP_TARGET");
            var plan=Plan(sim,target);Assert.IsTrue(plan.available,plan.reason);Assert.Contains(target.id,plan.forecast.hits.ToArray());
            Option(sim,3,"SELF");Assert.IsFalse(Plan(sim,target).available);
        }
        [TestCase("foreign")] [TestCase("hostile")] [TestCase("expired")] [TestCase("delayed")] [TestCase("future")] [TestCase("other-kind")]
        public void InactiveOrForeignAreasDoNotCountAsOwnCoverage(string kind)
        {
            var sim=Fixture();var target=Enemy(sim,0,4);var fx=Field(sim,target.position);
            if(kind=="foreign")fx.casterId="foreign";if(kind=="hostile")fx.hostile=true;if(kind=="expired")fx.duration=0;
            if(kind=="delayed")fx.delay=.5f;if(kind=="future")fx.createdAt=1;if(kind=="other-kind")fx.kind=12;
            Assert.IsTrue(Plan(sim,target).available);
        }
        [Test] public void LegacyEmptyOwnerStillCountsAsOwnCoverage()
        {var sim=Fixture();var target=Enemy(sim,0,4);Field(sim,target.position).casterId="";Assert.IsFalse(Plan(sim,target).available);}
        [TestCase("KEEP",false)] [TestCase("REPLACE",true)]
        public void TwoLiveAreasArePreservedOrOnlyTheOldestIsReplaced(string mode,bool replace)
        {
            var sim=Fixture();Enemy(sim,0,6);var oldest=Field(sim,sim.State.position+new Vector2(-4,0));var newest=Field(sim,sim.State.position+new Vector2(4,0));
            var foreign=Field(sim,sim.State.position);foreign.casterId="foreign";Option(sim,4,mode);float resource=sim.State.resource;Advance(sim,15);
            Assert.AreEqual(replace?1:0,Starts(sim));Assert.AreEqual(!replace,sim.State.effects.Contains(oldest));
            Assert.Contains(newest,sim.State.effects);Assert.Contains(foreign,sim.State.effects);Assert.AreEqual(2,sim.State.effects.Count(f=>f.casterId==sim.State.heroId));
            Assert.AreEqual(resource-(replace?30:0),sim.State.resource,.0001f);
        }
        [Test] public void KeepIgnoresExpiredAndForeignAreasButCountsPendingOwnAreas()
        {
            var sim=Fixture();var target=Enemy(sim,0,6);Field(sim,sim.State.position,0);Field(sim,sim.State.position).casterId="foreign";
            var own=Field(sim,sim.State.position+Vector2.left*4);own.delay=1;Option(sim,4,"KEEP");Assert.IsTrue(Plan(sim,target).available);
            Field(sim,sim.State.position+Vector2.right*4).delay=1;Assert.IsFalse(Plan(sim,target).available);
        }
        [Test] public void DenseTriangleForecastAndActualAreaHitTheSameThreeEnemies()
        {
            var sim=Fixture();var target=Enemy(sim,-2.5f,2);Enemy(sim,2.5f,2);Enemy(sim,0,6.330127f);Option(sim,2,"GROUP");
            var plan=Plan(sim,target);Assert.IsTrue(plan.available,plan.reason);Assert.AreEqual(3,plan.forecast.uniqueTargets);
            Advance(sim,1);Assert.Less(Vector2.Distance(plan.forecast.aim,sim.State.heroAction.aim),.0001f);
            int root=sim.State.heroAction.id;Advance(sim,20);
            CollectionAssert.AreEquivalent(plan.forecast.hits,sim.State.damageEvents.Where(e=>e.definitionId=="M02"&&e.rootCastId==root).Select(e=>e.targetId).Distinct());
        }
        [Test] public void DenseCanCoverPerceivedEnemiesWhoseCentersAreBeyondCastRange()
        {
            var sim=Fixture();var target=Enemy(sim,0,11);var plan=Plan(sim,target);Assert.IsTrue(plan.available,plan.reason);
            Assert.LessOrEqual(Vector2.Distance(sim.State.position,plan.forecast.aim),10.0001f);Advance(sim);Assert.AreEqual(1,Starts(sim));
        }
        [TestCase("HIGH_HP")] [TestCase("LOW_HP")]
        public void TargetPlacementUsesTheExactGlobalTarget(string mode)
        {
            var sim=Fixture(legacyRow:false);var a=Enemy(sim,-3,3);var b=Enemy(sim,4,3);a.health=a.maxHealth*.5f;b.health=b.maxHealth*(mode=="HIGH_HP"?.9f:.1f);
            sim.Hero.edict=HuntEdictV2Editing.WithGlobal(sim.Hero.edict,"target.default",mode);Option(sim,3,"TARGET");Advance(sim,1);
            Assert.AreEqual(b.id,sim.State.heroAction.targetId);Assert.AreEqual(b.position,sim.State.heroAction.aim);
        }
        [TestCase(true)] [TestCase(false)]
        public void SelfPlacementStillRequiresItsSelectedPurpose(bool near)
        {
            var sim=Fixture();var target=Enemy(sim,0,near?2:5);Option(sim,3,"SELF");var plan=Plan(sim,target);Assert.AreEqual(near,plan.available);
            if(near){Assert.AreEqual(sim.State.position,plan.forecast.aim);Advance(sim);Assert.AreEqual(sim.State.position,sim.State.effects.Single().position);}
            sim.State.enemies.Clear();Assert.IsFalse(Plan(sim,null).available);
        }
        [TestCase("fresh")] [TestCase("missing")] [TestCase("stale")] [TestCase("future")] [TestCase("invalid")] [TestCase("rooted")]
        public void PathUsesOnlyFreshObservedVelocityForThreeQuartersOfASecond(string state)
        {
            var sim=Fixture();var target=Enemy(sim,0,4);sim.State.time=2;Option(sim,3,"PATH");
            if(state!="missing")sim.State.exploration.enemies.Add(new EnemyObservation{id=target.id,position=target.position,motionSampled=true,
                seenAt=state=="stale"?1.5f:state=="future"?3:2,velocity=state=="invalid"?new Vector2(float.NaN,0):Vector2.right*2});
            if(state=="rooted")target.statuses.Add(new StatusEffect{kind=StatusKind.Root,remaining=1});
            string before=JsonUtility.ToJson(sim.State);var plan=Plan(sim,target);Assert.IsTrue(plan.available,plan.reason);
            Assert.Less(Vector2.Distance(target.position+(state=="fresh"?Vector2.right*1.5f:Vector2.zero),plan.forecast.aim),.0001f);
            Assert.AreEqual(before,JsonUtility.ToJson(sim.State));
        }
        [Test] public void HiddenDeadAndExcludedEnemiesDoNotInflateTheGroupCount()
        {
            var sim=Fixture();var target=Enemy(sim,0,4);Enemy(sim,.1f,4).dead=true;Enemy(sim,0,40);var excluded=Enemy(sim,-.1f,4);
            sim.State.edictTarget=new EdictTargetState();sim.State.edictTarget.excluded.Add(excluded.id);Option(sim,2,"GROUP");Assert.IsFalse(Plan(sim,target).available);
        }
        [Test] public void InvalidPlacementIsRejectedBeforePaymentWhileDenseCanFindALegalAlternative()
        {
            var sim=Fixture();var target=Enemy(sim,0,4);sim.State.layout.legacy=false;
            sim.State.layout.obstacles.Add(new RiftObstacle{id="landing",position=target.position,radius=.5f,blocksSight=false,blocksWalk=false,blocksProjectile=false,blocksLanding=true});
            Option(sim,3,"TARGET");var plan=Plan(sim,target);Assert.IsFalse(plan.available);Assert.AreEqual("LANDING",plan.blockCode);
            float before=sim.State.resource;Advance(sim,1);Assert.AreEqual(before,sim.State.resource);Assert.AreEqual(0,Starts(sim));
            Option(sim,3,"DENSE");plan=Plan(sim,target);Assert.IsTrue(plan.available,plan.reason);Assert.IsTrue(sim.Map.CanLand(plan.forecast.aim,.1f));
            sim.State.decisionTime=0;Advance(sim,15);Assert.AreEqual(1,Starts(sim));
        }
        [Test] public void ObservedPathStopsAtTerrainInsteadOfPlacingAcrossTheWall()
        {
            var sim=Fixture();var target=Enemy(sim,0,4);sim.State.layout.legacy=false;sim.State.time=2;
            sim.State.layout.obstacles.Add(new RiftObstacle{id="wall",position=target.position+Vector2.up,halfSize=new Vector2(2,.1f),blocksSight=false,blocksWalk=true,blocksLanding=true});
            sim.State.exploration.enemies.Add(new EnemyObservation{id=target.id,position=target.position,motionSampled=true,seenAt=2,velocity=Vector2.up*2});
            Option(sim,3,"PATH");var plan=Plan(sim,target);Assert.IsTrue(plan.available,plan.reason);
            Assert.Less(plan.forecast.aim.y,target.position.y+1);Assert.Greater(plan.forecast.aim.y,target.position.y);Assert.IsTrue(sim.Map.CanLand(plan.forecast.aim,.1f));
        }
        [Test] public void FollowWithoutLegendaryPreservesTheChoiceAndCreatesAFixedField()
        {
            var sim=Fixture();var target=Enemy(sim,0,2);Option(sim,5,"FOLLOW");var plan=Plan(sim,target);
            Assert.IsTrue(plan.available);Assert.That(plan.reason,Does.Contain("LM01"));Advance(sim);
            Assert.AreEqual("FOLLOW",HuntEdictV2.Value(sim.Hero.edict,"M02",5));Assert.IsFalse(sim.State.effects.Single().followsTarget);
        }
        [Test] public void ExistingFollowingAreaKeepsItsModeAndMovesAtOneMeterPerSecondUpToFour()
        {
            var sim=Fixture(gear:new[]{"LM01"});var target=Enemy(sim,0,2);Option(sim,3,"SELF");Option(sim,5,"FOLLOW");
            Advance(sim,9);var field=sim.State.effects.Single();Assert.AreEqual(0,field.moved);
            Option(sim,5,"FIXED");Option(sim,1,"OFF");target.position=sim.State.position+Vector2.up*10;
            Advance(sim,10);Assert.AreEqual(.5f,field.moved,.0001f);Assert.IsTrue(field.followsTarget);
            target.position=sim.State.position+Vector2.up*20;Advance(sim,10);Assert.AreEqual(.5f,field.moved,.0001f);
            target.position=sim.State.position+Vector2.up*10;Advance(sim,80);Assert.AreEqual(4,field.moved,.0001f);Assert.AreEqual(1,Starts(sim));
        }
        [Test] public void BothDerivedPoliciesFollowTheDocumentOrderAndKeepDistinctRows()
        {
            var sim=Fixture(legacyRow:false);sim.Hero.build.activeSkills.Add(12);sim.State.build.activeSkills.Add(12);
            sim.Hero.edict=HuntEdictV2.WithOption(HuntEdictV2Storage.CreateForHero(sim.Hero),"BASIC",1,"OFF");sim.Hero.edict=HuntEdictV2Editing.WithSkillOrderMoved(sim.Hero.edict,"M02",-1);sim.RefreshEdict();
            var rows=EdictRuleOrder.ForSimulation(sim.State.build.rules,sim.Hero.edict).Where(o=>o.rule.action==RuleAction.Skill).ToList();
            CollectionAssert.AreEqual(new[]{13,12},rows.Select(r=>r.rule.skill));Assert.AreEqual(2,rows.Select(r=>r.row).Distinct().Count());
            Enemy(sim,0,4);Advance(sim,1);Assert.AreEqual(13,sim.State.heroAction.skill);
        }
        [TestCase("RESOURCE")] [TestCase("COOLDOWN")] [TestCase("LEVEL_LOCK")]
        public void TheCompiledPolicyStillRespectsExecutionGates(string gate)
        {
            var sim=Fixture();Enemy(sim,0,4);if(gate=="RESOURCE")sim.State.resource=0;if(gate=="COOLDOWN")sim.State.cooldowns[13]=100;
            if(gate=="LEVEL_LOCK"){sim.Hero.level=1;sim.State.trainingUsesOwnedHero=true;}Advance(sim,1);Assert.AreEqual(0,Starts(sim));
            Assert.IsTrue(sim.State.decisions.Any(d=>d.ruleId=="edict:M02"&&d.code==gate));
        }
        [Test] public void TargetPlacementCanApproachWithoutALegacyRowAndStopsWhenDisabled()
        {
            var sim=Fixture(legacyRow:false);Enemy(sim,0,11);Option(sim,3,"TARGET");Vector2 before=sim.State.position;Advance(sim,1);
            Assert.AreNotEqual(before,sim.State.position);Assert.IsTrue(sim.State.decisions.Any(d=>d.ruleId=="edict:M02"&&d.code=="RANGE"));
            Option(sim,1,"OFF");sim.State.decisionTime=0;before=sim.State.position;Advance(sim,10);Assert.AreEqual(before,sim.State.position);Assert.AreEqual(-1,sim.State.movementRule);
            Option(sim,1,"ON");sim.State.decisionTime=0;Advance(sim,80);Assert.Greater(Starts(sim),0);
        }
        [TestCase(false,"FIXED",false)] [TestCase(true,"FIXED",false)] [TestCase(false,"FOLLOW",false)] [TestCase(true,"FOLLOW",true)]
        public void ModeAndPaidPreparationSurviveEditsAndSaveRestoration(bool legendary,string mode,bool follows)
        {
            var sim=Fixture(gear:legendary?new[]{"LM01"}:Array.Empty<string>());Enemy(sim,0,4);Option(sim,3,"SELF");
            // The self area needs a target within its radius; later movement reveals follow versus fixed.
            sim.State.enemies[0].position=sim.State.position+Vector2.up*2;Option(sim,5,mode);Advance(sim,2);var action=sim.State.heroAction;
            Assert.AreEqual("edict:M02",action.policy.rule.id);Assert.IsFalse(action.released);float paid=sim.State.resource;
            Option(sim,5,mode=="FIXED"?"FOLLOW":"FIXED");Option(sim,1,"OFF");var restored=Restore(sim);
            for(int i=0;i<60;i++){Advance(sim,1);Advance(restored,1);Assert.AreEqual(JsonUtility.ToJson(sim.State),JsonUtility.ToJson(restored.State),"replay tick "+i);}
            Assert.AreEqual(paid,sim.State.resource);Assert.AreEqual(follows,sim.State.effects.Single().followsTarget);
            Assert.AreEqual(follows,sim.State.effects.Single().moved>0);Assert.AreEqual(1,Starts(sim));
            Assert.AreEqual(1,sim.State.actionEvents.Count(e=>e.actionId==action.id&&e.kind=="ACTION_RELEASE"));
            Advance(sim,90);Assert.IsEmpty(sim.State.effects);Assert.AreEqual(1,Starts(sim));
        }
        [Test] public void SmTwoPieceAndLc02UseTheRealCostOnlyOnceAfterPurposePasses()
        {
            var sim=Fixture(gear:new[]{"SM1","SM2","LC02"});Enemy(sim,0,4);sim.State.itemEffects.reducedNext=true;sim.State.itemEffects.lc02Charge=5;
            Option(sim,2,"GROUP");float before=sim.State.resource;Advance(sim,1);Assert.AreEqual(before,sim.State.resource);Assert.IsTrue(sim.State.itemEffects.reducedNext);
            Option(sim,2,"NEW_AREA");sim.State.decisionTime=0;Advance(sim,1);Assert.AreEqual(15,sim.State.heroAction.cost,.001f);Assert.AreEqual(before-15,sim.State.resource,.001f);
            Assert.IsFalse(sim.State.itemEffects.reducedNext);Option(sim,1,"OFF");Advance(sim,140);Assert.AreEqual(1,Starts(sim));
        }
        [Test] public void BlizzardCreatesOwnExposureWithoutWaitingForFireballAndFireballConsumesIt()
        {
            var sim=Fixture(gear:new[]{"SM1","SM2","SM3","SM4"});var target=Enemy(sim,0,4);Advance(sim,51);
            Assert.Greater(target.frostMarkTime,0);Assert.AreEqual(sim.State.heroId,target.frostCasterId);
            sim.Hero.build.activeSkills.Add(12);sim.State.build.activeSkills.Add(12);sim.Hero.edict=HuntEdictV2.WithOption(HuntEdictV2Storage.CreateForHero(sim.Hero),"BASIC",1,"OFF");
            sim.Hero.edict=HuntEdictV2.WithOption(sim.Hero.edict,"M01",2,"EXPOSURE");Option(sim,1,"OFF");sim.State.resource=sim.Stats.maxResource;sim.State.decisionTime=0;
            Advance(sim,40);Assert.IsTrue(sim.State.damageEvents.Any(e=>e.definitionId=="SM4"));Assert.Greater(target.frostCooldown,0);
        }
    }
}
