from pathlib import Path
import collections, datetime, hashlib, json, statistics

root = Path(__file__).resolve().parent
paths = [root.parent/'EdictNova/AfterFinal24/runs.jsonl', root/'AfterFinal24/runs.jsonl']
sets = [[json.loads(line) for line in p.read_text().splitlines()] for p in paths]
key = lambda r: (r['mode'], r['summary']['seedIndex'])
B, A = [{key(r): r for r in rows} for rows in sets]
assert len(B) == len(A) == 24 and set(B) == set(A)
for folder in [root.parent/'EdictNova/AfterFinal24', root/'AfterFinal24']:
    header = json.loads((folder/'header.json').read_text())
    assert header['status'] == 'complete' and header['completedRuns'] == 24

matched = ['seed', 'map', 'encounter', 'objective', 'equipment', 'sheet', 'maxHp', 'baseDamage']
for k, b in B.items():
    assert b['edict'] == A[k]['edict'], ('policy mismatch', k)
    for field in matched:
        assert b['summary'][field] == A[k]['summary'][field], (k, field)
for r in sets[0] + sets[1]:
    chain = next(s for s in r['summary']['skills'] if s['definitionId'] == 'M03')
    assert chain['starts'] == len(r['casts'])
    assert chain['hits'] == sum(c['hits'] for c in r['casts'])
    assert chain['releases'] == sum(p['chainReleases'] for p in r['phases'])
    assert chain['interruptions'] == sum(c['finish'] == 'interrupted' for c in r['casts'])
    assert abs(r['summary']['ticks']*.05 - sum(p['seconds'] for p in r['phases'])) < .1

documents = {mode: next(r['edict'] for r in sets[0] if r['mode'] == mode)
             for mode in ['edict', 'survival-configured']}
for r in sets[0] + sets[1]:
    if r['mode'] in documents:
        assert r['edict'] == documents[r['mode']]
default, configured = [{x['id']: x['value'] for x in documents[mode]['global']}
                       for mode in ['edict', 'survival-configured']]
policy_diff = {k: {'default': default[k], 'configured': v}
               for k, v in configured.items() if default[k] != v}
assert len(policy_diff) == 13
assert documents['edict']['skills'] == documents['survival-configured']['skills']
assert documents['edict']['slots'] == documents['survival-configured']['slots']
assert documents['edict']['skillOrder'] == documents['survival-configured']['skillOrder']

summary = {}
for label, rows in [('before', sets[0]), ('after', sets[1])]:
    for mode in ['legacy', 'edict', 'survival-configured']:
        group = [r for r in rows if r['mode'] == mode]
        casts = [c for r in group for c in r['casts']]
        stopped = [c for c in casts if c['finish'] == 'interrupted']
        skill = lambda name, field: sum(next((s[field] for s in r['summary']['skills']
                           if s['definitionId'] == name), 0) for r in group)
        summary[label+'-'+mode] = {
            'outcomes': dict(collections.Counter(r['summary']['outcome'] for r in group)),
            'bossSpawned': sum(r['summary']['bossSpawned'] for r in group),
            'starts': len(casts), 'releases': skill('M03', 'releases'), 'hits': sum(c['hits'] for c in casts),
            'finishes': dict(collections.Counter(c['finish'] for c in casts)),
            'interruptReasons': dict(collections.Counter(c['interruptionReason'] for c in stopped)),
            'replacements': dict(collections.Counter(c['replacementRule'] for c in stopped)),
            'lastGlobalRequest': dict(collections.Counter(str((c['emergencyAtLastDecision'],
                                   c['dodgeAtLastDecision'], c['survivalRole'])) for c in stopped)),
            'teleportStarts': skill('M04', 'starts'), 'shieldStarts': skill('M05', 'starts'),
            'basicStarts': skill('BASIC','starts'), 'basicHits': skill('BASIC','hits'),
            'novaStarts': skill('M06', 'starts'), 'novaReleases': skill('M06', 'releases'), 'novaHits': skill('M06', 'hits'),
            'meanBeforeBossSeconds': statistics.mean(r['phases'][0]['seconds'] for r in group),
            'resourceBlockedChecks': sum(r['summary']['resourceChecks'] for r in group),
            'meanDamage': statistics.mean(r['summary']['damage'] for r in group),
            'meanTime': statistics.mean(r['summary']['time'] for r in group)}
assert all(x['summary']==B[key(x)]['summary'] for x in sets[1] if x['mode']=='legacy')
control = {}
for mode in ['legacy','edict','survival-configured']:
    replacements=[c for r in sets[1] if r['mode']==mode for c in r['casts'] if c['replacementRule']=='edict:M06']
    assert all(c['replacementAction']>=0 and c['replacementDecisionAt']==c['interruptedAt'] and c['replacementDecision'] for c in replacements)
    control[mode]={'casts':len(replacements),'decisions':dict(collections.Counter(c['replacementDecision'] for c in replacements)),
        'finishes':dict(collections.Counter(c['replacementFinish'] for c in replacements)),
        'hits':sum(c['replacementHits'] for c in replacements),
        'castTargetApplications':sum(len(c['replacementStatusTargets']) for c in replacements),
        'emptyControlReleases':sum(c['replacementFinish']=='released' and not c['replacementStatusTargets'] for c in replacements)}
pairs = [{'mode': k[0], 'seedIndex': k[1],
          'before': {f: B[k]['summary'][f] for f in ['outcome', 'time', 'damage', 'bossSpawnTime', 'bossRemainingHp', 'kills']},
          'after': {f: A[k]['summary'][f] for f in ['outcome', 'time', 'damage', 'bossSpawnTime', 'bossRemainingHp', 'kills']}}
         for k in sorted(B)]
result = {'createdUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope': 'Eight outcome-selected stage-20 seeds, level-30 Chain Control and eight legal items, '
                   'three modes before and after Mage BASIC. The baseline is the preserved final M06 run (214b3de), with source provenance checked against its archive manifest. Survival configuration is diagnostic-only; '
                   'fresh defaults and player settings remain unchanged. No damage or affix tuning. '
                   'Last-decision context is observational, not necessarily the cause of a later-tick interruption.',
          'inputs': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
          'matchedFields': matched, 'matchedPolicyDocuments': True, 'legacySummariesUnchanged': True, 'baselineReusedFrom': 'EdictNova/AfterFinal24', 'replacementControlAfter': control, 'replacementControlNote': 'Same-frame selected decisions and actual M06 release, damage and applied status targets. Status includes refreshes; this is not prevented enemy casts or damage saved. No causal labels are retroactively assigned to schema-3 baseline casts.', 'policyDiff': policy_diff, 'documents': documents,
          'summary': summary, 'pairs': pairs}
(root/'comparison.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(summary, indent=2))
