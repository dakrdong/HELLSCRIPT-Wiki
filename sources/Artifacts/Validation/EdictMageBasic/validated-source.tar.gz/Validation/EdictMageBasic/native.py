from pathlib import Path
import subprocess,json,datetime,sys
root=Path(__file__).resolve().parent
out=root/sys.argv[1];out.mkdir(exist_ok=False)
save=out/'save';save.mkdir()
exe=Path.cwd()/'Builds/macOS-EdictMageBasic/HELLSCRIPT.app/Contents/MacOS/HELLSCRIPT'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
for label,extra in [('checkpoint',[]),('resume',['-hellscriptMageBasicResume']),('bolt',['-hellscriptMageBoltResume'])]:
 args=[str(exe),'-hellscriptMageBasicSmoke','-hellscriptSavePath',str(save),'-hellscriptScreenshots',str(out),'-logFile',str(out/(label+'.log'))]+extra
 (out/(label+'-command.json')).write_text(json.dumps(args,indent=2)+'\n')
 with (out/(label+'-stdout.log')).open('w') as log:
  info={'startedUtc':now()};proc=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT);info['pid']=proc.pid
  (out/(label+'-process.json')).write_text(json.dumps(info,indent=2)+'\n');print(label,json.dumps(info),flush=True)
  try: code=proc.wait(timeout=90)
  except subprocess.TimeoutExpired:
   proc.terminate()
   try: proc.wait(timeout=10)
   except subprocess.TimeoutExpired: proc.kill();proc.wait()
   code=124
  info.update(endedUtc=now(),exitCode=code);(out/(label+'-process.json')).write_text(json.dumps(info,indent=2)+'\n');print(label,json.dumps(info),flush=True)
  if code: sys.exit(code)
