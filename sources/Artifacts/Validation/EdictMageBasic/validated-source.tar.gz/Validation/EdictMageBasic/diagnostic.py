from pathlib import Path
import json, subprocess, datetime, sys
root=Path(__file__).resolve().parent
setup=json.loads((root/'setup.json').read_text())
name=sys.argv[1]
args=['/Applications/Unity/Hub/Editor/6000.6.0f1/Unity.app/Contents/MacOS/Unity','-batchmode','-nographics','-quit','-projectPath',setup['baselineProject'] if len(sys.argv)>2 and sys.argv[2]=='baseline' else setup['diagnosticProject'],'-logFile',str(root/(name+'.log')),'-executeMethod','Hellscript.Editor.BuildIntegrationValidation.RunChainDiagnostics','-hellscriptChainConfiguredSurvival','-hellscriptAuditStage','20','-hellscriptChainSeeds','0,1,2,3,4,5,9,14','-hellscriptAuditOutput',str(root/name)]
(root/(name+'-command.json')).write_text(json.dumps(args,indent=2)+'\n')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root/(name+'-stdout.log')).open('w') as out:
 info={'startedUtc':now()};p=subprocess.Popen(args,stdout=out,stderr=subprocess.STDOUT);info['pid']=p.pid
 (root/(name+'-process.json')).write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info),flush=True)
 code=p.wait();info.update(endedUtc=now(),exitCode=code)
 (root/(name+'-process.json')).write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info),flush=True)
sys.exit(code)
