from pathlib import Path
import sys, json, subprocess, datetime
root=Path(__file__).resolve().parent
setup=json.loads((root/'setup.json').read_text())
name=sys.argv[1];mode=sys.argv[2]
unity='/Applications/Unity/Hub/Editor/6000.6.0f1/Unity.app/Contents/MacOS/Unity'
project=setup['buildProject'] if mode=='build' else setup['project']
args=[unity,'-batchmode','-nographics','-projectPath',project,'-logFile',str(root/(name+'.log'))]
if mode=='build':
 args+=['-quit','-executeMethod','Hellscript.Editor.ProjectBuilder.BuildMac','-hellscriptBuildOutput',str(Path.cwd()/'Builds/macOS-EdictMageBasic/HELLSCRIPT.app')]
else:
 args+=['-runTests','-testPlatform','EditMode','-testResults',str(root/(name+'.xml'))]
 if len(sys.argv)>3: args+=['-testFilter',sys.argv[3]]
(root/(name+'-command.json')).write_text(json.dumps(args,indent=2)+'\n')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root/(name+'-stdout.log')).open('w') as out:
 info={'startedUtc':now()};process=subprocess.Popen(args,stdout=out,stderr=subprocess.STDOUT);info['pid']=process.pid
 (root/(name+'-process.json')).write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info),flush=True)
 code=process.wait();info.update(endedUtc=now(),exitCode=code)
 (root/(name+'-process.json')).write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info),flush=True)
sys.exit(code)
