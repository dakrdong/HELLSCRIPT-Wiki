using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Hellscript
{
    public static class RandomStream
    {
        public static uint Next(ref uint state) { if(state==0)state=0xA341316Cu; state^=state<<13;state^=state>>17;state^=state<<5;return state; }
        public static float Unit(ref uint state) => (Next(ref state)&0xFFFFFF)/16777216f;
        public static int Range(ref uint state,int min,int max) => min+(int)(Unit(ref state)*(max-min));
    }

    public sealed class HeroStats
    {
        public float hp, damage, armor, resistance, regen, speed, pickup, crit, critDamage, attackSpeed, cdr, costReduction, healing,shieldMultiplier;
        public float[] bonuses=new float[24];
        public HashSet<string> specials=new HashSet<string>();
        readonly Dictionary<string,HashSet<int>> sets=new Dictionary<string,HashSet<int>>();
        public int SetPieces(string id)=>sets.TryGetValue(id,out var slots)?slots.Count:0;
        public bool[] passives=new bool[6];
        float baseSpeed;
        public float SpeedWithBonus(float bonus)=>baseSpeed*(1+Mathf.Min(.5f,bonuses[21]/100+bonus));
        public HeroStats(HeroSave hero, bool training=false)
        {
            int level=training?30:hero.level; int c=(int)hero.heroClass;
            foreach(int p in hero.build.passives) if(p>=0&&p<6)passives[p]=true;
            var equipped=hero.inventory.Where(x=>x.equipped).ToList();
            foreach(var item in equipped)
            {
                for(int i=0;i<bonuses.Length;i++)bonuses[i]+=item.Value(i);
                if(!string.IsNullOrEmpty(item.special))specials.Add(item.special);
                var unique=ItemCatalog.Unique(item.special);
                if(unique!=null&&!string.IsNullOrEmpty(unique.setId))
                {if(!sets.TryGetValue(unique.setId,out var slots))sets[unique.setId]=slots=new HashSet<int>();slots.Add(item.slot);}
            }
            float primary=30+2*(level-1)+bonuses[10+c]+bonuses[14];
            float str=(c==0?30+2*(level-1):10+level-1)+bonuses[10]+bonuses[14];
            float dex=(c==1?30+2*(level-1):10+level-1)+bonuses[11]+bonuses[14];
            float intel=(c==2?30+2*(level-1):10+level-1)+bonuses[12]+bonuses[14];
            float flatHp=bonuses[0]; armor=str*2+bonuses[2];resistance=intel+bonuses[3];
            float weapon=20, weaponSpeed=0;
            foreach(var item in equipped)
            {
                var basis=ItemCatalog.Base(item);float value=basis.main*(1+.08f*(item.level-1));
                float upgraded=value*(1+.05f*item.enhancement);
                if(item.slot==0){weapon=upgraded;weaponSpeed=basis.attackSpeed;}
                else if(item.slot<=5)armor+=upgraded;
                else if(item.slot==6)flatHp+=upgraded;
                else resistance+=upgraded;
                resistance+=basis.resistance*(1+.08f*(item.level-1));
            }
            hp=(new[]{300,240,210}[c]+new[]{35,28,25}[c]*(level-1)+flatHp)*(1+bonuses[1]/100);
            damage=weapon*(1+.002f*primary);
            regen=new[]{8,10,12}[c]+bonuses[20]; if(c==2&&passives[4])regen*=1.2f;
            baseSpeed=new[]{4f,4.4f,4f}[c];speed=SpeedWithBonus(0);
            pickup=Mathf.Min(6,1.5f+bonuses[22]+(specials.Contains("LC01")?2.5f:0));
            crit=Mathf.Min(.75f,.05f+dex*.0003f+bonuses[15]/100);critDamage=1.5f+bonuses[16]/100;
            attackSpeed=1+Mathf.Clamp(weaponSpeed+bonuses[17]/100,-.5f,.5f);
            cdr=Mathf.Min(.4f,bonuses[18]/100); costReduction=Mathf.Min(.5f,bonuses[19]/100);
            healing=1+bonuses[23]/100+(10+level-1+bonuses[13]+bonuses[14])*.001f;
            shieldMultiplier=1+(10+level-1+bonuses[13]+bonuses[14])*.001f+(c==0&&passives[4]||c==2&&passives[3]?.2f:0);
        }
    }

    public static class Economy
    {
        public static readonly string[] LegendIds={"LW01","LW02","LW03","LW04","LA01","LA02","LA03","LA04","LM01","LM02","LM03","LM04","LC01","LC02","LC03"};
        public static readonly string[] LegendNames={"소용돌이의 송곳니","낙성의 발걸음","고독한 처형","마지막 명령","끝없는 궤적","좁혀진 사선","독사의 탈피","검은 전염","겨울의 발자취","되울림의 잿불","환류의 매듭","종말의 회로","파수꾼의 고리","절제의 서약","꺼지지 않는 심장"};
        public static int FreeSlots(HeroSave hero) => hero.capacity-hero.inventory.Count(x=>!x.equipped);
        public static int XpRequired(int level) => 100+60*(level-1)+15*(level-1)*(level-1);
        public static void AddXp(HeroSave hero,int xp)
        {
            if(hero.level>=30)return;hero.xp+=xp;
            while(hero.level<30&&hero.xp>=XpRequired(hero.level)){hero.xp-=XpRequired(hero.level);hero.level++;}
            if(hero.level==30)hero.xp=0;
        }
        public static bool AllowedAffix(int a,int s)=>ItemCatalog.Affixes.Any(d=>d.stat==a&&d.Allows(s));
        public static Item CreateItem(HeroClass c,int slot,int rarity,int level,ref uint rng,string id=null)
            =>ItemGenerator.Create(c,slot,rarity,level,ref rng,id);
        public static bool Referenced(HeroSave hero,Item item)=>
            (hero.build.equipmentIds?.Contains(item.id)??false)||hero.presets.Any(p=>p?.equipmentIds?.Contains(item.id)??false);
        public static bool Protected(HeroSave hero,Item item)=>item.locked||item.equipped||Referenced(hero,item);
        static bool Owned(AccountSave a,Item item)=>item!=null&&a.heroes.Any(h=>h.inventory.Contains(item));
        static bool TownService(AccountSave a)=>a.suspendedRun==null||a.suspendedRun.phase==RunPhase.Cleared||a.suspendedRun.phase==RunPhase.Failed;
        public static string EquipError(HeroSave hero,Item item)
        {
            if(item==null||!hero.inventory.Contains(item))return "이 캐릭터가 보유한 장비만 장착할 수 있습니다.";
            if(item.equipped)return "이미 장착한 장비입니다.";
            if(hero.level<item.RequiredLevel)return Loc.F("캐릭터 레벨 {0}이 필요합니다.", item.RequiredLevel);
            if(!ItemCatalog.Base(item).Fits(hero.heroClass,item.slot)||ItemCatalog.Unique(item.special) is UniqueItemDefinition u&&!u.Fits(hero.heroClass,item.slot))return "다른 직업의 전용 장비입니다.";
            return "";
        }
        public static bool AddItem(HeroSave hero,Item item,BagPolicy policy,AccountSave account=null)
        {
            if(item==null||hero.inventory.Any(i=>i.id==item.id))return false;
            if(FreeSlots(hero)>0){ItemAcquisition.Stamp(account,item);hero.inventory.Add(item);return true;}
            if(policy!=BagPolicy.Replace)return false;
            var worst=hero.inventory.Where(x=>!Protected(hero,x)&&!(account?.heroes.Any(h=>Referenced(h,x))??false)&&x.rarity<3).OrderBy(x=>x.rarity).ThenBy(x=>x.level).ThenBy(x=>x.Price).FirstOrDefault();
            if(worst==null||Compare(item,worst)<=0)return false;
            ItemAcquisition.Stamp(account,item);hero.inventory.Remove(worst);hero.inventory.Add(item);return true;
        }
        static int Compare(Item a,Item b) {int c=a.rarity.CompareTo(b.rarity);if(c==0)c=a.level.CompareTo(b.level);return c==0?a.Price.CompareTo(b.Price):c;}
        public static bool Equip(HeroSave hero,Item item)
        {
            if(!string.IsNullOrEmpty(EquipError(hero,item)))return false;
            foreach(var i in hero.inventory)if(i.slot==item.slot)i.equipped=false;
            item.equipped=true;return true;
        }
        public static bool Dismantle(AccountSave account,HeroSave hero,Item item)
        {
            if(!aOwns(account,hero,item)||(Protected(hero,item)||account.heroes.Any(h=>Referenced(h,item))))return false;
            if(item.rarity==3)account.cores[item.slot]++;else account.materials+=new[]{1,2,5}[item.rarity];
            int invested=item.contentVersion>0?item.investedMaterials:20*((1<<item.enhancement)-1);account.materials+=(int)(invested*4L/5);hero.inventory.Remove(item);return true;
        }
        static bool aOwns(AccountSave a,HeroSave h,Item i)=>i!=null&&a.heroes.Contains(h)&&h.inventory.Contains(i);
        public static bool Sell(AccountSave a,HeroSave h,Item item)
        {
            if(!aOwns(a,h,item)||(Protected(h,item)||a.heroes.Any(owner=>Referenced(owner,item))))return false;
            if((long)a.gold+item.Price>int.MaxValue)return false;
            a.gold+=item.Price;h.inventory.Remove(item);return true;
        }
        public static int EnhancementMaterials(Item item)=>item.enhancement>=5?0:20*(1<<item.enhancement);
        public static long EnhancementGold(Item item)=>item.enhancement>=5?0:200L*(item.enhancement+1)*item.level;
        public static long RerollGold(Item item)=>500L*item.level*(1<<Math.Min(item.rerolls,5));
        public static bool Enhance(AccountSave a,Item item)
        {
            if(!Owned(a,item)||!TownService(a)||item.enhancement>=5)return false;
            int mats=EnhancementMaterials(item);long gold=EnhancementGold(item);
            if(a.materials<mats||a.gold<gold)return false;
            a.materials-=mats;a.gold-=(int)gold;item.enhancement++;item.investedMaterials+=mats;return true;
        }
        public static bool Reroll(AccountSave a,Item item,int index,ref uint rng)
            =>item!=null&&index>=0&&index<item.rolls.Count&&Reroll(a,item,item.rolls[index].slotId,ref rng);
        public static bool Reroll(AccountSave a,Item item,string slotId,ref uint rng)
        {
            if(!Owned(a,item)||!TownService(a)||!string.IsNullOrEmpty(item.rerollSlotId)&&item.rerollSlotId!=slotId)return false;
            int index=item.rolls.FindIndex(r=>r.slotId==slotId);if(index<0||ItemGenerator.RerollPool(item,slotId).Count==0)return false;
            long cost=RerollGold(item);if(a.gold<cost)return false;
            uint next=rng;var roll=ItemGenerator.Reroll(item,slotId,ref next);
            a.gold-=(int)cost;item.rerollSlotId=slotId;item.rerolls++;item.rolls[index]=roll;item.name=item.DisplayName;rng=next;return true;
        }
        public static bool Sweep(AccountSave account,string requestId,ref uint rng)
        {
            if(account.receipts.Contains(requestId))return false;
            string day=DateTime.UtcNow.ToString("yyyy-MM-dd");if(account.sweepDay!=day){account.sweepDay=day;account.sweepCount=0;}
            var h=account.Hero;if(h.highestClear<1||account.sweepCount>=3||FreeSlots(h)<3)return false;
            for(int i=0;i<3;i++)AddItem(h,CreateItem(h.heroClass,RandomStream.Range(ref rng,0,8),RandomStream.Unit(ref rng)<.15f?3:2,RandomStream.Range(ref rng,Mathf.Max(1,h.highestClear-2),h.highestClear+3),ref rng),BagPolicy.Ignore,account);
            account.gold+=800+50*h.highestClear;account.materials+=5+h.highestClear/5;account.sweepCount++;account.receipts.Add(requestId);return true;
        }
    }
}
