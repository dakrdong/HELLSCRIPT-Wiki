using System;
using System.Collections.Generic;
using System.Text;

namespace Hellscript
{
    // The source strings in this project are written in Korean, so Korean is the key of every
    // entry and needs no table of its own. A new language is one more entry in All plus one more
    // table file; nothing else in the game has to know which languages exist.
    public sealed class LanguageOption
    {
        public string Code { get; }
        public string NativeName { get; }
        public string EnglishName { get; }
        public bool NeedsTable { get; }
        public LanguageOption(string code, string nativeName, string englishName, bool needsTable)
        { Code = code; NativeName = nativeName; EnglishName = englishName; NeedsTable = needsTable; }
    }

    public static class LanguageOptions
    {
        // The language the literals in the source are written in. It is the key of every entry.
        public const string Source = "ko";
        public const string Default = Source;
        public static readonly LanguageOption[] All =
        {
            new LanguageOption("ko", "한국어", "Korean", false),
            new LanguageOption("en", "English", "English", true),
        };
        public static bool IsSupported(string code) => Find(code) != null;
        public static LanguageOption Find(string code)
        {
            if (string.IsNullOrEmpty(code)) return null;
            foreach (var option in All) if (string.Equals(option.Code, code, StringComparison.Ordinal)) return option;
            return null;
        }
        // An unknown or damaged code becomes the default instead of leaving the game without text.
        public static string Nearest(string code) => IsSupported(code) ? code : Default;
    }

    // One line per entry: the Korean source string, a tab, then the translation. Both columns
    // escape the characters that would otherwise end the line or the column.
    public static class LocalizationTable
    {
        public sealed class Result
        {
            public Dictionary<string, string> Entries { get; } = new Dictionary<string, string>(StringComparer.Ordinal);
            public int Duplicates { get; internal set; }
            public int Malformed { get; internal set; }
            public int Blank { get; internal set; }
        }
        public static Result Parse(string text)
        {
            var result = new Result();
            if (string.IsNullOrEmpty(text)) return result;
            foreach (string raw in text.Split('\n'))
            {
                string line = raw.EndsWith("\r", StringComparison.Ordinal) ? raw.Substring(0, raw.Length - 1) : raw;
                if (line.Length == 0 || line[0] == '#') continue;
                int tab = line.IndexOf('\t');
                if (tab <= 0) { result.Malformed++; continue; }
                string key = Unescape(line.Substring(0, tab)), value = Unescape(line.Substring(tab + 1));
                // A unit suffix such as the counter in "적 3명" carries no word in English, so an
                // entry is allowed to translate to nothing. Only a missing key is malformed.
                if (value.Length == 0) result.Blank++;
                if (result.Entries.ContainsKey(key)) { result.Duplicates++; continue; }
                result.Entries[key] = value;
            }
            return result;
        }
        public static string Escape(string value)
        {
            if (string.IsNullOrEmpty(value)) return "";
            var text = new StringBuilder(value.Length + 8);
            foreach (char c in value)
            {
                if (c == '\\') text.Append("\\\\");
                else if (c == '\n') text.Append("\\n");
                else if (c == '\r') text.Append("\\r");
                else if (c == '\t') text.Append("\\t");
                else text.Append(c);
            }
            return text.ToString();
        }
        public static string Unescape(string value)
        {
            if (string.IsNullOrEmpty(value)) return "";
            if (value.IndexOf('\\') < 0) return value;
            var text = new StringBuilder(value.Length);
            for (int i = 0; i < value.Length; i++)
            {
                if (value[i] != '\\' || i + 1 >= value.Length) { text.Append(value[i]); continue; }
                char next = value[++i];
                if (next == 'n') text.Append('\n');
                else if (next == 'r') text.Append('\r');
                else if (next == 't') text.Append('\t');
                else if (next == '\\') text.Append('\\');
                else { text.Append('\\'); text.Append(next); }
            }
            return text.ToString();
        }
    }

    // Reading a string never fails: a missing entry, a damaged table and a translation whose
    // placeholders do not match the source all fall back to the Korean the source was written in.
    public static class Loc
    {
        static Dictionary<string, string> table;
        static readonly HashSet<string> missing = new HashSet<string>(StringComparer.Ordinal);
        public static string Language { get; private set; } = LanguageOptions.Default;
        public static bool IsSource => table == null;
        public static int MissingCount => missing.Count;
        public static IEnumerable<string> Missing => missing;
        public static void UseSource() => Use(LanguageOptions.Source, null);
        public static void Use(string code, Dictionary<string, string> entries)
        {
            string chosen = LanguageOptions.Nearest(code);
            bool source = string.Equals(chosen, LanguageOptions.Source, StringComparison.Ordinal);
            var chosenTable = source || entries == null || entries.Count == 0 ? null : entries;
            Language = chosen; table = chosenTable; missing.Clear();
        }
        // Composes a line in the source language deliberately. Used where the result is written to a
        // save file: those bytes may not depend on the language on screen, and the finished line is
        // read from the table when it is displayed.
        public static string Source(string text, params object[] args)
        {
            if (string.IsNullOrEmpty(text) || args == null || args.Length == 0) return text;
            try { return string.Format(text, args); } catch (FormatException) { return text; }
        }
        public static string T(string text)
        {
            if (table == null || string.IsNullOrEmpty(text)) return text;
            if (table.TryGetValue(text, out string translated)) return translated;
            // A line that is already composed from translated parts reaches here too and simply
            // passes through. Only text still written in the source language counts as missing.
            if (WrittenInSource(text)) missing.Add(text);
            return text;
        }
        // A skill name, a rule reason or an error message arrives here as an argument still written
        // in the source language, so each one is read from the table as well. Nothing is copied while
        // the source language is in use.
        static object[] Translated(object[] args)
        {
            object[] values = args;
            for (int i = 0; i < args.Length; i++)
            {
                if (!(args[i] is string source) || source.Length == 0) continue;
                string translated = T(source);
                if (ReferenceEquals(translated, source)) continue;
                if (ReferenceEquals(values, args)) values = (object[])args.Clone();
                values[i] = translated;
            }
            return values;
        }
        static bool WrittenInSource(string text)
        {
            if (string.IsNullOrEmpty(text)) return false;
            foreach (char c in text) if (c >= 0xAC00 && c <= 0xD7A3 || c >= 0x3130 && c <= 0x318F) return true;
            return false;
        }
        // A translation that lost or renumbered a placeholder would throw in the middle of drawing a
        // screen, so the source template composes the line instead.
        public static string F(string text, params object[] args)
        {
            if (string.IsNullOrEmpty(text)) return text;
            if (args == null || args.Length == 0) return T(text);
            string template = T(text);
            var values = Translated(args);
            try { return string.Format(template, values); }
            catch (FormatException)
            {
                if (!ReferenceEquals(template, text)) { try { return string.Format(text, values); } catch (FormatException) { } }
                return text;
            }
        }
    }
}
