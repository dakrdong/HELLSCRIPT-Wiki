using System.Collections.Generic;
using System.IO;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class CasualFieldSmokeProbeTests
    {
        [Test] public void CapturedCurrentEdictFieldInteractions()
        {
            string path=Path.Combine(Application.dataPath,"../Builds/Validation/CasualFields20261014/field-smoke-final2-save/hellscript-local-v1.json");
            var account=JsonUtility.FromJson<AccountSave>(File.ReadAllText(path));var run=account.suspendedRun;
            var catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();
            try
            {
                var powers=HuntEdictQuickMenu.With(HuntEdictLoadout.FromHero(account.Hero),new Dictionary<string,string>{{"explore.order","ENEMIES,LOOT,CHESTS,SHRINES"},{"common.order","DODGE,BUFF,PRIORITY_LOOT,ATTACK,OBJECTIVE,EXPLORE,REGROUP"}});
                account.Hero.build=powers.ToBuild(account.Hero.build);account.Hero.edict=powers.edict.Copy();run.build=account.Hero.build.Copy();
                run.edictAction=null; // The fresh fixture has not started regrouping under the old policy.
                var sim=new CombatSimulation(account,catalog,run.stage,restore:run);run.paused=false;
                float health=run.health;for(int n=0;n<100&&run.layout.shrines[0].phase!=ShrinePhase.Used;n++)sim.Tick(.05f);
                Assert.AreEqual(ShrinePhase.Used,run.layout.shrines[0].phase,run.action);Assert.AreEqual(health,run.health);Assert.Greater(run.resolveShrineTime,19);
                powers=HuntEdictQuickMenu.With(HuntEdictLoadout.FromHero(account.Hero),new Dictionary<string,string>{{"explore.chests","ON"},{"explore.cursedChest","AFTER_COMBAT"}});
                account.Hero.build=powers.ToBuild(account.Hero.build);account.Hero.edict=powers.edict.Copy();run.build=account.Hero.build.Copy();
                sim=new CombatSimulation(account,catalog,run.stage,restore:run);run.paused=false;
                var evt=run.layout.events[0];var chest=run.layout.chests.Single(c=>c.id==evt.chestId);chest.discovered=true;run.position=chest.openingPosition;RiftExploration.Discover(run,sim.Map);
                for(int n=0;n<80&&run.layout.events[0].phase==RiftEventPhase.Dormant;n++)sim.Tick(.05f);
                Assert.AreEqual(RiftEventPhase.Active,run.layout.events[0].phase,run.action);
                for(int n=0;n<260&&run.layout.events[0].phase==RiftEventPhase.Active;n++)sim.Tick(.05f);
                Assert.AreEqual(RiftEventPhase.Succeeded,run.layout.events[0].phase,run.action);
                for(int n=0;n<240&&run.layout.chests.Single(c=>c.id==evt.chestId).phase!=ChestPhase.Opened;n++)sim.Tick(.05f);
                Assert.AreEqual(ChestPhase.Opened,run.layout.chests.Single(c=>c.id==evt.chestId).phase,run.action);
            }
            finally{Object.DestroyImmediate(catalog);}
        }
    }
}
