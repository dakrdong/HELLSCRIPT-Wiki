using System.IO;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class CasualFieldSmokeProbeTests
    {
        [TestCase(false)][TestCase(true)] public void CapturedD4CursedEvent(bool edict)
        {
            string root=Path.Combine(Application.dataPath,"../Builds/Validation/CasualFields20261014/field-smoke-retry");
            var account=JsonUtility.FromJson<AccountSave>(File.ReadAllText(Path.Combine(root,"account-checkpoint.json")));
            var run=JsonUtility.FromJson<RunState>(File.ReadAllText(Path.Combine(root,"checkpoint.json")));
            account.Hero.useEdict=edict;
            var catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();
            try
            {
                var sim=new CombatSimulation(account,catalog,run.stage,restore:run);run.paused=false;
                Debug.Log("FIELD_PROBE start="+run.position+" walkable="+sim.Map.Walkable(run.position)+" blind="+run.heroBlindTime+" blockers="+string.Join(",",run.layout.obstacles.Where(o=>o.Contains(run.position)).Select(o=>o.kind)));
                foreach(var e in run.enemies.Where(e=>!string.IsNullOrEmpty(e.eventId)))Debug.Log("FIELD_PROBE enemy="+e.id+" dist="+Vector2.Distance(run.position,e.position)+" line="+sim.Map.LineClear(run.position,e.position)+" blockers="+string.Join(",",run.layout.obstacles.Where(o=>o.Contains(e.position)).Select(o=>o.kind)));
                for(int n=0;n<260;n++)
                {
                    sim.Tick(.05f);
                    if(n%20==0)Debug.Log("FIELD_PROBE t="+run.time+" pos="+run.position+" dmg="+run.dealt+" action="+run.action+" target="+run.targetId+" pursuit="+JsonUtility.ToJson(run.edictTarget));
                }
                Assert.AreEqual(RiftEventPhase.Succeeded,run.layout.events[0].phase);
            }
            finally{Object.DestroyImmediate(catalog);}
        }
    }
}
