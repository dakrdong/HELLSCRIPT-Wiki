using System;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // A continuous 1000-tier list keeps only visible rows alive; rewards come from the runtime catalog.
    public sealed class RiftRewardList:MonoBehaviour
    {
        ContentWindowView view;RectTransform[] rows;Text[] labels,states,unlocks;Image[] icons;float height,width;int selected;int first=-1;
        GameStore store;Action<int> choose;long revision=-1;
        public int FirstVisible=>first+1;public int LastVisible=>Mathf.Min(RiftEntryRules.RewardStages,first+rows.Length);
        public int RowPoolCount=>rows?.Length??0;
        public void Initialize(ContentWindowView v,Func<float> reading,int selected,GameStore store,Action<int> choose)
        {
            view=v;this.selected=selected;this.store=store;this.choose=choose;float factor=reading?.Invoke()??1;height=112*factor;width=v.Width-24;
            GetComponent<VerticalLayoutGroup>().enabled=false;GetComponent<ContentSizeFitter>().enabled=false;
            view.Body.sizeDelta=new Vector2(0,RiftEntryRules.RewardStages*height);
            int count=Mathf.CeilToInt(view.Scroll.viewport.rect.height/height)+3;rows=new RectTransform[count];labels=new Text[count];states=new Text[count];unlocks=new Text[count];icons=new Image[count];
            for(int i=0;i<count;i++)
            {
                int index=i;var button=v.Button(transform,"",0,0,width,height-2,()=>this.choose(first+index+1));
                var row=rows[i]=(RectTransform)button.transform;
                labels[i]=UiLayout.Text(row,"Rift tier","",12,0,width-92,28*factor,Mathf.RoundToInt(UiTheme.Body*factor),UiTheme.Text);
                labels[i].alignment=TextAnchor.MiddleLeft;
                states[i]=UiLayout.Text(row,"Reward claim state","",12,28*factor,width-92,28*factor,Mathf.RoundToInt(UiTheme.Caption*factor),UiTheme.Muted);
                unlocks[i]=UiLayout.Text(row,"Rift content unlock","",12,56*factor,width-92,54*factor,Mathf.RoundToInt(UiTheme.Caption*factor),UiTheme.Gold);
                var icon=UiLayout.Rect("First-clear box icon",row);UiLayout.Place(icon,width-64,(height-56)/2,56,56);icons[i]=icon.gameObject.AddComponent<Image>();icons[i].preserveAspect=true;icons[i].raycastTarget=false;
            }
            view.Scroll.onValueChanged.AddListener(_=>Refresh());Refresh();
        }
        void Refresh()
        {
            if(rows==null)return;int start=Mathf.Clamp(Mathf.FloorToInt(view.Body.anchoredPosition.y/height),0,Mathf.Max(0,RiftEntryRules.RewardStages-rows.Length));
            if(start==first&&revision==store.Revision)return;first=start;revision=store.Revision;
            for(int i=0;i<rows.Length;i++)
            {
                int stage=start+i+1;UiLayout.Place(rows[i],0,(stage-1)*height,width,height-2);rows[i].name="rift-reward-tier-"+stage;
                labels[i].text=Loc.F("균열 {0}단계",stage);string state=RewardBoxes.Status(store.Data,stage);
                var grants=RewardBoxCatalog.FirstClear(stage);var main=grants.LastOrDefault(g=>RewardBoxCatalog.Find(g.boxId).kind=="equipment")??grants.Last();
                icons[i].sprite=Resources.Load<Sprite>("Art/RewardBoxes/"+RewardBoxCatalog.Find(main.boxId).icon);
                states[i].text=Loc.T(state=="claimed"?"수령 완료":state=="ready"?"수령 가능":"클리어 후 수령")+" · "+Loc.F("상자 {0}개",grants.Sum(g=>g.count));
                string summary=ContentUnlocks.StageSummary(stage);
                unlocks[i].text=summary==""?"":Loc.F("콘텐츠 개방: {0}",summary);
                if(stage==RiftRarityBalance.MinimumLegendaryStage)unlocks[i].text=Loc.T("전설·세트 장비 획득 시작");
                UiTheme.Choice(rows[i].GetComponent<Button>(),stage==selected);
            }
        }
        void Start(){view.Body.anchoredPosition=new Vector2(0,Mathf.Clamp((selected-2)*height,0,Mathf.Max(0,view.Body.rect.height-view.Scroll.viewport.rect.height)));Refresh();}
        void LateUpdate()=>Refresh();
    }
}
