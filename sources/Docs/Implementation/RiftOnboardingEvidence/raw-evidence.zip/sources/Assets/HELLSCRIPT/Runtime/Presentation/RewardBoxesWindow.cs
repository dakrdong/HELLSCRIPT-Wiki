using System;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Hellscript
{
    // Created with tools/new_content_ui.py. The common shell owns layout; GameStore owns mutations.
    public static class RewardBoxesWindow
    {
        public static ContentWindowView Open(Transform parent,GameStore store,Func<float> readingScale,Action closed=null)
        {
            var session=new Session(parent,store,readingScale);
            var view=ContentWindowView.Open(parent,"보상 상자",EquipmentViewSource.Owned,readingScale,session.Draw,()=>{session.Result?.Close();closed?.Invoke();},new Vector2(720,820));
            StoreViewBinding.Attach(view,store,view.Repaint);return view;
        }
        public static RectTransform Row(ContentWindowView view,string name,float height)
        {var r=UiLayout.Rect(name,view.Body);r.gameObject.AddComponent<LayoutElement>().preferredHeight=height;return r;}
        static Text Text(Transform parent,string text,float x,float y,float w,float h,float scale=1)
            =>UiLayout.Text(parent,"Reward box text",text,x,y,w,h,Mathf.RoundToInt(UiTheme.Body*scale),UiTheme.Text);
        public static void Icon(Transform parent,RewardBoxDefinition definition,float x,float y,float size)
        {
            var r=UiLayout.Rect("Reward box icon "+definition.id,parent);UiLayout.Place(r,x,y,size,size);
            var image=r.gameObject.AddComponent<Image>();image.sprite=Resources.Load<Sprite>("Art/RewardBoxes/"+definition.icon);image.preserveAspect=true;image.raycastTarget=false;
        }
        static void Paragraph(ContentWindowView v,string text,float scale)
        {
            float w=v.Width-24;var row=Row(v,"Reward description",1);var label=Text(row,text,0,0,w,1000,scale);
            float h=Mathf.Max(28,label.preferredHeight+8);label.rectTransform.sizeDelta=new Vector2(w,h);row.GetComponent<LayoutElement>().preferredHeight=h;
        }
        public static string Contents(RewardBoxDefinition d,int stage,int quality=0)
        {
            int amount=RewardBoxCatalog.Amount(d,stage);
            switch(d.kind)
            {
                case "equipment":return Loc.F("장비 1개 · 아이템 레벨 {0}\n개봉하는 캐릭터의 직업에 맞춰 지급합니다.",RewardBoxCatalog.ItemLevel(stage))+
                    (quality>0?"\n"+Loc.F("접사 품질 {0}% 이상",quality/100):"")+
                    (d.setOnly?"\n"+Loc.T("현재 출시된 직업 세트에서 무작위로 지급합니다."):"");
                case "gem":return string.IsNullOrEmpty(d.gemId)?Loc.F("{0}단계 보석 · 선택한 색상 {1}개",d.tier,amount):Loc.F("{0}단계 {1} · {2}개",d.tier,Loc.T(GemCatalog.Find(d.gemId).name),amount);
                case "cores":return d.slot<0?Loc.F("선택한 장비 부위의 코어 {0}개",amount):Loc.F("{0} 코어 {1}개",Loc.T(GameCatalog.Slots[d.slot]),amount);
                case "rune":return d.eachType?Loc.T("G0 1칸 룬 · 5종류를 1개씩 지급합니다."):Loc.F("G{0} {1}칸 룬 {2}개 · 종류와 모양은 무작위입니다.",d.grade,d.size,amount);
                default:return Loc.F("{0} · {1:N0}개",Loc.T(d.kind=="stones"?"강화석":d.kind=="materials"?"제작 재료":d.kind=="premium"?"심연 주화":"골드"),amount);
            }
        }
        public static ContentWindowView ShowFirstClear(Transform parent,GameStore store,Func<float> reading,int stage)
        {
            string message="";
            var view=ContentWindowView.Open(parent,"균열 최초 보상",EquipmentViewSource.Catalog,reading,v=>
            {
                float f=reading?.Invoke()??1,w=v.Width-24;
                Text(v.Navigation,Loc.F("균열 {0}단계 · 계정당 1회",stage),0,0,w,34,f);
                if(stage<=RiftRarityBalance.MinimumLegendaryStage)
                    Paragraph(v,Loc.F("균열 전설·세트 장비는 {0}단계부터 획득할 수 있습니다. 이전 단계에서는 확률이 0%입니다.",RiftRarityBalance.MinimumLegendaryStage),f);
                var features=ContentUnlocks.AtStage(stage);
                if(features.Length>0)
                {
                    Paragraph(v,Loc.T("이 단계에서 열리는 콘텐츠"),f);
                    Paragraph(v,Loc.T("콘텐츠는 클리어 기록이 확정되면 계정 전체에 자동으로 개방됩니다. 상자 수령 여부와는 관계없습니다."),f);
                    foreach(var feature in features)
                    {
                        string status=Loc.T(ContentUnlocks.Has(store.Data,feature.id)?"개방됨":"클리어 후 개방");
                        Paragraph(v,Loc.T(feature.name)+" · "+status+"\n"+Loc.T(feature.guide),f);
                    }
                }
                var next=ContentUnlocks.NextAfter(stage);
                if(next!=null)Paragraph(v,Loc.F("다음 콘텐츠 · 균열 {0}단계: {1}",next.stage,ContentUnlocks.StageSummary(next.stage)),f);
                Paragraph(v,Loc.T("최초 클리어 상자"),f);
                Paragraph(v,Loc.T("정상 클리어 후 상자를 수령할 수 있습니다. 기존 최초 클리어 골드·재료는 전투에서 자동 지급됩니다."),f);
                foreach(var grant in RewardBoxCatalog.FirstClear(stage))
                {
                    var d=RewardBoxCatalog.Find(grant.boxId);var row=Row(v,"First-clear box "+d.id,86*f);Icon(row,d,0,0,64);
                    Text(row,d.Name+" × "+grant.count,70,0,w-70,56*f,f);
                    Text(row,d.kind=="equipment"?Loc.F("아이템 레벨 {0}",RewardBoxCatalog.ItemLevel(stage)):Loc.F("상자당 {0:N0}개",RewardBoxCatalog.Amount(d,stage)),70,56*f,w-70,28*f,f*.8f);
                }
                if(message!="")Paragraph(v,message,f);
                string state=RewardBoxes.Status(store.Data,stage);
                var claim=v.Button(v.Actions,state=="claimed"?"수령 완료":state=="locked"?"클리어 후 수령":"상자 수령",0,0,(w-8)/2,44,()=>
                {message=store.ClaimRiftFirstRewards(Guid.NewGuid().ToString("N"),stage)?Loc.T("보상 상자 보관함에 지급했습니다."):Loc.T(store.Error);v.Repaint();},true);
                claim.name="reward-box-claim-"+stage;claim.interactable=state=="ready"&&store.Data.suspendedRun==null;
                v.Button(v.Actions,"보상 상자",(w+8)/2,0,(w-8)/2,44,()=>Open(parent,store,reading)).name="reward-box-inventory";
            },maximumSize:new Vector2(680,780));
            StoreViewBinding.Attach(view,store,view.Repaint);return view;
        }
        sealed class Session
        {
            readonly Transform parent;readonly GameStore store;readonly Func<float> reading;
            int page,category;string selected,choice="",message="";
            public ContentWindowView Result;
            readonly string[] categories={"전체","장비","보석","재화","룬"};
            public Session(Transform parent,GameStore store,Func<float> reading){this.parent=parent;this.store=store;this.reading=reading;}
            bool Filter(OwnedRewardBox b)
            {string kind=RewardBoxCatalog.Find(b.boxId).kind;return category==0||category==1&&kind=="equipment"||category==2&&kind=="gem"||category==4&&kind=="rune"||category==3&&kind!="equipment"&&kind!="gem"&&kind!="rune";}
            public void Draw(ContentWindowView v)
            {
                float f=reading?.Invoke()??1,w=v.Width-24,cw=(w-16)/5;
                for(int i=0;i<5;i++)
                {int c=i;var button=v.Button(v.Navigation,categories[i],i*(cw+4),0,cw,32,()=>{category=c;page=0;v.Repaint();},category==i);button.name="reward-box-filter-"+i;var label=button.GetComponentInChildren<Text>();label.resizeTextForBestFit=true;label.resizeTextMinSize=10;label.resizeTextMaxSize=label.fontSize;}
                var owned=store.Data.rewardBoxes.owned.Where(Filter).ToArray();page=Mathf.Clamp(page,0,Math.Max(0,(owned.Length-1)/8));
                Paragraph(v,Loc.F("보유 상자 {0:N0}개 · {1}/{2}쪽",owned.Sum(b=>(long)b.count),page+1,Math.Max(1,(owned.Length+7)/8)),f);
                if(owned.Length==0)Paragraph(v,Loc.T("보유한 상자가 없습니다. 균열 최초 보상에서 상자를 수령하세요."),f);
                foreach(var box in owned.Skip(page*8).Take(8))
                {
                    var d=RewardBoxCatalog.Find(box.boxId);var row=Row(v,"Owned reward box "+box.id,86*f);
                    var button=v.Button(row,"",0,0,w,86*f,()=>{selected=box.id;choice="";message="";v.Repaint();},selected==box.id);button.name="reward-box-select-"+box.id;
                    Icon(button.transform,d,2,0,68);Text(button.transform,d.Name+" × "+box.count,76,4,w-84,56*f,f);
                    Text(button.transform,Loc.F("균열 {0}단계 보상",box.sourceStage),76,60*f,w-84,24*f,f*.8f);
                }
                var paging=Row(v,"Box pages",36);var prev=v.Button(paging,"이전",0,0,(w-8)/2,34,()=>{page--;v.Repaint();});prev.interactable=page>0;
                var next=v.Button(paging,"다음",(w+8)/2,0,(w-8)/2,34,()=>{page++;v.Repaint();});next.interactable=(page+1)*8<owned.Length;
                var selectedBox=owned.FirstOrDefault(b=>b.id==selected);
                if(selectedBox==null){selected=owned.Skip(page*8).FirstOrDefault()?.id;selectedBox=owned.FirstOrDefault(b=>b.id==selected);choice="";}
                var definition=selectedBox==null?null:RewardBoxCatalog.Find(selectedBox.boxId);
                bool chooseGem=definition?.kind=="gem"&&string.IsNullOrEmpty(definition.gemId),chooseCore=definition?.kind=="cores"&&definition.slot<0;
                if(definition!=null)
                {
                    Paragraph(v,definition.Name+"\n"+Contents(definition,selectedBox.sourceStage,selectedBox.minimumQuality),f);
                    if(chooseGem||chooseCore)
                    {
                        Paragraph(v,Loc.T(chooseGem?"지급받을 보석 색상을 선택하세요.":"지급받을 코어 부위를 선택하세요."),f);
                        int count=chooseGem?6:8,columns=chooseGem?3:4;float bw=(w-(columns-1)*4)/columns;
                        var choices=Row(v,"Box choices",Mathf.CeilToInt(count/(float)columns)*48*f);
                        for(int i=0;i<count;i++)
                        {
                            string value=chooseGem?GemCatalog.Gems[i].id:i.ToString(),label=chooseGem?Loc.T(GemCatalog.Gems[i].name):Loc.T(GameCatalog.Slots[i]);
                            var button=v.Button(choices,label,i%columns*(bw+4),i/columns*48*f,bw,44*f,()=>{choice=value;v.Repaint();},choice==value);
                            button.name="reward-box-choice-"+value;
                        }
                    }
                }
                if(message!="")Paragraph(v,message,f);
                if(store.Data.suspendedRun!=null)Paragraph(v,Loc.T("균열을 마치고 성소에서 상자를 개봉하세요."),f);
                bool canOpen=selectedBox!=null&&store.Data.suspendedRun==null&&(!(chooseGem||chooseCore)||choice!="");
                Action<int> open=count=>
                {
                    if(store.OpenRewardBox(Guid.NewGuid().ToString("N"),selectedBox.id,count,choice))
                    {
                        message=Loc.F("상자 {0}개를 개봉했습니다.",count);var items=store.LastBoxEquipment.ToArray();
                        if(items.Length>0)
                        {
                            Result?.Close();Result=ContentWindowView.Open(parent,"획득 장비",EquipmentViewSource.RewardSnapshot,reading,r=>
                            {foreach(var item in items)ItemDetailView.Append(r.Body,item,r.Width-24,textScale:reading?.Invoke()??1,source:EquipmentViewSource.RewardSnapshot);r.Button(r.Actions,"닫기",0,0,r.Width-24,44,()=>Result.Close());},maximumSize:new Vector2(680,800));
                        }
                    }
                    else message=Loc.T(store.Error);
                    v.Repaint();
                };
                var one=v.Button(v.Actions,"1개 개봉",0,0,(w-8)/2,44,()=>open(1),true);one.name="reward-box-open-one";one.interactable=canOpen;
                int batch=Math.Min(RewardBoxes.MaximumOpen,selectedBox?.count??0);
                var many=v.Button(v.Actions,Loc.F("{0}개 개봉",batch),(w+8)/2,0,(w-8)/2,44,()=>open(batch));many.name="reward-box-open-batch";many.interactable=canOpen&&batch>1;
            }
        }
    }
}
