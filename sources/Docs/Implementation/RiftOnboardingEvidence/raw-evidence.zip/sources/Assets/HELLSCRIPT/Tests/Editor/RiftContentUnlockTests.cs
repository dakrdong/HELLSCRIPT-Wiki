using System;
using System.IO;
using System.Linq;
using Hellscript.Runes;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class RiftContentUnlockTests
    {
        string directory;GameStore store;uint rng=45;
        AccountSave A=>store.Data;
        [SetUp] public void Setup()
        {
            Loc.UseSource();directory=Path.Combine(Path.GetTempPath(),"rift-unlock-v2-"+Guid.NewGuid());store=new GameStore(directory);
            A.Hero.level=30;A.gold=1000000;A.materials=10000;A.enhancementStones=1000;A.premium=1000;
        }
        [TearDown] public void Cleanup(){Loc.UseSource();if(Directory.Exists(directory))Directory.Delete(directory,true);}
        void Clear(int stage){A.Hero.highestClear=stage;ContentUnlocks.Reconcile(A);}
        Item Gear(int slot=3,int rarity=2,string power=null)
        {var item=ItemGenerator.Create(A.Hero.heroClass,slot,rarity,1,ref rng,uniqueId:power);A.Hero.inventory.Add(item);return item;}
        static string Json(object value)=>JsonUtility.ToJson(value);
        [Test] public void UnidentifiedPurchaseOpensAtTwentyFiveAndCanAwardLegendariesAndSets()
        {
            A.Hero.id="rarity-gate-hero";Clear(24);string before=Json(A);
            Assert.IsFalse(store.BuyGambleItem("locked-24",2,GambleShop.Level(A.Hero)));Assert.AreEqual(before,Json(A));
            Clear(25);A.gold=10000000;bool legendary=false,set=false;
            for(int n=0;n<10000&&!(legendary&&set);n++)
            {
                string request="gate-25-"+n;uint sample=RuneEconomy.Seed("gamble:"+A.Hero.id+":"+request);
                if(RandomStream.Unit(ref sample)>=.02f)continue;
                int gold=A.gold;Assert.IsTrue(store.BuyGambleItem(request,2,GambleShop.Level(A.Hero)),store.Error);
                var item=A.Hero.inventory.Single(i=>i.id=="gamble-"+request);Assert.AreEqual(3,item.rarity);
                Assert.AreEqual(gold-GambleShop.Price(2,GambleShop.Level(A.Hero)),A.gold);
                if(string.IsNullOrEmpty(ItemCatalog.Unique(item.special).setId))legendary=true;else set=true;
            }
            Assert.IsTrue(legendary&&set,"Both released pools must be reachable before Rift 30.");
            var loaded=new GameStore(directory);Assert.IsTrue(loaded.Data.Hero.inventory.Any(i=>i.rarity==3));
        }
        [Test] public void RerollWaitsUntilThirtyFiveAndExistingAccessSurvivesReload()
        {
            Clear(34);var item=Gear();string before=Json(A);uint random=99;
            Assert.IsFalse(Economy.Reroll(A,item,item.rolls[0].slotId,ref random));Assert.AreEqual(99u,random);Assert.AreEqual(before,Json(A));
            Clear(35);Assert.IsTrue(Economy.Reroll(A,item,item.rolls[0].slotId,ref random));
            A.Hero.highestClear=25;Assert.IsTrue(store.Save());
            Assert.IsTrue(ContentUnlocks.Has(new GameStore(directory).Data,ContentUnlocks.Reroll));
        }
        [Test] public void PopupMilestonesDescribeEveryActualGateExactlyOnce()
        {
            Assert.AreEqual(14,ContentUnlocks.Rules.features.Length);
            CollectionAssert.AreEquivalent(ContentUnlocks.Rules.features.Where(f=>f.stage>0).Select(f=>f.id),Enumerable.Range(1,1000).SelectMany(ContentUnlocks.AtStage).Select(f=>f.id));
            Assert.AreEqual(5,ContentUnlocks.NextAfter(3).stage);Assert.IsNull(ContentUnlocks.NextAfter(1000));
            Assert.IsEmpty(ContentUnlocks.AtStage(99));Assert.IsTrue(ContentUnlocks.Rules.features.All(f=>f.early==""));
        }
        [Test] public void SlotUpgradeAndAdditionalWorkstationWaitForFiveWhileGearWorksAtOne()
        {
            Clear(1);var item=A.Hero.inventory[0];Assert.IsTrue(store.EnhanceEquipment("gear",A.Hero.id,GearEnhancement.Quote(item,A.gold,1)));
            Clear(4);string before=Json(A);Assert.IsFalse(store.StartSlotUpgrade("early",A.Hero.id,BlacksmithCatalog.Slots[0].id,1));
            Assert.IsFalse(store.UnlockForgeStation("station",A.forge.stations));Assert.AreEqual(before,Json(A));
            Clear(5);int stones=A.enhancementStones;Assert.IsTrue(store.StartSlotUpgrade("open",A.Hero.id,BlacksmithCatalog.Slots[0].id,1),store.Error);
            Assert.AreEqual(stones-BlacksmithCatalog.Stones(2),A.enhancementStones);Assert.AreEqual(1,A.forge.jobs.Count);
        }
        [Test] public void EarlyGemsAreRetainedButCannotOpenServicesOrElixirCrafting()
        {
            GemInventory.Add(A,new GemStack{gemId="G01",tier=1,count=20});Clear(9);string before=Json(A);
            Assert.IsFalse(store.FuseGems("early-fuse","G01",1));Assert.IsFalse(store.BuyTownGem("early-buy","G01"));Assert.AreEqual(before,Json(A));
            Clear(10);Assert.IsTrue(store.FuseGems("fuse","G01",1));Assert.AreEqual(15,GemStacks.Count(A.gems,"G01",1));
            Assert.AreEqual(0,Jeweler.CraftCount(A,"G01",1,GemBatch.One));Clear(59);Assert.IsFalse(Jeweler.Craft(A,A.Hero.id,"G01",1,GemBatch.One));
            Clear(60);Assert.IsTrue(Jeweler.Craft(A,A.Hero.id,"G01",1,GemBatch.One));Assert.AreEqual(14,GemStacks.Count(A.gems,"G01",1));
        }
        [Test] public void RuneEntryPointsRejectBeforeFifteenWithoutConsumingOwnedRunes()
        {
            Clear(14);string before=Json(A);int revision=A.runes.revision;
            Assert.IsFalse(store.CommitRuneLayouts(Array.Empty<MasteryRunePlacement>(),revision));
            Assert.IsFalse(store.SaveRunePreset(0,"early",revision));Assert.IsFalse(store.BuyTownRune("buy",2));
            Assert.IsFalse(store.ReshapeRunes("reshape",A.runes.owned[0].id,A.runes.owned[1].id,revision));
            Assert.IsFalse(store.AscendRunes("ascend",A.runes.owned.Take(2).Select(r=>r.id).ToArray(),revision));
            Assert.IsFalse(store.ClaimRuneAscensions("claim",0,revision));Assert.AreEqual(before,Json(A));
            Clear(15);Assert.IsTrue(store.SaveRunePreset(0,"open",revision));Assert.IsTrue(store.BuyTownRune("buy-open",2));
        }
        [Test] public void RuneOwnershipDropsBeforeUnlockButMasteryBeginsAtFifteen()
        {
            Clear(14);var p=RuneMasteryProgress.Get(A.runes,RuneMasteryCatalog.EquippedWeapon(A.Hero));int xp=p.xp,count=A.runes.owned.Count;
            RuneGrowth.GrantVictory(A,new RunState{id="before",training=-1,stage=14});Assert.AreEqual(xp,p.xp);Assert.Greater(A.runes.owned.Count,count);
            Clear(15);RuneGrowth.GrantVictory(A,new RunState{id="after",training=-1,stage=15});Assert.Greater(p.xp,xp);
        }
        [Test] public void SalvagingCollectsAspectsBeforeFortyButUpgradeAndImprintWait()
        {
            Clear(39);for(int n=0;n<2;n++){var item=Gear(3,3,"LW03");Assert.IsTrue(Economy.Dismantle(A,A.Hero,item));}
            Assert.AreEqual(2,AspectStone.Count(A,"LW03"));var target=Gear();target.equipped=true;
            string before=Json(A);Assert.IsFalse(store.UpgradeAspect("early","LW03",1));Assert.IsFalse(store.ImprintAspect(new AspectImprintPlan(A,target,"LW03")));Assert.AreEqual(before,Json(A));
            Clear(40);Assert.IsTrue(store.UpgradeAspect("open","LW03",1));Assert.IsTrue(store.ImprintAspect(new AspectImprintPlan(A,target,"LW03")));Assert.AreEqual(2,A.Hero.inventory.Single(i=>i.id==target.id).aspectLevel);
        }
        [Test] public void MasterworkWaitsForEightyAndCoreStockCannotBypassOneHundredTwenty()
        {
            Clear(79);var item=Gear();item.enhancement=5;string before=Json(A);uint random=rng;
            Assert.IsFalse(ItemQuality.Advance(A,item,ref random));Assert.AreEqual(rng,random);Assert.AreEqual(before,Json(A));
            Clear(80);Assert.IsTrue(ItemQuality.Advance(A,item,ref random));Assert.AreEqual(1,item.masterwork);
            A.cores[0]=10;Clear(119);string recipe=CoreCrafting.Recipes.First(r=>r.slot==0&&r.heroClass==0).id;
            Assert.IsFalse(store.CraftCoreEquipment("early-core",CoreCrafting.Quote(A,recipe,0),12));Assert.AreEqual(10,A.cores[0]);
            Clear(120);Assert.IsTrue(store.CraftCoreEquipment("open-core",CoreCrafting.Quote(A,recipe,0),12));Assert.AreEqual(0,A.cores[0]);
        }
        [TestCase(0)] [TestCase(1)] [TestCase(5)] [TestCase(8)] [TestCase(10)] [TestCase(12)] [TestCase(15)]
        public void ReleasedAccountsKeepPreviousServicesAndMigrationIsIdempotent(int stage)
        {
            A.schema=12;A.contentUnlocks=new ContentUnlockState{version=1};A.Hero.highestClear=stage;
            string path=Path.Combine(directory,"hellscript-local-v1.json"),original=Json(A);File.WriteAllText(path,original);
            var loaded=new GameStore(directory);var account=loaded.Data;
            Assert.IsTrue(ContentUnlocks.Has(account,ContentUnlocks.Rune));Assert.IsTrue(ContentUnlocks.Has(account,ContentUnlocks.Aspect));
            Assert.AreEqual(stage>=1,ContentUnlocks.Has(account,ContentUnlocks.SlotEnhance));Assert.AreEqual(stage>=1,ContentUnlocks.Has(account,ContentUnlocks.Masterwork));
            Assert.AreEqual(stage>=5,ContentUnlocks.Has(account,ContentUnlocks.Elixir));Assert.AreEqual(stage>=8,ContentUnlocks.Has(account,ContentUnlocks.Reroll));
            Assert.AreEqual(stage>=10,ContentUnlocks.Has(account,ContentUnlocks.Shop));Assert.AreEqual(stage>=12,ContentUnlocks.Has(account,ContentUnlocks.Sweep));Assert.AreEqual(stage>=15,ContentUnlocks.Has(account,ContentUnlocks.CoreCraft));
            Assert.AreEqual(original,File.ReadAllText(path+".before-content-unlocks-v2.json"));
            string state=Json(account.contentUnlocks);ContentUnlocks.Normalize(account,legacy:true);Assert.AreEqual(state,Json(account.contentUnlocks));
            Assert.IsTrue(loaded.Save());Assert.AreEqual(state,Json(new GameStore(directory).Data.contentUnlocks));
        }
        [TestCase(0)] [TestCase(1)] [TestCase(3)] public void CurrentSaveCannotDowngradeOrInventUnlockVersion(int version)
        {
            Assert.IsTrue(store.Save());string path=Path.Combine(directory,"hellscript-local-v1.json");A.contentUnlocks.version=version;string bytes=Json(A);File.WriteAllText(path,bytes);
            Assert.Throws<NotSupportedException>(()=>new GameStore(directory));Assert.AreEqual(bytes,File.ReadAllText(path));
        }
        [Test] public void UnlockIsAccountWideAndDoesNotRequireClaimingFirstClearBoxes()
        {
            Clear(120);Assert.IsEmpty(A.rewardBoxes.claimedStages);Assert.IsTrue(store.Save());A.selectedHero=1;
            Assert.IsTrue(ContentUnlocks.Has(A,ContentUnlocks.CoreCraft));Assert.AreEqual(0,A.Hero.highestClear);
            uint random=1;Assert.IsFalse(Economy.Sweep(A,"no-personal",ref random));
            var loaded=new GameStore(directory);Assert.IsTrue(ContentUnlocks.Has(loaded.Data,ContentUnlocks.CoreCraft));Assert.IsEmpty(loaded.Data.rewardBoxes.claimedStages);
        }
    }
}
