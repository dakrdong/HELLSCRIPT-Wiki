using System.Collections.Generic;
using UnityEngine;

namespace Hellscript
{
    // Stored on newly generated layouts. Existing suspended maps and enemy snapshots stay intact.
    public static class IntroductoryRift
    {
        public const int LastStage=5,NormalCount=55,EliteCount=4;
        public const float GeometryScale=.70710678f; // sqrt(0.5): about half the area, with safe passage widths.
        public static bool Applies(int stage)=>stage>=1&&stage<=LastStage;
        public static float HealthMultiplier(int stage,bool boss)=>Mathf.Lerp(boss?.45f:.55f,boss?.65f:.75f,(stage-1)/4f);
        public static float AttackMultiplier(int stage)=>Mathf.Lerp(.30f,.50f,(stage-1)/4f);
        static void Scale(List<Vector2> points){for(int i=0;i<points.Count;i++)points[i]*=GeometryScale;}
        public static void ScaleGeometry(RiftLayout map)
        {
            if(!map.introductory)return;
            map.start*=GeometryScale;
            foreach(var room in map.rooms)
            {
                room.position*=GeometryScale;room.size*=GeometryScale;
                Scale(room.outline);Scale(room.groupAnchors);Scale(room.chestAnchors);
                foreach(var door in room.doors)door.position*=GeometryScale;
            }
            foreach(var corridor in map.corridors)
            {Scale(corridor.points);corridor.width=Mathf.Max(4,corridor.width*GeometryScale);for(int i=0;i<corridor.widths.Count;i++)corridor.widths[i]=Mathf.Max(4,corridor.widths[i]*GeometryScale);}
            foreach(var junction in map.junctions)junction.position*=GeometryScale;
            foreach(var obstacle in map.obstacles)
            {obstacle.position*=GeometryScale;obstacle.halfSize*=GeometryScale;obstacle.radius*=GeometryScale;}
            // Characters and bosses keep their physical footprint. Re-carve full-width door necks
            // and spawn-anchor clearance in the smaller rooms instead of weakening navigation checks.
            RiftOrganicGeometry.ShapeRooms(map);
        }
    }
}
