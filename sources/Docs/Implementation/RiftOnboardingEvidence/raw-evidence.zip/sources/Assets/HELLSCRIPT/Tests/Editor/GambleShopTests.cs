using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace Hellscript.Tests
{
    public sealed class GambleShopTests
    {
        string directory,path;GameStore store;GameCatalog catalog;
        [SetUp] public void Setup()
        {
            directory=Path.Combine(Path.GetTempPath(),"hellscript-gamble-"+Guid.NewGuid().ToString("N"));path=Path.Combine(directory,"hellscript-local-v1.json");
            catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();store=new GameStore(directory,catalog);
            store.Data.gold=1000000;store.Data.Hero.level=12;store.Data.Hero.highestClear=25;
        }
        [TearDown] public void Cleanup(){UnityEngine.Object.DestroyImmediate(catalog);if(Directory.Exists(directory))Directory.Delete(directory,true);}
        [Test] public void PriceIsFixedBySlotAndLevelAtTwiceTheRareVendorReference()
        {
            for(int level=1;level<=60;level++)for(int slot=0;slot<8;slot++)
            {Assert.AreEqual(2*GambleShop.VendorReferencePrice(slot,level),GambleShop.Price(slot,level));Assert.Greater(GambleShop.Price(slot,level),0);}
            Assert.AreEqual(12800,GambleShop.Price(0,10));Assert.AreEqual(7680,GambleShop.Price(5,10));
            Assert.AreEqual(0,GambleShop.Price(-1,10));Assert.AreEqual(0,GambleShop.Price(8,10));Assert.AreEqual(0,GambleShop.Price(0,61));
        }
        [Test] public void PurchaseCommitsTheRevealedItemOnceAndSurvivesReload()
        {
            var h=store.Data.Hero;int level=GambleShop.Level(h),gold=store.Data.gold,count=h.inventory.Count;
            string earned=JsonUtility.ToJson(h.equipmentShop.earned);
            Assert.IsTrue(store.BuyGambleItem("reveal",0,level),store.Error);
            var item=h.inventory.Single(i=>i.id=="gamble-reveal");string original=JsonUtility.ToJson(item);
            Assert.AreEqual(count+1,h.inventory.Count);Assert.AreEqual(gold-GambleShop.Price(0,level),store.Data.gold);
            Assert.AreEqual(level,item.level);Assert.LessOrEqual(item.RequiredLevel,h.level);Assert.AreEqual("shop",item.acquisitionKind);Assert.IsFalse(item.equipped);Assert.DoesNotThrow(()=>ItemCatalog.Validate(item));
            Assert.AreEqual(earned,JsonUtility.ToJson(h.equipmentShop.earned),"Gambling must not advance the earned-power anchor.");
            Assert.IsTrue(store.BuyGambleItem("reveal",0,level));Assert.AreEqual(count+1,h.inventory.Count);
            Assert.IsFalse(store.BuyGambleItem("reveal",1,level));
            var loaded=new GameStore(directory,catalog);Assert.AreEqual(store.Data.gold,loaded.Data.gold);Assert.AreEqual(original,JsonUtility.ToJson(loaded.Data.Hero.inventory.Single(i=>i.id==item.id)));
        }
        [Test] public void StaleQuoteFundsSpaceAndActiveRunRejectWithoutCharge()
        {
            int level=GambleShop.Level(store.Data.Hero);string before=JsonUtility.ToJson(store.Data);
            Assert.IsFalse(store.BuyGambleItem("stale",0,level-1));Assert.AreEqual(before,JsonUtility.ToJson(store.Data));
            store.Data.gold=0;Assert.IsFalse(store.BuyGambleItem("poor",0,level));store.Data.gold=1000000;
            var sim=new CombatSimulation(store.Data,catalog,1,seed:2);store.Data.suspendedRun=sim.State;
            Assert.IsFalse(store.BuyGambleItem("run",0,level));store.Data.suspendedRun=null;
            uint rng=18;while(Economy.FreeSlots(store.Data.Hero)>0)Economy.AddItem(store.Data.Hero,Economy.CreateItem(0,1,0,1,ref rng),BagPolicy.Ignore,store.Data);
            before=JsonUtility.ToJson(store.Data);Assert.IsFalse(store.BuyGambleItem("full",0,level));Assert.AreEqual(before,JsonUtility.ToJson(store.Data));
        }
        [Test] public void SaveFailureLeavesNoChargeOrItemAndTheSameRequestCanRetry()
        {
            Assert.IsTrue(store.Save());int level=GambleShop.Level(store.Data.Hero);string before=JsonUtility.ToJson(store.Data),disk=File.ReadAllText(path);
            Directory.CreateDirectory(path+".tmp");LogAssert.Expect(LogType.Error,new Regex("저장하지 못했습니다:"));
            Assert.IsFalse(store.BuyGambleItem("disk",3,level));Assert.AreEqual(before,JsonUtility.ToJson(store.Data));Assert.AreEqual(disk,File.ReadAllText(path));
            Directory.Delete(path+".tmp");Assert.IsTrue(store.BuyGambleItem("disk",3,level),store.Error);Assert.AreEqual(3,store.Data.Hero.inventory.Single(i=>i.id=="gamble-disk").slot);
        }
        [Test] public void GamblingPreservesTheExistingAccountUnlockAndCannotBypassIt()
        {
            var fresh=new GameStore(Path.Combine(directory,"fresh"),catalog);fresh.Data.gold=1000000;string before=JsonUtility.ToJson(fresh.Data);
            Assert.IsFalse(fresh.BuyGambleItem("locked",0,GambleShop.Level(fresh.Data.Hero)));Assert.AreEqual(before,JsonUtility.ToJson(fresh.Data));
            fresh.Data.heroes[1].highestClear=25;
            Assert.IsTrue(fresh.BuyGambleItem("unlocked",0,GambleShop.Level(fresh.Data.Hero)),fresh.Error);
        }
        [Test] public void RewardsUseRealClassCompatibleLootAtACappedLevelForEverySlot()
        {
            for(int hero=0;hero<3;hero++)
            {
                store.Data.selectedHero=hero;var h=store.Data.Hero;h.level=20;h.highestClear=50;store.Data.gold=2000000;
                for(int slot=0;slot<8;slot++)
                {
                    string request="class-"+hero+"-"+slot;Assert.IsTrue(store.BuyGambleItem(request,slot,GambleShop.Level(h)),store.Error);
                    // Class/level eligibility is independent of owning the main weapon a new offhand requires.
                    var item=h.inventory.Single(i=>i.id=="gamble-"+request);Assert.AreEqual(slot,item.slot);Assert.AreEqual(40,item.level);Assert.That(item.rarity,Is.InRange(1,3));Assert.IsTrue(string.IsNullOrEmpty(Storage.WearError(h,item)));Assert.DoesNotThrow(()=>ItemCatalog.Validate(item));
                }
            }
        }
    }
}
