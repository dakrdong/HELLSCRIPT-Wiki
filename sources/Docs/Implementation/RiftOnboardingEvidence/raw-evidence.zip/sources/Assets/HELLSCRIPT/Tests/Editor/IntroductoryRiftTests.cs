using System;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace Hellscript.Tests
{
    public sealed class IntroductoryRiftTests
    {
        [TestCase(.2f)] [TestCase(.22f)] [TestCase(.3f)] public void ObservedEarlyRunCornerCanReachItsNextRoom(float step)
        {
            var map=RiftGenerator.Generate(20262261,"corner",1,HeroClass.Warrior);
            var nav=new RiftNavigation(map);var from=new Vector2(18.0582981f,21.7537727f);var to=new Vector2(-1.29289317f,32.5269127f);
            TestContext.WriteLine("walkable="+nav.Walkable(from)+" path="+string.Join(";",nav.FindPath(from,to)?.Select(p=>p.ToString("F6"))??Array.Empty<string>()));
            Assert.IsTrue(nav.Walkable(from),"Observed movement left the walkable floor.");
            var position=from;
            for(int i=0;i<1500&&Vector2.Distance(position,to)>.2f;i++)position=nav.Move(position,to,step,0,i*.05f);
            Assert.Less(Vector2.Distance(position,to),.2f,"Movement stalled at "+position);
        }
        [Test] public void GeometryReallyHalvesFloorEnvelopeAndKeepsGraphEndpoints()
        {
            var map=RiftGenerator.Generate(81002,"area",6,HeroClass.Warrior,forcedTheme:0,forcedCount:6);
            float before=RiftDensity.Measure(map).hullArea;
            map.introductory=true;IntroductoryRift.ScaleGeometry(map);
            Assert.That(RiftDensity.Measure(map).hullArea/before,Is.InRange(.48f,.56f));
            foreach(var edge in map.corridors)
            {
                Assert.Less(Vector2.Distance(edge.points.First(),map.rooms[edge.roomA].doors[edge.doorA].position),.01f);
                Assert.Less(Vector2.Distance(edge.points.Last(),map.rooms[edge.roomB].doors[edge.doorB].position),.01f);
            }
        }
        [Test] public void FloorSeamToleranceDoesNotBridgeARealGap()
        {
            var map=new RiftLayout();
            map.rooms.Add(new RiftRoom{position=Vector2.zero,size=Vector2.one*2});
            map.rooms.Add(new RiftRoom{index=1,position=new Vector2(2.001f,0),size=Vector2.one*2});
            var surface=new RiftSurface(map);
            Assert.IsFalse(surface.SegmentOnFloor(new Vector2(.95f,0),new Vector2(1.05f,0)));
        }
        [TestCase(1)] [TestCase(5)] [TestCase(6)]
        public void NewMapsHaveCorrectBudgetAndReachableCombatAndRewards(int stage)
        {
            foreach(uint seed in new uint[]{1,2,3,17,81002,20262261})
            {
                var map=RiftGenerator.Generate(seed,"intro-"+seed,stage,HeroClass.Warrior);
                Assert.AreEqual(stage<=5,map.introductory);RiftGenerator.Validate(map);
                Assert.AreEqual(stage<=5?55:110,map.spawns.Count(s=>s.elite<0));
                Assert.AreEqual(stage<=5?4:8,map.spawns.Count(s=>s.elite>=0));
                var nav=new RiftNavigation(map);Assert.IsTrue(map.spawns.All(s=>nav.Reachable(s.position)));
                Assert.IsTrue(map.chests.All(c=>c.accessPoints.Any(nav.Reachable)));
                Assert.AreEqual(2,map.chests.Count(c=>c.reward!=null));
                Assert.IsTrue(map.chests.Where(c=>c.reward!=null).All(c=>c.reward.rarity<3));
            }
        }
        [TestCase(1,38.5f,5.4f)] [TestCase(5,71.42588f,11.149424f)] [TestCase(6,102.85297f,23.52522f)]
        public void SpawnedEnemyStatsUseIntroductoryCurveOnlyInNewEarlyMaps(int stage,float hp,float attack)
        {
            var catalog=ScriptableObject.CreateInstance<GameCatalog>();catalog.Populate();
            try
            {
                var sim=new CombatSimulation(GameStore.NewAccount(),catalog,stage,seed:20262261);
                var enemy=sim.State.enemies.First(e=>e.kind==0&&e.elite<0&&!e.boss);
                Assert.AreEqual(hp,enemy.maxHealth,.01f);Assert.AreEqual(attack,enemy.attack,.01f);
            }
            finally{UnityEngine.Object.DestroyImmediate(catalog);}
        }
    }
}
