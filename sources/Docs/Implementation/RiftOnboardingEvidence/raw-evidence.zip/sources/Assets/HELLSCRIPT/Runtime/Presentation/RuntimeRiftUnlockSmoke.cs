using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Hellscript
{
    public sealed class RuntimeRiftUnlockSmoke:MonoBehaviour
    {
        GameController game;string output;readonly List<string> checks=new List<string>();
        static void Require(bool value,string message){if(!value)throw new InvalidOperationException(message);}
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)] static void Foreground()
        {if(Debug.isDebugBuild&&Environment.GetCommandLineArgs().Contains("-hellscriptRiftUnlockSmoke"))Application.runInBackground=true;}
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Boot()
        {
            if(!Debug.isDebugBuild||!Environment.GetCommandLineArgs().Contains("-hellscriptRiftUnlockSmoke"))return;
            Application.runInBackground=true;new GameObject("Native rift unlock acceptance").AddComponent<RuntimeRiftUnlockSmoke>();
        }
        void OnEnable()=>Application.logMessageReceived+=Error;
        void OnDisable()=>Application.logMessageReceived-=Error;
        void Error(string message,string trace,LogType type)
        {if(type!=LogType.Exception)return;if(output!=null)File.WriteAllText(Path.Combine(output,"failure.txt"),message+"\n"+trace);Application.Quit(1);}
        Button Find(string name)=>game.UI.GetComponentsInChildren<Button>().Where(b=>b.name==name&&b.gameObject.activeInHierarchy).OrderByDescending(b=>b.GetComponentInParent<Canvas>().sortingOrder).FirstOrDefault();
        static Rect Bounds(RectTransform r){var v=new Vector3[4];r.GetWorldCorners(v);return Rect.MinMaxRect(v[0].x,v[0].y,v[2].x,v[2].y);}
        IEnumerator Tap(Button button)
        {
            Require(button!=null,"Missing pointer target");Require(button.interactable,"Disabled target: "+button.name);
            string targetName=button.name;var rect=(RectTransform)button.transform;var scroll=button.GetComponentInParent<ScrollRect>();
            if(scroll!=null)
            {
                Canvas.ForceUpdateCanvases();float delta=Bounds(scroll.viewport).center.y-Bounds(rect).center.y;
                var scale=button.GetComponentInParent<Canvas>().scaleFactor;var p=scroll.content.anchoredPosition;p.y=Mathf.Clamp(p.y+delta/scale,0,Mathf.Max(0,scroll.content.rect.height-scroll.viewport.rect.height));scroll.content.anchoredPosition=p;
                yield return null;yield return null;
                // Scrolling a pooled list can recycle the original button into another tier.
                button=Find(targetName);Require(button!=null,"Recycled target disappeared: "+targetName);rect=(RectTransform)button.transform;
            }
            // Keep an explicitly scoped target: stacked content windows share the close-button name.
            yield return new WaitForEndOfFrame();if(button==null||!button.gameObject.activeInHierarchy)button=Find(targetName);Require(button!=null,"Pointer target disappeared: "+targetName);rect=(RectTransform)button.transform;Canvas.ForceUpdateCanvases();
            var pointer=new PointerEventData(EventSystem.current){position=RectTransformUtility.WorldToScreenPoint(null,rect.TransformPoint(rect.rect.center)),button=PointerEventData.InputButton.Left};var hits=new List<RaycastResult>();EventSystem.current.RaycastAll(pointer,hits);
            bool reachable=hits.Count>0&&hits[0].gameObject.GetComponentInParent<Button>()==button;
            if(!reachable)yield return Capture("blocked-"+targetName);
            Require(reachable,"Pointer blocked: "+button.name+" position="+pointer.position+" hits="+string.Join(",",hits.Take(5).Select(h=>h.gameObject.name)));
            ExecuteEvents.Execute(button.gameObject,pointer,ExecuteEvents.pointerDownHandler);ExecuteEvents.Execute(button.gameObject,pointer,ExecuteEvents.pointerUpHandler);ExecuteEvents.Execute(button.gameObject,pointer,ExecuteEvents.pointerClickHandler);
            yield return null;yield return null;
        }
        IEnumerator Tap(string name)=>Tap(Find(name));
        ContentWindowView Top()=>game.UI.GetComponentsInChildren<ContentWindowView>().OrderByDescending(v=>v.GetComponent<Canvas>().sortingOrder).First();
        IEnumerator ClosePopup()=>Tap(Top().GetComponentsInChildren<Button>().Single(b=>b.name=="content-close"));
        IEnumerator Capture(string name)
        {Canvas.ForceUpdateCanvases();yield return new WaitForEndOfFrame();var texture=ScreenCapture.CaptureScreenshotAsTexture();File.WriteAllBytes(Path.Combine(output,name+".png"),texture.EncodeToPNG());Destroy(texture);}
        IEnumerator Resize(int w,int h,string language,int scale)
        {
            game.ApplyLanguage(language);game.InterfaceScale.Apply(scale);game.UI.ApplyInterfaceScale();Screen.SetResolution(w,h,FullScreenMode.Windowed);float until=Time.realtimeSinceStartup+8;
            while((Screen.width!=w||Screen.height!=h)&&Time.realtimeSinceStartup<until)yield return null;Require(Screen.width==w&&Screen.height==h,"Resolution mismatch");yield return new WaitForSecondsRealtime(.3f);
        }
        void ClearThrough(int stage)
        {
            game.Store.Data.Hero.highestClear=stage;ContentUnlocks.Reconcile(game.Store.Data);Require(game.Store.Save(),game.Store.Error);
        }
        void WalkTo(TownStation station)
        {
            game.Town.Request(station);for(int n=0;n<2000&&game.Town.Nearby!=station;n++)game.Town.Tick(.05f);
            Require(game.Town.Nearby==station,"Town fixture failed to reach "+station);game.UI.RefreshPlaza();
        }
        bool HasText(string value)=>game.UI.GetComponentsInChildren<Text>().Any(t=>t.text.Contains(value));
        IEnumerator CloseWindows(){while(game.UI.GetComponentsInChildren<ContentWindowView>().Length>0)yield return ClosePopup();}
        IEnumerator Start()
        {
            var args=Environment.GetCommandLineArgs();int save=Array.IndexOf(args,"-hellscriptSavePath");
            for(int i=0;i<args.Length-1;i++)if(args[i]=="-hellscriptEvidencePath")output=args[i+1];
            Require(output!=null&&save>=0,"Isolated save and evidence paths required");Directory.CreateDirectory(output);
            yield return null;game=FindAnyObjectByType<GameController>();Require(game?.Store!=null,"Missing runtime store");
            game.EnterPlaza(true);var a=game.Store.Data;a.guide.hintsHidden=true;
            game.Begin(seed:20262261);yield return null;game.Combat.State.paused=true;
            Require(game.Combat.State.layout.introductory&&game.Combat.State.layout.spawns.Count==59,"Native entry did not use the introductory map");
            yield return Capture("introductory-rift-native");game.Combat.Abandon();game.ReturnTown();yield return null;
            checks.Add("PASS native entry: actual R1 map with 55 normals and four elites. This is a UI fixture; continuous natural play is measured separately.");
            a.gold=100000;a.enhancementStones=1000;
            Require(ContentUnlocks.Rules.features.Where(f=>f.stage>0).All(f=>!ContentUnlocks.Has(a,f.id)),"Fresh account opened growth services");
            yield return Resize(440,956,"ko",100);ClearThrough(4);WalkTo(TownStation.Blacksmith);game.UI.ShowBlacksmith(1);yield return null;
            Require(Find("forge-slot-start")==null,"Locked slot service exposes an action");Require(HasText(ContentUnlocks.Condition(ContentUnlocks.SlotEnhance)),"Missing locked slot condition");yield return Capture("slot-locked-r4");
            ClearThrough(5);game.UI.BlacksmithPanel.Repaint();yield return null;int stones=a.enhancementStones;
            yield return Tap("forge-slot-start");Require(a.forge.jobs.Count==1&&a.enhancementStones<stones,"Unlocked slot action did not commit");
            checks.Add("PASS pointer: R4 slot service locked -> R5 job starts and stones are deducted exactly once.");game.UI.CloseBlacksmith();yield return null;
            ClearThrough(9);game.SelectedStage=10;game.UI.ShowRiftKeeper();yield return null;yield return Tap("rift-first-rewards");yield return Tap("rift-reward-tier-10");
            Require(HasText(Loc.T("이 단계에서 열리는 콘텐츠"))&&HasText(Loc.T("클리어 후 개방")),"R10 detail missing locked content guidance");yield return Capture("gem-unlock-r10-before");
            ClearThrough(10);Top().Repaint();yield return null;Require(HasText(Loc.T("개방됨")),"R10 did not reflect auto-unlock");Require(a.rewardBoxes.claimedStages.Count==0,"Unlock should not claim boxes");
            checks.Add("PASS R10 detail reflects account auto-unlock without claiming any reward box.");yield return CloseWindows();
            foreach(int milestone in new[]{25,30,35})
            {
                ClearThrough(milestone-1);game.SelectedStage=milestone;game.UI.ShowRiftKeeper();yield return null;
                yield return Tap("rift-first-rewards");yield return Tap("rift-reward-tier-"+milestone);
                if(milestone==30)Require(HasText(RewardBoxCatalog.Find("legendary-weapon").Name),"R30 legendary box missing");
                else Require(HasText(Loc.T(milestone==25?"미확인 장비 상점":"옵션 재설정"))&&HasText(Loc.T("클리어 후 개방")),"Missing boundary unlock notice");
                yield return Capture("boundary-before-"+milestone);ClearThrough(milestone);Top().Repaint();yield return null;
                if(milestone!=30)Require(HasText(Loc.T("개방됨")),"Boundary did not unlock");
                checks.Add("PASS pointer: first-clear detail and boundary transition R"+milestone);yield return CloseWindows();
            }
            foreach(int stage in new[]{29,30})
            {
                game.SelectedStage=stage;game.UI.ShowRiftRewards();yield return null;
                Require(HasText(Loc.F("균열 전설·세트 장비는 {0}단계부터 획득할 수 있습니다. 이전 단계에서는 확률이 0%입니다.",30)),"Missing rarity gate notice");
                yield return Capture("rarity-"+stage);
            }
            game.UI.ShowTown();ClearThrough(59);
            foreach(var size in new[]{new[]{440,956},new[]{956,440},new[]{1600,900},new[]{1600,1000},new[]{2100,900}})
            foreach(string language in new[]{"ko","en"})foreach(int scale in new[]{100,150})
            {
                yield return Resize(size[0],size[1],language,scale);int milestone=size[0]==440?30:size[0]==956?35:25;game.SelectedStage=milestone;game.UI.ShowRiftKeeper();yield return null;yield return Tap("rift-first-rewards");
                var list=FindAnyObjectByType<RiftRewardList>();Require(list!=null&&list.RowPoolCount<30,"Rift list is not pooled");
                var row=Find("rift-reward-tier-"+milestone);Require(row!=null,"Milestone list row missing");
                var unlock=row.GetComponentsInChildren<Text>().Single(t=>t.name=="Rift content unlock");Require(unlock.text.Contains(Loc.T(milestone==30?"전설·세트 장비 획득 시작":milestone==25?"미확인 장비 상점":"옵션 재설정")),"List does not show the milestone");
                Require(unlock.preferredHeight<=unlock.rectTransform.rect.height+2,"Truncated unlock list text "+language+" "+scale);
                if(size[0]==440&&language=="ko"&&scale==100)yield return Capture("unlock-list-440-ko");
                yield return Tap("rift-reward-tier-"+milestone);var view=Top();Canvas.ForceUpdateCanvases();var frame=Bounds(view.Frame);
                Require(HasText(milestone==30?RewardBoxCatalog.Find("legendary-weapon").Name:Loc.T(milestone==25?"미확인 장비 상점":"옵션 재설정")),"Missing milestone");
                foreach(var text in view.GetComponentsInChildren<Text>().Where(t=>t.name=="Reward box text"))Require(text.preferredHeight<=text.rectTransform.rect.height+2,"Truncated milestone text "+text.text);
                foreach(string name in new[]{"reward-box-claim-"+milestone,"reward-box-inventory"})
                {var rect=Bounds((RectTransform)Find(name).transform);Require(frame.Contains(rect.min+Vector2.one)&&frame.Contains(rect.max-Vector2.one),"Footer escaped safe area");}
                Require(Loc.MissingCount==0,"Missing translations: "+string.Join(";",Loc.Missing));
                if(size[0]==440&&language=="ko"&&scale==100||size[0]==956&&language=="en"&&scale==150)yield return Capture($"unlock-detail-{size[0]}-{language}-{scale}");
                checks.Add($"PASS first-clear list and unlock detail R{milestone} {size[0]}x{size[1]} {language} {scale}%");yield return CloseWindows();
            }
            yield return Resize(440,956,"ko",100);WalkTo(TownStation.GemMerchant);GemInventory.Add(a,new GemStack{gemId="G03",tier=1,count=2});game.UI.ShowTownGemShop();yield return null;
            Require(!Find("jeweler-craft").interactable,"R59 elixir crafting enabled");Require(HasText(ContentUnlocks.Condition(ContentUnlocks.Elixir))||Find("jeweler-nav-potions")!=null,"Missing elixir gate");
            ClearThrough(60);game.UI.JewelerPanel.Repaint();yield return null;yield return Tap("jeweler-craft");Require(GemStacks.Count(a.gems,"G03",1)==1&&a.Hero.potions.Count(GemElixirs.Id("G03",1))==1,"R60 potion craft failed");
            checks.Add("PASS pointer: R59 potion craft disabled -> R60 crafting consumes one gem and grants one potion.");game.UI.CloseJeweler();yield return null;
            ClearThrough(120);a.selectedHero=1;Require(ContentUnlocks.Has(a,ContentUnlocks.CoreCraft),"Account unlock lost on hero switch");Require(game.Store.Save(),game.Store.Error);
            var loaded=new GameStore(args[save+1],game.catalog);Require(loaded.Data.contentUnlocks.version==ContentUnlocks.Version&&ContentUnlocks.Has(loaded.Data,ContentUnlocks.CoreCraft),"Unlock did not survive reload");Require(a.rewardBoxes.claimedStages.Count==0,"Unexpected box claim");
            checks.Add("PASS cross-hero access and save/reload; no first-clear reward claimed by unlock flow.");
            File.WriteAllLines(Path.Combine(output,"runtime.txt"),checks);Debug.Log("HELLSCRIPT_RIFT_UNLOCK_RUNTIME_OK");Application.Quit(0);
        }
    }
}
