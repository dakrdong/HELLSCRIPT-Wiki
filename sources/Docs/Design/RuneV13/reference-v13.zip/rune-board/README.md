# HELLSCRIPT 룬 보드 v13 — 공개 UI 시안

- `index.html`: 가로·세로 자동 전환
- `landscape.html`: 가로형
- `portrait.html`: 세로형

세 HTML은 승인된 v13 원본의 파일명만 바꾼 복사본입니다. 이미지, 스타일, 스크립트는 HTML에 포함되어 있으며 별도 설치나 빌드가 필요하지 않습니다.

## 게시

이 `rune-board` 폴더를 GitHub `dakrdong/HELLSCRIPT-Wiki` 저장소의 `main` 루트에 추가하세요. 기존 루트 `index.html`, 위키 파일, 배포 설정은 변경하지 않습니다.

GitHub Pages 배포가 성공하면 다음 경로에서 열 수 있습니다.

- https://dakrdong.github.io/HELLSCRIPT-Wiki/rune-board/
- https://dakrdong.github.io/HELLSCRIPT-Wiki/rune-board/landscape.html
- https://dakrdong.github.io/HELLSCRIPT-Wiki/rune-board/portrait.html

이 ZIP을 만드는 시점에는 GitHub 연결의 파일 쓰기가 403으로 거절되어 커밋이나 배포를 수행하지 못했습니다. 위 주소는 배포 후 예상 주소이며 현재 공개 완료를 의미하지 않습니다.

## 주의

위키를 다시 내보낼 때 이 폴더가 삭제되지 않도록 보존하세요. 시연 데이터와 브라우저 저장소를 사용하는 프로토타입이며 실제 계정·전투·인벤토리·창고에 연결되지 않습니다. 기존 로컬 파일의 편집을 옮길 때는 JSON 내보내기/불러오기를 사용하세요.

공개 대상은 이 HTML과 설명 파일뿐이며, 대화 내용이나 다른 프로젝트 자료를 포함하지 않습니다.
